/*
Navicat MySQL Data Transfer

Source Server         : test_3306
Source Server Version : 50725
Source Host           : 192.168.0.59:3306
Source Database       : oam

Target Server Type    : MYSQL
Target Server Version : 50725
File Encoding         : 65001

Date: 2019-05-10 14:44:00
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for c_authority
-- ----------------------------
DROP TABLE IF EXISTS `c_authority`;
CREATE TABLE `c_authority` (
  `id` varchar(32) NOT NULL,
  `sort` bigint(20) NOT NULL AUTO_INCREMENT,
  `auth_code` varchar(50) NOT NULL,
  `auth_text` varchar(50) NOT NULL,
  `auth_order` int(11) DEFAULT NULL,
  `auth_type` smallint(6) DEFAULT NULL,
  `resoureces_url` varchar(255) DEFAULT NULL,
  `flag` smallint(6) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `parent_id` varchar(32) DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `authority_sort_key` (`sort`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of c_authority
-- ----------------------------
INSERT INTO `c_authority` VALUES ('06cc6be614f211e7b61c507b9dae4454', '45', 'deleteSysLogs', '删除系统日志', '3', '2', '/sysLogsController/deleteSysLogs.do', '1', '', 'ca94dc3414f111e7b61c507b9dae4454', '2017-03-30 10:38:59', '2017-03-30 10:38:59');
INSERT INTO `c_authority` VALUES ('075cef3db14411e68bc4507b9dae4454', '25', 'getDictList', '查询数字字典列表', '1', '1', '/dictController/getPageData.do', '0', '', 'f34538adb14311e68bc4507b9dae4454', '2016-11-23 14:14:03', null);
INSERT INTO `c_authority` VALUES ('144B2E062AFE407B80FFE11494353EA2', '31', 'zonePathManage', '文件路径管理', '7', '1', '/zonePathController/viewPage.do', '1', '', '3b5ea9dcb11d11e68bc4507b9dae4454', '2016-09-01 14:26:20', null);
INSERT INTO `c_authority` VALUES ('1f97c4a2b14411e68bc4507b9dae4454', '26', 'skipAddDict', '跳转添加数字字典', '2', '2', '/dictController/skipAddDict.do', '1', '', 'f34538adb14311e68bc4507b9dae4454', '2016-11-23 14:14:43', null);
INSERT INTO `c_authority` VALUES ('20db6022b12311e68bc4507b9dae4454', '19', 'getUserDetail', '查询用户详细', '4', '2', '/userController/getDetail.do', '1', '', 'ad2f2ee6b12011e68bc4507b9dae4454', '2016-11-23 10:18:32', null);
INSERT INTO `c_authority` VALUES ('32ca861bb12011e68bc4507b9dae4454', '8', 'roleManage', '角色管理', '4', '1', '/roleController/viewPage.do', '1', '', '3b5ea9dcb11d11e68bc4507b9dae4454', '2016-11-23 09:57:33', null);
INSERT INTO `c_authority` VALUES ('33C22D17058648ADA85169ACC6D0FE82', '32', 'editZonePath', '修改文件路径', '5', '2', '/zonePathController/editZonePath.do', '1', '', '144B2E062AFE407B80FFE11494353EA2', '2016-09-01 14:29:39', null);
INSERT INTO `c_authority` VALUES ('3680f6afb12411e68bc4507b9dae4454', '23', 'siteIndex', '网站主页', '1', '1', '/index.do', '0', '', null, '2016-11-23 10:26:17', null);
INSERT INTO `c_authority` VALUES ('3875e4feb14411e68bc4507b9dae4454', '27', 'addDict', '添加数字字典', '3', '2', '/dictController/addDict.do', '1', '', 'f34538adb14311e68bc4507b9dae4454', '2016-11-23 14:15:25', null);
INSERT INTO `c_authority` VALUES ('3b5ea9dcb11d11e68bc4507b9dae4454', '1', 'systemManage', '系统管理', '500', '0', null, '1', '&#xe61d;', null, '2016-11-23 09:36:19', null);
INSERT INTO `c_authority` VALUES ('474011dfb12211e68bc4507b9dae4454', '18', 'addUser', '添加用户', '3', '2', '/userController/addUser.do', '1', '', 'ad2f2ee6b12011e68bc4507b9dae4454', '2016-11-23 10:12:27', null);
INSERT INTO `c_authority` VALUES ('4ad0e0dcb11f11e68bc4507b9dae4454', '4', 'skipAddAuth', '跳转添加权限', '2', '2', '/authController/skipAddAuth.do', '1', '', 'dd77e2b2b11e11e68bc4507b9dae4454', '2016-11-23 09:51:04', null);
INSERT INTO `c_authority` VALUES ('523b0a82b12011e68bc4507b9dae4454', '9', 'getRoleList', '查询角色列表', '1', '1', '/roleController/getPageData.do', '0', '', '32ca861bb12011e68bc4507b9dae4454', '2016-11-23 09:58:26', null);
INSERT INTO `c_authority` VALUES ('55bc7521b14411e68bc4507b9dae4454', '28', 'getDictDetail', '查询数字字典', '4', '2', '/dictController/getDetail.do', '1', '', 'f34538adb14311e68bc4507b9dae4454', '2016-11-23 14:16:14', null);
INSERT INTO `c_authority` VALUES ('56d9467ab11f11e68bc4507b9dae4454', '5', 'addAuth', '添加权限', '3', '2', '/authController/addAuth.do', '1', '', 'dd77e2b2b11e11e68bc4507b9dae4454', '2016-11-23 09:51:24', null);
INSERT INTO `c_authority` VALUES ('61ac9dceb12011e68bc4507b9dae4454', '10', 'skipAddRole', '跳转添加角色', '2', '2', '/roleController/skipAddRole.do', '1', '', '32ca861bb12011e68bc4507b9dae4454', '2016-11-23 09:58:52', null);
INSERT INTO `c_authority` VALUES ('627ad9f9b14411e68bc4507b9dae4454', '29', 'editDict', '修改数字字典', '5', '2', '/dictController/editDict.do', '1', '', 'f34538adb14311e68bc4507b9dae4454', '2016-11-23 14:16:36', null);
INSERT INTO `c_authority` VALUES ('69a17420b12311e68bc4507b9dae4454', '20', 'editUser', '修改用户', '5', '2', '/userController/editUser.do', '1', '', 'ad2f2ee6b12011e68bc4507b9dae4454', '2016-11-23 10:20:34', null);
INSERT INTO `c_authority` VALUES ('6a8efaf8b11f11e68bc4507b9dae4454', '6', 'getAuthDetail', '查询权限详情', '4', '2', '/authController/getDetail.do', '1', '', 'dd77e2b2b11e11e68bc4507b9dae4454', '2016-11-23 09:51:57', null);
INSERT INTO `c_authority` VALUES ('704da868b14411e68bc4507b9dae4454', '30', 'delDict', '删除数字字典', '6', '2', '/dictController/delDict.do', '1', '', 'f34538adb14311e68bc4507b9dae4454', '2016-11-23 14:16:59', null);
INSERT INTO `c_authority` VALUES ('73A67F3C1367404ABBB67D0E111A7366', '33', 'skipAddZonePath', '跳转添加文件路径', '2', '2', '/zonePathController/skipAddZonePath.do', '1', '', '144B2E062AFE407B80FFE11494353EA2', '2016-09-01 14:27:49', null);
INSERT INTO `c_authority` VALUES ('74faf7e3b12011e68bc4507b9dae4454', '11', 'addRole', '添加角色', '3', '2', '/roleController/addRole.do', '1', '', '32ca861bb12011e68bc4507b9dae4454', '2016-11-23 09:59:24', null);
INSERT INTO `c_authority` VALUES ('77f188fab11f11e68bc4507b9dae4454', '7', 'delAuth', '删除权限', '5', '2', '/authController/delAuth.do', '1', '', 'dd77e2b2b11e11e68bc4507b9dae4454', '2016-11-23 09:52:20', null);
INSERT INTO `c_authority` VALUES ('86C6BA4D08DF4086ABD89CD7C86C5DD6', '34', 'createFileDirectory', '创建物理目录', '7', '2', '/zonePathController/createFileDirectory.do', '1', '', '144B2E062AFE407B80FFE11494353EA2', '2016-09-01 14:32:19', null);
INSERT INTO `c_authority` VALUES ('8a2ced2db12011e68bc4507b9dae4454', '12', 'getRoleDetail', '查询角色详细', '4', '2', '/roleController/viewPage.do', '1', '', '32ca861bb12011e68bc4507b9dae4454', '2016-11-23 10:00:00', null);
INSERT INTO `c_authority` VALUES ('8e237443184511e8bce8507b9dae4454', '47', 'OA', 'OAM', '3', '0', null, '0', '', null, '2018-02-23 10:59:25', '2018-02-23 10:59:25');
INSERT INTO `c_authority` VALUES ('94CEF3D7561F45E4A38E7C5E86A9DF52', '39', 'loginLogManage', '登录日志管理', '6', '1', '/loginLogController/viewPage.do', '1', '', '3b5ea9dcb11d11e68bc4507b9dae4454', '2016-08-31 11:26:37', null);
INSERT INTO `c_authority` VALUES ('96f55f60b12011e68bc4507b9dae4454', '13', 'editRole', '修改角色', '5', '2', '/roleController/editRole.do', '1', '', '32ca861bb12011e68bc4507b9dae4454', '2016-11-23 10:00:21', null);
INSERT INTO `c_authority` VALUES ('a105be76184511e8bce8507b9dae4454', '48', 'fwbl', '发文办理', '1', '1', '/fwblController/**', '0', '', '8e237443184511e8bce8507b9dae4454', '2018-02-23 10:59:57', '2018-02-23 10:59:57');
INSERT INTO `c_authority` VALUES ('a27f75b4b12011e68bc4507b9dae4454', '14', 'delRole', '删除角色', '6', '2', '/roleController/delRole.do', '1', '', '32ca861bb12011e68bc4507b9dae4454', '2016-11-23 10:00:41', null);
INSERT INTO `c_authority` VALUES ('A485D461507C4C20846944B9EC66D507', '35', 'getZonePathList', '查询文件路径列表', '1', '1', '/zonePathController/getPageData.do', '0', '', '144B2E062AFE407B80FFE11494353EA2', '2016-09-01 14:27:17', null);
INSERT INTO `c_authority` VALUES ('ad2f2ee6b12011e68bc4507b9dae4454', '15', 'userManage', '用户管理', '1', '1', '/userController/viewPage.do', '1', '', '3b5ea9dcb11d11e68bc4507b9dae4454', '2016-11-23 10:00:59', null);
INSERT INTO `c_authority` VALUES ('b042c01a184511e8bce8507b9dae4454', '49', 'fwdj', '发文登记', '2', '1', '/fwdjController/**', '0', '', '8e237443184511e8bce8507b9dae4454', '2018-02-23 11:00:23', '2018-02-23 11:00:23');
INSERT INTO `c_authority` VALUES ('b5b408c9b12311e68bc4507b9dae4454', '21', 'changePassword', '管理员修改密码', '6', '2', '/userController/changePassword.do', '1', '', 'ad2f2ee6b12011e68bc4507b9dae4454', '2016-11-23 10:22:41', null);
INSERT INTO `c_authority` VALUES ('BE67B42B4F4C42258431DF0FCCB8BF1B', '40', 'getloginLogList', '查询登录日志列表', '1', '1', '/loginLogController/getPageData.do', '0', '', '94CEF3D7561F45E4A38E7C5E86A9DF52', '2016-08-31 11:30:26', null);
INSERT INTO `c_authority` VALUES ('c34baa22184511e8bce8507b9dae4454', '50', 'swbl', '收文办理', '3', '1', '/swblController/**', '0', '', '8e237443184511e8bce8507b9dae4454', '2018-02-23 11:00:55', '2018-02-23 11:00:55');
INSERT INTO `c_authority` VALUES ('c39858afb12311e68bc4507b9dae4454', '22', 'deleteUser', '删除用户', '7', '2', '/userController/deleteUser.do', '1', '', 'ad2f2ee6b12011e68bc4507b9dae4454', '2016-11-23 10:23:05', null);
INSERT INTO `c_authority` VALUES ('c9bd3c4eb12111e68bc4507b9dae4454', '16', 'getUserList', '查询用户列表', '1', '1', '/userController/getPageData.do', '0', '', 'ad2f2ee6b12011e68bc4507b9dae4454', '2016-11-23 10:08:56', null);
INSERT INTO `c_authority` VALUES ('ca94dc3414f111e7b61c507b9dae4454', '42', 'sysLogsManage', '系统日志管理', '8', '0', '/sysLogsController/viewPage.do', '1', '', '3b5ea9dcb11d11e68bc4507b9dae4454', '2017-03-30 10:37:18', '2017-03-30 10:37:18');
INSERT INTO `c_authority` VALUES ('d0e1ba22184511e8bce8507b9dae4454', '51', 'swdj', '收文登记', '4', '1', '/swdjController/**', '0', '', '8e237443184511e8bce8507b9dae4454', '2018-02-23 11:01:17', '2018-02-23 11:01:17');
INSERT INTO `c_authority` VALUES ('D610CAB377F2475886011AED0BC04306', '36', 'delZonePath', '删除文件路径', '6', '2', '/zonePathController/delZonePath.do', '1', '', '144B2E062AFE407B80FFE11494353EA2', '2016-09-01 14:31:28', null);
INSERT INTO `c_authority` VALUES ('D7A6DB3FD72C4F97A00DAC91E32541A5', '37', 'getZonePathDetail', '查询文件路径详细', '4', '2', '/zonePathController/getDetail.do', '1', '', '144B2E062AFE407B80FFE11494353EA2', '2016-09-01 14:29:12', null);
INSERT INTO `c_authority` VALUES ('dd77e2b2b11e11e68bc4507b9dae4454', '2', 'authManage', '权限管理', '5', '1', '/authController/viewPage.do', '1', '', '3b5ea9dcb11d11e68bc4507b9dae4454', '2016-11-23 09:48:01', null);
INSERT INTO `c_authority` VALUES ('e1528e3014f111e7b61c507b9dae4454', '43', 'getSysLogsData', '查询系统日志列表', '1', '1', '/sysLogsController/getPageData.do', '0', '', 'ca94dc3414f111e7b61c507b9dae4454', '2017-03-30 10:37:56', '2017-03-30 10:37:56');
INSERT INTO `c_authority` VALUES ('e3d81f31b12111e68bc4507b9dae4454', '17', 'skipAddUser', '跳转添加用户', '2', '2', '/userController/skipAddUser.do', '1', '', 'ad2f2ee6b12011e68bc4507b9dae4454', '2016-11-23 10:09:40', null);
INSERT INTO `c_authority` VALUES ('e9be1f7416e511e7aff900163e06a512', '46', 'editAuth', '修改权限', '5', '2', '/authController/editAuth.do', '1', '', 'dd77e2b2b11e11e68bc4507b9dae4454', '2017-04-01 22:17:19', '2017-04-01 22:17:19');
INSERT INTO `c_authority` VALUES ('f34538adb14311e68bc4507b9dae4454', '24', 'dictManage', '数字字典管理', '6', '1', '/dictController/viewPage.do', '1', '', '3b5ea9dcb11d11e68bc4507b9dae4454', '2016-11-23 14:13:29', null);
INSERT INTO `c_authority` VALUES ('f5120428184511e8bce8507b9dae4454', '52', 'goldGeOffice', '在线拟稿', '5', '1', '/officeController/**', '0', '', '8e237443184511e8bce8507b9dae4454', '2018-02-23 11:02:18', '2018-02-23 11:02:18');
INSERT INTO `c_authority` VALUES ('f98cc659b11e11e68bc4507b9dae4454', '3', 'getAuthList', '查询权限列表', '1', '1', '/authController/getPageData.do', '0', '', 'dd77e2b2b11e11e68bc4507b9dae4454', '2016-11-23 09:48:48', null);
INSERT INTO `c_authority` VALUES ('FD1EB0BA0AB749C2AA400D225BF1C908', '41', 'delLoginLog', '删除登录日志', '2', '2', '/loginLogController/delLoginLog.do', '1', '', '94CEF3D7561F45E4A38E7C5E86A9DF52', '2016-08-31 11:31:01', null);
INSERT INTO `c_authority` VALUES ('FF8D15F2F35340EABA64439982E033C6', '38', 'addZonePath', '添加文件路径', '3', '2', '/zonePathController/addZonePath.do', '1', '', '144B2E062AFE407B80FFE11494353EA2', '2016-09-01 14:28:16', null);

-- ----------------------------
-- Table structure for c_authority_role
-- ----------------------------
DROP TABLE IF EXISTS `c_authority_role`;
CREATE TABLE `c_authority_role` (
  `role_id` varchar(32) NOT NULL,
  `auth_id` varchar(32) NOT NULL,
  PRIMARY KEY (`auth_id`,`role_id`),
  KEY `FK_i7kop6y8ut3p0cs08l1f7m0dg` (`auth_id`) USING BTREE,
  KEY `FK_5kj1hdc1bi0or8skfwh2fvvci` (`role_id`) USING BTREE,
  CONSTRAINT `c_authority_role_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `c_role` (`id`),
  CONSTRAINT `c_authority_role_ibfk_2` FOREIGN KEY (`auth_id`) REFERENCES `c_authority` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of c_authority_role
-- ----------------------------
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '06cc6be614f211e7b61c507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '075cef3db14411e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '144B2E062AFE407B80FFE11494353EA2');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '1f97c4a2b14411e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '20db6022b12311e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '32ca861bb12011e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '33C22D17058648ADA85169ACC6D0FE82');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '3680f6afb12411e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '3875e4feb14411e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '3b5ea9dcb11d11e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '474011dfb12211e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '4ad0e0dcb11f11e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '523b0a82b12011e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '55bc7521b14411e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '56d9467ab11f11e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '61ac9dceb12011e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '627ad9f9b14411e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '69a17420b12311e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '6a8efaf8b11f11e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '704da868b14411e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '73A67F3C1367404ABBB67D0E111A7366');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '74faf7e3b12011e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '77f188fab11f11e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '86C6BA4D08DF4086ABD89CD7C86C5DD6');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '8a2ced2db12011e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '8e237443184511e8bce8507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '94CEF3D7561F45E4A38E7C5E86A9DF52');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '96f55f60b12011e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'a105be76184511e8bce8507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'a27f75b4b12011e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'A485D461507C4C20846944B9EC66D507');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'ad2f2ee6b12011e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'b042c01a184511e8bce8507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'b5b408c9b12311e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'BE67B42B4F4C42258431DF0FCCB8BF1B');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'c34baa22184511e8bce8507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'c39858afb12311e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'c9bd3c4eb12111e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'ca94dc3414f111e7b61c507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'd0e1ba22184511e8bce8507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'D610CAB377F2475886011AED0BC04306');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'D7A6DB3FD72C4F97A00DAC91E32541A5');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'dd77e2b2b11e11e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'e1528e3014f111e7b61c507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'e3d81f31b12111e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'e9be1f7416e511e7aff900163e06a512');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'f34538adb14311e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'f5120428184511e8bce8507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'f98cc659b11e11e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'FD1EB0BA0AB749C2AA400D225BF1C908');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'FF8D15F2F35340EABA64439982E033C6');

-- ----------------------------
-- Table structure for c_basedict
-- ----------------------------
DROP TABLE IF EXISTS `c_basedict`;
CREATE TABLE `c_basedict` (
  `id` varchar(32) NOT NULL,
  `sort` bigint(20) NOT NULL AUTO_INCREMENT,
  `dict_item` varchar(255) NOT NULL,
  `dict_type` varchar(255) NOT NULL,
  `dict_value` varchar(255) NOT NULL,
  `dict_flag` int(11) NOT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `dict_sort_key` (`sort`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of c_basedict
-- ----------------------------
INSERT INTO `c_basedict` VALUES ('031f6099079711e6aa01507b9dae4454', '2', '正常', 'auth_flag', '0', '1', null, '2016-03-29 12:09:53');
INSERT INTO `c_basedict` VALUES ('031f6102079711e6aa01507b9dae4454', '3', '控制', 'auth_flag', '1', '1', null, '2016-02-29 15:09:19');
INSERT INTO `c_basedict` VALUES ('031f6186079711e6aa01507b9dae4454', '4', '菜单', 'auth_type', '0', '1', null, '2016-02-29 15:10:01');
INSERT INTO `c_basedict` VALUES ('031f6220079711e6aa01507b9dae4454', '5', '访问', 'auth_type', '1', '1', null, '2016-02-29 15:10:16');
INSERT INTO `c_basedict` VALUES ('031f62ba079711e6aa01507b9dae4454', '8', '按钮', 'auth_type', '2', '1', null, '2016-03-03 11:58:39');
INSERT INTO `c_basedict` VALUES ('12cd43d6c1cb11e6b57b507b9dae4454', '67', '后端', 'role_type', '0', '1', null, '2016-12-14 15:01:03');
INSERT INTO `c_basedict` VALUES ('179f18d2c1cb11e6b57b507b9dae4454', '68', '前端', 'role_type', '1', '1', null, '2016-12-14 15:01:11');
INSERT INTO `c_basedict` VALUES ('CA1ABCED526C47A7827DBA07D22DE9D2', '43', '临时文件', 'file_type', 'tempFile', '1', null, '2016-09-27 17:13:54');
INSERT INTO `c_basedict` VALUES ('F21CB370ADF0487B9E7ECB62697DCAEE', '52', '普通文件', 'file_type', 'commomFile', '1', null, '2016-09-01 14:12:54');

-- ----------------------------
-- Table structure for c_login_log
-- ----------------------------
DROP TABLE IF EXISTS `c_login_log`;
CREATE TABLE `c_login_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(32) DEFAULT NULL,
  `user_name` varchar(50) NOT NULL,
  `login_ip` bigint(20) NOT NULL,
  `log_details` varchar(255) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2262 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of c_login_log
-- ----------------------------
INSERT INTO `c_login_log` VALUES ('1375', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-20 16:19:22', '2017-03-20 16:19:22');
INSERT INTO `c_login_log` VALUES ('1376', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-20 16:20:37', '2017-03-20 16:20:37');
INSERT INTO `c_login_log` VALUES ('1377', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-21 17:27:18', '2017-03-21 17:27:18');
INSERT INTO `c_login_log` VALUES ('1378', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-21 18:00:32', '2017-03-21 18:00:32');
INSERT INTO `c_login_log` VALUES ('1379', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-21 18:01:53', '2017-03-21 18:01:53');
INSERT INTO `c_login_log` VALUES ('1380', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-21 18:02:39', '2017-03-21 18:02:39');
INSERT INTO `c_login_log` VALUES ('1381', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-21 18:06:44', '2017-03-21 18:06:44');
INSERT INTO `c_login_log` VALUES ('1382', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-21 18:12:58', '2017-03-21 18:12:58');
INSERT INTO `c_login_log` VALUES ('1383', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-22 10:11:55', '2017-03-22 10:11:55');
INSERT INTO `c_login_log` VALUES ('1384', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-22 10:15:47', '2017-03-22 10:15:47');
INSERT INTO `c_login_log` VALUES ('1385', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-22 10:19:22', '2017-03-22 10:19:22');
INSERT INTO `c_login_log` VALUES ('1386', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-22 12:34:30', '2017-03-22 12:34:30');
INSERT INTO `c_login_log` VALUES ('1387', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-22 17:39:07', '2017-03-22 17:39:07');
INSERT INTO `c_login_log` VALUES ('1388', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-22 18:14:12', '2017-03-22 18:14:12');
INSERT INTO `c_login_log` VALUES ('1389', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-22 18:14:41', '2017-03-22 18:14:41');
INSERT INTO `c_login_log` VALUES ('1390', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-23 09:08:55', '2017-03-23 09:08:55');
INSERT INTO `c_login_log` VALUES ('1391', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-23 09:09:44', '2017-03-23 09:09:44');
INSERT INTO `c_login_log` VALUES ('1392', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-23 09:10:34', '2017-03-23 09:10:34');
INSERT INTO `c_login_log` VALUES ('1393', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-23 09:15:14', '2017-03-23 09:15:14');
INSERT INTO `c_login_log` VALUES ('1394', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-23 09:19:08', '2017-03-23 09:19:08');
INSERT INTO `c_login_log` VALUES ('1395', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-27 09:26:39', '2017-03-27 09:26:39');
INSERT INTO `c_login_log` VALUES ('1396', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-27 09:28:19', '2017-03-27 09:28:19');
INSERT INTO `c_login_log` VALUES ('1397', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-27 09:32:21', '2017-03-27 09:32:21');
INSERT INTO `c_login_log` VALUES ('1398', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-27 09:33:59', '2017-03-27 09:33:59');
INSERT INTO `c_login_log` VALUES ('1399', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-27 09:44:55', '2017-03-27 09:44:55');
INSERT INTO `c_login_log` VALUES ('1400', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-27 10:19:01', '2017-03-27 10:19:01');
INSERT INTO `c_login_log` VALUES ('1401', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-27 10:21:48', '2017-03-27 10:21:48');
INSERT INTO `c_login_log` VALUES ('1402', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-27 10:26:03', '2017-03-27 10:26:03');
INSERT INTO `c_login_log` VALUES ('1403', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-27 10:39:32', '2017-03-27 10:39:32');
INSERT INTO `c_login_log` VALUES ('1404', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-27 10:45:56', '2017-03-27 10:45:56');
INSERT INTO `c_login_log` VALUES ('1405', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-27 10:48:14', '2017-03-27 10:48:14');
INSERT INTO `c_login_log` VALUES ('1406', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-27 10:52:07', '2017-03-27 10:52:07');
INSERT INTO `c_login_log` VALUES ('1407', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-27 11:20:24', '2017-03-27 11:20:24');
INSERT INTO `c_login_log` VALUES ('1408', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-28 08:47:34', '2017-03-28 08:47:34');
INSERT INTO `c_login_log` VALUES ('1409', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-28 08:47:58', '2017-03-28 08:47:58');
INSERT INTO `c_login_log` VALUES ('1410', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-28 08:48:29', '2017-03-28 08:48:29');
INSERT INTO `c_login_log` VALUES ('1411', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-28 08:49:18', '2017-03-28 08:49:18');
INSERT INTO `c_login_log` VALUES ('1412', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-28 08:51:06', '2017-03-28 08:51:06');
INSERT INTO `c_login_log` VALUES ('1413', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-28 08:57:27', '2017-03-28 08:57:27');
INSERT INTO `c_login_log` VALUES ('1414', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-28 09:19:21', '2017-03-28 09:19:21');
INSERT INTO `c_login_log` VALUES ('1415', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-29 10:39:57', '2017-03-29 10:39:57');
INSERT INTO `c_login_log` VALUES ('1416', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-29 11:21:01', '2017-03-29 11:21:01');
INSERT INTO `c_login_log` VALUES ('1417', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-29 15:29:59', '2017-03-29 15:29:59');
INSERT INTO `c_login_log` VALUES ('1418', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-30 10:36:02', '2017-03-30 10:36:02');
INSERT INTO `c_login_log` VALUES ('1419', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-30 10:40:29', '2017-03-30 10:40:29');
INSERT INTO `c_login_log` VALUES ('1420', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-30 10:51:15', '2017-03-30 10:51:15');
INSERT INTO `c_login_log` VALUES ('1421', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-30 10:52:08', '2017-03-30 10:52:08');
INSERT INTO `c_login_log` VALUES ('1422', null, 'admin', '2130706433', '用户成功登录系统', '2017-04-01 17:40:24', '2017-04-01 17:40:24');
INSERT INTO `c_login_log` VALUES ('1423', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-11 10:09:19', '2017-07-11 10:09:19');
INSERT INTO `c_login_log` VALUES ('1424', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-11 10:11:07', '2017-07-11 10:11:07');
INSERT INTO `c_login_log` VALUES ('1425', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-11 10:15:16', '2017-07-11 10:15:16');
INSERT INTO `c_login_log` VALUES ('1426', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-11 10:30:08', '2017-07-11 10:30:08');
INSERT INTO `c_login_log` VALUES ('1427', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-11 10:35:57', '2017-07-11 10:35:57');
INSERT INTO `c_login_log` VALUES ('1428', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-11 12:14:38', '2017-07-11 12:14:38');
INSERT INTO `c_login_log` VALUES ('1429', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-11 12:23:21', '2017-07-11 12:23:21');
INSERT INTO `c_login_log` VALUES ('1430', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-11 15:39:54', '2017-07-11 15:39:54');
INSERT INTO `c_login_log` VALUES ('1431', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-11 15:44:05', '2017-07-11 15:44:05');
INSERT INTO `c_login_log` VALUES ('1432', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-11 15:44:41', '2017-07-11 15:44:41');
INSERT INTO `c_login_log` VALUES ('1433', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-11 15:51:36', '2017-07-11 15:51:36');
INSERT INTO `c_login_log` VALUES ('1434', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-11 15:57:17', '2017-07-11 15:57:17');
INSERT INTO `c_login_log` VALUES ('1435', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-11 16:13:55', '2017-07-11 16:13:55');
INSERT INTO `c_login_log` VALUES ('1436', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-25 09:15:30', '2017-07-25 09:15:30');
INSERT INTO `c_login_log` VALUES ('1437', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-27 12:33:54', '2017-07-27 12:33:54');
INSERT INTO `c_login_log` VALUES ('1438', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-01 11:04:54', '2017-08-01 11:04:54');
INSERT INTO `c_login_log` VALUES ('1439', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-01 11:16:04', '2017-08-01 11:16:04');
INSERT INTO `c_login_log` VALUES ('1440', null, 'admin', '2130706433', '用户成功登录系统', '2018-01-19 15:12:52', '2018-01-19 15:12:52');
INSERT INTO `c_login_log` VALUES ('1441', null, 'admin', '2130706433', '用户成功登录系统', '2018-01-23 10:57:29', '2018-01-23 10:57:29');
INSERT INTO `c_login_log` VALUES ('1442', null, 'admin', '2130706433', '用户成功登录系统', '2018-01-23 11:08:06', '2018-01-23 11:08:06');
INSERT INTO `c_login_log` VALUES ('1443', null, 'admin', '2130706433', '用户成功登录系统', '2018-01-23 15:52:47', '2018-01-23 15:52:47');
INSERT INTO `c_login_log` VALUES ('1444', null, 'admin', '2130706433', '用户成功登录系统', '2018-01-23 17:51:05', '2018-01-23 17:51:05');
INSERT INTO `c_login_log` VALUES ('1445', null, 'admin', '2130706433', '用户成功登录系统', '2018-01-24 10:37:19', '2018-01-24 10:37:19');
INSERT INTO `c_login_log` VALUES ('1446', null, 'admin', '2130706433', '用户成功登录系统', '2018-01-24 16:35:31', '2018-01-24 16:35:31');
INSERT INTO `c_login_log` VALUES ('1447', null, 'admin', '2130706433', '用户成功登录系统', '2018-01-24 16:35:53', '2018-01-24 16:35:53');
INSERT INTO `c_login_log` VALUES ('1448', null, 'admin', '2130706433', '用户成功登录系统', '2018-01-24 16:36:28', '2018-01-24 16:36:28');
INSERT INTO `c_login_log` VALUES ('1449', null, 'admin', '2130706433', '用户成功登录系统', '2018-01-24 16:37:21', '2018-01-24 16:37:21');
INSERT INTO `c_login_log` VALUES ('1450', null, 'admin', '2130706433', '用户成功登录系统', '2018-01-24 16:59:49', '2018-01-24 16:59:49');
INSERT INTO `c_login_log` VALUES ('1451', null, 'admin', '2130706433', '用户成功登录系统', '2018-01-24 17:08:18', '2018-01-24 17:08:18');
INSERT INTO `c_login_log` VALUES ('1452', null, 'system', '2130706433', '用户成功登录系统', '2018-01-26 10:14:28', '2018-01-26 10:14:28');
INSERT INTO `c_login_log` VALUES ('1453', null, 'system', '2130706433', '用户成功登录系统', '2018-01-26 12:05:07', '2018-01-26 12:05:07');
INSERT INTO `c_login_log` VALUES ('1454', null, 'system', '2130706433', '用户成功登录系统', '2018-01-26 15:11:00', '2018-01-26 15:11:00');
INSERT INTO `c_login_log` VALUES ('1455', null, 'system', '2130706433', '用户成功登录系统', '2018-01-29 08:44:17', '2018-01-29 08:44:17');
INSERT INTO `c_login_log` VALUES ('1456', null, 'system', '2130706433', '用户成功登录系统', '2018-01-29 09:20:34', '2018-01-29 09:20:34');
INSERT INTO `c_login_log` VALUES ('1457', null, 'system', '2130706433', '用户成功登录系统', '2018-01-29 11:30:48', '2018-01-29 11:30:48');
INSERT INTO `c_login_log` VALUES ('1458', null, 'system', '2130706433', '用户成功登录系统', '2018-01-29 17:27:49', '2018-01-29 17:27:49');
INSERT INTO `c_login_log` VALUES ('1459', null, 'system', '2130706433', '用户成功登录系统', '2018-01-29 17:30:02', '2018-01-29 17:30:02');
INSERT INTO `c_login_log` VALUES ('1460', null, 'system', '2130706433', '用户成功登录系统', '2018-01-29 17:33:10', '2018-01-29 17:33:10');
INSERT INTO `c_login_log` VALUES ('1461', null, 'system', '2130706433', '用户成功登录系统', '2018-01-30 12:25:55', '2018-01-30 12:25:55');
INSERT INTO `c_login_log` VALUES ('1462', null, 'system', '2130706433', '用户成功登录系统', '2018-01-30 14:24:58', '2018-01-30 14:24:58');
INSERT INTO `c_login_log` VALUES ('1463', null, 'system', '2130706433', '用户成功登录系统', '2018-01-30 15:17:23', '2018-01-30 15:17:23');
INSERT INTO `c_login_log` VALUES ('1464', null, 'system', '2130706433', '用户成功登录系统', '2018-01-30 15:18:25', '2018-01-30 15:18:25');
INSERT INTO `c_login_log` VALUES ('1465', null, 'system', '2130706433', '用户成功登录系统', '2018-01-30 16:28:27', '2018-01-30 16:28:27');
INSERT INTO `c_login_log` VALUES ('1466', null, 'system', '2130706433', '用户成功登录系统', '2018-01-30 16:46:49', '2018-01-30 16:46:49');
INSERT INTO `c_login_log` VALUES ('1467', null, 'system', '2130706433', '用户成功登录系统', '2018-01-30 17:00:01', '2018-01-30 17:00:01');
INSERT INTO `c_login_log` VALUES ('1468', null, 'system', '2130706433', '用户成功登录系统', '2018-01-30 17:42:19', '2018-01-30 17:42:19');
INSERT INTO `c_login_log` VALUES ('1469', null, 'system', '2130706433', '用户成功登录系统', '2018-01-30 17:54:14', '2018-01-30 17:54:14');
INSERT INTO `c_login_log` VALUES ('1470', null, 'system', '2130706433', '用户成功登录系统', '2018-01-31 08:51:22', '2018-01-31 08:51:22');
INSERT INTO `c_login_log` VALUES ('1471', null, 'system', '2130706433', '用户成功登录系统', '2018-01-31 10:48:04', '2018-01-31 10:48:04');
INSERT INTO `c_login_log` VALUES ('1472', null, 'system', '2130706433', '用户成功登录系统', '2018-01-31 15:45:36', '2018-01-31 15:45:36');
INSERT INTO `c_login_log` VALUES ('1473', null, 'system', '2130706433', '用户成功登录系统', '2018-01-31 15:55:48', '2018-01-31 15:55:48');
INSERT INTO `c_login_log` VALUES ('1474', null, 'system', '2130706433', '用户成功登录系统', '2018-01-31 16:42:53', '2018-01-31 16:42:53');
INSERT INTO `c_login_log` VALUES ('1475', null, 'system', '2130706433', '用户成功登录系统', '2018-01-31 16:51:43', '2018-01-31 16:51:43');
INSERT INTO `c_login_log` VALUES ('1476', null, 'system', '2130706433', '用户成功登录系统', '2018-01-31 16:55:19', '2018-01-31 16:55:19');
INSERT INTO `c_login_log` VALUES ('1477', null, 'system', '2130706433', '用户成功登录系统', '2018-01-31 16:55:47', '2018-01-31 16:55:47');
INSERT INTO `c_login_log` VALUES ('1478', null, 'system', '2130706433', '用户成功登录系统', '2018-01-31 17:05:43', '2018-01-31 17:05:43');
INSERT INTO `c_login_log` VALUES ('1479', null, 'system', '2130706433', '用户成功登录系统', '2018-01-31 17:06:10', '2018-01-31 17:06:10');
INSERT INTO `c_login_log` VALUES ('1480', null, 'system', '2130706433', '用户成功登录系统', '2018-01-31 18:13:55', '2018-01-31 18:13:55');
INSERT INTO `c_login_log` VALUES ('1481', null, 'system', '2130706433', '用户成功登录系统', '2018-02-01 09:01:45', '2018-02-01 09:01:45');
INSERT INTO `c_login_log` VALUES ('1482', null, 'system', '2130706433', '用户成功登录系统', '2018-02-01 09:18:04', '2018-02-01 09:18:04');
INSERT INTO `c_login_log` VALUES ('1483', null, 'system', '2130706433', '用户成功登录系统', '2018-02-01 11:00:27', '2018-02-01 11:00:27');
INSERT INTO `c_login_log` VALUES ('1484', null, 'system', '2130706433', '用户成功登录系统', '2018-02-01 11:14:03', '2018-02-01 11:14:03');
INSERT INTO `c_login_log` VALUES ('1485', null, 'system', '2130706433', '用户成功登录系统', '2018-02-01 11:30:35', '2018-02-01 11:30:35');
INSERT INTO `c_login_log` VALUES ('1486', null, 'system', '2130706433', '用户成功登录系统', '2018-02-01 11:43:42', '2018-02-01 11:43:42');
INSERT INTO `c_login_log` VALUES ('1487', null, 'system', '2130706433', '用户成功登录系统', '2018-02-01 11:53:29', '2018-02-01 11:53:29');
INSERT INTO `c_login_log` VALUES ('1488', null, 'system', '2130706433', '用户成功登录系统', '2018-02-01 11:56:56', '2018-02-01 11:56:56');
INSERT INTO `c_login_log` VALUES ('1489', null, 'system', '2130706433', '用户成功登录系统', '2018-02-01 12:06:14', '2018-02-01 12:06:14');
INSERT INTO `c_login_log` VALUES ('1490', null, 'system', '2130706433', '用户成功登录系统', '2018-02-01 14:14:35', '2018-02-01 14:14:35');
INSERT INTO `c_login_log` VALUES ('1491', null, 'system', '2130706433', '用户成功登录系统', '2018-02-01 14:15:27', '2018-02-01 14:15:27');
INSERT INTO `c_login_log` VALUES ('1492', null, 'system', '2130706433', '用户成功登录系统', '2018-02-01 15:25:09', '2018-02-01 15:25:09');
INSERT INTO `c_login_log` VALUES ('1493', null, 'system', '2130706433', '用户成功登录系统', '2018-02-01 15:56:34', '2018-02-01 15:56:34');
INSERT INTO `c_login_log` VALUES ('1494', null, 'system', '2130706433', '用户成功登录系统', '2018-02-01 16:05:15', '2018-02-01 16:05:15');
INSERT INTO `c_login_log` VALUES ('1495', null, 'system', '2130706433', '用户成功登录系统', '2018-02-01 16:44:12', '2018-02-01 16:44:12');
INSERT INTO `c_login_log` VALUES ('1496', null, 'system', '2130706433', '用户成功登录系统', '2018-02-01 17:42:05', '2018-02-01 17:42:05');
INSERT INTO `c_login_log` VALUES ('1497', null, 'system', '2130706433', '用户成功登录系统', '2018-02-01 18:10:10', '2018-02-01 18:10:10');
INSERT INTO `c_login_log` VALUES ('1498', null, 'system', '2130706433', '用户成功登录系统', '2018-02-01 18:18:40', '2018-02-01 18:18:40');
INSERT INTO `c_login_log` VALUES ('1499', null, 'system', '2130706433', '用户成功登录系统', '2018-02-02 08:51:38', '2018-02-02 08:51:38');
INSERT INTO `c_login_log` VALUES ('1500', null, 'system', '2130706433', '用户成功登录系统', '2018-02-02 09:04:53', '2018-02-02 09:04:53');
INSERT INTO `c_login_log` VALUES ('1501', null, 'system', '2130706433', '用户成功登录系统', '2018-02-02 09:41:39', '2018-02-02 09:41:39');
INSERT INTO `c_login_log` VALUES ('1502', null, 'system', '2130706433', '用户成功登录系统', '2018-02-02 10:55:58', '2018-02-02 10:55:58');
INSERT INTO `c_login_log` VALUES ('1503', null, 'system', '2130706433', '用户成功登录系统', '2018-02-02 14:26:44', '2018-02-02 14:26:44');
INSERT INTO `c_login_log` VALUES ('1504', null, 'system', '2130706433', '用户成功登录系统', '2018-02-02 15:32:51', '2018-02-02 15:32:51');
INSERT INTO `c_login_log` VALUES ('1505', null, 'system', '2130706433', '用户成功登录系统', '2018-02-02 15:45:17', '2018-02-02 15:45:17');
INSERT INTO `c_login_log` VALUES ('1506', null, 'system', '2130706433', '用户成功登录系统', '2018-02-02 15:50:52', '2018-02-02 15:50:52');
INSERT INTO `c_login_log` VALUES ('1507', null, 'system', '2130706433', '用户成功登录系统', '2018-02-02 15:59:39', '2018-02-02 15:59:39');
INSERT INTO `c_login_log` VALUES ('1508', null, 'system', '2130706433', '用户成功登录系统', '2018-02-02 16:10:31', '2018-02-02 16:10:31');
INSERT INTO `c_login_log` VALUES ('1509', null, 'system', '2130706433', '用户成功登录系统', '2018-02-02 16:35:35', '2018-02-02 16:35:35');
INSERT INTO `c_login_log` VALUES ('1510', null, 'system', '2130706433', '用户成功登录系统', '2018-02-02 18:25:44', '2018-02-02 18:25:44');
INSERT INTO `c_login_log` VALUES ('1511', null, 'system', '2130706433', '用户成功登录系统', '2018-02-04 09:25:47', '2018-02-04 09:25:47');
INSERT INTO `c_login_log` VALUES ('1512', null, 'system', '2130706433', '用户成功登录系统', '2018-02-04 09:35:45', '2018-02-04 09:35:45');
INSERT INTO `c_login_log` VALUES ('1513', null, 'system', '2130706433', '用户成功登录系统', '2018-02-04 09:44:13', '2018-02-04 09:44:13');
INSERT INTO `c_login_log` VALUES ('1514', null, 'system', '2130706433', '用户成功登录系统', '2018-02-04 09:47:58', '2018-02-04 09:47:58');
INSERT INTO `c_login_log` VALUES ('1515', null, 'system', '2130706433', '用户成功登录系统', '2018-02-04 09:48:43', '2018-02-04 09:48:43');
INSERT INTO `c_login_log` VALUES ('1516', null, 'system', '2130706433', '用户成功登录系统', '2018-02-04 09:57:51', '2018-02-04 09:57:51');
INSERT INTO `c_login_log` VALUES ('1517', null, 'system', '2130706433', '用户成功登录系统', '2018-02-04 10:01:25', '2018-02-04 10:01:25');
INSERT INTO `c_login_log` VALUES ('1518', null, 'system', '2130706433', '用户成功登录系统', '2018-02-04 11:09:14', '2018-02-04 11:09:14');
INSERT INTO `c_login_log` VALUES ('1519', null, 'system', '2130706433', '用户成功登录系统', '2018-02-04 11:23:49', '2018-02-04 11:23:49');
INSERT INTO `c_login_log` VALUES ('1520', null, 'system', '2130706433', '用户成功登录系统', '2018-02-04 11:45:44', '2018-02-04 11:45:44');
INSERT INTO `c_login_log` VALUES ('1521', null, 'system', '2130706433', '用户成功登录系统', '2018-02-04 11:51:10', '2018-02-04 11:51:10');
INSERT INTO `c_login_log` VALUES ('1522', null, 'system', '2130706433', '用户成功登录系统', '2018-02-04 12:15:29', '2018-02-04 12:15:29');
INSERT INTO `c_login_log` VALUES ('1523', null, 'system', '2130706433', '用户成功登录系统', '2018-02-04 12:26:32', '2018-02-04 12:26:32');
INSERT INTO `c_login_log` VALUES ('1524', null, 'system', '2130706433', '用户成功登录系统', '2018-02-04 14:33:00', '2018-02-04 14:33:00');
INSERT INTO `c_login_log` VALUES ('1525', null, 'system', '2130706433', '用户成功登录系统', '2018-02-04 14:42:13', '2018-02-04 14:42:13');
INSERT INTO `c_login_log` VALUES ('1526', null, 'system', '2130706433', '用户成功登录系统', '2018-02-04 15:42:55', '2018-02-04 15:42:55');
INSERT INTO `c_login_log` VALUES ('1527', null, 'system', '2130706433', '用户成功登录系统', '2018-02-04 16:03:26', '2018-02-04 16:03:26');
INSERT INTO `c_login_log` VALUES ('1528', null, 'system', '2130706433', '用户成功登录系统', '2018-02-05 08:49:53', '2018-02-05 08:49:53');
INSERT INTO `c_login_log` VALUES ('1529', null, 'system', '2130706433', '用户成功登录系统', '2018-02-05 09:10:00', '2018-02-05 09:10:00');
INSERT INTO `c_login_log` VALUES ('1530', null, 'system', '2130706433', '用户成功登录系统', '2018-02-05 09:15:41', '2018-02-05 09:15:41');
INSERT INTO `c_login_log` VALUES ('1531', null, 'system', '2130706433', '用户成功登录系统', '2018-02-05 09:36:54', '2018-02-05 09:36:54');
INSERT INTO `c_login_log` VALUES ('1532', null, 'system', '2130706433', '用户成功登录系统', '2018-02-05 10:32:18', '2018-02-05 10:32:18');
INSERT INTO `c_login_log` VALUES ('1533', null, 'system', '2130706433', '用户成功登录系统', '2018-02-05 11:02:22', '2018-02-05 11:02:22');
INSERT INTO `c_login_log` VALUES ('1534', null, 'system', '2130706433', '用户成功登录系统', '2018-02-05 11:17:22', '2018-02-05 11:17:22');
INSERT INTO `c_login_log` VALUES ('1535', null, 'system', '2130706433', '用户成功登录系统', '2018-02-05 11:56:55', '2018-02-05 11:56:55');
INSERT INTO `c_login_log` VALUES ('1536', null, 'system', '2130706433', '用户成功登录系统', '2018-02-05 14:12:17', '2018-02-05 14:12:17');
INSERT INTO `c_login_log` VALUES ('1537', null, 'system', '2130706433', '用户成功登录系统', '2018-02-05 14:33:01', '2018-02-05 14:33:01');
INSERT INTO `c_login_log` VALUES ('1538', null, 'system', '2130706433', '用户成功登录系统', '2018-02-05 14:52:52', '2018-02-05 14:52:52');
INSERT INTO `c_login_log` VALUES ('1539', null, 'system', '2130706433', '用户成功登录系统', '2018-02-05 15:07:42', '2018-02-05 15:07:42');
INSERT INTO `c_login_log` VALUES ('1540', null, 'system', '2130706433', '用户成功登录系统', '2018-02-05 15:54:05', '2018-02-05 15:54:05');
INSERT INTO `c_login_log` VALUES ('1541', null, 'system', '2130706433', '用户成功登录系统', '2018-02-05 16:06:32', '2018-02-05 16:06:32');
INSERT INTO `c_login_log` VALUES ('1542', null, 'system', '2130706433', '用户成功登录系统', '2018-02-05 17:13:20', '2018-02-05 17:13:20');
INSERT INTO `c_login_log` VALUES ('1543', null, 'system', '2130706433', '用户成功登录系统', '2018-02-05 18:03:02', '2018-02-05 18:03:02');
INSERT INTO `c_login_log` VALUES ('1544', null, 'system', '2130706433', '用户成功登录系统', '2018-02-05 18:05:14', '2018-02-05 18:05:14');
INSERT INTO `c_login_log` VALUES ('1545', null, 'system', '2130706433', '用户成功登录系统', '2018-02-06 08:59:25', '2018-02-06 08:59:25');
INSERT INTO `c_login_log` VALUES ('1546', null, 'system', '2130706433', '用户成功登录系统', '2018-02-06 09:02:55', '2018-02-06 09:02:55');
INSERT INTO `c_login_log` VALUES ('1547', null, 'system', '2130706433', '用户成功登录系统', '2018-02-06 09:42:36', '2018-02-06 09:42:36');
INSERT INTO `c_login_log` VALUES ('1548', null, 'system', '2130706433', '用户成功登录系统', '2018-02-06 10:25:21', '2018-02-06 10:25:21');
INSERT INTO `c_login_log` VALUES ('1549', null, 'system', '2130706433', '用户成功登录系统', '2018-02-06 10:49:37', '2018-02-06 10:49:37');
INSERT INTO `c_login_log` VALUES ('1550', null, 'system', '2130706433', '用户成功登录系统', '2018-02-06 10:49:45', '2018-02-06 10:49:45');
INSERT INTO `c_login_log` VALUES ('1551', null, 'system', '2130706433', '用户成功登录系统', '2018-02-06 11:10:51', '2018-02-06 11:10:51');
INSERT INTO `c_login_log` VALUES ('1552', null, 'system', '2130706433', '用户成功登录系统', '2018-02-06 11:29:44', '2018-02-06 11:29:44');
INSERT INTO `c_login_log` VALUES ('1553', null, 'system', '2130706433', '用户成功登录系统', '2018-02-06 11:30:30', '2018-02-06 11:30:30');
INSERT INTO `c_login_log` VALUES ('1554', null, 'system', '2130706433', '用户成功登录系统', '2018-02-06 12:02:20', '2018-02-06 12:02:20');
INSERT INTO `c_login_log` VALUES ('1555', null, 'system', '2130706433', '用户成功登录系统', '2018-02-06 12:11:46', '2018-02-06 12:11:46');
INSERT INTO `c_login_log` VALUES ('1556', null, 'system', '2130706433', '用户成功登录系统', '2018-02-06 12:14:36', '2018-02-06 12:14:36');
INSERT INTO `c_login_log` VALUES ('1557', null, 'system', '2130706433', '用户成功登录系统', '2018-02-06 12:18:43', '2018-02-06 12:18:43');
INSERT INTO `c_login_log` VALUES ('1558', null, 'system', '2130706433', '用户成功登录系统', '2018-02-06 12:19:52', '2018-02-06 12:19:52');
INSERT INTO `c_login_log` VALUES ('1559', null, 'system', '2130706433', '用户成功登录系统', '2018-02-06 12:26:03', '2018-02-06 12:26:03');
INSERT INTO `c_login_log` VALUES ('1560', null, 'system', '2130706433', '用户成功登录系统', '2018-02-06 14:09:19', '2018-02-06 14:09:19');
INSERT INTO `c_login_log` VALUES ('1561', null, 'system', '2130706433', '用户成功登录系统', '2018-02-06 14:13:04', '2018-02-06 14:13:04');
INSERT INTO `c_login_log` VALUES ('1562', null, 'system', '2130706433', '用户成功登录系统', '2018-02-06 14:26:13', '2018-02-06 14:26:13');
INSERT INTO `c_login_log` VALUES ('1563', null, 'system', '2130706433', '用户成功登录系统', '2018-02-06 17:13:56', '2018-02-06 17:13:56');
INSERT INTO `c_login_log` VALUES ('1564', null, 'system', '2130706433', '用户成功登录系统', '2018-02-06 17:18:50', '2018-02-06 17:18:50');
INSERT INTO `c_login_log` VALUES ('1565', null, 'system', '2130706433', '用户成功登录系统', '2018-02-06 18:06:24', '2018-02-06 18:06:24');
INSERT INTO `c_login_log` VALUES ('1566', null, 'system', '2130706433', '用户成功登录系统', '2018-02-07 08:50:34', '2018-02-07 08:50:34');
INSERT INTO `c_login_log` VALUES ('1567', null, 'system', '2130706433', '用户成功登录系统', '2018-02-07 08:58:40', '2018-02-07 08:58:40');
INSERT INTO `c_login_log` VALUES ('1568', null, 'system', '2130706433', '用户成功登录系统', '2018-02-07 09:07:18', '2018-02-07 09:07:18');
INSERT INTO `c_login_log` VALUES ('1569', null, 'system', '2130706433', '用户成功登录系统', '2018-02-07 10:21:44', '2018-02-07 10:21:44');
INSERT INTO `c_login_log` VALUES ('1570', null, 'system', '2130706433', '用户成功登录系统', '2018-02-07 11:02:50', '2018-02-07 11:02:50');
INSERT INTO `c_login_log` VALUES ('1571', null, 'system', '2130706433', '用户成功登录系统', '2018-02-07 11:05:26', '2018-02-07 11:05:26');
INSERT INTO `c_login_log` VALUES ('1572', null, 'system', '2130706433', '用户成功登录系统', '2018-02-07 11:24:24', '2018-02-07 11:24:24');
INSERT INTO `c_login_log` VALUES ('1573', null, 'system', '2130706433', '用户成功登录系统', '2018-02-07 11:35:34', '2018-02-07 11:35:34');
INSERT INTO `c_login_log` VALUES ('1574', null, 'system', '2130706433', '用户成功登录系统', '2018-02-07 11:46:55', '2018-02-07 11:46:55');
INSERT INTO `c_login_log` VALUES ('1575', null, 'system', '2130706433', '用户成功登录系统', '2018-02-07 11:50:28', '2018-02-07 11:50:28');
INSERT INTO `c_login_log` VALUES ('1576', null, 'system', '2130706433', '用户成功登录系统', '2018-02-07 12:16:38', '2018-02-07 12:16:38');
INSERT INTO `c_login_log` VALUES ('1577', null, 'system', '2130706433', '用户成功登录系统', '2018-02-07 14:05:18', '2018-02-07 14:05:18');
INSERT INTO `c_login_log` VALUES ('1578', null, 'system', '2130706433', '用户成功登录系统', '2018-02-07 14:11:56', '2018-02-07 14:11:56');
INSERT INTO `c_login_log` VALUES ('1579', null, 'system', '2130706433', '用户成功登录系统', '2018-02-07 14:14:50', '2018-02-07 14:14:50');
INSERT INTO `c_login_log` VALUES ('1580', null, 'system', '2130706433', '用户成功登录系统', '2018-02-07 14:18:10', '2018-02-07 14:18:10');
INSERT INTO `c_login_log` VALUES ('1581', null, 'system', '2130706433', '用户成功登录系统', '2018-02-07 14:36:57', '2018-02-07 14:36:57');
INSERT INTO `c_login_log` VALUES ('1582', null, 'system', '2130706433', '用户成功登录系统', '2018-02-07 14:37:53', '2018-02-07 14:37:53');
INSERT INTO `c_login_log` VALUES ('1583', null, 'system', '2130706433', '用户成功登录系统', '2018-02-07 14:45:58', '2018-02-07 14:45:58');
INSERT INTO `c_login_log` VALUES ('1584', null, 'system', '2130706433', '用户成功登录系统', '2018-02-07 14:58:20', '2018-02-07 14:58:20');
INSERT INTO `c_login_log` VALUES ('1585', null, 'system', '2130706433', '用户成功登录系统', '2018-02-07 15:03:04', '2018-02-07 15:03:04');
INSERT INTO `c_login_log` VALUES ('1586', null, 'system', '2130706433', '用户成功登录系统', '2018-02-07 15:37:26', '2018-02-07 15:37:26');
INSERT INTO `c_login_log` VALUES ('1587', null, 'system', '2130706433', '用户成功登录系统', '2018-02-07 15:49:04', '2018-02-07 15:49:04');
INSERT INTO `c_login_log` VALUES ('1588', null, 'system', '2130706433', '用户成功登录系统', '2018-02-07 15:53:24', '2018-02-07 15:53:24');
INSERT INTO `c_login_log` VALUES ('1589', null, 'system', '2130706433', '用户成功登录系统', '2018-02-07 16:13:15', '2018-02-07 16:13:15');
INSERT INTO `c_login_log` VALUES ('1590', null, 'system', '2130706433', '用户成功登录系统', '2018-02-07 16:15:45', '2018-02-07 16:15:45');
INSERT INTO `c_login_log` VALUES ('1591', null, 'system', '2130706433', '用户成功登录系统', '2018-02-07 16:24:18', '2018-02-07 16:24:18');
INSERT INTO `c_login_log` VALUES ('1592', null, 'system', '2130706433', '用户成功登录系统', '2018-02-07 16:31:53', '2018-02-07 16:31:53');
INSERT INTO `c_login_log` VALUES ('1593', null, 'system', '2130706433', '用户成功登录系统', '2018-02-07 16:42:52', '2018-02-07 16:42:52');
INSERT INTO `c_login_log` VALUES ('1594', null, 'system', '2130706433', '用户成功登录系统', '2018-02-07 16:50:48', '2018-02-07 16:50:48');
INSERT INTO `c_login_log` VALUES ('1595', null, 'system', '2130706433', '用户成功登录系统', '2018-02-07 17:09:07', '2018-02-07 17:09:07');
INSERT INTO `c_login_log` VALUES ('1596', null, 'system', '2130706433', '用户成功登录系统', '2018-02-07 17:10:12', '2018-02-07 17:10:12');
INSERT INTO `c_login_log` VALUES ('1597', null, 'system', '2130706433', '用户成功登录系统', '2018-02-07 17:21:08', '2018-02-07 17:21:08');
INSERT INTO `c_login_log` VALUES ('1598', null, 'system', '2130706433', '用户成功登录系统', '2018-02-07 17:41:15', '2018-02-07 17:41:15');
INSERT INTO `c_login_log` VALUES ('1599', null, 'system', '2130706433', '用户成功登录系统', '2018-02-07 18:50:14', '2018-02-07 18:50:14');
INSERT INTO `c_login_log` VALUES ('1600', null, 'system', '2130706433', '用户成功登录系统', '2018-02-08 09:21:37', '2018-02-08 09:21:37');
INSERT INTO `c_login_log` VALUES ('1601', null, 'system', '2130706433', '用户成功登录系统', '2018-02-08 09:23:15', '2018-02-08 09:23:15');
INSERT INTO `c_login_log` VALUES ('1602', null, 'system', '2130706433', '用户成功登录系统', '2018-02-08 09:23:15', '2018-02-08 09:23:15');
INSERT INTO `c_login_log` VALUES ('1603', null, 'system', '2130706433', '用户成功登录系统', '2018-02-08 09:28:07', '2018-02-08 09:28:07');
INSERT INTO `c_login_log` VALUES ('1604', null, 'system', '2130706433', '用户成功登录系统', '2018-02-08 09:32:59', '2018-02-08 09:32:59');
INSERT INTO `c_login_log` VALUES ('1605', null, 'system', '2130706433', '用户成功登录系统', '2018-02-08 09:33:53', '2018-02-08 09:33:53');
INSERT INTO `c_login_log` VALUES ('1606', null, 'system', '2130706433', '用户成功登录系统', '2018-02-08 09:37:49', '2018-02-08 09:37:49');
INSERT INTO `c_login_log` VALUES ('1607', null, 'system', '2130706433', '用户成功登录系统', '2018-02-08 09:50:42', '2018-02-08 09:50:42');
INSERT INTO `c_login_log` VALUES ('1608', null, 'system', '2130706433', '用户成功登录系统', '2018-02-08 09:56:00', '2018-02-08 09:56:00');
INSERT INTO `c_login_log` VALUES ('1609', null, 'system', '2130706433', '用户成功登录系统', '2018-02-08 09:59:08', '2018-02-08 09:59:08');
INSERT INTO `c_login_log` VALUES ('1610', null, 'system', '2130706433', '用户成功登录系统', '2018-02-08 10:13:53', '2018-02-08 10:13:53');
INSERT INTO `c_login_log` VALUES ('1611', null, 'system', '2130706433', '用户成功登录系统', '2018-02-08 10:50:05', '2018-02-08 10:50:05');
INSERT INTO `c_login_log` VALUES ('1612', null, 'system', '2130706433', '用户成功登录系统', '2018-02-08 11:04:59', '2018-02-08 11:04:59');
INSERT INTO `c_login_log` VALUES ('1613', null, 'system', '2130706433', '用户成功登录系统', '2018-02-08 11:09:48', '2018-02-08 11:09:48');
INSERT INTO `c_login_log` VALUES ('1614', null, 'system', '2130706433', '用户成功登录系统', '2018-02-08 11:15:39', '2018-02-08 11:15:39');
INSERT INTO `c_login_log` VALUES ('1615', null, 'system', '2130706433', '用户成功登录系统', '2018-02-08 11:24:24', '2018-02-08 11:24:24');
INSERT INTO `c_login_log` VALUES ('1616', null, 'system', '2130706433', '用户成功登录系统', '2018-02-08 12:27:22', '2018-02-08 12:27:22');
INSERT INTO `c_login_log` VALUES ('1617', null, 'system', '2130706433', '用户成功登录系统', '2018-02-08 14:12:14', '2018-02-08 14:12:14');
INSERT INTO `c_login_log` VALUES ('1618', null, 'system', '2130706433', '用户成功登录系统', '2018-02-08 14:26:08', '2018-02-08 14:26:08');
INSERT INTO `c_login_log` VALUES ('1619', null, 'system', '2130706433', '用户成功登录系统', '2018-02-08 14:54:57', '2018-02-08 14:54:57');
INSERT INTO `c_login_log` VALUES ('1620', null, 'system', '2130706433', '用户成功登录系统', '2018-02-08 14:58:59', '2018-02-08 14:58:59');
INSERT INTO `c_login_log` VALUES ('1621', null, 'system', '2130706433', '用户成功登录系统', '2018-02-08 15:45:40', '2018-02-08 15:45:40');
INSERT INTO `c_login_log` VALUES ('1622', null, 'system', '2130706433', '用户成功登录系统', '2018-02-08 15:47:24', '2018-02-08 15:47:24');
INSERT INTO `c_login_log` VALUES ('1623', null, 'system', '2130706433', '用户成功登录系统', '2018-02-08 16:03:45', '2018-02-08 16:03:45');
INSERT INTO `c_login_log` VALUES ('1624', null, 'system', '2130706433', '用户成功登录系统', '2018-02-08 16:59:23', '2018-02-08 16:59:23');
INSERT INTO `c_login_log` VALUES ('1625', null, 'system', '2130706433', '用户成功登录系统', '2018-02-08 17:00:49', '2018-02-08 17:00:49');
INSERT INTO `c_login_log` VALUES ('1626', null, 'system', '2130706433', '用户成功登录系统', '2018-02-08 17:03:06', '2018-02-08 17:03:06');
INSERT INTO `c_login_log` VALUES ('1627', null, 'system', '2130706433', '用户成功登录系统', '2018-02-08 17:23:50', '2018-02-08 17:23:50');
INSERT INTO `c_login_log` VALUES ('1628', null, 'system', '2130706433', '用户成功登录系统', '2018-02-08 17:24:46', '2018-02-08 17:24:46');
INSERT INTO `c_login_log` VALUES ('1629', null, 'system', '2130706433', '用户成功登录系统', '2018-02-08 17:37:40', '2018-02-08 17:37:40');
INSERT INTO `c_login_log` VALUES ('1630', null, 'system', '2130706433', '用户成功登录系统', '2018-02-08 18:21:20', '2018-02-08 18:21:20');
INSERT INTO `c_login_log` VALUES ('1631', null, 'system', '2130706433', '用户成功登录系统', '2018-02-08 18:39:25', '2018-02-08 18:39:25');
INSERT INTO `c_login_log` VALUES ('1632', null, 'system', '2130706433', '用户成功登录系统', '2018-02-08 18:39:42', '2018-02-08 18:39:42');
INSERT INTO `c_login_log` VALUES ('1633', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 09:26:40', '2018-02-09 09:26:40');
INSERT INTO `c_login_log` VALUES ('1634', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 09:26:41', '2018-02-09 09:26:41');
INSERT INTO `c_login_log` VALUES ('1635', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 09:27:29', '2018-02-09 09:27:29');
INSERT INTO `c_login_log` VALUES ('1636', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 09:28:03', '2018-02-09 09:28:03');
INSERT INTO `c_login_log` VALUES ('1637', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 09:30:49', '2018-02-09 09:30:49');
INSERT INTO `c_login_log` VALUES ('1638', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 09:31:18', '2018-02-09 09:31:18');
INSERT INTO `c_login_log` VALUES ('1639', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 09:32:48', '2018-02-09 09:32:48');
INSERT INTO `c_login_log` VALUES ('1640', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 09:34:18', '2018-02-09 09:34:18');
INSERT INTO `c_login_log` VALUES ('1641', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 09:36:59', '2018-02-09 09:36:59');
INSERT INTO `c_login_log` VALUES ('1642', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 09:39:36', '2018-02-09 09:39:36');
INSERT INTO `c_login_log` VALUES ('1643', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 09:42:21', '2018-02-09 09:42:21');
INSERT INTO `c_login_log` VALUES ('1644', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 09:43:38', '2018-02-09 09:43:38');
INSERT INTO `c_login_log` VALUES ('1645', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 09:43:39', '2018-02-09 09:43:39');
INSERT INTO `c_login_log` VALUES ('1646', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 09:45:25', '2018-02-09 09:45:25');
INSERT INTO `c_login_log` VALUES ('1647', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 09:48:46', '2018-02-09 09:48:46');
INSERT INTO `c_login_log` VALUES ('1648', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 09:49:00', '2018-02-09 09:49:00');
INSERT INTO `c_login_log` VALUES ('1649', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 09:49:23', '2018-02-09 09:49:23');
INSERT INTO `c_login_log` VALUES ('1650', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 10:02:14', '2018-02-09 10:02:14');
INSERT INTO `c_login_log` VALUES ('1651', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 10:14:21', '2018-02-09 10:14:21');
INSERT INTO `c_login_log` VALUES ('1652', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 10:14:45', '2018-02-09 10:14:45');
INSERT INTO `c_login_log` VALUES ('1653', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 10:19:59', '2018-02-09 10:19:59');
INSERT INTO `c_login_log` VALUES ('1654', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 10:20:47', '2018-02-09 10:20:47');
INSERT INTO `c_login_log` VALUES ('1655', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 10:30:27', '2018-02-09 10:30:27');
INSERT INTO `c_login_log` VALUES ('1656', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 10:33:18', '2018-02-09 10:33:18');
INSERT INTO `c_login_log` VALUES ('1657', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 10:42:45', '2018-02-09 10:42:45');
INSERT INTO `c_login_log` VALUES ('1658', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 10:46:03', '2018-02-09 10:46:03');
INSERT INTO `c_login_log` VALUES ('1659', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 11:01:17', '2018-02-09 11:01:17');
INSERT INTO `c_login_log` VALUES ('1660', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 11:45:47', '2018-02-09 11:45:47');
INSERT INTO `c_login_log` VALUES ('1661', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 11:51:16', '2018-02-09 11:51:16');
INSERT INTO `c_login_log` VALUES ('1662', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 11:54:36', '2018-02-09 11:54:36');
INSERT INTO `c_login_log` VALUES ('1663', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 12:04:15', '2018-02-09 12:04:15');
INSERT INTO `c_login_log` VALUES ('1664', null, 'system', '2130706433', '用户成功登录系统', '2018-02-09 12:30:18', '2018-02-09 12:30:18');
INSERT INTO `c_login_log` VALUES ('1665', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 14:15:09', '2018-02-09 14:15:09');
INSERT INTO `c_login_log` VALUES ('1666', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 14:24:57', '2018-02-09 14:24:57');
INSERT INTO `c_login_log` VALUES ('1667', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 15:54:30', '2018-02-09 15:54:30');
INSERT INTO `c_login_log` VALUES ('1668', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 16:05:34', '2018-02-09 16:05:34');
INSERT INTO `c_login_log` VALUES ('1669', null, 'system', '2130706433', '用户成功登录系统', '2018-02-09 16:27:54', '2018-02-09 16:27:54');
INSERT INTO `c_login_log` VALUES ('1670', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 16:43:40', '2018-02-09 16:43:40');
INSERT INTO `c_login_log` VALUES ('1671', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 16:45:59', '2018-02-09 16:45:59');
INSERT INTO `c_login_log` VALUES ('1672', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-09 16:46:08', '2018-02-09 16:46:08');
INSERT INTO `c_login_log` VALUES ('1673', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-22 11:02:19', '2018-02-22 11:02:19');
INSERT INTO `c_login_log` VALUES ('1674', null, 'system', '2130706433', '用户成功登录系统', '2018-02-22 14:22:22', '2018-02-22 14:22:22');
INSERT INTO `c_login_log` VALUES ('1675', null, 'system', '2130706433', '用户成功登录系统', '2018-02-22 14:22:31', '2018-02-22 14:22:31');
INSERT INTO `c_login_log` VALUES ('1676', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-22 14:39:38', '2018-02-22 14:39:38');
INSERT INTO `c_login_log` VALUES ('1677', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-22 14:47:11', '2018-02-22 14:47:11');
INSERT INTO `c_login_log` VALUES ('1678', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-22 14:47:42', '2018-02-22 14:47:42');
INSERT INTO `c_login_log` VALUES ('1679', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-22 14:58:08', '2018-02-22 14:58:08');
INSERT INTO `c_login_log` VALUES ('1680', null, 'system', '2130706433', '用户成功登录系统', '2018-02-22 15:09:34', '2018-02-22 15:09:34');
INSERT INTO `c_login_log` VALUES ('1681', null, 'system', '2130706433', '用户成功登录系统', '2018-02-22 15:13:50', '2018-02-22 15:13:50');
INSERT INTO `c_login_log` VALUES ('1682', null, 'system', '2130706433', '用户成功登录系统', '2018-02-22 15:54:34', '2018-02-22 15:54:34');
INSERT INTO `c_login_log` VALUES ('1683', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-22 16:12:53', '2018-02-22 16:12:53');
INSERT INTO `c_login_log` VALUES ('1684', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-22 16:26:43', '2018-02-22 16:26:43');
INSERT INTO `c_login_log` VALUES ('1685', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-22 16:28:16', '2018-02-22 16:28:16');
INSERT INTO `c_login_log` VALUES ('1686', null, 'system', '2130706433', '用户成功登录系统', '2018-02-22 16:59:45', '2018-02-22 16:59:45');
INSERT INTO `c_login_log` VALUES ('1687', null, 'system', '2130706433', '用户成功登录系统', '2018-02-22 17:01:49', '2018-02-22 17:01:49');
INSERT INTO `c_login_log` VALUES ('1688', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-22 17:10:12', '2018-02-22 17:10:12');
INSERT INTO `c_login_log` VALUES ('1689', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-22 17:13:20', '2018-02-22 17:13:20');
INSERT INTO `c_login_log` VALUES ('1690', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-22 17:19:24', '2018-02-22 17:19:24');
INSERT INTO `c_login_log` VALUES ('1691', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-22 17:31:48', '2018-02-22 17:31:48');
INSERT INTO `c_login_log` VALUES ('1692', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-22 17:35:18', '2018-02-22 17:35:18');
INSERT INTO `c_login_log` VALUES ('1693', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-22 17:43:26', '2018-02-22 17:43:26');
INSERT INTO `c_login_log` VALUES ('1694', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-23 08:49:03', '2018-02-23 08:49:03');
INSERT INTO `c_login_log` VALUES ('1695', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-23 08:56:24', '2018-02-23 08:56:24');
INSERT INTO `c_login_log` VALUES ('1696', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-23 08:57:28', '2018-02-23 08:57:28');
INSERT INTO `c_login_log` VALUES ('1697', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-23 08:57:54', '2018-02-23 08:57:54');
INSERT INTO `c_login_log` VALUES ('1698', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-23 09:01:00', '2018-02-23 09:01:00');
INSERT INTO `c_login_log` VALUES ('1699', null, 'system', '2130706433', '用户成功登录系统', '2018-02-23 09:12:59', '2018-02-23 09:12:59');
INSERT INTO `c_login_log` VALUES ('1700', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-23 09:19:56', '2018-02-23 09:19:56');
INSERT INTO `c_login_log` VALUES ('1701', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-23 10:00:10', '2018-02-23 10:00:10');
INSERT INTO `c_login_log` VALUES ('1702', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-23 10:39:15', '2018-02-23 10:39:15');
INSERT INTO `c_login_log` VALUES ('1703', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-23 10:47:39', '2018-02-23 10:47:39');
INSERT INTO `c_login_log` VALUES ('1704', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-23 10:58:26', '2018-02-23 10:58:26');
INSERT INTO `c_login_log` VALUES ('1705', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-23 11:03:10', '2018-02-23 11:03:10');
INSERT INTO `c_login_log` VALUES ('1706', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-23 11:05:34', '2018-02-23 11:05:34');
INSERT INTO `c_login_log` VALUES ('1707', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-23 11:05:52', '2018-02-23 11:05:52');
INSERT INTO `c_login_log` VALUES ('1708', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-23 11:11:54', '2018-02-23 11:11:54');
INSERT INTO `c_login_log` VALUES ('1709', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-23 11:12:14', '2018-02-23 11:12:14');
INSERT INTO `c_login_log` VALUES ('1710', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-23 11:31:52', '2018-02-23 11:31:52');
INSERT INTO `c_login_log` VALUES ('1711', null, 'system', '2130706433', '用户成功登录系统', '2018-02-23 11:44:16', '2018-02-23 11:44:16');
INSERT INTO `c_login_log` VALUES ('1712', null, 'system', '2130706433', '用户成功登录系统', '2018-02-23 11:51:15', '2018-02-23 11:51:15');
INSERT INTO `c_login_log` VALUES ('1713', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-23 11:59:49', '2018-02-23 11:59:49');
INSERT INTO `c_login_log` VALUES ('1714', null, 'system', '2130706433', '用户成功登录系统', '2018-02-23 12:10:54', '2018-02-23 12:10:54');
INSERT INTO `c_login_log` VALUES ('1715', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-23 14:20:05', '2018-02-23 14:20:05');
INSERT INTO `c_login_log` VALUES ('1716', null, 'system', '2130706433', '用户成功登录系统', '2018-02-23 14:26:11', '2018-02-23 14:26:11');
INSERT INTO `c_login_log` VALUES ('1717', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-23 14:41:49', '2018-02-23 14:41:49');
INSERT INTO `c_login_log` VALUES ('1718', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-23 15:17:27', '2018-02-23 15:17:27');
INSERT INTO `c_login_log` VALUES ('1719', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-23 15:31:42', '2018-02-23 15:31:42');
INSERT INTO `c_login_log` VALUES ('1720', null, 'system', '2130706433', '用户成功登录系统', '2018-02-23 15:32:03', '2018-02-23 15:32:03');
INSERT INTO `c_login_log` VALUES ('1721', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-23 16:20:21', '2018-02-23 16:20:21');
INSERT INTO `c_login_log` VALUES ('1722', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-23 16:28:02', '2018-02-23 16:28:02');
INSERT INTO `c_login_log` VALUES ('1723', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-23 19:01:58', '2018-02-23 19:01:58');
INSERT INTO `c_login_log` VALUES ('1724', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-23 19:08:25', '2018-02-23 19:08:25');
INSERT INTO `c_login_log` VALUES ('1725', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-24 08:52:43', '2018-02-24 08:52:43');
INSERT INTO `c_login_log` VALUES ('1726', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-24 08:57:55', '2018-02-24 08:57:55');
INSERT INTO `c_login_log` VALUES ('1727', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-24 08:58:19', '2018-02-24 08:58:19');
INSERT INTO `c_login_log` VALUES ('1728', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-24 10:02:55', '2018-02-24 10:02:55');
INSERT INTO `c_login_log` VALUES ('1729', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-24 14:10:24', '2018-02-24 14:10:24');
INSERT INTO `c_login_log` VALUES ('1730', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-24 15:03:18', '2018-02-24 15:03:18');
INSERT INTO `c_login_log` VALUES ('1731', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-24 15:19:51', '2018-02-24 15:19:51');
INSERT INTO `c_login_log` VALUES ('1732', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-24 15:26:09', '2018-02-24 15:26:09');
INSERT INTO `c_login_log` VALUES ('1733', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-26 08:56:22', '2018-02-26 08:56:22');
INSERT INTO `c_login_log` VALUES ('1734', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-26 08:56:32', '2018-02-26 08:56:32');
INSERT INTO `c_login_log` VALUES ('1735', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-26 08:56:55', '2018-02-26 08:56:55');
INSERT INTO `c_login_log` VALUES ('1736', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-26 08:58:03', '2018-02-26 08:58:03');
INSERT INTO `c_login_log` VALUES ('1737', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-26 09:01:22', '2018-02-26 09:01:22');
INSERT INTO `c_login_log` VALUES ('1738', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-26 10:07:34', '2018-02-26 10:07:34');
INSERT INTO `c_login_log` VALUES ('1739', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-26 11:12:00', '2018-02-26 11:12:00');
INSERT INTO `c_login_log` VALUES ('1740', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-26 12:22:00', '2018-02-26 12:22:00');
INSERT INTO `c_login_log` VALUES ('1741', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-02-26 12:35:05', '2018-02-26 12:35:05');
INSERT INTO `c_login_log` VALUES ('1742', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-26 15:14:56', '2018-02-26 15:14:56');
INSERT INTO `c_login_log` VALUES ('1743', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-26 15:15:28', '2018-02-26 15:15:28');
INSERT INTO `c_login_log` VALUES ('1744', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-26 15:29:21', '2018-02-26 15:29:21');
INSERT INTO `c_login_log` VALUES ('1745', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-26 16:50:09', '2018-02-26 16:50:09');
INSERT INTO `c_login_log` VALUES ('1746', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-26 18:27:56', '2018-02-26 18:27:56');
INSERT INTO `c_login_log` VALUES ('1747', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-27 08:50:30', '2018-02-27 08:50:30');
INSERT INTO `c_login_log` VALUES ('1748', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-27 09:16:05', '2018-02-27 09:16:05');
INSERT INTO `c_login_log` VALUES ('1749', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-27 10:43:41', '2018-02-27 10:43:41');
INSERT INTO `c_login_log` VALUES ('1750', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-27 10:44:44', '2018-02-27 10:44:44');
INSERT INTO `c_login_log` VALUES ('1751', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-27 14:19:28', '2018-02-27 14:19:28');
INSERT INTO `c_login_log` VALUES ('1752', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-27 14:32:24', '2018-02-27 14:32:24');
INSERT INTO `c_login_log` VALUES ('1753', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-27 15:53:45', '2018-02-27 15:53:45');
INSERT INTO `c_login_log` VALUES ('1754', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-27 15:57:30', '2018-02-27 15:57:30');
INSERT INTO `c_login_log` VALUES ('1755', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-27 16:01:28', '2018-02-27 16:01:28');
INSERT INTO `c_login_log` VALUES ('1756', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-27 16:10:48', '2018-02-27 16:10:48');
INSERT INTO `c_login_log` VALUES ('1757', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-27 16:17:38', '2018-02-27 16:17:38');
INSERT INTO `c_login_log` VALUES ('1758', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-27 16:34:48', '2018-02-27 16:34:48');
INSERT INTO `c_login_log` VALUES ('1759', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-27 17:19:37', '2018-02-27 17:19:37');
INSERT INTO `c_login_log` VALUES ('1760', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-27 17:24:38', '2018-02-27 17:24:38');
INSERT INTO `c_login_log` VALUES ('1761', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-27 17:32:56', '2018-02-27 17:32:56');
INSERT INTO `c_login_log` VALUES ('1762', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-27 17:58:20', '2018-02-27 17:58:20');
INSERT INTO `c_login_log` VALUES ('1763', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-27 18:17:18', '2018-02-27 18:17:18');
INSERT INTO `c_login_log` VALUES ('1764', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-28 08:49:56', '2018-02-28 08:49:56');
INSERT INTO `c_login_log` VALUES ('1765', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-28 08:52:35', '2018-02-28 08:52:35');
INSERT INTO `c_login_log` VALUES ('1766', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-28 08:53:10', '2018-02-28 08:53:10');
INSERT INTO `c_login_log` VALUES ('1767', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-28 09:15:44', '2018-02-28 09:15:44');
INSERT INTO `c_login_log` VALUES ('1768', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-28 09:16:53', '2018-02-28 09:16:53');
INSERT INTO `c_login_log` VALUES ('1769', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-28 09:29:35', '2018-02-28 09:29:35');
INSERT INTO `c_login_log` VALUES ('1770', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-28 09:39:29', '2018-02-28 09:39:29');
INSERT INTO `c_login_log` VALUES ('1771', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-28 10:06:06', '2018-02-28 10:06:06');
INSERT INTO `c_login_log` VALUES ('1772', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-28 10:39:06', '2018-02-28 10:39:06');
INSERT INTO `c_login_log` VALUES ('1773', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-28 10:44:42', '2018-02-28 10:44:42');
INSERT INTO `c_login_log` VALUES ('1774', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-28 11:17:33', '2018-02-28 11:17:33');
INSERT INTO `c_login_log` VALUES ('1775', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-28 11:22:36', '2018-02-28 11:22:36');
INSERT INTO `c_login_log` VALUES ('1776', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-28 11:39:47', '2018-02-28 11:39:47');
INSERT INTO `c_login_log` VALUES ('1777', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-28 11:39:58', '2018-02-28 11:39:58');
INSERT INTO `c_login_log` VALUES ('1778', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-28 12:25:07', '2018-02-28 12:25:07');
INSERT INTO `c_login_log` VALUES ('1779', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-28 14:21:26', '2018-02-28 14:21:26');
INSERT INTO `c_login_log` VALUES ('1780', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-28 14:23:05', '2018-02-28 14:23:05');
INSERT INTO `c_login_log` VALUES ('1781', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-28 14:23:58', '2018-02-28 14:23:58');
INSERT INTO `c_login_log` VALUES ('1782', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-28 14:24:11', '2018-02-28 14:24:11');
INSERT INTO `c_login_log` VALUES ('1783', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-28 14:24:43', '2018-02-28 14:24:43');
INSERT INTO `c_login_log` VALUES ('1784', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-28 14:26:42', '2018-02-28 14:26:42');
INSERT INTO `c_login_log` VALUES ('1785', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-28 15:15:10', '2018-02-28 15:15:10');
INSERT INTO `c_login_log` VALUES ('1786', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-28 15:38:54', '2018-02-28 15:38:54');
INSERT INTO `c_login_log` VALUES ('1787', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-28 16:55:56', '2018-02-28 16:55:56');
INSERT INTO `c_login_log` VALUES ('1788', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-28 17:18:40', '2018-02-28 17:18:40');
INSERT INTO `c_login_log` VALUES ('1789', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-28 18:32:20', '2018-02-28 18:32:20');
INSERT INTO `c_login_log` VALUES ('1790', null, 'hhl', '2130706433', '用户成功登录系统', '2018-02-28 18:33:08', '2018-02-28 18:33:08');
INSERT INTO `c_login_log` VALUES ('1791', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-01 08:45:11', '2018-03-01 08:45:11');
INSERT INTO `c_login_log` VALUES ('1792', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-01 08:51:41', '2018-03-01 08:51:41');
INSERT INTO `c_login_log` VALUES ('1793', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-01 08:55:39', '2018-03-01 08:55:39');
INSERT INTO `c_login_log` VALUES ('1794', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-01 09:32:36', '2018-03-01 09:32:36');
INSERT INTO `c_login_log` VALUES ('1795', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-01 09:34:27', '2018-03-01 09:34:27');
INSERT INTO `c_login_log` VALUES ('1796', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-01 09:36:00', '2018-03-01 09:36:00');
INSERT INTO `c_login_log` VALUES ('1797', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-01 09:51:48', '2018-03-01 09:51:48');
INSERT INTO `c_login_log` VALUES ('1798', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-01 10:04:54', '2018-03-01 10:04:54');
INSERT INTO `c_login_log` VALUES ('1799', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-01 10:42:40', '2018-03-01 10:42:40');
INSERT INTO `c_login_log` VALUES ('1800', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-01 10:52:30', '2018-03-01 10:52:30');
INSERT INTO `c_login_log` VALUES ('1801', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-01 11:05:32', '2018-03-01 11:05:32');
INSERT INTO `c_login_log` VALUES ('1802', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-01 11:31:53', '2018-03-01 11:31:53');
INSERT INTO `c_login_log` VALUES ('1803', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-01 12:05:22', '2018-03-01 12:05:22');
INSERT INTO `c_login_log` VALUES ('1804', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-01 14:21:45', '2018-03-01 14:21:45');
INSERT INTO `c_login_log` VALUES ('1805', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-01 15:38:24', '2018-03-01 15:38:24');
INSERT INTO `c_login_log` VALUES ('1806', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-01 16:42:43', '2018-03-01 16:42:43');
INSERT INTO `c_login_log` VALUES ('1807', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-02 08:47:43', '2018-03-02 08:47:43');
INSERT INTO `c_login_log` VALUES ('1808', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-02 08:57:59', '2018-03-02 08:57:59');
INSERT INTO `c_login_log` VALUES ('1809', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-02 09:20:04', '2018-03-02 09:20:04');
INSERT INTO `c_login_log` VALUES ('1810', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-02 11:47:59', '2018-03-02 11:47:59');
INSERT INTO `c_login_log` VALUES ('1811', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-02 15:39:54', '2018-03-02 15:39:54');
INSERT INTO `c_login_log` VALUES ('1812', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-09 14:25:09', '2018-03-09 14:25:09');
INSERT INTO `c_login_log` VALUES ('1813', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-12 15:07:18', '2018-03-12 15:07:18');
INSERT INTO `c_login_log` VALUES ('1814', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-12 16:29:45', '2018-03-12 16:29:45');
INSERT INTO `c_login_log` VALUES ('1815', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-13 10:21:59', '2018-03-13 10:21:59');
INSERT INTO `c_login_log` VALUES ('1816', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-13 10:47:11', '2018-03-13 10:47:11');
INSERT INTO `c_login_log` VALUES ('1817', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-13 11:04:15', '2018-03-13 11:04:15');
INSERT INTO `c_login_log` VALUES ('1818', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-16 17:41:13', '2018-03-16 17:41:13');
INSERT INTO `c_login_log` VALUES ('1819', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-20 08:53:45', '2018-03-20 08:53:45');
INSERT INTO `c_login_log` VALUES ('1820', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-22 09:26:12', '2018-03-22 09:26:12');
INSERT INTO `c_login_log` VALUES ('1821', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-22 09:38:10', '2018-03-22 09:38:10');
INSERT INTO `c_login_log` VALUES ('1822', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-22 10:12:32', '2018-03-22 10:12:32');
INSERT INTO `c_login_log` VALUES ('1823', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-23 10:08:50', '2018-03-23 10:08:50');
INSERT INTO `c_login_log` VALUES ('1824', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-23 10:32:54', '2018-03-23 10:32:54');
INSERT INTO `c_login_log` VALUES ('1825', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-23 11:59:34', '2018-03-23 11:59:34');
INSERT INTO `c_login_log` VALUES ('1826', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-23 14:28:38', '2018-03-23 14:28:38');
INSERT INTO `c_login_log` VALUES ('1827', null, 'hhl', '2130706433', '用户成功登录系统', '2018-03-26 09:43:50', '2018-03-26 09:43:50');
INSERT INTO `c_login_log` VALUES ('1828', null, 'hhl', '2130706433', '用户成功登录系统', '2018-04-24 12:00:42', '2018-04-24 12:00:42');
INSERT INTO `c_login_log` VALUES ('1829', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-04-24 12:05:15', '2018-04-24 12:05:15');
INSERT INTO `c_login_log` VALUES ('1830', null, 'hhl', '2130706433', '用户成功登录系统', '2018-04-24 12:15:40', '2018-04-24 12:15:40');
INSERT INTO `c_login_log` VALUES ('1831', null, 'hhl', '2130706433', '用户成功登录系统', '2018-04-24 12:17:32', '2018-04-24 12:17:32');
INSERT INTO `c_login_log` VALUES ('1832', null, 'hhl', '2130706433', '用户成功登录系统', '2018-04-24 12:17:29', '2018-04-24 12:17:29');
INSERT INTO `c_login_log` VALUES ('1833', null, 'wanvesystem', '2130706433', '用户成功登录系统', '2018-04-24 12:18:12', '2018-04-24 12:18:12');
INSERT INTO `c_login_log` VALUES ('1834', null, 'hhl', '2130706433', '用户成功登录系统', '2018-04-24 12:32:27', '2018-04-24 12:32:27');
INSERT INTO `c_login_log` VALUES ('1835', null, 'hhl', '2130706433', '用户成功登录系统', '2018-04-24 14:08:50', '2018-04-24 14:08:50');
INSERT INTO `c_login_log` VALUES ('1836', null, 'hhl', '2130706433', '用户成功登录系统', '2018-04-24 14:12:18', '2018-04-24 14:12:18');
INSERT INTO `c_login_log` VALUES ('1837', null, 'hhl', '2130706433', '用户成功登录系统', '2018-04-24 14:13:35', '2018-04-24 14:13:35');
INSERT INTO `c_login_log` VALUES ('1838', null, 'hhl', '2130706433', '用户成功登录系统', '2018-04-25 18:02:59', '2018-04-25 18:02:59');
INSERT INTO `c_login_log` VALUES ('1839', null, 'hhl', '2130706433', '用户成功登录系统', '2018-04-25 18:04:36', '2018-04-25 18:04:36');
INSERT INTO `c_login_log` VALUES ('1840', null, 'hhl', '2130706433', '用户成功登录系统', '2018-04-25 18:08:03', '2018-04-25 18:08:03');
INSERT INTO `c_login_log` VALUES ('1841', null, 'hhl', '2130706433', '用户成功登录系统', '2018-04-25 18:24:26', '2018-04-25 18:24:26');
INSERT INTO `c_login_log` VALUES ('1842', null, 'hhl', '2130706433', '用户成功登录系统', '2018-04-25 19:30:03', '2018-04-25 19:30:03');
INSERT INTO `c_login_log` VALUES ('1843', null, 'hhl', '2130706433', '用户成功登录系统', '2018-04-26 10:05:03', '2018-04-26 10:05:03');
INSERT INTO `c_login_log` VALUES ('1844', null, 'hhl', '2130706433', '用户成功登录系统', '2018-04-26 10:05:03', '2018-04-26 10:05:03');
INSERT INTO `c_login_log` VALUES ('1845', null, 'hhl', '2130706433', '用户成功登录系统', '2018-04-26 11:59:57', '2018-04-26 11:59:57');
INSERT INTO `c_login_log` VALUES ('1846', null, 'hhl', '2130706433', '用户成功登录系统', '2018-04-26 12:00:45', '2018-04-26 12:00:45');
INSERT INTO `c_login_log` VALUES ('1847', null, 'hhl', '2130706433', '用户成功登录系统', '2018-04-26 12:02:05', '2018-04-26 12:02:05');
INSERT INTO `c_login_log` VALUES ('1848', null, 'hhl', '2130706433', '用户成功登录系统', '2018-04-26 12:03:55', '2018-04-26 12:03:55');
INSERT INTO `c_login_log` VALUES ('1849', null, 'hhl', '2130706433', '用户成功登录系统', '2018-04-26 14:20:34', '2018-04-26 14:20:34');
INSERT INTO `c_login_log` VALUES ('1850', null, 'hhl', '2130706433', '用户成功登录系统', '2018-04-26 15:10:28', '2018-04-26 15:10:28');
INSERT INTO `c_login_log` VALUES ('1851', null, 'hhl', '2130706433', '用户成功登录系统', '2018-04-26 16:57:10', '2018-04-26 16:57:10');
INSERT INTO `c_login_log` VALUES ('1852', null, 'hhl', '2130706433', '用户成功登录系统', '2018-04-26 17:32:40', '2018-04-26 17:32:40');
INSERT INTO `c_login_log` VALUES ('1853', null, 'hhl', '2130706433', '用户成功登录系统', '2018-04-26 17:50:36', '2018-04-26 17:50:36');
INSERT INTO `c_login_log` VALUES ('1854', null, 'hhl', '2130706433', '用户成功登录系统', '2018-04-27 09:16:03', '2018-04-27 09:16:03');
INSERT INTO `c_login_log` VALUES ('1855', null, 'hhl', '2130706433', '用户成功登录系统', '2018-04-27 09:55:17', '2018-04-27 09:55:17');
INSERT INTO `c_login_log` VALUES ('1856', null, 'hhl', '2130706433', '用户成功登录系统', '2018-04-27 10:01:04', '2018-04-27 10:01:04');
INSERT INTO `c_login_log` VALUES ('1857', null, 'hhl', '2130706433', '用户成功登录系统', '2018-04-27 10:03:17', '2018-04-27 10:03:17');
INSERT INTO `c_login_log` VALUES ('1858', null, 'hhl', '2130706433', '用户成功登录系统', '2018-04-27 12:21:58', '2018-04-27 12:21:58');
INSERT INTO `c_login_log` VALUES ('1859', null, 'hhl', '2130706433', '用户成功登录系统', '2018-04-27 14:19:30', '2018-04-27 14:19:30');
INSERT INTO `c_login_log` VALUES ('1860', null, 'hhl', '2130706433', '用户成功登录系统', '2018-04-27 14:21:06', '2018-04-27 14:21:06');
INSERT INTO `c_login_log` VALUES ('1861', null, 'hhl', '2130706433', '用户成功登录系统', '2018-04-27 16:14:00', '2018-04-27 16:14:00');
INSERT INTO `c_login_log` VALUES ('1862', null, 'hhl', '2130706433', '用户成功登录系统', '2018-04-28 15:06:51', '2018-04-28 15:06:51');
INSERT INTO `c_login_log` VALUES ('1863', null, 'hhl', '2130706433', '用户成功登录系统', '2018-04-28 16:45:11', '2018-04-28 16:45:11');
INSERT INTO `c_login_log` VALUES ('1864', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-02 14:26:25', '2018-05-02 14:26:25');
INSERT INTO `c_login_log` VALUES ('1865', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-02 14:37:07', '2018-05-02 14:37:07');
INSERT INTO `c_login_log` VALUES ('1866', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-02 15:25:51', '2018-05-02 15:25:51');
INSERT INTO `c_login_log` VALUES ('1867', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-02 15:25:31', '2018-05-02 15:25:31');
INSERT INTO `c_login_log` VALUES ('1868', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-02 15:59:30', '2018-05-02 15:59:30');
INSERT INTO `c_login_log` VALUES ('1869', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-02 16:01:23', '2018-05-02 16:01:23');
INSERT INTO `c_login_log` VALUES ('1870', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-02 16:09:14', '2018-05-02 16:09:14');
INSERT INTO `c_login_log` VALUES ('1871', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-04 09:06:18', '2018-05-04 09:06:18');
INSERT INTO `c_login_log` VALUES ('1872', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-21 11:58:29', '2018-05-21 11:58:29');
INSERT INTO `c_login_log` VALUES ('1873', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-21 15:25:19', '2018-05-21 15:25:19');
INSERT INTO `c_login_log` VALUES ('1874', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-21 17:11:21', '2018-05-21 17:11:21');
INSERT INTO `c_login_log` VALUES ('1875', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-21 18:12:57', '2018-05-21 18:12:57');
INSERT INTO `c_login_log` VALUES ('1876', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-21 18:41:56', '2018-05-21 18:41:56');
INSERT INTO `c_login_log` VALUES ('1877', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-21 19:42:26', '2018-05-21 19:42:26');
INSERT INTO `c_login_log` VALUES ('1878', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-23 15:28:51', '2018-05-23 15:28:51');
INSERT INTO `c_login_log` VALUES ('1879', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-23 15:30:32', '2018-05-23 15:30:32');
INSERT INTO `c_login_log` VALUES ('1880', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-23 15:59:28', '2018-05-23 15:59:28');
INSERT INTO `c_login_log` VALUES ('1881', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-23 16:36:21', '2018-05-23 16:36:21');
INSERT INTO `c_login_log` VALUES ('1882', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-23 16:54:54', '2018-05-23 16:54:54');
INSERT INTO `c_login_log` VALUES ('1883', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-23 16:58:09', '2018-05-23 16:58:09');
INSERT INTO `c_login_log` VALUES ('1884', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-24 09:18:11', '2018-05-24 09:18:11');
INSERT INTO `c_login_log` VALUES ('1885', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-24 09:59:21', '2018-05-24 09:59:21');
INSERT INTO `c_login_log` VALUES ('1886', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-24 10:01:32', '2018-05-24 10:01:32');
INSERT INTO `c_login_log` VALUES ('1887', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-24 10:15:50', '2018-05-24 10:15:50');
INSERT INTO `c_login_log` VALUES ('1888', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-24 10:44:22', '2018-05-24 10:44:22');
INSERT INTO `c_login_log` VALUES ('1889', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-24 10:56:30', '2018-05-24 10:56:30');
INSERT INTO `c_login_log` VALUES ('1890', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-24 14:14:23', '2018-05-24 14:14:23');
INSERT INTO `c_login_log` VALUES ('1891', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-24 14:20:23', '2018-05-24 14:20:23');
INSERT INTO `c_login_log` VALUES ('1892', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-24 15:02:25', '2018-05-24 15:02:25');
INSERT INTO `c_login_log` VALUES ('1893', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-24 16:43:11', '2018-05-24 16:43:11');
INSERT INTO `c_login_log` VALUES ('1894', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-24 16:45:39', '2018-05-24 16:45:39');
INSERT INTO `c_login_log` VALUES ('1895', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-24 16:57:27', '2018-05-24 16:57:27');
INSERT INTO `c_login_log` VALUES ('1896', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-24 18:01:49', '2018-05-24 18:01:49');
INSERT INTO `c_login_log` VALUES ('1897', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-24 19:01:39', '2018-05-24 19:01:39');
INSERT INTO `c_login_log` VALUES ('1898', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-24 19:01:39', '2018-05-24 19:01:39');
INSERT INTO `c_login_log` VALUES ('1899', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-28 12:16:57', '2018-05-28 12:16:57');
INSERT INTO `c_login_log` VALUES ('1900', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-28 14:25:32', '2018-05-28 14:25:32');
INSERT INTO `c_login_log` VALUES ('1901', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-28 15:02:20', '2018-05-28 15:02:20');
INSERT INTO `c_login_log` VALUES ('1902', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-28 16:19:58', '2018-05-28 16:19:58');
INSERT INTO `c_login_log` VALUES ('1903', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-28 18:41:28', '2018-05-28 18:41:28');
INSERT INTO `c_login_log` VALUES ('1904', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-28 18:50:09', '2018-05-28 18:50:09');
INSERT INTO `c_login_log` VALUES ('1905', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-29 09:17:38', '2018-05-29 09:17:38');
INSERT INTO `c_login_log` VALUES ('1906', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-29 15:05:55', '2018-05-29 15:05:55');
INSERT INTO `c_login_log` VALUES ('1907', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-29 15:37:26', '2018-05-29 15:37:26');
INSERT INTO `c_login_log` VALUES ('1908', null, 'hhl', '2130706433', '用户成功登录系统', '2018-05-29 16:56:13', '2018-05-29 16:56:13');
INSERT INTO `c_login_log` VALUES ('1909', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-06 08:58:39', '2018-06-06 08:58:39');
INSERT INTO `c_login_log` VALUES ('1910', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-06 09:36:16', '2018-06-06 09:36:16');
INSERT INTO `c_login_log` VALUES ('1911', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-06 09:36:33', '2018-06-06 09:36:33');
INSERT INTO `c_login_log` VALUES ('1912', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-06 09:37:59', '2018-06-06 09:37:59');
INSERT INTO `c_login_log` VALUES ('1913', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-06 09:47:48', '2018-06-06 09:47:48');
INSERT INTO `c_login_log` VALUES ('1914', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-06 09:55:13', '2018-06-06 09:55:13');
INSERT INTO `c_login_log` VALUES ('1915', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-06 10:09:44', '2018-06-06 10:09:44');
INSERT INTO `c_login_log` VALUES ('1916', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-06 11:02:02', '2018-06-06 11:02:02');
INSERT INTO `c_login_log` VALUES ('1917', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-06 11:35:14', '2018-06-06 11:35:14');
INSERT INTO `c_login_log` VALUES ('1918', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-06 14:08:38', '2018-06-06 14:08:38');
INSERT INTO `c_login_log` VALUES ('1919', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-06 16:49:27', '2018-06-06 16:49:27');
INSERT INTO `c_login_log` VALUES ('1920', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-06 19:07:47', '2018-06-06 19:07:47');
INSERT INTO `c_login_log` VALUES ('1921', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-06 19:58:56', '2018-06-06 19:58:56');
INSERT INTO `c_login_log` VALUES ('1922', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-06 20:01:10', '2018-06-06 20:01:10');
INSERT INTO `c_login_log` VALUES ('1923', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-07 08:48:34', '2018-06-07 08:48:34');
INSERT INTO `c_login_log` VALUES ('1924', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-07 16:47:31', '2018-06-07 16:47:31');
INSERT INTO `c_login_log` VALUES ('1925', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-08 15:09:28', '2018-06-08 15:09:28');
INSERT INTO `c_login_log` VALUES ('1926', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-11 09:04:09', '2018-06-11 09:04:09');
INSERT INTO `c_login_log` VALUES ('1927', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-11 09:31:21', '2018-06-11 09:31:21');
INSERT INTO `c_login_log` VALUES ('1928', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-11 18:10:41', '2018-06-11 18:10:41');
INSERT INTO `c_login_log` VALUES ('1929', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-11 18:13:18', '2018-06-11 18:13:18');
INSERT INTO `c_login_log` VALUES ('1930', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-11 19:28:03', '2018-06-11 19:28:03');
INSERT INTO `c_login_log` VALUES ('1931', null, 'hhl', '3232235574', '用户成功登录系统', '2018-06-11 20:12:59', '2018-06-11 20:12:59');
INSERT INTO `c_login_log` VALUES ('1932', null, 'hhl', '3232235574', '用户成功登录系统', '2018-06-11 20:13:52', '2018-06-11 20:13:52');
INSERT INTO `c_login_log` VALUES ('1933', null, 'hhl', '3232235574', '用户成功登录系统', '2018-06-11 20:14:08', '2018-06-11 20:14:08');
INSERT INTO `c_login_log` VALUES ('1934', null, 'hhl', '3232235574', '用户成功登录系统', '2018-06-11 20:14:28', '2018-06-11 20:14:28');
INSERT INTO `c_login_log` VALUES ('1935', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-19 11:04:47', '2018-06-19 11:04:47');
INSERT INTO `c_login_log` VALUES ('1936', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-19 11:05:30', '2018-06-19 11:05:30');
INSERT INTO `c_login_log` VALUES ('1937', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-19 11:57:56', '2018-06-19 11:57:56');
INSERT INTO `c_login_log` VALUES ('1938', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-19 14:28:07', '2018-06-19 14:28:07');
INSERT INTO `c_login_log` VALUES ('1939', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-19 14:42:34', '2018-06-19 14:42:34');
INSERT INTO `c_login_log` VALUES ('1940', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-19 16:02:38', '2018-06-19 16:02:38');
INSERT INTO `c_login_log` VALUES ('1941', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-19 16:17:35', '2018-06-19 16:17:35');
INSERT INTO `c_login_log` VALUES ('1942', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-19 16:22:29', '2018-06-19 16:22:29');
INSERT INTO `c_login_log` VALUES ('1943', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-20 09:06:41', '2018-06-20 09:06:41');
INSERT INTO `c_login_log` VALUES ('1944', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-20 09:06:41', '2018-06-20 09:06:41');
INSERT INTO `c_login_log` VALUES ('1945', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-20 10:20:10', '2018-06-20 10:20:10');
INSERT INTO `c_login_log` VALUES ('1946', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-20 10:20:42', '2018-06-20 10:20:42');
INSERT INTO `c_login_log` VALUES ('1947', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-20 14:19:51', '2018-06-20 14:19:51');
INSERT INTO `c_login_log` VALUES ('1948', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-21 09:18:29', '2018-06-21 09:18:29');
INSERT INTO `c_login_log` VALUES ('1949', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-21 10:52:11', '2018-06-21 10:52:11');
INSERT INTO `c_login_log` VALUES ('1950', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-25 09:30:38', '2018-06-25 09:30:38');
INSERT INTO `c_login_log` VALUES ('1951', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-27 14:43:21', '2018-06-27 14:43:21');
INSERT INTO `c_login_log` VALUES ('1952', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-28 10:09:24', '2018-06-28 10:09:24');
INSERT INTO `c_login_log` VALUES ('1953', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-28 12:30:06', '2018-06-28 12:30:06');
INSERT INTO `c_login_log` VALUES ('1954', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-28 16:27:46', '2018-06-28 16:27:46');
INSERT INTO `c_login_log` VALUES ('1955', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-28 16:53:51', '2018-06-28 16:53:51');
INSERT INTO `c_login_log` VALUES ('1956', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-28 17:59:22', '2018-06-28 17:59:22');
INSERT INTO `c_login_log` VALUES ('1957', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-29 08:50:37', '2018-06-29 08:50:37');
INSERT INTO `c_login_log` VALUES ('1958', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-29 14:57:44', '2018-06-29 14:57:44');
INSERT INTO `c_login_log` VALUES ('1959', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-29 14:57:55', '2018-06-29 14:57:55');
INSERT INTO `c_login_log` VALUES ('1960', null, 'hhl', '2130706433', '用户成功登录系统', '2018-06-29 15:18:53', '2018-06-29 15:18:53');
INSERT INTO `c_login_log` VALUES ('1961', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-02 09:06:07', '2018-07-02 09:06:07');
INSERT INTO `c_login_log` VALUES ('1962', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-02 09:08:43', '2018-07-02 09:08:43');
INSERT INTO `c_login_log` VALUES ('1963', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-02 11:59:22', '2018-07-02 11:59:22');
INSERT INTO `c_login_log` VALUES ('1964', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-02 14:20:28', '2018-07-02 14:20:28');
INSERT INTO `c_login_log` VALUES ('1965', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-02 14:44:21', '2018-07-02 14:44:21');
INSERT INTO `c_login_log` VALUES ('1966', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-02 15:12:12', '2018-07-02 15:12:12');
INSERT INTO `c_login_log` VALUES ('1967', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-02 15:12:46', '2018-07-02 15:12:46');
INSERT INTO `c_login_log` VALUES ('1968', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-02 15:19:19', '2018-07-02 15:19:19');
INSERT INTO `c_login_log` VALUES ('1969', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-02 15:32:53', '2018-07-02 15:32:53');
INSERT INTO `c_login_log` VALUES ('1970', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-03 09:40:57', '2018-07-03 09:40:57');
INSERT INTO `c_login_log` VALUES ('1971', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-03 17:04:56', '2018-07-03 17:04:56');
INSERT INTO `c_login_log` VALUES ('1972', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-03 17:20:38', '2018-07-03 17:20:38');
INSERT INTO `c_login_log` VALUES ('1973', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-06 09:02:53', '2018-07-06 09:02:53');
INSERT INTO `c_login_log` VALUES ('1974', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-06 09:57:37', '2018-07-06 09:57:37');
INSERT INTO `c_login_log` VALUES ('1975', null, 'hhl', '3232235522', '用户成功登录系统', '2018-07-06 10:05:16', '2018-07-06 10:05:16');
INSERT INTO `c_login_log` VALUES ('1976', null, 'hhl', '3232235538', '用户成功登录系统', '2018-07-06 10:05:22', '2018-07-06 10:05:22');
INSERT INTO `c_login_log` VALUES ('1977', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-06 11:04:56', '2018-07-06 11:04:56');
INSERT INTO `c_login_log` VALUES ('1978', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-06 11:08:46', '2018-07-06 11:08:46');
INSERT INTO `c_login_log` VALUES ('1979', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-06 11:32:36', '2018-07-06 11:32:36');
INSERT INTO `c_login_log` VALUES ('1980', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-06 14:32:39', '2018-07-06 14:32:39');
INSERT INTO `c_login_log` VALUES ('1981', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-09 18:10:30', '2018-07-09 18:10:30');
INSERT INTO `c_login_log` VALUES ('1982', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-10 09:41:10', '2018-07-10 09:41:10');
INSERT INTO `c_login_log` VALUES ('1983', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-11 15:06:33', '2018-07-11 15:06:33');
INSERT INTO `c_login_log` VALUES ('1984', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-13 12:25:07', '2018-07-13 12:25:07');
INSERT INTO `c_login_log` VALUES ('1985', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-13 14:24:32', '2018-07-13 14:24:32');
INSERT INTO `c_login_log` VALUES ('1986', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-17 17:41:16', '2018-07-17 17:41:16');
INSERT INTO `c_login_log` VALUES ('1987', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-18 18:53:35', '2018-07-18 18:53:35');
INSERT INTO `c_login_log` VALUES ('1988', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-19 09:07:11', '2018-07-19 09:07:11');
INSERT INTO `c_login_log` VALUES ('1989', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-19 09:08:20', '2018-07-19 09:08:20');
INSERT INTO `c_login_log` VALUES ('1990', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-19 09:08:37', '2018-07-19 09:08:37');
INSERT INTO `c_login_log` VALUES ('1991', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-19 09:13:03', '2018-07-19 09:13:03');
INSERT INTO `c_login_log` VALUES ('1992', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-19 09:13:46', '2018-07-19 09:13:46');
INSERT INTO `c_login_log` VALUES ('1993', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-19 09:13:59', '2018-07-19 09:13:59');
INSERT INTO `c_login_log` VALUES ('1994', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-19 09:14:08', '2018-07-19 09:14:08');
INSERT INTO `c_login_log` VALUES ('1995', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-19 09:15:48', '2018-07-19 09:15:48');
INSERT INTO `c_login_log` VALUES ('1996', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-19 09:36:08', '2018-07-19 09:36:08');
INSERT INTO `c_login_log` VALUES ('1997', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-19 09:57:46', '2018-07-19 09:57:46');
INSERT INTO `c_login_log` VALUES ('1998', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-19 09:57:55', '2018-07-19 09:57:55');
INSERT INTO `c_login_log` VALUES ('1999', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-19 09:58:25', '2018-07-19 09:58:25');
INSERT INTO `c_login_log` VALUES ('2000', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-19 10:02:01', '2018-07-19 10:02:01');
INSERT INTO `c_login_log` VALUES ('2001', null, 'hhl', '3232235561', '用户成功登录系统', '2018-07-19 10:18:57', '2018-07-19 10:18:57');
INSERT INTO `c_login_log` VALUES ('2002', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-19 10:52:06', '2018-07-19 10:52:06');
INSERT INTO `c_login_log` VALUES ('2003', null, 'hhl', '3232235561', '用户成功登录系统', '2018-07-19 12:02:23', '2018-07-19 12:02:23');
INSERT INTO `c_login_log` VALUES ('2004', null, 'hhl', '3232235561', '用户成功登录系统', '2018-07-19 12:03:43', '2018-07-19 12:03:43');
INSERT INTO `c_login_log` VALUES ('2005', null, 'hhl', '3232235561', '用户成功登录系统', '2018-07-19 12:13:16', '2018-07-19 12:13:16');
INSERT INTO `c_login_log` VALUES ('2006', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-19 12:23:01', '2018-07-19 12:23:01');
INSERT INTO `c_login_log` VALUES ('2007', null, 'hhl', '3232235561', '用户成功登录系统', '2018-07-19 14:06:13', '2018-07-19 14:06:13');
INSERT INTO `c_login_log` VALUES ('2008', null, 'hhl', '3232235561', '用户成功登录系统', '2018-07-19 14:06:33', '2018-07-19 14:06:33');
INSERT INTO `c_login_log` VALUES ('2009', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-19 15:18:40', '2018-07-19 15:18:40');
INSERT INTO `c_login_log` VALUES ('2010', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-19 16:55:55', '2018-07-19 16:55:55');
INSERT INTO `c_login_log` VALUES ('2011', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-19 17:59:01', '2018-07-19 17:59:01');
INSERT INTO `c_login_log` VALUES ('2012', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-20 08:55:31', '2018-07-20 08:55:31');
INSERT INTO `c_login_log` VALUES ('2013', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-20 18:13:51', '2018-07-20 18:13:51');
INSERT INTO `c_login_log` VALUES ('2014', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-20 18:14:26', '2018-07-20 18:14:26');
INSERT INTO `c_login_log` VALUES ('2015', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-20 18:24:20', '2018-07-20 18:24:20');
INSERT INTO `c_login_log` VALUES ('2016', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-23 09:29:32', '2018-07-23 09:29:32');
INSERT INTO `c_login_log` VALUES ('2017', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-23 09:31:18', '2018-07-23 09:31:18');
INSERT INTO `c_login_log` VALUES ('2018', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-23 10:23:29', '2018-07-23 10:23:29');
INSERT INTO `c_login_log` VALUES ('2019', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-30 09:08:41', '2018-07-30 09:08:41');
INSERT INTO `c_login_log` VALUES ('2020', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-30 09:09:18', '2018-07-30 09:09:18');
INSERT INTO `c_login_log` VALUES ('2021', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-30 09:11:35', '2018-07-30 09:11:35');
INSERT INTO `c_login_log` VALUES ('2022', null, 'hhl', '3232235592', '用户成功登录系统', '2018-07-30 09:52:07', '2018-07-30 09:52:07');
INSERT INTO `c_login_log` VALUES ('2023', null, 'hhl', '3232235589', '用户成功登录系统', '2018-07-30 10:51:42', '2018-07-30 10:51:42');
INSERT INTO `c_login_log` VALUES ('2024', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-31 15:09:11', '2018-07-31 15:09:11');
INSERT INTO `c_login_log` VALUES ('2025', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-31 15:15:02', '2018-07-31 15:15:02');
INSERT INTO `c_login_log` VALUES ('2026', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-31 15:17:02', '2018-07-31 15:17:02');
INSERT INTO `c_login_log` VALUES ('2027', null, 'hhl', '2130706433', '用户成功登录系统', '2018-07-31 16:47:55', '2018-07-31 16:47:55');
INSERT INTO `c_login_log` VALUES ('2028', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-01 09:12:34', '2018-08-01 09:12:34');
INSERT INTO `c_login_log` VALUES ('2029', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-01 09:16:43', '2018-08-01 09:16:43');
INSERT INTO `c_login_log` VALUES ('2030', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-01 09:24:45', '2018-08-01 09:24:45');
INSERT INTO `c_login_log` VALUES ('2031', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-01 14:26:35', '2018-08-01 14:26:35');
INSERT INTO `c_login_log` VALUES ('2032', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-02 09:12:00', '2018-08-02 09:12:00');
INSERT INTO `c_login_log` VALUES ('2033', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-02 14:41:23', '2018-08-02 14:41:23');
INSERT INTO `c_login_log` VALUES ('2034', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-02 15:27:05', '2018-08-02 15:27:05');
INSERT INTO `c_login_log` VALUES ('2035', null, 'hhl', '3232235551', '用户成功登录系统', '2018-08-02 17:03:05', '2018-08-02 17:03:05');
INSERT INTO `c_login_log` VALUES ('2036', null, 'hhl', '3232235527', '用户成功登录系统', '2018-08-02 17:03:51', '2018-08-02 17:03:51');
INSERT INTO `c_login_log` VALUES ('2037', null, 'hhl', '3232235527', '用户成功登录系统', '2018-08-02 17:05:46', '2018-08-02 17:05:46');
INSERT INTO `c_login_log` VALUES ('2038', null, 'hhl', '3232235527', '用户成功登录系统', '2018-08-02 17:10:06', '2018-08-02 17:10:06');
INSERT INTO `c_login_log` VALUES ('2039', null, 'hhl', '3232235551', '用户成功登录系统', '2018-08-02 17:10:22', '2018-08-02 17:10:22');
INSERT INTO `c_login_log` VALUES ('2040', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-03 08:51:59', '2018-08-03 08:51:59');
INSERT INTO `c_login_log` VALUES ('2041', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-03 10:34:29', '2018-08-03 10:34:29');
INSERT INTO `c_login_log` VALUES ('2042', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-03 11:17:53', '2018-08-03 11:17:53');
INSERT INTO `c_login_log` VALUES ('2043', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-03 11:31:20', '2018-08-03 11:31:20');
INSERT INTO `c_login_log` VALUES ('2044', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-03 12:07:34', '2018-08-03 12:07:34');
INSERT INTO `c_login_log` VALUES ('2045', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-03 12:19:56', '2018-08-03 12:19:56');
INSERT INTO `c_login_log` VALUES ('2046', null, 'hhl', '3232235551', '用户成功登录系统', '2018-08-03 14:42:19', '2018-08-03 14:42:19');
INSERT INTO `c_login_log` VALUES ('2047', null, 'hhl', '3232235555', '用户成功登录系统', '2018-08-03 14:44:38', '2018-08-03 14:44:38');
INSERT INTO `c_login_log` VALUES ('2048', null, 'hhl', '3232235555', '用户成功登录系统', '2018-08-03 14:59:48', '2018-08-03 14:59:48');
INSERT INTO `c_login_log` VALUES ('2049', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-06 11:49:46', '2018-08-06 11:49:46');
INSERT INTO `c_login_log` VALUES ('2050', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-06 14:21:00', '2018-08-06 14:21:00');
INSERT INTO `c_login_log` VALUES ('2051', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-07 14:58:24', '2018-08-07 14:58:24');
INSERT INTO `c_login_log` VALUES ('2052', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-07 16:23:51', '2018-08-07 16:23:51');
INSERT INTO `c_login_log` VALUES ('2053', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-08 09:36:07', '2018-08-08 09:36:07');
INSERT INTO `c_login_log` VALUES ('2054', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-08 15:43:44', '2018-08-08 15:43:44');
INSERT INTO `c_login_log` VALUES ('2055', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-08 17:34:40', '2018-08-08 17:34:40');
INSERT INTO `c_login_log` VALUES ('2056', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-08 17:34:55', '2018-08-08 17:34:55');
INSERT INTO `c_login_log` VALUES ('2057', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-09 10:18:47', '2018-08-09 10:18:47');
INSERT INTO `c_login_log` VALUES ('2058', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-09 14:15:59', '2018-08-09 14:15:59');
INSERT INTO `c_login_log` VALUES ('2059', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-09 16:27:03', '2018-08-09 16:27:03');
INSERT INTO `c_login_log` VALUES ('2060', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-10 15:22:56', '2018-08-10 15:22:56');
INSERT INTO `c_login_log` VALUES ('2061', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-10 15:23:57', '2018-08-10 15:23:57');
INSERT INTO `c_login_log` VALUES ('2062', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-13 14:32:02', '2018-08-13 14:32:02');
INSERT INTO `c_login_log` VALUES ('2063', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-13 15:15:45', '2018-08-13 15:15:45');
INSERT INTO `c_login_log` VALUES ('2064', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-13 15:16:37', '2018-08-13 15:16:37');
INSERT INTO `c_login_log` VALUES ('2065', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-13 15:40:19', '2018-08-13 15:40:19');
INSERT INTO `c_login_log` VALUES ('2066', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-13 17:03:10', '2018-08-13 17:03:10');
INSERT INTO `c_login_log` VALUES ('2067', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-13 17:27:44', '2018-08-13 17:27:44');
INSERT INTO `c_login_log` VALUES ('2068', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-13 17:32:56', '2018-08-13 17:32:56');
INSERT INTO `c_login_log` VALUES ('2069', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-14 09:00:57', '2018-08-14 09:00:57');
INSERT INTO `c_login_log` VALUES ('2070', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-14 10:14:53', '2018-08-14 10:14:53');
INSERT INTO `c_login_log` VALUES ('2071', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-14 10:15:10', '2018-08-14 10:15:10');
INSERT INTO `c_login_log` VALUES ('2072', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-14 10:37:27', '2018-08-14 10:37:27');
INSERT INTO `c_login_log` VALUES ('2073', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-14 10:40:10', '2018-08-14 10:40:10');
INSERT INTO `c_login_log` VALUES ('2074', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-14 11:05:35', '2018-08-14 11:05:35');
INSERT INTO `c_login_log` VALUES ('2075', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-14 11:08:43', '2018-08-14 11:08:43');
INSERT INTO `c_login_log` VALUES ('2076', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-14 11:09:59', '2018-08-14 11:09:59');
INSERT INTO `c_login_log` VALUES ('2077', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-14 11:32:04', '2018-08-14 11:32:04');
INSERT INTO `c_login_log` VALUES ('2078', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-14 11:35:25', '2018-08-14 11:35:25');
INSERT INTO `c_login_log` VALUES ('2079', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-14 11:47:54', '2018-08-14 11:47:54');
INSERT INTO `c_login_log` VALUES ('2080', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-14 11:53:11', '2018-08-14 11:53:11');
INSERT INTO `c_login_log` VALUES ('2081', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-14 12:24:21', '2018-08-14 12:24:21');
INSERT INTO `c_login_log` VALUES ('2082', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-14 14:12:30', '2018-08-14 14:12:30');
INSERT INTO `c_login_log` VALUES ('2083', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-14 14:13:40', '2018-08-14 14:13:40');
INSERT INTO `c_login_log` VALUES ('2084', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-14 14:18:15', '2018-08-14 14:18:15');
INSERT INTO `c_login_log` VALUES ('2085', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-14 14:20:10', '2018-08-14 14:20:10');
INSERT INTO `c_login_log` VALUES ('2086', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-14 15:43:55', '2018-08-14 15:43:55');
INSERT INTO `c_login_log` VALUES ('2087', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-14 18:14:28', '2018-08-14 18:14:28');
INSERT INTO `c_login_log` VALUES ('2088', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-15 08:46:52', '2018-08-15 08:46:52');
INSERT INTO `c_login_log` VALUES ('2089', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-15 09:07:48', '2018-08-15 09:07:48');
INSERT INTO `c_login_log` VALUES ('2090', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-15 09:08:02', '2018-08-15 09:08:02');
INSERT INTO `c_login_log` VALUES ('2091', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-15 09:16:25', '2018-08-15 09:16:25');
INSERT INTO `c_login_log` VALUES ('2092', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-15 09:52:39', '2018-08-15 09:52:39');
INSERT INTO `c_login_log` VALUES ('2093', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-15 10:51:46', '2018-08-15 10:51:46');
INSERT INTO `c_login_log` VALUES ('2094', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-15 11:42:02', '2018-08-15 11:42:02');
INSERT INTO `c_login_log` VALUES ('2095', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-15 15:14:07', '2018-08-15 15:14:07');
INSERT INTO `c_login_log` VALUES ('2096', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-15 15:17:54', '2018-08-15 15:17:54');
INSERT INTO `c_login_log` VALUES ('2097', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-15 15:33:07', '2018-08-15 15:33:07');
INSERT INTO `c_login_log` VALUES ('2098', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-15 15:37:17', '2018-08-15 15:37:17');
INSERT INTO `c_login_log` VALUES ('2099', null, 'hhl', '3232235557', '用户成功登录系统', '2018-08-15 15:44:15', '2018-08-15 15:44:15');
INSERT INTO `c_login_log` VALUES ('2100', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-15 16:14:08', '2018-08-15 16:14:08');
INSERT INTO `c_login_log` VALUES ('2101', null, 'hhl', '3232235557', '用户成功登录系统', '2018-08-15 16:14:16', '2018-08-15 16:14:16');
INSERT INTO `c_login_log` VALUES ('2102', null, 'hhl', '3232235557', '用户成功登录系统', '2018-08-15 17:27:51', '2018-08-15 17:27:51');
INSERT INTO `c_login_log` VALUES ('2103', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-15 17:30:29', '2018-08-15 17:30:29');
INSERT INTO `c_login_log` VALUES ('2104', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-15 17:57:13', '2018-08-15 17:57:13');
INSERT INTO `c_login_log` VALUES ('2105', null, 'hhl', '3232235557', '用户成功登录系统', '2018-08-15 17:59:36', '2018-08-15 17:59:36');
INSERT INTO `c_login_log` VALUES ('2106', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-15 18:04:03', '2018-08-15 18:04:03');
INSERT INTO `c_login_log` VALUES ('2107', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-15 18:11:50', '2018-08-15 18:11:50');
INSERT INTO `c_login_log` VALUES ('2108', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-15 18:14:39', '2018-08-15 18:14:39');
INSERT INTO `c_login_log` VALUES ('2109', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-15 18:16:49', '2018-08-15 18:16:49');
INSERT INTO `c_login_log` VALUES ('2110', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-16 09:01:59', '2018-08-16 09:01:59');
INSERT INTO `c_login_log` VALUES ('2111', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-16 09:02:12', '2018-08-16 09:02:12');
INSERT INTO `c_login_log` VALUES ('2112', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-16 09:11:28', '2018-08-16 09:11:28');
INSERT INTO `c_login_log` VALUES ('2113', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-16 09:11:38', '2018-08-16 09:11:38');
INSERT INTO `c_login_log` VALUES ('2114', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-16 09:12:43', '2018-08-16 09:12:43');
INSERT INTO `c_login_log` VALUES ('2115', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-16 09:58:16', '2018-08-16 09:58:16');
INSERT INTO `c_login_log` VALUES ('2116', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-16 10:07:30', '2018-08-16 10:07:30');
INSERT INTO `c_login_log` VALUES ('2117', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-16 14:13:27', '2018-08-16 14:13:27');
INSERT INTO `c_login_log` VALUES ('2118', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-16 14:19:22', '2018-08-16 14:19:22');
INSERT INTO `c_login_log` VALUES ('2119', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-16 14:45:44', '2018-08-16 14:45:44');
INSERT INTO `c_login_log` VALUES ('2120', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-16 14:58:01', '2018-08-16 14:58:01');
INSERT INTO `c_login_log` VALUES ('2121', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-16 15:03:01', '2018-08-16 15:03:01');
INSERT INTO `c_login_log` VALUES ('2122', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-16 15:40:21', '2018-08-16 15:40:21');
INSERT INTO `c_login_log` VALUES ('2123', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-17 16:48:42', '2018-08-17 16:48:42');
INSERT INTO `c_login_log` VALUES ('2124', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-17 16:48:49', '2018-08-17 16:48:49');
INSERT INTO `c_login_log` VALUES ('2125', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-17 16:51:23', '2018-08-17 16:51:23');
INSERT INTO `c_login_log` VALUES ('2126', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-17 17:26:45', '2018-08-17 17:26:45');
INSERT INTO `c_login_log` VALUES ('2127', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-17 17:27:16', '2018-08-17 17:27:16');
INSERT INTO `c_login_log` VALUES ('2128', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-17 17:28:13', '2018-08-17 17:28:13');
INSERT INTO `c_login_log` VALUES ('2129', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-20 08:51:47', '2018-08-20 08:51:47');
INSERT INTO `c_login_log` VALUES ('2130', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-20 09:07:28', '2018-08-20 09:07:28');
INSERT INTO `c_login_log` VALUES ('2131', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-20 09:48:08', '2018-08-20 09:48:08');
INSERT INTO `c_login_log` VALUES ('2132', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-20 10:19:28', '2018-08-20 10:19:28');
INSERT INTO `c_login_log` VALUES ('2133', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-20 10:20:53', '2018-08-20 10:20:53');
INSERT INTO `c_login_log` VALUES ('2134', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-20 11:41:16', '2018-08-20 11:41:16');
INSERT INTO `c_login_log` VALUES ('2135', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-20 11:46:37', '2018-08-20 11:46:37');
INSERT INTO `c_login_log` VALUES ('2136', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-20 14:40:03', '2018-08-20 14:40:03');
INSERT INTO `c_login_log` VALUES ('2137', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-20 14:40:29', '2018-08-20 14:40:29');
INSERT INTO `c_login_log` VALUES ('2138', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-20 17:15:31', '2018-08-20 17:15:31');
INSERT INTO `c_login_log` VALUES ('2139', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-20 17:21:10', '2018-08-20 17:21:10');
INSERT INTO `c_login_log` VALUES ('2140', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-20 17:31:46', '2018-08-20 17:31:46');
INSERT INTO `c_login_log` VALUES ('2141', null, 'hhl', '3232235587', '用户成功登录系统', '2018-08-20 17:57:34', '2018-08-20 17:57:34');
INSERT INTO `c_login_log` VALUES ('2142', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-20 18:07:45', '2018-08-20 18:07:45');
INSERT INTO `c_login_log` VALUES ('2143', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-20 18:24:05', '2018-08-20 18:24:05');
INSERT INTO `c_login_log` VALUES ('2144', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-21 09:04:21', '2018-08-21 09:04:21');
INSERT INTO `c_login_log` VALUES ('2145', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-21 09:09:17', '2018-08-21 09:09:17');
INSERT INTO `c_login_log` VALUES ('2146', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-21 09:09:50', '2018-08-21 09:09:50');
INSERT INTO `c_login_log` VALUES ('2147', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-21 09:11:07', '2018-08-21 09:11:07');
INSERT INTO `c_login_log` VALUES ('2148', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-21 09:32:55', '2018-08-21 09:32:55');
INSERT INTO `c_login_log` VALUES ('2149', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-21 09:44:26', '2018-08-21 09:44:26');
INSERT INTO `c_login_log` VALUES ('2150', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-21 10:45:36', '2018-08-21 10:45:36');
INSERT INTO `c_login_log` VALUES ('2151', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-21 10:53:04', '2018-08-21 10:53:04');
INSERT INTO `c_login_log` VALUES ('2152', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-21 11:15:36', '2018-08-21 11:15:36');
INSERT INTO `c_login_log` VALUES ('2153', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-21 11:25:07', '2018-08-21 11:25:07');
INSERT INTO `c_login_log` VALUES ('2154', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-21 11:30:25', '2018-08-21 11:30:25');
INSERT INTO `c_login_log` VALUES ('2155', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-21 12:52:22', '2018-08-21 12:52:22');
INSERT INTO `c_login_log` VALUES ('2156', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-21 14:12:04', '2018-08-21 14:12:04');
INSERT INTO `c_login_log` VALUES ('2157', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-21 14:13:04', '2018-08-21 14:13:04');
INSERT INTO `c_login_log` VALUES ('2158', null, 'hhl', '3232235587', '用户成功登录系统', '2018-08-21 14:27:12', '2018-08-21 14:27:12');
INSERT INTO `c_login_log` VALUES ('2159', null, 'hhl', '3232235557', '用户成功登录系统', '2018-08-21 14:28:41', '2018-08-21 14:28:41');
INSERT INTO `c_login_log` VALUES ('2160', null, 'hhl', '3232235557', '用户成功登录系统', '2018-08-21 14:29:14', '2018-08-21 14:29:14');
INSERT INTO `c_login_log` VALUES ('2161', null, 'hhl', '3232235587', '用户成功登录系统', '2018-08-21 14:47:00', '2018-08-21 14:47:00');
INSERT INTO `c_login_log` VALUES ('2162', null, 'hhl', '3232235587', '用户成功登录系统', '2018-08-21 14:48:55', '2018-08-21 14:48:55');
INSERT INTO `c_login_log` VALUES ('2163', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-21 14:53:59', '2018-08-21 14:53:59');
INSERT INTO `c_login_log` VALUES ('2164', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-21 14:55:38', '2018-08-21 14:55:38');
INSERT INTO `c_login_log` VALUES ('2165', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-21 15:26:09', '2018-08-21 15:26:09');
INSERT INTO `c_login_log` VALUES ('2166', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-21 15:44:48', '2018-08-21 15:44:48');
INSERT INTO `c_login_log` VALUES ('2167', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-21 15:49:50', '2018-08-21 15:49:50');
INSERT INTO `c_login_log` VALUES ('2168', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-21 15:50:07', '2018-08-21 15:50:07');
INSERT INTO `c_login_log` VALUES ('2169', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-21 16:26:49', '2018-08-21 16:26:49');
INSERT INTO `c_login_log` VALUES ('2170', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-21 17:35:47', '2018-08-21 17:35:47');
INSERT INTO `c_login_log` VALUES ('2171', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-21 17:45:54', '2018-08-21 17:45:54');
INSERT INTO `c_login_log` VALUES ('2172', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-21 18:41:39', '2018-08-21 18:41:39');
INSERT INTO `c_login_log` VALUES ('2173', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-21 19:12:06', '2018-08-21 19:12:06');
INSERT INTO `c_login_log` VALUES ('2174', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-21 19:35:29', '2018-08-21 19:35:29');
INSERT INTO `c_login_log` VALUES ('2175', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-21 19:39:05', '2018-08-21 19:39:05');
INSERT INTO `c_login_log` VALUES ('2176', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-21 19:39:19', '2018-08-21 19:39:19');
INSERT INTO `c_login_log` VALUES ('2177', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 08:49:27', '2018-08-22 08:49:27');
INSERT INTO `c_login_log` VALUES ('2178', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 09:01:05', '2018-08-22 09:01:05');
INSERT INTO `c_login_log` VALUES ('2179', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 09:01:42', '2018-08-22 09:01:42');
INSERT INTO `c_login_log` VALUES ('2180', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 09:02:16', '2018-08-22 09:02:16');
INSERT INTO `c_login_log` VALUES ('2181', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 09:04:55', '2018-08-22 09:04:55');
INSERT INTO `c_login_log` VALUES ('2182', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 09:10:45', '2018-08-22 09:10:45');
INSERT INTO `c_login_log` VALUES ('2183', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 09:32:12', '2018-08-22 09:32:12');
INSERT INTO `c_login_log` VALUES ('2184', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 09:59:44', '2018-08-22 09:59:44');
INSERT INTO `c_login_log` VALUES ('2185', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 11:18:25', '2018-08-22 11:18:25');
INSERT INTO `c_login_log` VALUES ('2186', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 11:21:37', '2018-08-22 11:21:37');
INSERT INTO `c_login_log` VALUES ('2187', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 11:22:37', '2018-08-22 11:22:37');
INSERT INTO `c_login_log` VALUES ('2188', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 11:57:45', '2018-08-22 11:57:45');
INSERT INTO `c_login_log` VALUES ('2189', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 12:01:15', '2018-08-22 12:01:15');
INSERT INTO `c_login_log` VALUES ('2190', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 12:01:51', '2018-08-22 12:01:51');
INSERT INTO `c_login_log` VALUES ('2191', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 12:14:48', '2018-08-22 12:14:48');
INSERT INTO `c_login_log` VALUES ('2192', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 12:31:08', '2018-08-22 12:31:08');
INSERT INTO `c_login_log` VALUES ('2193', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 14:34:54', '2018-08-22 14:34:54');
INSERT INTO `c_login_log` VALUES ('2194', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 14:38:05', '2018-08-22 14:38:05');
INSERT INTO `c_login_log` VALUES ('2195', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 14:42:59', '2018-08-22 14:42:59');
INSERT INTO `c_login_log` VALUES ('2196', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 14:45:34', '2018-08-22 14:45:34');
INSERT INTO `c_login_log` VALUES ('2197', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 14:54:11', '2018-08-22 14:54:11');
INSERT INTO `c_login_log` VALUES ('2198', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 16:11:58', '2018-08-22 16:11:58');
INSERT INTO `c_login_log` VALUES ('2199', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 16:14:27', '2018-08-22 16:14:27');
INSERT INTO `c_login_log` VALUES ('2200', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 16:17:07', '2018-08-22 16:17:07');
INSERT INTO `c_login_log` VALUES ('2201', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 16:35:08', '2018-08-22 16:35:08');
INSERT INTO `c_login_log` VALUES ('2202', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 16:52:43', '2018-08-22 16:52:43');
INSERT INTO `c_login_log` VALUES ('2203', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 16:53:00', '2018-08-22 16:53:00');
INSERT INTO `c_login_log` VALUES ('2204', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 16:55:22', '2018-08-22 16:55:22');
INSERT INTO `c_login_log` VALUES ('2205', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 17:01:17', '2018-08-22 17:01:17');
INSERT INTO `c_login_log` VALUES ('2206', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 17:02:05', '2018-08-22 17:02:05');
INSERT INTO `c_login_log` VALUES ('2207', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 17:03:13', '2018-08-22 17:03:13');
INSERT INTO `c_login_log` VALUES ('2208', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 17:14:08', '2018-08-22 17:14:08');
INSERT INTO `c_login_log` VALUES ('2209', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 17:26:22', '2018-08-22 17:26:22');
INSERT INTO `c_login_log` VALUES ('2210', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 17:40:39', '2018-08-22 17:40:39');
INSERT INTO `c_login_log` VALUES ('2211', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 18:06:17', '2018-08-22 18:06:17');
INSERT INTO `c_login_log` VALUES ('2212', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 19:11:20', '2018-08-22 19:11:20');
INSERT INTO `c_login_log` VALUES ('2213', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 19:17:29', '2018-08-22 19:17:29');
INSERT INTO `c_login_log` VALUES ('2214', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 19:23:03', '2018-08-22 19:23:03');
INSERT INTO `c_login_log` VALUES ('2215', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 19:31:30', '2018-08-22 19:31:30');
INSERT INTO `c_login_log` VALUES ('2216', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 20:07:32', '2018-08-22 20:07:32');
INSERT INTO `c_login_log` VALUES ('2217', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 20:20:31', '2018-08-22 20:20:31');
INSERT INTO `c_login_log` VALUES ('2218', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 20:26:13', '2018-08-22 20:26:13');
INSERT INTO `c_login_log` VALUES ('2219', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 20:31:58', '2018-08-22 20:31:58');
INSERT INTO `c_login_log` VALUES ('2220', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 20:41:15', '2018-08-22 20:41:15');
INSERT INTO `c_login_log` VALUES ('2221', null, 'wll', '2130706433', '用户成功登录系统', '2018-08-22 20:45:27', '2018-08-22 20:45:27');
INSERT INTO `c_login_log` VALUES ('2222', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 20:53:02', '2018-08-22 20:53:02');
INSERT INTO `c_login_log` VALUES ('2223', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 21:06:52', '2018-08-22 21:06:52');
INSERT INTO `c_login_log` VALUES ('2224', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-22 21:10:07', '2018-08-22 21:10:07');
INSERT INTO `c_login_log` VALUES ('2225', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-23 09:04:29', '2018-08-23 09:04:29');
INSERT INTO `c_login_log` VALUES ('2226', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-23 09:06:37', '2018-08-23 09:06:37');
INSERT INTO `c_login_log` VALUES ('2227', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-23 09:34:13', '2018-08-23 09:34:13');
INSERT INTO `c_login_log` VALUES ('2228', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-23 09:40:01', '2018-08-23 09:40:01');
INSERT INTO `c_login_log` VALUES ('2229', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-23 10:01:33', '2018-08-23 10:01:33');
INSERT INTO `c_login_log` VALUES ('2230', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-23 10:11:36', '2018-08-23 10:11:36');
INSERT INTO `c_login_log` VALUES ('2231', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-23 10:15:46', '2018-08-23 10:15:46');
INSERT INTO `c_login_log` VALUES ('2232', null, 'hhl', '0', '用户成功登录系统', '2018-08-23 10:30:16', '2018-08-23 10:30:16');
INSERT INTO `c_login_log` VALUES ('2233', null, 'hhl', '0', '用户成功登录系统', '2018-08-23 10:41:30', '2018-08-23 10:41:30');
INSERT INTO `c_login_log` VALUES ('2234', null, 'hhl', '0', '用户成功登录系统', '2018-08-23 10:49:47', '2018-08-23 10:49:47');
INSERT INTO `c_login_log` VALUES ('2235', null, 'hhl', '0', '用户成功登录系统', '2018-08-23 10:54:03', '2018-08-23 10:54:03');
INSERT INTO `c_login_log` VALUES ('2236', null, 'hhl', '0', '用户成功登录系统', '2018-08-23 10:58:40', '2018-08-23 10:58:40');
INSERT INTO `c_login_log` VALUES ('2237', null, 'hhl', '0', '用户成功登录系统', '2018-08-23 11:07:31', '2018-08-23 11:07:31');
INSERT INTO `c_login_log` VALUES ('2238', null, 'hhl', '0', '用户成功登录系统', '2018-08-23 12:00:42', '2018-08-23 12:00:42');
INSERT INTO `c_login_log` VALUES ('2239', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-23 12:07:45', '2018-08-23 12:07:45');
INSERT INTO `c_login_log` VALUES ('2240', null, 'hhl', '0', '用户成功登录系统', '2018-08-23 16:31:50', '2018-08-23 16:31:50');
INSERT INTO `c_login_log` VALUES ('2241', null, 'hhl', '0', '用户成功登录系统', '2018-08-23 16:34:43', '2018-08-23 16:34:43');
INSERT INTO `c_login_log` VALUES ('2242', null, 'hhl', '0', '用户成功登录系统', '2018-08-23 16:41:08', '2018-08-23 16:41:08');
INSERT INTO `c_login_log` VALUES ('2243', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-23 17:04:50', '2018-08-23 17:04:50');
INSERT INTO `c_login_log` VALUES ('2244', null, 'hhl', '0', '用户成功登录系统', '2018-08-23 17:32:04', '2018-08-23 17:32:04');
INSERT INTO `c_login_log` VALUES ('2245', null, 'hhl', '0', '用户成功登录系统', '2018-08-23 17:42:28', '2018-08-23 17:42:28');
INSERT INTO `c_login_log` VALUES ('2246', null, 'hhl', '0', '用户成功登录系统', '2018-08-23 17:56:48', '2018-08-23 17:56:48');
INSERT INTO `c_login_log` VALUES ('2247', null, 'hhl', '0', '用户成功登录系统', '2018-08-23 18:00:24', '2018-08-23 18:00:24');
INSERT INTO `c_login_log` VALUES ('2248', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-23 18:20:59', '2018-08-23 18:20:59');
INSERT INTO `c_login_log` VALUES ('2249', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-23 19:07:02', '2018-08-23 19:07:02');
INSERT INTO `c_login_log` VALUES ('2250', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-23 19:24:55', '2018-08-23 19:24:55');
INSERT INTO `c_login_log` VALUES ('2251', null, 'hhl', '0', '用户成功登录系统', '2018-08-23 19:34:34', '2018-08-23 19:34:34');
INSERT INTO `c_login_log` VALUES ('2252', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-23 20:22:25', '2018-08-23 20:22:25');
INSERT INTO `c_login_log` VALUES ('2253', null, 'wll', '0', '用户成功登录系统', '2018-08-23 20:36:49', '2018-08-23 20:36:49');
INSERT INTO `c_login_log` VALUES ('2254', null, 'wll', '0', '用户成功登录系统', '2018-08-23 21:09:50', '2018-08-23 21:09:50');
INSERT INTO `c_login_log` VALUES ('2255', null, 'hhl', '0', '用户成功登录系统', '2018-08-23 21:25:59', '2018-08-23 21:25:59');
INSERT INTO `c_login_log` VALUES ('2256', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-24 08:43:11', '2018-08-24 08:43:11');
INSERT INTO `c_login_log` VALUES ('2257', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-24 08:46:38', '2018-08-24 08:46:38');
INSERT INTO `c_login_log` VALUES ('2258', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-24 09:25:14', '2018-08-24 09:25:14');
INSERT INTO `c_login_log` VALUES ('2259', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-24 10:15:53', '2018-08-24 10:15:53');
INSERT INTO `c_login_log` VALUES ('2260', null, 'hhl', '0', '用户成功登录系统', '2018-08-24 14:16:42', '2018-08-24 14:16:42');
INSERT INTO `c_login_log` VALUES ('2261', null, 'hhl', '2130706433', '用户成功登录系统', '2018-08-24 14:37:30', '2018-08-24 14:37:30');

-- ----------------------------
-- Table structure for c_role
-- ----------------------------
DROP TABLE IF EXISTS `c_role`;
CREATE TABLE `c_role` (
  `id` varchar(32) NOT NULL,
  `sort` bigint(20) NOT NULL AUTO_INCREMENT,
  `role_text` varchar(50) NOT NULL,
  `role_name` varchar(50) NOT NULL,
  `role_memo` varchar(255) DEFAULT NULL,
  `flag` smallint(6) DEFAULT NULL,
  `role_type` smallint(6) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_sort_key` (`sort`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of c_role
-- ----------------------------
INSERT INTO `c_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '1', '管理员', 'ROLE_ADMIN', '系统管理员', '0', '0', '2017-03-30 10:39:34', '2018-02-23 11:02:42');

-- ----------------------------
-- Table structure for c_user
-- ----------------------------
DROP TABLE IF EXISTS `c_user`;
CREATE TABLE `c_user` (
  `id` varchar(32) NOT NULL,
  `sort` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) NOT NULL,
  `chinese_name` varchar(50) DEFAULT NULL,
  `pass_word` varchar(64) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `tel` varchar(20) DEFAULT NULL,
  `link_address` varchar(200) DEFAULT NULL,
  `skin` varchar(10) DEFAULT NULL,
  `photo_id` bigint(20) DEFAULT NULL,
  `photo_path` varchar(200) DEFAULT NULL,
  `memo` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL,
  `credentials_non_expired` tinyint(1) NOT NULL,
  `account_non_locked` tinyint(1) NOT NULL,
  `account_non_expired` tinyint(1) NOT NULL,
  `user_type` smallint(6) DEFAULT NULL,
  `ucode` varchar(32) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_user_sort` (`sort`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of c_user
-- ----------------------------
INSERT INTO `c_user` VALUES ('e20afce4b12511e68bc4507b9dae4454', '1', 'admin', '管理员', '01bb92d4684274ca5685738031621046495621d620f8dc78026dd291b700dd8e', '454654654@qq.com', '15920231523', null, null, null, null, null, '', '1', '1', '1', '1', '0', null, '2016-11-23 10:38:15', '2016-11-23 10:38:15');

-- ----------------------------
-- Table structure for c_user_role
-- ----------------------------
DROP TABLE IF EXISTS `c_user_role`;
CREATE TABLE `c_user_role` (
  `user_id` varchar(32) NOT NULL,
  `role_id` varchar(32) NOT NULL,
  PRIMARY KEY (`role_id`,`user_id`),
  KEY `FK_ryx81a2lxs8gia9b88uqx16y6` (`role_id`),
  KEY `FK_pnmkqxfhkfoup945qhjst4k4r` (`user_id`),
  CONSTRAINT `FK_pnmkqxfhkfoup945qhjst4k4r` FOREIGN KEY (`user_id`) REFERENCES `c_user` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_ryx81a2lxs8gia9b88uqx16y6` FOREIGN KEY (`role_id`) REFERENCES `c_role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of c_user_role
-- ----------------------------
INSERT INTO `c_user_role` VALUES ('e20afce4b12511e68bc4507b9dae4454', '14065dccb12011e68bc4507b9dae4454');

-- ----------------------------
-- Table structure for m_base_file
-- ----------------------------
DROP TABLE IF EXISTS `m_base_file`;
CREATE TABLE `m_base_file` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `file_name` varchar(255) NOT NULL,
  `pattern` varchar(255) NOT NULL,
  `big_pattern` varchar(255) DEFAULT NULL,
  `content_type` varchar(100) DEFAULT NULL,
  `create_by` varchar(50) DEFAULT NULL,
  `file_kind` smallint(6) NOT NULL,
  `file_size` varchar(30) DEFAULT NULL,
  `file_type` varchar(10) NOT NULL,
  `length` bigint(20) NOT NULL,
  `md5_code` varchar(32) DEFAULT NULL,
  `real_name` varchar(80) DEFAULT NULL,
  `save_path` varchar(255) NOT NULL,
  `transfer_path` varchar(255) DEFAULT NULL,
  `zone_path_id` bigint(20) NOT NULL,
  `turn_status` smallint(6) DEFAULT NULL,
  `main_id` bigint(20) DEFAULT NULL,
  `status` smallint(6) NOT NULL DEFAULT '0',
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of m_base_file
-- ----------------------------

-- ----------------------------
-- Table structure for m_zone_path
-- ----------------------------
DROP TABLE IF EXISTS `m_zone_path`;
CREATE TABLE `m_zone_path` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `text` varchar(255) DEFAULT NULL,
  `priority` int(11) NOT NULL,
  `path` varchar(255) NOT NULL,
  `type` varchar(20) NOT NULL,
  `virtual_path` varchar(255) DEFAULT NULL,
  `view_path` varchar(255) DEFAULT NULL,
  `warm_value` bigint(20) DEFAULT NULL,
  `zone_name` varchar(1) DEFAULT NULL,
  `flag` smallint(6) DEFAULT NULL,
  `status` smallint(6) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of m_zone_path
-- ----------------------------
INSERT INTO `m_zone_path` VALUES ('1', '普通文件', '1', 'D:/RBSG_FILE_STORE/common-file', 'commomFile', 'D:/RBSG_FILE_STORE/common-file/view', '/attachment/view', '10000', 'D', '1', null, null, null);
INSERT INTO `m_zone_path` VALUES ('2', '临时文件地址', '1', 'D:/RBSG_FILE_STORE/temp-file', 'tempFile', '', 'tempFile', '10000', 'D', '0', null, '2017-07-25 09:16:07', '2017-07-25 09:16:14');

-- ----------------------------
-- Table structure for sys_logs
-- ----------------------------
DROP TABLE IF EXISTS `sys_logs`;
CREATE TABLE `sys_logs` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `THREAD` varchar(100) DEFAULT NULL,
  `CLASS_NAME` varchar(200) DEFAULT NULL,
  `METHOD` varchar(100) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `LOGLEVEL` varchar(10) DEFAULT NULL,
  `MSG` varchar(5000) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=235514 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sys_logs
-- ----------------------------
