/*
Navicat MySQL Data Transfer

Source Server         : test_3306
Source Server Version : 50725
Source Host           : 192.168.0.59:3306
Source Database       : rbib

Target Server Type    : MYSQL
Target Server Version : 50725
File Encoding         : 65001

Date: 2019-05-10 14:44:54
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for c_authority
-- ----------------------------
DROP TABLE IF EXISTS `c_authority`;
CREATE TABLE `c_authority` (
  `id` varchar(32) NOT NULL,
  `sort` bigint(20) NOT NULL AUTO_INCREMENT,
  `auth_code` varchar(50) NOT NULL,
  `auth_text` varchar(50) NOT NULL,
  `auth_order` int(11) DEFAULT NULL,
  `auth_type` smallint(6) DEFAULT NULL,
  `open_way` smallint(6) DEFAULT NULL,
  `resoureces_url` varchar(255) DEFAULT NULL,
  `flag` smallint(6) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `parent_id` varchar(32) DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `authority_sort_key` (`sort`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=175 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of c_authority
-- ----------------------------
INSERT INTO `c_authority` VALUES ('06cc6be614f211e7b61c507b9dae4454', '45', 'deleteSysLogs', '删除系统日志', '3', '2', null, '/sysLogsController/deleteSysLogs.do', '1', '', 'ca94dc3414f111e7b61c507b9dae4454', '2017-03-30 10:38:59', '2017-03-30 10:38:59');
INSERT INTO `c_authority` VALUES ('075cef3db14411e68bc4507b9dae4454', '25', 'getDictList', '查询数字字典列表', '1', '1', null, '/dictController/getPageData.do', '0', '', 'f34538adb14311e68bc4507b9dae4454', '2016-11-23 14:14:03', null);
INSERT INTO `c_authority` VALUES ('096b361bca7f11e7b5d7507b9dae4454', '170', 'getSubUserDetail', '查询子账号详情', '3', '2', null, '/userController/getSubUserDetail.do', '1', '', 'decaa8faca7e11e7b5d7507b9dae4454', '2017-11-16 11:34:23', '2017-11-16 11:34:23');
INSERT INTO `c_authority` VALUES ('0ab359cfb4b611e7b9d4507b9dae4454', '113', 'getProcDefDetail', '跳转修改流程定义', '6', '2', null, '/procDefController/getDetail.do', '1', '', 'c2d8d93cb4ab11e7b9d4507b9dae4454', '2017-10-19 18:12:39', '2017-10-19 18:12:39');
INSERT INTO `c_authority` VALUES ('0f95872fb4af11e7b9d4507b9dae4454', '111', 'editProcDef', '修改流程定义', '4', '2', null, '/procDefController/editProcDef.do', '1', '', 'c2d8d93cb4ab11e7b9d4507b9dae4454', '2017-10-19 17:22:41', '2017-10-19 17:22:41');
INSERT INTO `c_authority` VALUES ('12485e29beef11e7b827507b9dae4454', '151', 'myAbnormalReceiptsPage', '我的绩效登记记录', '1', '1', null, '/staffPerformanceController/myAbnormalReceiptsPage.do', '0', '', 'a804c624beee11e7b827507b9dae4454', '2017-11-01 18:26:08', '2017-11-01 18:26:08');
INSERT INTO `c_authority` VALUES ('144B2E062AFE407B80FFE11494353EA2', '31', 'zonePathManage', '文件路径管理', '7', '0', null, '/zonePathController/viewPage.do', '1', '', '3b5ea9dcb11d11e68bc4507b9dae4454', '2016-09-01 14:26:20', '2017-10-20 14:19:51');
INSERT INTO `c_authority` VALUES ('161c6c08bae911e7a2d8507b9dae4454', '141', 'skipHandleWasteTransfer', '跳转办理废旧资产页面', '8', '2', '2', '/wasteTransferController/skipHandleWasteTransfer.do', '1', '', '2ea0ab5ebab911e7a2d8507b9dae4454', '2017-10-27 15:33:18', '2017-10-27 15:33:18');
INSERT INTO `c_authority` VALUES ('181e5ef066da11e783a7507b9dae4454', '59', 'deleteContent', '删除文章', '11', '2', null, '/contentController/deleteContent.do', '1', '', '8917027a66ba11e783a7507b9dae4454', '2017-07-12 16:14:11', '2017-07-12 16:14:11');
INSERT INTO `c_authority` VALUES ('1a5bcfe98df311e78342507b9dae4454', '96', 'queryPageMsgRecord', '分页查询信息', '4', '1', null, '/msgRecordController/getPageData.do', '1', '', 'd8c7282b8df111e78342507b9dae4454', '2017-08-31 10:21:11', '2017-08-31 10:21:11');
INSERT INTO `c_authority` VALUES ('1b765774bac011e7a2d8507b9dae4454', '139', 'chsystem', '常虎定制系统', '3', '0', '0', null, '1', 'icon_menu_flag', null, '2017-10-27 10:39:52', '2017-10-27 10:39:52');
INSERT INTO `c_authority` VALUES ('1f4d1db3c03f11e7ab51507b9dae4454', '163', 'deleteTollStation', '删除收费站管理', '5', '2', '0', '/tollStationController/deleteTollStation.do', '1', '', '5be7c891c03e11e7ab51507b9dae4454', '2017-11-03 10:31:41', '2017-11-03 10:31:41');
INSERT INTO `c_authority` VALUES ('1f97c4a2b14411e68bc4507b9dae4454', '26', 'skipAddDict', '跳转添加数字字典', '2', '2', null, '/dictController/skipAddDict.do', '1', '', 'f34538adb14311e68bc4507b9dae4454', '2016-11-23 14:14:43', null);
INSERT INTO `c_authority` VALUES ('20c1a691944811e7a354507b9dae4454', '102', 'updateMyInfo', '修改个人信息', '4', '2', null, '/userController/updateMyInfo.do', '1', '', '3680f6afb12411e68bc4507b9dae4454', '2017-09-08 11:45:17', '2017-09-08 11:45:17');
INSERT INTO `c_authority` VALUES ('20db6022b12311e68bc4507b9dae4454', '19', 'getUserDetail', '查询用户详细', '4', '2', null, '/userController/getDetail.do', '1', '', 'ad2f2ee6b12011e68bc4507b9dae4454', '2016-11-23 10:18:32', null);
INSERT INTO `c_authority` VALUES ('20f640f48df211e78342507b9dae4454', '93', 'skipAddWxRecord', '跳转添加微信', '1', '2', null, '/msgRecordController/skipAddWxRecord.do', '1', '', 'd8c7282b8df111e78342507b9dae4454', '2017-08-31 10:14:12', '2017-08-31 10:14:12');
INSERT INTO `c_authority` VALUES ('225a2560beef11e7b827507b9dae4454', '152', 'handleAbnormalReceiptsPage', '待办理绩效登记记录', '2', '1', null, '/staffPerformanceController/handleAbnormalReceiptsPage.do', '0', '', 'a804c624beee11e7b827507b9dae4454', '2017-11-01 18:26:35', '2017-11-01 18:26:35');
INSERT INTO `c_authority` VALUES ('24e7d1f366d911e783a7507b9dae4454', '54', 'skipContentList', '跳转文章列表', '6', '2', null, '/contentController/viewPage.do', '1', '', '8917027a66ba11e783a7507b9dae4454', '2017-07-12 16:07:23', '2017-07-12 16:07:23');
INSERT INTO `c_authority` VALUES ('2549004db7c611e79b95507b9dae4454', '125', 'takeMonitorManage', '调取监控管理', '2', '0', null, '/takeMonitorController/viewPage.do', '1', '', 'b1cf6cd8b7c411e79b95507b9dae4454', '2017-10-23 15:45:33', '2017-10-23 15:45:33');
INSERT INTO `c_authority` VALUES ('254c5410b7c611e79b95507b9dae4454', '126', 'skipAddTakeMonitor', '跳转添加调取监控', '1', '2', null, '/takeMonitorController/skipAddTakeMonitor.do', '1', null, '2549004db7c611e79b95507b9dae4454', '2017-10-23 15:45:33', '2017-10-23 15:45:33');
INSERT INTO `c_authority` VALUES ('254ebf4bb7c611e79b95507b9dae4454', '127', 'addTakeMonitor', '添加调取监控', '2', '2', null, '/takeMonitorController/addTakeMonitor.do', '1', null, '2549004db7c611e79b95507b9dae4454', '2017-10-23 15:45:33', '2017-10-23 15:45:33');
INSERT INTO `c_authority` VALUES ('2552f1f2b7c611e79b95507b9dae4454', '128', 'skipEditTakeMonitor', '跳转编辑调取监控', '3', '2', null, '/takeMonitorController/skipEditTakeMonitor.do', '1', null, '2549004db7c611e79b95507b9dae4454', '2017-10-23 15:45:33', '2017-10-23 15:45:33');
INSERT INTO `c_authority` VALUES ('25588feeb7c611e79b95507b9dae4454', '129', 'editTakeMonitor', '编辑调取监控', '4', '2', null, '/takeMonitorController/editTakeMonitor.do', '1', null, '2549004db7c611e79b95507b9dae4454', '2017-10-23 15:45:33', '2017-10-23 15:45:33');
INSERT INTO `c_authority` VALUES ('255addacb7c611e79b95507b9dae4454', '130', 'deleteTakeMonitor', '删除调取监控', '5', '2', null, '/takeMonitorController/deleteTakeMonitor.do', '1', null, '2549004db7c611e79b95507b9dae4454', '2017-10-23 15:45:33', '2017-10-23 15:45:33');
INSERT INTO `c_authority` VALUES ('255d44f5b7c611e79b95507b9dae4454', '131', 'queryPageTakeMonitor', '分页查询调取监控', '6', '2', null, '/takeMonitorController/getPageData.do', '1', null, '2549004db7c611e79b95507b9dae4454', '2017-10-23 15:45:33', '2017-10-23 15:45:33');
INSERT INTO `c_authority` VALUES ('2ea0ab5ebab911e7a2d8507b9dae4454', '132', 'wasteTransferManage', '废旧资产转移管理', '1', '0', null, '/wasteTransferController/viewPage.do', '1', '', 'b1cf6cd8b7c411e79b95507b9dae4454', '2017-10-27 09:50:24', '2017-10-27 09:50:24');
INSERT INTO `c_authority` VALUES ('2eaaa1b0bab911e7a2d8507b9dae4454', '133', 'skipAddWasteTransfer', '跳转添加废旧资产转移', '1', '2', null, '/wasteTransferController/skipAddWasteTransfer.do', '1', null, '2ea0ab5ebab911e7a2d8507b9dae4454', '2017-10-27 09:50:24', '2017-10-27 09:50:24');
INSERT INTO `c_authority` VALUES ('2eae3fecbab911e7a2d8507b9dae4454', '134', 'addWasteTransfer', '添加废旧资产转移', '2', '2', null, '/wasteTransferController/addWasteTransfer.do', '1', null, '2ea0ab5ebab911e7a2d8507b9dae4454', '2017-10-27 09:50:24', '2017-10-27 09:50:24');
INSERT INTO `c_authority` VALUES ('2eb1ff50bab911e7a2d8507b9dae4454', '135', 'skipEditWasteTransfer', '跳转编辑废旧资产转移', '3', '2', null, '/wasteTransferController/skipEditWasteTransfer.do', '1', null, '2ea0ab5ebab911e7a2d8507b9dae4454', '2017-10-27 09:50:24', '2017-10-27 09:50:24');
INSERT INTO `c_authority` VALUES ('2eb99a4bbab911e7a2d8507b9dae4454', '136', 'editWasteTransfer', '编辑废旧资产转移', '4', '2', null, '/wasteTransferController/editWasteTransfer.do', '1', null, '2ea0ab5ebab911e7a2d8507b9dae4454', '2017-10-27 09:50:24', '2017-10-27 09:50:24');
INSERT INTO `c_authority` VALUES ('2ebc3cb2bab911e7a2d8507b9dae4454', '137', 'deleteWasteTransfer', '删除废旧资产转移', '5', '2', null, '/wasteTransferController/deleteWasteTransfer.do', '1', null, '2ea0ab5ebab911e7a2d8507b9dae4454', '2017-10-27 09:50:24', '2017-10-27 09:50:24');
INSERT INTO `c_authority` VALUES ('2ebec800bab911e7a2d8507b9dae4454', '138', 'queryPageWasteTransfer', '分页查询废旧资产转移', '6', '2', null, '/wasteTransferController/getPageData.do', '1', null, '2ea0ab5ebab911e7a2d8507b9dae4454', '2017-10-27 09:50:24', '2017-10-27 09:50:24');
INSERT INTO `c_authority` VALUES ('32ca861bb12011e68bc4507b9dae4454', '8', 'roleManage', '角色管理', '4', '0', null, '/roleController/viewPage.do', '1', '', '3b5ea9dcb11d11e68bc4507b9dae4454', '2016-11-23 09:57:33', '2017-10-20 14:20:03');
INSERT INTO `c_authority` VALUES ('33201f4fbfaf11e79515507b9dae4454', '153', 'sendStaffPerformance', '绩效文件送办', '7', '2', null, '/staffPerformanceController/sendStaffPerformance.do', '1', '', 'a804c624beee11e7b827507b9dae4454', '2017-11-02 17:21:26', '2017-11-02 17:21:26');
INSERT INTO `c_authority` VALUES ('33C22D17058648ADA85169ACC6D0FE82', '32', 'editZonePath', '修改文件路径', '5', '2', null, '/zonePathController/editZonePath.do', '1', '', '144B2E062AFE407B80FFE11494353EA2', '2016-09-01 14:29:39', null);
INSERT INTO `c_authority` VALUES ('35b6ee598df211e78342507b9dae4454', '94', 'skipAddSmsRecord', '跳转添加短信', '2', '2', null, '/msgRecordController/skipAddSmsRecord.do', '1', '', 'd8c7282b8df111e78342507b9dae4454', '2017-08-31 10:14:47', '2017-08-31 10:14:47');
INSERT INTO `c_authority` VALUES ('36422d9966cc11e783a7507b9dae4454', '51', 'addTopic', '添加栏目', '3', '2', null, '/topicController/addTopic.do', '1', '', '8917027a66ba11e783a7507b9dae4454', '2017-07-12 14:34:49', '2017-07-12 14:34:49');
INSERT INTO `c_authority` VALUES ('3680f6afb12411e68bc4507b9dae4454', '23', 'siteIndex', '网站主页', '1', '1', null, '/index.do', '0', '', null, '2016-11-23 10:26:17', null);
INSERT INTO `c_authority` VALUES ('368d7eaab4af11e7b9d4507b9dae4454', '112', 'deleteProcDef', '删除流程定义', '5', '2', null, '/procDefController/deleteProcDef.do', '1', '', 'c2d8d93cb4ab11e7b9d4507b9dae4454', '2017-10-19 17:23:46', '2017-10-19 17:23:46');
INSERT INTO `c_authority` VALUES ('3875e4feb14411e68bc4507b9dae4454', '27', 'addDict', '添加数字字典', '3', '2', null, '/dictController/addDict.do', '1', '', 'f34538adb14311e68bc4507b9dae4454', '2016-11-23 14:15:25', null);
INSERT INTO `c_authority` VALUES ('3a389a16893511e7942f507b9dae4454', '61', 'skipAddFriendLink', '跳转添加友情链接', '1', '2', null, '/friendLinkController/skipAddFriendLink.do', '1', '', 'fcbfeb9f893411e7942f507b9dae4454', '2017-08-25 09:32:04', '2017-08-25 09:32:04');
INSERT INTO `c_authority` VALUES ('3b5ea9dcb11d11e68bc4507b9dae4454', '1', 'systemManage', '系统管理', '10', '0', null, null, '1', '', null, '2016-11-23 09:36:19', '2017-10-20 14:14:09');
INSERT INTO `c_authority` VALUES ('3f1a0cd3bfaf11e79515507b9dae4454', '154', 'goHandlePage', '绩效办理', '8', '2', null, '/staffPerformanceController/goHandlePage.do', '1', '', 'a804c624beee11e7b827507b9dae4454', '2017-11-02 17:21:46', '2017-11-02 17:21:46');
INSERT INTO `c_authority` VALUES ('409bdf579e8511e7a438507b9dae4454', '106', 'importUserByExcel', '导入用户信息excel', '8', '1', null, '/userController/addUserByExcelImport.do', '1', '', 'ad2f2ee6b12011e68bc4507b9dae4454', '2017-09-21 12:28:33', '2017-09-21 12:28:33');
INSERT INTO `c_authority` VALUES ('45e80d45976e11e79c2b507b9dae4454', '103', 'oasSngleSignOn', 'OA办公系统', '2', '0', '2', '/oas/singleSignOn.do', '1', 'icon_menu_oa', null, '2017-09-12 11:55:53', '2017-09-12 11:55:53');
INSERT INTO `c_authority` VALUES ('474011dfb12211e68bc4507b9dae4454', '18', 'addUser', '添加用户', '3', '2', null, '/userController/addUser.do', '1', '', 'ad2f2ee6b12011e68bc4507b9dae4454', '2016-11-23 10:12:27', null);
INSERT INTO `c_authority` VALUES ('4793493c8df211e78342507b9dae4454', '95', 'deleteMsgRecord', '删除信息', '3', '2', null, '/msgRecordController/deleteMsgRecord.do', '1', '', 'd8c7282b8df111e78342507b9dae4454', '2017-08-31 10:15:17', '2017-08-31 10:15:17');
INSERT INTO `c_authority` VALUES ('48216baf8d3611e7b759507b9dae4454', '88', 'addLinkBook', '添加通讯录', '2', '2', null, '/linkBookController/admin/addLinkBook.do', '1', '', '7e571cb18d3511e7b759507b9dae4454', '2017-08-30 11:48:24', '2017-08-30 11:48:24');
INSERT INTO `c_authority` VALUES ('4ad0e0dcb11f11e68bc4507b9dae4454', '4', 'skipAddAuth', '跳转添加权限', '2', '2', null, '/authController/skipAddAuth.do', '1', '', 'dd77e2b2b11e11e68bc4507b9dae4454', '2016-11-23 09:51:04', null);
INSERT INTO `c_authority` VALUES ('4b1b3fb1c9dd11e7999b507b9dae4454', '166', 'deleteUserByRid', '删除用户关联', '9', '2', null, '/roleController/deleteByUidAndRid.do', '1', '', '32ca861bb12011e68bc4507b9dae4454', '2017-11-15 16:16:06', '2017-11-15 16:16:06');
INSERT INTO `c_authority` VALUES ('4e3224c266cc11e783a7507b9dae4454', '52', 'editTopic', '修改栏目', '4', '2', null, '/topicController/editTopic.do', '1', '', '8917027a66ba11e783a7507b9dae4454', '2017-07-12 14:35:29', '2017-07-12 14:35:29');
INSERT INTO `c_authority` VALUES ('4efa49c4ca7f11e7b5d7507b9dae4454', '171', 'updateSubAccount', '修改子账号信息', null, '2', null, '/userController/updateSubAccount.do', '1', '', 'decaa8faca7e11e7b5d7507b9dae4454', '2017-11-16 11:36:20', '2017-11-16 11:36:20');
INSERT INTO `c_authority` VALUES ('504a60c7bfaf11e79515507b9dae4454', '155', 'uploadGoodsStaffPerformanceFile', '上传绩效文件', '9', '2', null, '/staffPerformanceFileController/uploadGoodsStaffPerformanceFile.do', '1', '', 'a804c624beee11e7b827507b9dae4454', '2017-11-02 17:22:15', '2017-11-02 17:22:15');
INSERT INTO `c_authority` VALUES ('523b0a82b12011e68bc4507b9dae4454', '9', 'getRoleList', '查询角色列表', '1', '1', null, '/roleController/getPageData.do', '0', '', '32ca861bb12011e68bc4507b9dae4454', '2016-11-23 09:58:26', null);
INSERT INTO `c_authority` VALUES ('5471a8cd893511e7942f507b9dae4454', '62', 'addFriendLink', '添加友情链接', '2', '2', null, '/friendLinkController/addFriendLink.do', '1', '', 'fcbfeb9f893411e7942f507b9dae4454', '2017-08-25 09:32:48', '2017-08-25 09:32:48');
INSERT INTO `c_authority` VALUES ('55bc7521b14411e68bc4507b9dae4454', '28', 'getDictDetail', '查询数字字典', '4', '2', null, '/dictController/getDetail.do', '1', '', 'f34538adb14311e68bc4507b9dae4454', '2016-11-23 14:16:14', null);
INSERT INTO `c_authority` VALUES ('56d9467ab11f11e68bc4507b9dae4454', '5', 'addAuth', '添加权限', '3', '2', null, '/authController/addAuth.do', '1', '', 'dd77e2b2b11e11e68bc4507b9dae4454', '2016-11-23 09:51:24', null);
INSERT INTO `c_authority` VALUES ('58c245bd8d3611e7b759507b9dae4454', '89', 'getLinkBookDetail', '跳转编辑通讯录', '3', '2', null, '/linkBookController/admin/getDetail.do', '1', '', '7e571cb18d3511e7b759507b9dae4454', '2017-08-30 11:48:52', '2017-08-30 11:48:52');
INSERT INTO `c_authority` VALUES ('5b8e6ce5bfaf11e79515507b9dae4454', '156', 'downloadPerformanceFile', '下载绩效文件', '10', '2', null, '/staffPerformanceFileController/downloadPerformanceFile.do', '1', '', 'a804c624beee11e7b827507b9dae4454', '2017-11-02 17:22:34', '2017-11-02 17:22:34');
INSERT INTO `c_authority` VALUES ('5be7c891c03e11e7ab51507b9dae4454', '158', 'tollStation', '收费站管理', '10', '0', '0', '/tollStationController/viewPage.do', '1', '', '3b5ea9dcb11d11e68bc4507b9dae4454', '2017-11-03 10:26:13', '2017-11-03 10:26:13');
INSERT INTO `c_authority` VALUES ('6123fd3b9e8511e7a438507b9dae4454', '107', 'updateUserByExcel', '导入更新用户信息excel', '9', '1', null, '/userController/updateUserByExcelImport.do', '1', '', 'ad2f2ee6b12011e68bc4507b9dae4454', '2017-09-21 12:29:28', '2017-09-21 12:29:28');
INSERT INTO `c_authority` VALUES ('61ac9dceb12011e68bc4507b9dae4454', '10', 'skipAddRole', '跳转添加角色', '2', '2', null, '/roleController/skipAddRole.do', '1', '', '32ca861bb12011e68bc4507b9dae4454', '2016-11-23 09:58:52', null);
INSERT INTO `c_authority` VALUES ('627ad9f9b14411e68bc4507b9dae4454', '29', 'editDict', '修改数字字典', '5', '2', null, '/dictController/editDict.do', '1', '', 'f34538adb14311e68bc4507b9dae4454', '2016-11-23 14:16:36', null);
INSERT INTO `c_authority` VALUES ('62a7ef708c9911e78adb507b9dae4454', '80', 'department', '部门管理', '11', '0', null, '/departmentController/viewPage.do', '1', '', '3b5ea9dcb11d11e68bc4507b9dae4454', '2017-08-29 17:06:32', '2017-08-29 17:06:32');
INSERT INTO `c_authority` VALUES ('68ef3ea38d3611e7b759507b9dae4454', '90', 'editLinkBook', '编辑通讯录', '4', '2', null, '/linkBookController/admin/editLinkBook.do', '1', '', '7e571cb18d3511e7b759507b9dae4454', '2017-08-30 11:49:19', '2017-08-30 11:49:19');
INSERT INTO `c_authority` VALUES ('69a17420b12311e68bc4507b9dae4454', '20', 'editUser', '修改用户', '5', '2', null, '/userController/editUser.do', '1', '', 'ad2f2ee6b12011e68bc4507b9dae4454', '2016-11-23 10:20:34', null);
INSERT INTO `c_authority` VALUES ('6a8efaf8b11f11e68bc4507b9dae4454', '6', 'getAuthDetail', '查询权限详情', '4', '2', null, '/authController/getDetail.do', '1', '', 'dd77e2b2b11e11e68bc4507b9dae4454', '2016-11-23 09:51:57', null);
INSERT INTO `c_authority` VALUES ('704da868b14411e68bc4507b9dae4454', '30', 'delDict', '删除数字字典', '6', '2', null, '/dictController/delDict.do', '1', '', 'f34538adb14311e68bc4507b9dae4454', '2016-11-23 14:16:59', null);
INSERT INTO `c_authority` VALUES ('70d4278166cb11e783a7507b9dae4454', '49', 'skipAddTopic', '跳转添加栏目', '1', '2', null, '/topicController/skipAddTopic.do', '1', '', '8917027a66ba11e783a7507b9dae4454', '2017-07-12 14:29:17', '2017-07-12 14:29:17');
INSERT INTO `c_authority` VALUES ('71cf8735893511e7942f507b9dae4454', '63', 'getFriendLinkDetail', '跳转编辑友情链接', '3', '2', null, '/friendLinkController/getDetail.do', '1', '', 'fcbfeb9f893411e7942f507b9dae4454', '2017-08-25 09:33:37', '2017-08-25 09:33:37');
INSERT INTO `c_authority` VALUES ('73727785b7c511e79b95507b9dae4454', '118', 'abnormalReceiptsManage', '收款异常事件管理', '1', '0', null, '/abnormalReceiptsController/abnormalReceiptsPage.do', '1', '', 'b1cf6cd8b7c411e79b95507b9dae4454', '2017-10-23 15:40:38', '2017-10-23 15:40:38');
INSERT INTO `c_authority` VALUES ('737d4dbfb7c511e79b95507b9dae4454', '119', 'skipAddAbnormalReceipts', '跳转添加收款异常事件', '1', '2', null, '/abnormalReceiptsController/skipAddAbnormalReceipts.do', '1', null, '73727785b7c511e79b95507b9dae4454', '2017-10-23 15:40:38', '2017-10-23 15:40:38');
INSERT INTO `c_authority` VALUES ('73863e14b7c511e79b95507b9dae4454', '120', 'addAbnormalReceipts', '添加收款异常事件', '2', '2', null, '/abnormalReceiptsController/addAbnormalReceipts.do', '1', null, '73727785b7c511e79b95507b9dae4454', '2017-10-23 15:40:38', '2017-10-23 15:40:38');
INSERT INTO `c_authority` VALUES ('738b1b3bb7c511e79b95507b9dae4454', '121', 'skipEditAbnormalReceipts', '跳转编辑收款异常事件', '3', '2', null, '/abnormalReceiptsController/skipEditAbnormalReceipts.do', '1', null, '73727785b7c511e79b95507b9dae4454', '2017-10-23 15:40:38', '2017-10-23 15:40:38');
INSERT INTO `c_authority` VALUES ('738f8cacb7c511e79b95507b9dae4454', '122', 'editAbnormalReceipts', '编辑收款异常事件', '4', '2', null, '/abnormalReceiptsController/editAbnormalReceipts.do', '1', null, '73727785b7c511e79b95507b9dae4454', '2017-10-23 15:40:38', '2017-10-23 15:40:38');
INSERT INTO `c_authority` VALUES ('7397b65cb7c511e79b95507b9dae4454', '123', 'deleteAbnormalReceipts', '删除收款异常事件', '5', '2', null, '/abnormalReceiptsController/deleteAbnormalReceipts.do', '1', null, '73727785b7c511e79b95507b9dae4454', '2017-10-23 15:40:38', '2017-10-23 15:40:38');
INSERT INTO `c_authority` VALUES ('739dce14b7c511e79b95507b9dae4454', '124', 'queryPageAbnormalReceipts', '分页查询收款异常事件', '6', '2', null, '/abnormalReceiptsController/getPageData.do', '1', null, '73727785b7c511e79b95507b9dae4454', '2017-10-23 15:40:38', '2017-10-23 15:40:38');
INSERT INTO `c_authority` VALUES ('73A67F3C1367404ABBB67D0E111A7366', '33', 'skipAddZonePath', '跳转添加文件路径', '2', '2', null, '/zonePathController/skipAddZonePath.do', '1', '', '144B2E062AFE407B80FFE11494353EA2', '2016-09-01 14:27:49', null);
INSERT INTO `c_authority` VALUES ('73e85a01cb3a11e7b965507b9dae4454', '172', 'switchAccount', '账号切换', '20', '1', null, '/switchAccount.do', '1', '', null, '2017-11-17 09:55:57', '2017-11-17 09:55:57');
INSERT INTO `c_authority` VALUES ('74faf7e3b12011e68bc4507b9dae4454', '11', 'addRole', '添加角色', '3', '2', null, '/roleController/addRole.do', '1', '', '32ca861bb12011e68bc4507b9dae4454', '2016-11-23 09:59:24', null);
INSERT INTO `c_authority` VALUES ('7672b747894111e7942f507b9dae4454', '74', 'manageCompanies', '公司信息管理', '10', '0', null, '/companyController/admin/viewPage.do', '1', '', '3b5ea9dcb11d11e68bc4507b9dae4454', '2017-08-25 10:58:28', '2017-08-25 10:58:28');
INSERT INTO `c_authority` VALUES ('77f188fab11f11e68bc4507b9dae4454', '7', 'delAuth', '删除权限', '5', '2', null, '/authController/delAuth.do', '1', '', 'dd77e2b2b11e11e68bc4507b9dae4454', '2016-11-23 09:52:20', null);
INSERT INTO `c_authority` VALUES ('781df8f1bfb911e79515507b9dae4454', '157', 'exportAbnormalReceiptsWord', '导出收款异常事件表格', '8', '2', null, '/abnormalReceiptsController/exportAbnormalReceiptsWord.do', '1', '', '73727785b7c511e79b95507b9dae4454', '2017-11-02 18:34:57', '2017-11-02 18:34:57');
INSERT INTO `c_authority` VALUES ('7854cafb8d3611e7b759507b9dae4454', '91', 'deleteLinkBook', '删除通讯录', '5', '2', null, '/linkBookController/admin/deleteLinkBook.do', '1', '', '7e571cb18d3511e7b759507b9dae4454', '2017-08-30 11:49:45', '2017-08-30 11:49:45');
INSERT INTO `c_authority` VALUES ('799ff811976e11e79c2b507b9dae4454', '104', 'dmsSingleSignOn', '档案系统', '4', '0', '2', '/dms/singleSignOn.do', '1', 'icon_menu_archive', null, '2017-09-12 11:57:20', '2017-09-12 11:57:20');
INSERT INTO `c_authority` VALUES ('7b633b3566d911e783a7507b9dae4454', '55', 'skipAddContent', '跳转添加文章', '7', '2', null, '/contentController/skipAddContent.do', '1', '', '8917027a66ba11e783a7507b9dae4454', '2017-07-12 16:09:48', '2017-07-12 16:09:48');
INSERT INTO `c_authority` VALUES ('7e571cb18d3511e7b759507b9dae4454', '86', 'listLinkBook', '通讯录列表', '12', '0', null, '/linkBookController/admin/viewPage.do', '1', '', '3b5ea9dcb11d11e68bc4507b9dae4454', '2017-08-30 11:42:45', '2017-08-30 11:42:45');
INSERT INTO `c_authority` VALUES ('80799c34985811e79c1c507b9dae4454', '105', 'topicEditerAuth', '设置栏目权限', '12', '2', null, '/topicController/editerAuth.do', '1', '', '8917027a66ba11e783a7507b9dae4454', '2017-09-13 15:53:00', '2017-09-13 15:53:00');
INSERT INTO `c_authority` VALUES ('816ed601b4ae11e7b9d4507b9dae4454', '109', 'addProcDef', '添加流程定义', '2', '2', null, '/procDefController/addProcDef.do', '1', '', 'c2d8d93cb4ab11e7b9d4507b9dae4454', '2017-10-19 17:18:42', '2017-10-19 17:18:42');
INSERT INTO `c_authority` VALUES ('86C6BA4D08DF4086ABD89CD7C86C5DD6', '34', 'createFileDirectory', '创建物理目录', '7', '2', null, '/zonePathController/createFileDirectory.do', '1', '', '144B2E062AFE407B80FFE11494353EA2', '2016-09-01 14:32:19', null);
INSERT INTO `c_authority` VALUES ('88706b8d893511e7942f507b9dae4454', '64', 'editFriendLink', '编辑友情链接', '4', '2', null, '/friendLinkController/editFriendLink.do', '1', '', 'fcbfeb9f893411e7942f507b9dae4454', '2017-08-25 09:34:15', '2017-08-25 09:34:15');
INSERT INTO `c_authority` VALUES ('8913f497b55e11e7a96c507b9dae4454', '116', 'processManage', '流程管理', '20', '0', null, null, '1', '', '3b5ea9dcb11d11e68bc4507b9dae4454', '2017-10-20 14:18:50', '2017-10-20 14:18:50');
INSERT INTO `c_authority` VALUES ('8917027a66ba11e783a7507b9dae4454', '48', 'topicManager', '栏目管理', '9', '0', null, '/topicController/viewPage.do', '1', '', '3b5ea9dcb11d11e68bc4507b9dae4454', '2017-07-12 12:28:17', '2017-07-12 12:28:17');
INSERT INTO `c_authority` VALUES ('89ef9fb2cb3a11e7b965507b9dae4454', '173', 'j_spring_security_exit_user', '注销子账号', '1', '1', null, '/j_spring_security_exit_user', '0', '', '73e85a01cb3a11e7b965507b9dae4454', '2017-11-17 09:56:34', '2017-11-17 09:56:34');
INSERT INTO `c_authority` VALUES ('8a2ced2db12011e68bc4507b9dae4454', '12', 'getRoleDetail', '查询角色详细', '4', '2', null, '/roleController/viewPage.do', '1', '', '32ca861bb12011e68bc4507b9dae4454', '2016-11-23 10:00:00', null);
INSERT INTO `c_authority` VALUES ('9182ca618d3511e7b759507b9dae4454', '87', 'skipAddLinkBook', '跳转添加通讯录', '1', '2', null, '/linkBookController/admin/skipAddLinkBook.do', '1', '', '7e571cb18d3511e7b759507b9dae4454', '2017-08-30 11:43:17', '2017-08-30 11:43:17');
INSERT INTO `c_authority` VALUES ('93c2cf9b66cb11e783a7507b9dae4454', '50', 'deleteTopic', '删除栏目', '2', '2', null, '/topicController/deleteTopic.do', '1', '', '8917027a66ba11e783a7507b9dae4454', '2017-07-12 14:30:16', '2017-07-12 14:30:16');
INSERT INTO `c_authority` VALUES ('94c80fa28c9911e78adb507b9dae4454', '81', 'skipAddDepartment', '跳转添加部门管理', '1', '2', null, '/departmentController/skipAddDepartment.do', '1', '', '62a7ef708c9911e78adb507b9dae4454', '2017-08-29 17:07:56', '2017-08-29 17:07:56');
INSERT INTO `c_authority` VALUES ('94CEF3D7561F45E4A38E7C5E86A9DF52', '39', 'loginLogManage', '登录日志管理', '6', '0', null, '/loginLogController/viewPage.do', '1', '', '3b5ea9dcb11d11e68bc4507b9dae4454', '2016-08-31 11:26:37', '2017-10-20 14:19:48');
INSERT INTO `c_authority` VALUES ('96f55f60b12011e68bc4507b9dae4454', '13', 'editRole', '修改角色', '5', '2', null, '/roleController/editRole.do', '1', '', '32ca861bb12011e68bc4507b9dae4454', '2016-11-23 10:00:21', null);
INSERT INTO `c_authority` VALUES ('9714477dcb3a11e7b965507b9dae4454', '174', 'j_spring_security_switch_user', '切换子账号', '2', '1', null, '/j_spring_security_switch_user', '0', '', '73e85a01cb3a11e7b965507b9dae4454', '2017-11-17 09:56:56', '2017-11-17 09:56:56');
INSERT INTO `c_authority` VALUES ('98458d15c03e11e7ab51507b9dae4454', '159', 'skipAddTollStation', '跳转添加收费站管理', '1', '2', '0', '/tollStationController/skipAddTollStation.do', '1', '', '5be7c891c03e11e7ab51507b9dae4454', '2017-11-03 10:27:54', '2017-11-03 10:27:54');
INSERT INTO `c_authority` VALUES ('998ae65a911811e7bd2b507b9dae4454', '98', 'loadMyDetail', '查看个人信息', '1', '1', null, '/userController/loadMyDetail.do', '0', '', '3680f6afb12411e68bc4507b9dae4454', '2017-09-04 10:27:32', '2017-09-04 10:27:32');
INSERT INTO `c_authority` VALUES ('9ac43a33b4bb11e7b9d4507b9dae4454', '114', 'designProcess', '设计流程页面', '10', '1', null, '/procNodeController/designProcess.do', '1', '', 'c2d8d93cb4ab11e7b9d4507b9dae4454', '2017-10-19 18:52:32', '2017-10-19 18:52:32');
INSERT INTO `c_authority` VALUES ('a11797e666d511e783a7507b9dae4454', '53', 'getTopicDetail', '跳转编辑栏目', '5', '2', null, '/topicController/getDetail.do', '1', '', '8917027a66ba11e783a7507b9dae4454', '2017-07-12 15:42:13', '2017-07-12 15:42:13');
INSERT INTO `c_authority` VALUES ('a27f75b4b12011e68bc4507b9dae4454', '14', 'delRole', '删除角色', '6', '2', null, '/roleController/delRole.do', '1', '', '32ca861bb12011e68bc4507b9dae4454', '2016-11-23 10:00:41', null);
INSERT INTO `c_authority` VALUES ('a2ed47f066d911e783a7507b9dae4454', '56', 'getContentDetail', '跳转编辑文章', '7', '2', null, '/contentController/getDetail.do', '1', '', '8917027a66ba11e783a7507b9dae4454', '2017-07-12 16:10:55', '2017-07-12 16:10:55');
INSERT INTO `c_authority` VALUES ('a37e1d7b911811e7bd2b507b9dae4454', '99', 'goChangePwd', '修改密码页面', '2', '1', null, '/userController/goChangePwd.do', '0', '', '3680f6afb12411e68bc4507b9dae4454', '2017-09-04 10:27:49', '2017-09-04 10:27:49');
INSERT INTO `c_authority` VALUES ('A485D461507C4C20846944B9EC66D507', '35', 'getZonePathList', '查询文件路径列表', '1', '1', null, '/zonePathController/getPageData.do', '0', '', '144B2E062AFE407B80FFE11494353EA2', '2016-09-01 14:27:17', null);
INSERT INTO `c_authority` VALUES ('a67ab444893511e7942f507b9dae4454', '65', 'deleteFriendLink', '删除友情链接', '5', '2', null, '/friendLinkController/deleteFriendLink.do', '1', '', 'fcbfeb9f893411e7942f507b9dae4454', '2017-08-25 09:35:05', '2017-08-25 09:35:05');
INSERT INTO `c_authority` VALUES ('a804c624beee11e7b827507b9dae4454', '144', 'staffPerformanceManage', '绩效管理', '3', '0', null, '/staffPerformanceController/staffPerformancePage.do', '1', '', 'b1cf6cd8b7c411e79b95507b9dae4454', '2017-11-01 18:23:09', '2017-11-01 18:23:09');
INSERT INTO `c_authority` VALUES ('a810883dbeee11e7b827507b9dae4454', '145', 'skipAddStaffPerformance', '跳转添加绩效', '1', '2', null, '/staffPerformanceController/skipAddStaffPerformance.do', '1', null, 'a804c624beee11e7b827507b9dae4454', '2017-11-01 18:23:10', '2017-11-01 18:23:10');
INSERT INTO `c_authority` VALUES ('a811a8f2beee11e7b827507b9dae4454', '146', 'addStaffPerformance', '添加绩效', '2', '2', null, '/staffPerformanceController/addStaffPerformance.do', '1', null, 'a804c624beee11e7b827507b9dae4454', '2017-11-01 18:23:10', '2017-11-01 18:23:10');
INSERT INTO `c_authority` VALUES ('a8129a8bbeee11e7b827507b9dae4454', '147', 'getStaffPerformanceDetail', '跳转编辑绩效', '3', '2', null, '/staffPerformanceController/getDetail.do', '1', '', 'a804c624beee11e7b827507b9dae4454', '2017-11-01 18:23:10', '2017-11-01 18:23:10');
INSERT INTO `c_authority` VALUES ('a8155b4ebeee11e7b827507b9dae4454', '148', 'editStaffPerformance', '编辑绩效', '4', '2', null, '/staffPerformanceController/editStaffPerformance.do', '1', '', 'a804c624beee11e7b827507b9dae4454', '2017-11-01 18:23:10', '2017-11-01 18:23:10');
INSERT INTO `c_authority` VALUES ('a816909dbeee11e7b827507b9dae4454', '149', 'deleteStaffPerformance', '删除绩效', '5', '2', null, '/staffPerformanceController/deleteStaffPerformance.do', '1', null, 'a804c624beee11e7b827507b9dae4454', '2017-11-01 18:23:10', '2017-11-01 18:23:10');
INSERT INTO `c_authority` VALUES ('a81777a7beee11e7b827507b9dae4454', '150', 'queryPageStaffPerformance', '分页查询绩效', '6', '2', null, '/staffPerformanceController/getPageData.do', '1', null, 'a804c624beee11e7b827507b9dae4454', '2017-11-01 18:23:10', '2017-11-01 18:23:10');
INSERT INTO `c_authority` VALUES ('a9d186698c9911e78adb507b9dae4454', '82', 'addDepartment', '添加部门管理', '2', '2', null, '/departmentController/addDepartment.do', '1', '', '62a7ef708c9911e78adb507b9dae4454', '2017-08-29 17:08:31', '2017-08-29 17:08:31');
INSERT INTO `c_authority` VALUES ('aad42553894111e7942f507b9dae4454', '75', 'skipAddCompany', '跳转添加公司信息', '1', '2', null, '/companyController/admin/skipAddCompany.do', '1', '', '7672b747894111e7942f507b9dae4454', '2017-08-25 10:59:55', '2017-08-25 10:59:55');
INSERT INTO `c_authority` VALUES ('abf47986911811e7bd2b507b9dae4454', '100', 'changePwd', '修改个人密码', '3', '1', null, '/userController/changePwd.do', '1', '', '3680f6afb12411e68bc4507b9dae4454', '2017-09-04 10:28:03', '2017-09-04 10:28:03');
INSERT INTO `c_authority` VALUES ('ad2f2ee6b12011e68bc4507b9dae4454', '15', 'userManage', '用户管理', '1', '0', null, '/userController/viewPage.do', '1', '', '3b5ea9dcb11d11e68bc4507b9dae4454', '2016-11-23 10:00:59', '2017-09-08 10:29:39');
INSERT INTO `c_authority` VALUES ('b1cf6cd8b7c411e79b95507b9dae4454', '117', 'operateManager', '运营管理', '14', '0', '0', null, '1', '', '1b765774bac011e7a2d8507b9dae4454', '2017-10-23 15:35:13', '2017-10-23 15:35:13');
INSERT INTO `c_authority` VALUES ('b314d4b9c03e11e7ab51507b9dae4454', '160', 'addTollStation', '添加收费站管理', '2', '2', '0', '/tollStationController/addTollStation.do', '1', '', '5be7c891c03e11e7ab51507b9dae4454', '2017-11-03 10:28:39', '2017-11-03 10:28:39');
INSERT INTO `c_authority` VALUES ('b5b408c9b12311e68bc4507b9dae4454', '21', 'changePassword', '管理员修改密码', '6', '2', null, '/userController/changePassword.do', '1', '', 'ad2f2ee6b12011e68bc4507b9dae4454', '2016-11-23 10:22:41', null);
INSERT INTO `c_authority` VALUES ('b967316e894111e7942f507b9dae4454', '76', 'addCompany', '添加公司信息', '2', '2', null, '/companyController/admin/addCompany.do', '1', '', '7672b747894111e7942f507b9dae4454', '2017-08-25 11:00:20', '2017-08-25 11:00:20');
INSERT INTO `c_authority` VALUES ('bdc3532666d911e783a7507b9dae4454', '57', 'addContent', '添加文章', '9', '2', null, '/contentController/addContent.do', '1', '', '8917027a66ba11e783a7507b9dae4454', '2017-07-12 16:11:40', '2017-07-12 16:11:40');
INSERT INTO `c_authority` VALUES ('BE67B42B4F4C42258431DF0FCCB8BF1B', '40', 'getloginLogList', '查询登录日志列表', '1', '1', null, '/loginLogController/getPageData.do', '0', '', '94CEF3D7561F45E4A38E7C5E86A9DF52', '2016-08-31 11:30:26', null);
INSERT INTO `c_authority` VALUES ('c2d8d93cb4ab11e7b9d4507b9dae4454', '108', 'prodefManage', '流程定义管理', '1', '0', null, '/procDefController/viewPage.do', '1', '', '8913f497b55e11e7a96c507b9dae4454', '2017-10-19 16:59:04', '2017-10-19 16:59:04');
INSERT INTO `c_authority` VALUES ('c39858afb12311e68bc4507b9dae4454', '22', 'deleteUser', '删除用户', '7', '2', null, '/userController/deleteUser.do', '1', '', 'ad2f2ee6b12011e68bc4507b9dae4454', '2016-11-23 10:23:05', null);
INSERT INTO `c_authority` VALUES ('c7417db0894111e7942f507b9dae4454', '77', 'getCompanyDetail', '跳转编辑公司信息', '3', '2', null, '/companyController/admin/getDetail.do', '1', '', '7672b747894111e7942f507b9dae4454', '2017-08-25 11:00:43', '2017-08-25 11:00:43');
INSERT INTO `c_authority` VALUES ('c9bd3c4eb12111e68bc4507b9dae4454', '16', 'getUserList', '查询用户列表', '1', '1', null, '/userController/getPageData.do', '0', '', 'ad2f2ee6b12011e68bc4507b9dae4454', '2016-11-23 10:08:56', null);
INSERT INTO `c_authority` VALUES ('ca044c59b48211e7b9d4507b9dae4454', '115', 'showPassword', '管理员查看密码', '10', '2', null, '/userController/showPassword.do', '1', '', 'ad2f2ee6b12011e68bc4507b9dae4454', '2017-10-19 12:05:55', '2017-10-19 12:05:55');
INSERT INTO `c_authority` VALUES ('ca94dc3414f111e7b61c507b9dae4454', '42', 'sysLogsManage', '系统日志管理', '8', '0', null, '/sysLogsController/viewPage.do', '1', '', '3b5ea9dcb11d11e68bc4507b9dae4454', '2017-03-30 10:37:18', '2017-03-30 10:37:18');
INSERT INTO `c_authority` VALUES ('d037b56866d911e783a7507b9dae4454', '58', 'editContent', '修改文章', '10', '2', null, '/contentController/editContent.do', '1', '', '8917027a66ba11e783a7507b9dae4454', '2017-07-12 16:12:11', '2017-07-12 16:12:11');
INSERT INTO `c_authority` VALUES ('d474c4a0894111e7942f507b9dae4454', '78', 'editCompany', '编辑公司信息', '4', '2', null, '/companyController/admin/editCompany.do', '1', '', '7672b747894111e7942f507b9dae4454', '2017-08-25 11:01:05', '2017-08-25 11:01:05');
INSERT INTO `c_authority` VALUES ('D610CAB377F2475886011AED0BC04306', '36', 'delZonePath', '删除文件路径', '6', '2', null, '/zonePathController/delZonePath.do', '1', '', '144B2E062AFE407B80FFE11494353EA2', '2016-09-01 14:31:28', null);
INSERT INTO `c_authority` VALUES ('D7A6DB3FD72C4F97A00DAC91E32541A5', '37', 'getZonePathDetail', '查询文件路径详细', '4', '2', null, '/zonePathController/getDetail.do', '1', '', '144B2E062AFE407B80FFE11494353EA2', '2016-09-01 14:29:12', null);
INSERT INTO `c_authority` VALUES ('d8c7282b8df111e78342507b9dae4454', '92', 'msgRecordManage', '信息平台', '13', '0', null, '/msgRecordController/viewPage.do', '1', '', '3b5ea9dcb11d11e68bc4507b9dae4454', '2017-08-31 10:12:11', '2017-08-31 10:12:11');
INSERT INTO `c_authority` VALUES ('dcd0861ab4ae11e7b9d4507b9dae4454', '110', 'skipAddProcDef', '跳转添加流程定义', '3', '2', null, '/procDefController/skipAddProcDef.do', '1', '', 'c2d8d93cb4ab11e7b9d4507b9dae4454', '2017-10-19 17:21:16', '2017-10-19 17:21:16');
INSERT INTO `c_authority` VALUES ('dd77e2b2b11e11e68bc4507b9dae4454', '2', 'authManage', '权限管理', '5', '0', null, '/authController/viewPage.do', '1', '', '3b5ea9dcb11d11e68bc4507b9dae4454', '2016-11-23 09:48:01', '2017-10-20 14:20:05');
INSERT INTO `c_authority` VALUES ('decaa8faca7e11e7b5d7507b9dae4454', '167', 'viewSubAccount', '子账号管理', '11', '1', null, '/userController/viewSubAccount.do', '1', '', 'ad2f2ee6b12011e68bc4507b9dae4454', '2017-11-16 11:33:11', '2017-11-16 11:33:11');
INSERT INTO `c_authority` VALUES ('df84dfb9894111e7942f507b9dae4454', '79', 'deleteCompany', '删除公司信息', '5', '2', null, '/companyController/admin/deleteCompany.do', '1', '', '7672b747894111e7942f507b9dae4454', '2017-08-25 11:01:24', '2017-08-25 11:01:24');
INSERT INTO `c_authority` VALUES ('e1528e3014f111e7b61c507b9dae4454', '43', 'getSysLogsData', '查询系统日志列表', '1', '1', null, '/sysLogsController/getPageData.do', '0', '', 'ca94dc3414f111e7b61c507b9dae4454', '2017-03-30 10:37:56', '2017-03-30 10:37:56');
INSERT INTO `c_authority` VALUES ('e1651ce08c9911e78adb507b9dae4454', '83', 'getDepartmentDetail', '跳转编辑部门管理', '3', '2', null, '/departmentController/getDetail.do', '1', '', '62a7ef708c9911e78adb507b9dae4454', '2017-08-29 17:10:05', '2017-08-29 17:10:05');
INSERT INTO `c_authority` VALUES ('e3d81f31b12111e68bc4507b9dae4454', '17', 'skipAddUser', '跳转添加用户', '2', '2', null, '/userController/skipAddUser.do', '1', '', 'ad2f2ee6b12011e68bc4507b9dae4454', '2016-11-23 10:09:40', null);
INSERT INTO `c_authority` VALUES ('e5855c30c03e11e7ab51507b9dae4454', '161', 'getTollStationDetail', '跳转编辑收费站管理', '3', '2', '0', '/tollStationController/getDetail.do', '1', '', '5be7c891c03e11e7ab51507b9dae4454', '2017-11-03 10:30:04', '2017-11-03 10:30:04');
INSERT INTO `c_authority` VALUES ('e61474b8baef11e7a2d8507b9dae4454', '142', 'goHandleAbnormalReceipts', '办理收费异常事件', '7', '2', null, '/abnormalReceiptsController/goHandlePage.do', '1', '', '73727785b7c511e79b95507b9dae4454', '2017-10-27 16:21:58', '2017-10-27 16:21:58');
INSERT INTO `c_authority` VALUES ('e9be1f7416e511e7aff900163e06a512', '46', 'editAuth', '修改权限', '5', '2', null, '/authController/editAuth.do', '1', '', 'dd77e2b2b11e11e68bc4507b9dae4454', '2017-04-01 22:17:19', '2017-04-01 22:17:19');
INSERT INTO `c_authority` VALUES ('eba53648ca7e11e7b5d7507b9dae4454', '168', 'skipAddSubUser', '跳转添加子账号', '1', '1', null, '/userController/skipAddSubUser.do', '0', '', 'decaa8faca7e11e7b5d7507b9dae4454', '2017-11-16 11:33:33', '2017-11-16 11:33:33');
INSERT INTO `c_authority` VALUES ('ecc58e018df411e78342507b9dae4454', '97', 'addMsgRecord', '添加短信/微信', '5', '2', null, '/msgRecordController/addMsgRecord.do', '1', '', 'd8c7282b8df111e78342507b9dae4454', '2017-08-31 10:34:13', '2017-08-31 10:34:13');
INSERT INTO `c_authority` VALUES ('f07306c48c9911e78adb507b9dae4454', '84', 'editDepartment', '编辑部门管理', '4', '2', null, '/departmentController/editDepartment.do', '1', '', '62a7ef708c9911e78adb507b9dae4454', '2017-08-29 17:10:30', '2017-08-29 17:10:30');
INSERT INTO `c_authority` VALUES ('f34538adb14311e68bc4507b9dae4454', '24', 'dictManage', '数字字典管理', '6', '0', null, '/dictController/viewPage.do', '1', '', '3b5ea9dcb11d11e68bc4507b9dae4454', '2016-11-23 14:13:29', '2017-10-20 14:19:54');
INSERT INTO `c_authority` VALUES ('f463381eca7e11e7b5d7507b9dae4454', '169', 'addSubAccount', '添加子账号', '2', '2', null, '/userController/addSubAccount.do', '1', '', 'decaa8faca7e11e7b5d7507b9dae4454', '2017-11-16 11:33:48', '2017-11-16 11:33:48');
INSERT INTO `c_authority` VALUES ('f80137e1bae811e7a2d8507b9dae4454', '140', 'checkWasteTransfer', '查看废旧资产', '7', '2', '2', '/wasteTransferController/skipCheckWasteTransfer.do', '1', '', '2ea0ab5ebab911e7a2d8507b9dae4454', '2017-10-27 15:32:28', '2017-10-27 15:32:28');
INSERT INTO `c_authority` VALUES ('f98cc659b11e11e68bc4507b9dae4454', '3', 'getAuthList', '查询权限列表', '1', '1', null, '/authController/getPageData.do', '0', '', 'dd77e2b2b11e11e68bc4507b9dae4454', '2016-11-23 09:48:48', null);
INSERT INTO `c_authority` VALUES ('f99fa087bd5011e7be45507b9dae4454', '143', 'goHandleTakeMonitor', '办理调取监控', '7', '2', null, '/takeMonitorController/goHandlePage.do', '1', '', '2549004db7c611e79b95507b9dae4454', '2017-10-30 17:02:00', '2017-10-30 17:02:00');
INSERT INTO `c_authority` VALUES ('fcbfeb9f893411e7942f507b9dae4454', '60', 'friendLink', '友情链接管理', '9', '0', null, '/friendLinkController/viewPage.do', '1', '', '3b5ea9dcb11d11e68bc4507b9dae4454', '2017-08-25 09:30:20', '2017-08-25 09:30:20');
INSERT INTO `c_authority` VALUES ('fcc74dd6c9dc11e7999b507b9dae4454', '165', 'AddUserByRid', '选择用户', '8', '2', null, '/roleController/checkTree.do', '1', '', '32ca861bb12011e68bc4507b9dae4454', '2017-11-15 16:13:54', '2017-11-15 16:13:54');
INSERT INTO `c_authority` VALUES ('fccb2bc6c91711e7b0f1507b9dae4454', '164', 'skipGetUserByRid', '跳转到查看用户', '7', '2', null, '/roleController/skipGetUserByRid.do', '1', '', '32ca861bb12011e68bc4507b9dae4454', '2017-11-14 16:43:46', '2017-11-14 16:43:46');
INSERT INTO `c_authority` VALUES ('FD1EB0BA0AB749C2AA400D225BF1C908', '41', 'delLoginLog', '删除登录日志', '2', '2', null, '/loginLogController/delLoginLog.do', '1', '', '94CEF3D7561F45E4A38E7C5E86A9DF52', '2016-08-31 11:31:01', null);
INSERT INTO `c_authority` VALUES ('fe7e10fa8c9911e78adb507b9dae4454', '85', 'deleteDepartment', '删除部门管理', '5', '2', null, '/departmentController/deleteDepartment.do', '1', '', '62a7ef708c9911e78adb507b9dae4454', '2017-08-29 17:10:53', '2017-08-29 17:10:53');
INSERT INTO `c_authority` VALUES ('FF8D15F2F35340EABA64439982E033C6', '38', 'addZonePath', '添加文件路径', '3', '2', null, '/zonePathController/addZonePath.do', '1', '', '144B2E062AFE407B80FFE11494353EA2', '2016-09-01 14:28:16', null);
INSERT INTO `c_authority` VALUES ('ffd6bba3c03e11e7ab51507b9dae4454', '162', 'editTollStation', '编辑收费站管理', '4', '2', '0', '/tollStationController/editTollStation.do', '1', '', '5be7c891c03e11e7ab51507b9dae4454', '2017-11-03 10:30:48', '2017-11-03 10:30:48');

-- ----------------------------
-- Table structure for c_authority_role
-- ----------------------------
DROP TABLE IF EXISTS `c_authority_role`;
CREATE TABLE `c_authority_role` (
  `role_id` varchar(32) NOT NULL,
  `auth_id` varchar(32) NOT NULL,
  PRIMARY KEY (`auth_id`,`role_id`),
  KEY `FK_i7kop6y8ut3p0cs08l1f7m0dg` (`auth_id`),
  KEY `FK_5kj1hdc1bi0or8skfwh2fvvci` (`role_id`),
  CONSTRAINT `FK_5kj1hdc1bi0or8skfwh2fvvci` FOREIGN KEY (`role_id`) REFERENCES `c_role` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_i7kop6y8ut3p0cs08l1f7m0dg` FOREIGN KEY (`auth_id`) REFERENCES `c_authority` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of c_authority_role
-- ----------------------------
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '06cc6be614f211e7b61c507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '075cef3db14411e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '096b361bca7f11e7b5d7507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '0ab359cfb4b611e7b9d4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '0f95872fb4af11e7b9d4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '12485e29beef11e7b827507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '144B2E062AFE407B80FFE11494353EA2');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '161c6c08bae911e7a2d8507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('08a0ad2b9e7411e784005254003f140b', '181e5ef066da11e783a7507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '181e5ef066da11e783a7507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '1a5bcfe98df311e78342507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '1b765774bac011e7a2d8507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '1f4d1db3c03f11e7ab51507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '1f97c4a2b14411e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '20c1a691944811e7a354507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('348d11f866b111e783a7507b9dae4454', '20c1a691944811e7a354507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '20db6022b12311e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '20f640f48df211e78342507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('348d11f866b111e783a7507b9dae4454', '20f640f48df211e78342507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '225a2560beef11e7b827507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('08a0ad2b9e7411e784005254003f140b', '24e7d1f366d911e783a7507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '24e7d1f366d911e783a7507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '2549004db7c611e79b95507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '254c5410b7c611e79b95507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '254ebf4bb7c611e79b95507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '2552f1f2b7c611e79b95507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '25588feeb7c611e79b95507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '255addacb7c611e79b95507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '255d44f5b7c611e79b95507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '2ea0ab5ebab911e7a2d8507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '2eaaa1b0bab911e7a2d8507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '2eae3fecbab911e7a2d8507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '2eb1ff50bab911e7a2d8507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '2eb99a4bbab911e7a2d8507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '2ebc3cb2bab911e7a2d8507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '2ebec800bab911e7a2d8507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '32ca861bb12011e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '33201f4fbfaf11e79515507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '33C22D17058648ADA85169ACC6D0FE82');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '35b6ee598df211e78342507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('348d11f866b111e783a7507b9dae4454', '35b6ee598df211e78342507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('08a0ad2b9e7411e784005254003f140b', '36422d9966cc11e783a7507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '36422d9966cc11e783a7507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '3680f6afb12411e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('348d11f866b111e783a7507b9dae4454', '3680f6afb12411e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '368d7eaab4af11e7b9d4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '3875e4feb14411e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '3a389a16893511e7942f507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('08a0ad2b9e7411e784005254003f140b', '3b5ea9dcb11d11e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '3b5ea9dcb11d11e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '3f1a0cd3bfaf11e79515507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '409bdf579e8511e7a438507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('9cd17854976e11e79c2b507b9dae4454', '45e80d45976e11e79c2b507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '474011dfb12211e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '4793493c8df211e78342507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '48216baf8d3611e7b759507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '4ad0e0dcb11f11e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '4b1b3fb1c9dd11e7999b507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('08a0ad2b9e7411e784005254003f140b', '4e3224c266cc11e783a7507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '4e3224c266cc11e783a7507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '4efa49c4ca7f11e7b5d7507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '504a60c7bfaf11e79515507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '523b0a82b12011e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '5471a8cd893511e7942f507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '55bc7521b14411e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '56d9467ab11f11e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '58c245bd8d3611e7b759507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '5b8e6ce5bfaf11e79515507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '5be7c891c03e11e7ab51507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '6123fd3b9e8511e7a438507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '61ac9dceb12011e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '627ad9f9b14411e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '62a7ef708c9911e78adb507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '68ef3ea38d3611e7b759507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '69a17420b12311e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '6a8efaf8b11f11e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '704da868b14411e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('08a0ad2b9e7411e784005254003f140b', '70d4278166cb11e783a7507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '70d4278166cb11e783a7507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '71cf8735893511e7942f507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '73727785b7c511e79b95507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '737d4dbfb7c511e79b95507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '73863e14b7c511e79b95507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '738b1b3bb7c511e79b95507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '738f8cacb7c511e79b95507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '7397b65cb7c511e79b95507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '739dce14b7c511e79b95507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '73A67F3C1367404ABBB67D0E111A7366');
INSERT INTO `c_authority_role` VALUES ('c9b99e43cb3a11e7b965507b9dae4454', '73e85a01cb3a11e7b965507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '74faf7e3b12011e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '7672b747894111e7942f507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '77f188fab11f11e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '781df8f1bfb911e79515507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '7854cafb8d3611e7b759507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('bcc612b8976e11e79c2b507b9dae4454', '799ff811976e11e79c2b507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('08a0ad2b9e7411e784005254003f140b', '7b633b3566d911e783a7507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '7b633b3566d911e783a7507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '7e571cb18d3511e7b759507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('edcea2ef991311e781ec507b9dae4454', '80799c34985811e79c1c507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '816ed601b4ae11e7b9d4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '86C6BA4D08DF4086ABD89CD7C86C5DD6');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '88706b8d893511e7942f507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '8913f497b55e11e7a96c507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('08a0ad2b9e7411e784005254003f140b', '8917027a66ba11e783a7507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '8917027a66ba11e783a7507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('c9b99e43cb3a11e7b965507b9dae4454', '89ef9fb2cb3a11e7b965507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '8a2ced2db12011e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '9182ca618d3511e7b759507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('08a0ad2b9e7411e784005254003f140b', '93c2cf9b66cb11e783a7507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '93c2cf9b66cb11e783a7507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '94c80fa28c9911e78adb507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '94CEF3D7561F45E4A38E7C5E86A9DF52');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '96f55f60b12011e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('c9b99e43cb3a11e7b965507b9dae4454', '9714477dcb3a11e7b965507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '98458d15c03e11e7ab51507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '998ae65a911811e7bd2b507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('348d11f866b111e783a7507b9dae4454', '998ae65a911811e7bd2b507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '9ac43a33b4bb11e7b9d4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('08a0ad2b9e7411e784005254003f140b', 'a11797e666d511e783a7507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'a11797e666d511e783a7507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'a27f75b4b12011e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('08a0ad2b9e7411e784005254003f140b', 'a2ed47f066d911e783a7507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'a2ed47f066d911e783a7507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'a37e1d7b911811e7bd2b507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('348d11f866b111e783a7507b9dae4454', 'a37e1d7b911811e7bd2b507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'A485D461507C4C20846944B9EC66D507');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'a67ab444893511e7942f507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'a804c624beee11e7b827507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'a810883dbeee11e7b827507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'a811a8f2beee11e7b827507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'a8129a8bbeee11e7b827507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'a8155b4ebeee11e7b827507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'a816909dbeee11e7b827507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'a81777a7beee11e7b827507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'a9d186698c9911e78adb507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'aad42553894111e7942f507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'abf47986911811e7bd2b507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('348d11f866b111e783a7507b9dae4454', 'abf47986911811e7bd2b507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'ad2f2ee6b12011e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'b1cf6cd8b7c411e79b95507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'b314d4b9c03e11e7ab51507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'b5b408c9b12311e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'b967316e894111e7942f507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('08a0ad2b9e7411e784005254003f140b', 'bdc3532666d911e783a7507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'bdc3532666d911e783a7507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'BE67B42B4F4C42258431DF0FCCB8BF1B');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'c2d8d93cb4ab11e7b9d4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'c39858afb12311e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'c7417db0894111e7942f507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'c9bd3c4eb12111e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'ca044c59b48211e7b9d4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'ca94dc3414f111e7b61c507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('08a0ad2b9e7411e784005254003f140b', 'd037b56866d911e783a7507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'd037b56866d911e783a7507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'd474c4a0894111e7942f507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'D610CAB377F2475886011AED0BC04306');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'D7A6DB3FD72C4F97A00DAC91E32541A5');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'd8c7282b8df111e78342507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'dcd0861ab4ae11e7b9d4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'dd77e2b2b11e11e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'decaa8faca7e11e7b5d7507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'df84dfb9894111e7942f507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'e1528e3014f111e7b61c507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'e1651ce08c9911e78adb507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'e3d81f31b12111e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'e5855c30c03e11e7ab51507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'e61474b8baef11e7a2d8507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'e9be1f7416e511e7aff900163e06a512');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'eba53648ca7e11e7b5d7507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'ecc58e018df411e78342507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('348d11f866b111e783a7507b9dae4454', 'ecc58e018df411e78342507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'f07306c48c9911e78adb507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'f34538adb14311e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'f463381eca7e11e7b5d7507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'f80137e1bae811e7a2d8507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'f98cc659b11e11e68bc4507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'f99fa087bd5011e7be45507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'fcbfeb9f893411e7942f507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'fcc74dd6c9dc11e7999b507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'fccb2bc6c91711e7b0f1507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'FD1EB0BA0AB749C2AA400D225BF1C908');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'fe7e10fa8c9911e78adb507b9dae4454');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'FF8D15F2F35340EABA64439982E033C6');
INSERT INTO `c_authority_role` VALUES ('14065dccb12011e68bc4507b9dae4454', 'ffd6bba3c03e11e7ab51507b9dae4454');

-- ----------------------------
-- Table structure for c_basedict
-- ----------------------------
DROP TABLE IF EXISTS `c_basedict`;
CREATE TABLE `c_basedict` (
  `id` varchar(32) NOT NULL,
  `sort` bigint(20) NOT NULL AUTO_INCREMENT,
  `dict_item` varchar(255) NOT NULL,
  `dict_type` varchar(255) NOT NULL,
  `dict_value` varchar(255) NOT NULL,
  `dict_flag` int(11) NOT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `dict_sort_key` (`sort`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of c_basedict
-- ----------------------------
INSERT INTO `c_basedict` VALUES ('031f6099079711e6aa01507b9dae4454', '2', '正常', 'auth_flag', '0', '1', null, '2016-03-29 12:09:53');
INSERT INTO `c_basedict` VALUES ('031f6102079711e6aa01507b9dae4454', '3', '控制', 'auth_flag', '1', '1', null, '2016-02-29 15:09:19');
INSERT INTO `c_basedict` VALUES ('031f6186079711e6aa01507b9dae4454', '4', '菜单', 'auth_type', '0', '1', null, '2016-02-29 15:10:01');
INSERT INTO `c_basedict` VALUES ('031f6220079711e6aa01507b9dae4454', '5', '访问', 'auth_type', '1', '1', null, '2016-02-29 15:10:16');
INSERT INTO `c_basedict` VALUES ('031f62ba079711e6aa01507b9dae4454', '8', '按钮', 'auth_type', '2', '1', null, '2016-03-03 11:58:39');
INSERT INTO `c_basedict` VALUES ('12cd43d6c1cb11e6b57b507b9dae4454', '67', '后端', 'role_type', '0', '1', null, '2016-12-14 15:01:03');
INSERT INTO `c_basedict` VALUES ('179f18d2c1cb11e6b57b507b9dae4454', '68', '前端', 'role_type', '1', '1', null, '2016-12-14 15:01:11');
INSERT INTO `c_basedict` VALUES ('494e679db56211e7a96c507b9dae4454', '69', '本地打开', 'auth_open_way', '0', '1', '2017-10-20 14:45:41', '2017-10-20 14:45:41');
INSERT INTO `c_basedict` VALUES ('51243df6b56211e7a96c507b9dae4454', '70', '父窗口打开', 'auth_open_way', '1', '1', '2017-10-20 14:45:54', '2017-10-20 14:45:54');
INSERT INTO `c_basedict` VALUES ('5740d484b56211e7a96c507b9dae4454', '71', '新窗口打开', 'auth_open_way', '2', '1', '2017-10-20 14:46:04', '2017-10-20 14:46:04');
INSERT INTO `c_basedict` VALUES ('CA1ABCED526C47A7827DBA07D22DE9D2', '43', '临时文件', 'file_type', 'tempFile', '1', null, '2016-09-27 17:13:54');
INSERT INTO `c_basedict` VALUES ('F21CB370ADF0487B9E7ECB62697DCAEE', '52', '普通文件', 'file_type', 'commomFile', '1', null, '2016-09-01 14:12:54');

-- ----------------------------
-- Table structure for c_company
-- ----------------------------
DROP TABLE IF EXISTS `c_company`;
CREATE TABLE `c_company` (
  `id` varchar(32) NOT NULL,
  `company_no` varchar(50) DEFAULT NULL COMMENT '公司编号',
  `company_name` varchar(50) NOT NULL COMMENT '公司名称',
  `company_addr` varchar(100) DEFAULT NULL COMMENT '公司地址',
  `postal_code` varchar(20) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL COMMENT '备注',
  `banner_img_url` varchar(255) DEFAULT NULL,
  `banner_file_id` bigint(20) DEFAULT NULL,
  `status` smallint(6) DEFAULT NULL COMMENT '状态',
  `flag` smallint(6) DEFAULT NULL COMMENT '标志',
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of c_company
-- ----------------------------
INSERT INTO `c_company` VALUES ('1d3d6854946a11e7a354507b9dae4454', '20170908005', '测试图片', '', '523960', '不带图片，上传图1删除上传图2删除上传图3', '/attachment/view\\2017\\09-08\\5d307ce9-9d03-459a-9a93-9c07e534a943.jpg', '89', null, null, '2017-09-08 15:46:51', '2017-09-14 12:09:16');
INSERT INTO `c_company` VALUES ('3b93bf528ca211e78adb507b9dae4454', '20170829001', 'to-do list', '', null, '1.检查公司编码唯一，公司名唯一\r\n2.公司删除后，部门如何处理？', '/attachment/view\\2017\\09-08\\6b50988b-c0d1-41fc-991a-0432134c2442.jpg', '35', null, null, '2017-08-29 18:08:40', '2017-09-08 09:31:20');
INSERT INTO `c_company` VALUES ('46972469944111e7a354507b9dae4454', '20170908003', '新建添加', '', null, '不带图，修改上传，删除没有返回kw', '/attachment/view\\2017\\09-08\\d09fd4b6-813a-4300-904b-350b256629f2.jpg', '57', null, null, '2017-09-08 10:54:30', '2017-09-08 15:58:51');
INSERT INTO `c_company` VALUES ('4a250b1e946a11e7a354507b9dae4454', '20170908006', '测试图片', '', null, '带图1，删除图1无效，重新上传图2成功，上传图3删除，上传图3删除重新上传图1成功', '/attachment/view\\2017\\09-08\\3e436f39-c1df-49d7-b9bb-7d0bb18f54fe.jpg', '86', null, null, '2017-09-08 15:48:06', '2017-09-08 15:56:05');
INSERT INTO `c_company` VALUES ('5249dc0b946c11e7a354507b9dae4454', '20170908007', '没图片', '', null, '', null, null, null, null, '2017-09-08 16:02:39', '2017-09-08 16:03:05');
INSERT INTO `c_company` VALUES ('59917799944111e7a354507b9dae4454', '20170908004', '新建添加', '', null, '带图1，预览没问题，删除重新上传图2', '/attachment/view\\2017\\09-08\\ec90daa6-0504-4756-b776-645c8a30d3d2.jpg', '52', null, null, '2017-09-08 10:55:02', '2017-09-08 10:59:47');
INSERT INTO `c_company` VALUES ('80540867944111e7a354507b9dae4454', '20170908005', '新建添加', '', null, '带图删除', '/attachment/view\\2017\\09-08\\88e95c65-898b-467c-821d-1dde995f8d35.jpg', '56', null, null, '2017-09-08 10:56:07', '2017-09-08 11:01:55');
INSERT INTO `c_company` VALUES ('a90fa9578ec411e7b1a4507b9dae4454', '999.01', '东莞市公路桥梁开发建设总公司常虎高速公路管理处', '东莞市大岭山镇大塘水库旁', '', '东莞市公路桥梁开发建设总公司常虎高速公路管理处，公司地址是东莞市大岭山镇大塘水库旁，我们主要经营公路 公路货运，您可以拨打电话0769-85650276联系我们。', '/attachment/view\\2017\\09-08\\adc9490a-0f37-4e68-9126-acbf130c80c4.png', '36', null, null, '2017-09-01 11:20:04', '2017-11-17 14:23:21');
INSERT INTO `c_company` VALUES ('aec52e49944111e7a354507b9dae4454', '20170908006', '新建添加', '', null, '带图删除重新上传', '/attachment/view\\2017\\09-08\\7823b7fe-fb51-4a20-af9a-1b3c88e138d8.jpg', '72', null, null, '2017-09-08 10:57:25', '2017-09-08 14:50:30');
INSERT INTO `c_company` VALUES ('d429a192990211e781ec507b9dae4454', '20170914001', '测试邮政编码', '', '523962', '啊', '/attachment/view\\2017\\09-14\\6bc7d21e-bcc1-4507-b5a4-c66c62e98955.jpg', '90', null, null, '2017-09-14 12:09:58', '2017-09-14 12:10:09');
INSERT INTO `c_company` VALUES ('d5f60b0f8ec311e7b1a4507b9dae4454', '999', '东莞市路桥投资建设有限公司', '东莞市东城区莞樟大道55号', '523960', '经营范围:\r\n    公路桥梁的投资、建设、收费、管理与养护；市政公共设施管理；交通物业、交通领域及相关产业的投资和物业管理。(依法须经批准的项目，经相关部门批准后方可开展经营活动)', '/attachment/view\\2017\\09-08\\207baea9-d89f-46b9-ad6b-4c57f4969acb.png', '37', null, null, '2017-09-01 11:14:10', '2017-11-17 14:23:12');

-- ----------------------------
-- Table structure for c_department
-- ----------------------------
DROP TABLE IF EXISTS `c_department`;
CREATE TABLE `c_department` (
  `id` varchar(32) NOT NULL,
  `sort` bigint(20) NOT NULL AUTO_INCREMENT,
  `depart_no` varchar(50) DEFAULT NULL COMMENT '部门编号',
  `depart_name` varchar(50) DEFAULT NULL COMMENT '部门名称',
  `note` varchar(255) DEFAULT NULL COMMENT '备注',
  `level` int(11) DEFAULT NULL COMMENT '等级',
  `status` smallint(6) DEFAULT NULL COMMENT '状态',
  `flag` smallint(6) DEFAULT NULL COMMENT '标志',
  `company_id` varchar(32) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_department_sort` (`sort`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of c_department
-- ----------------------------
INSERT INTO `c_department` VALUES ('15b4d22acb3311e7b965507b9dae4454', '70', '001', '维修部', '', null, null, null, 'a90fa9578ec411e7b1a4507b9dae4454', '2017-11-17 09:03:13', '2017-11-17 09:03:13');
INSERT INTO `c_department` VALUES ('16b35150e2f411e8b0e6507b9dae4454', '85', '11', 'shuj', 'rewrwerw', '1', null, null, 'd5f60b0f8ec311e7b1a4507b9dae4454', '2018-11-08 09:17:37', '2018-11-08 10:23:18');
INSERT INTO `c_department` VALUES ('1a41ad04cb3311e7b965507b9dae4454', '71', '002', '工程部', '', null, null, null, 'a90fa9578ec411e7b1a4507b9dae4454', '2017-11-17 09:03:20', '2017-11-17 09:03:20');
INSERT INTO `c_department` VALUES ('2e83acb2d2a411e8b23c507b9dae4454', '77', '2', 'dasdsa', '', null, null, null, 'd5f60b0f8ec311e7b1a4507b9dae4454', '2018-10-18 15:05:21', '2018-11-08 10:19:37');
INSERT INTO `c_department` VALUES ('30e4d714d2a411e8b23c507b9dae4454', '78', '1', 'fsaad', '', null, null, null, 'd5f60b0f8ec311e7b1a4507b9dae4454', '2018-10-18 15:05:25', '2018-11-08 10:19:46');
INSERT INTO `c_department` VALUES ('3248920bc8ee11e7b0f1507b9dae4454', '67', '54', '设置部门', '', null, null, null, 'd5f60b0f8ec311e7b1a4507b9dae4454', '2017-11-14 11:45:01', '2017-11-14 11:45:01');
INSERT INTO `c_department` VALUES ('38f3abedc8ee11e7b0f1507b9dae4454', '68', '32', '理财部门', '', null, null, null, 'd5f60b0f8ec311e7b1a4507b9dae4454', '2017-11-14 11:45:12', '2017-11-14 11:45:12');
INSERT INTO `c_department` VALUES ('3d410987c8ee11e7b0f1507b9dae4454', '69', '54', '开发部门', '', null, null, null, 'd5f60b0f8ec311e7b1a4507b9dae4454', '2017-11-14 11:45:19', '2017-11-14 11:45:19');
INSERT INTO `c_department` VALUES ('44d630c592b511e780f9507b9dae4454', '9', '9527', '管理部门', '宿舍', '1', null, null, '3b93bf528ca211e78adb507b9dae4454', '2017-09-06 11:41:01', '2017-09-06 11:41:01');
INSERT INTO `c_department` VALUES ('479ada15d2a411e8b23c507b9dae4454', '80', 'b', 'hjfgjgf', '', null, null, null, 'd5f60b0f8ec311e7b1a4507b9dae4454', '2018-10-18 15:06:04', '2018-11-08 10:20:02');
INSERT INTO `c_department` VALUES ('a55a671e92b411e780f9507b9dae4454', '8', '8', '私人的部门', '9527', '1', null, null, '3b93bf528ca211e78adb507b9dae4454', '2017-09-06 11:36:34', '2017-09-06 11:36:34');
INSERT INTO `c_department` VALUES ('b1e46107c8ed11e7b0f1507b9dae4454', '57', '21.3', '保管部门', '', null, null, null, 'd5f60b0f8ec311e7b1a4507b9dae4454', '2017-11-14 11:41:25', '2017-11-17 14:23:48');
INSERT INTO `c_department` VALUES ('b8444263c8ed11e7b0f1507b9dae4454', '58', '321', '开销部门', '', null, null, null, 'd5f60b0f8ec311e7b1a4507b9dae4454', '2017-11-14 11:41:36', '2017-11-14 11:41:36');
INSERT INTO `c_department` VALUES ('bd76b9a0c8ed11e7b0f1507b9dae4454', '59', '3211', '学习部门', '', null, null, null, 'd5f60b0f8ec311e7b1a4507b9dae4454', '2017-11-14 11:41:45', '2017-11-14 11:41:45');
INSERT INTO `c_department` VALUES ('c5721fc2c8ed11e7b0f1507b9dae4454', '60', '45', '财经部门', '', null, null, null, 'd5f60b0f8ec311e7b1a4507b9dae4454', '2017-11-14 11:41:58', '2017-11-14 11:41:58');

-- ----------------------------
-- Table structure for c_department_link
-- ----------------------------
DROP TABLE IF EXISTS `c_department_link`;
CREATE TABLE `c_department_link` (
  `id` varchar(32) NOT NULL,
  `depart_id` varchar(32) DEFAULT NULL,
  `book_id` varchar(32) DEFAULT NULL,
  `flag` smallint(6) DEFAULT NULL COMMENT '标志',
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of c_department_link
-- ----------------------------
INSERT INTO `c_department_link` VALUES ('047eca49e2f311e8b0e6507b9dae4454', '16b35150e2f411e8b0e6507b9dae4454', '920574d8936611e7aafe507b9dae4454', null, '2018-11-08 09:09:57', '2018-11-08 09:09:57');
INSERT INTO `c_department_link` VALUES ('08c5ddafe2f311e8b0e6507b9dae4454', '16b35150e2f411e8b0e6507b9dae4454', '3c4edd8a92d411e780f9507b9dae4454', null, '2018-11-08 09:10:04', '2018-11-08 09:10:04');
INSERT INTO `c_department_link` VALUES ('222f45cae2f411e8b0e6507b9dae4454', '16b35150e2f411e8b0e6507b9dae4454', 'bfdb2b15936611e7aafe507b9dae4454', null, '2018-11-08 09:17:57', '2018-11-08 09:17:57');
INSERT INTO `c_department_link` VALUES ('253ca13de2f411e8b0e6507b9dae4454', '16b35150e2f411e8b0e6507b9dae4454', '3c4b3c6992d411e780f9507b9dae4454', null, '2018-11-08 09:18:02', '2018-11-08 09:18:02');
INSERT INTO `c_department_link` VALUES ('6ea952ffe2f211e8b0e6507b9dae4454', '16b35150e2f411e8b0e6507b9dae4454', '1d850f7c9f3811e7b685507b9dae4454', null, '2018-11-08 09:05:46', '2018-11-08 09:05:46');
INSERT INTO `c_department_link` VALUES ('862e4aace2f711e8b0e6507b9dae4454', '16b35150e2f411e8b0e6507b9dae4454', 'a51ea1779eb111e7a438507b9dae4454', null, '2018-11-08 09:42:13', '2018-11-08 09:42:13');
INSERT INTO `c_department_link` VALUES ('8726e2ece2ef11e8b0e6507b9dae4454', '16b35150e2f411e8b0e6507b9dae4454', '1d7d7a979f3811e7b685507b9dae4454', null, '2018-11-08 08:44:58', '2018-11-08 08:44:58');
INSERT INTO `c_department_link` VALUES ('93e47b7ce2f711e8b0e6507b9dae4454', '16b35150e2f411e8b0e6507b9dae4454', 'c881b58791f811e79ff4507b9dae4454', null, '2018-11-08 09:42:36', '2018-11-08 09:42:36');
INSERT INTO `c_department_link` VALUES ('c216fa26e2f111e8b0e6507b9dae4454', '16b35150e2f411e8b0e6507b9dae4454', '1d8e5d2a9f3811e7b685507b9dae4454', null, '2018-11-08 09:00:56', '2018-11-08 09:00:56');

-- ----------------------------
-- Table structure for c_department_user
-- ----------------------------
DROP TABLE IF EXISTS `c_department_user`;
CREATE TABLE `c_department_user` (
  `id` varchar(32) NOT NULL,
  `depart_id` varchar(32) DEFAULT NULL,
  `user_id` varchar(32) DEFAULT NULL,
  `flag` smallint(6) DEFAULT NULL COMMENT '标志',
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of c_department_user
-- ----------------------------
INSERT INTO `c_department_user` VALUES ('651ab86fc8ee11e7b0f1507b9dae4454', 'bd76b9a0c8ed11e7b0f1507b9dae4454', 'e87b77fb99b411e79af8507b9dae4454', null, '2017-11-14 11:46:26', '2017-11-14 11:46:26');
INSERT INTO `c_department_user` VALUES ('651ed480c8ee11e7b0f1507b9dae4454', 'c5721fc2c8ed11e7b0f1507b9dae4454', 'e87b77fb99b411e79af8507b9dae4454', null, '2017-11-14 11:46:26', '2017-11-14 11:46:26');
INSERT INTO `c_department_user` VALUES ('70a73999c8ee11e7b0f1507b9dae4454', '3d410987c8ee11e7b0f1507b9dae4454', 'ea5cd187943b11e7a354507b9dae4454', null, '2017-11-14 11:46:45', '2017-11-14 11:46:45');
INSERT INTO `c_department_user` VALUES ('70a97bfcc8ee11e7b0f1507b9dae4454', 'b1e46107c8ed11e7b0f1507b9dae4454', 'ea5cd187943b11e7a354507b9dae4454', null, '2017-11-14 11:46:45', '2017-11-14 11:46:45');
INSERT INTO `c_department_user` VALUES ('70abca6ec8ee11e7b0f1507b9dae4454', 'c5721fc2c8ed11e7b0f1507b9dae4454', 'ea5cd187943b11e7a354507b9dae4454', null, '2017-11-14 11:46:45', '2017-11-14 11:46:45');
INSERT INTO `c_department_user` VALUES ('70ae33acc8ee11e7b0f1507b9dae4454', '38f3abedc8ee11e7b0f1507b9dae4454', 'ea5cd187943b11e7a354507b9dae4454', null, '2017-11-14 11:46:45', '2017-11-14 11:46:45');
INSERT INTO `c_department_user` VALUES ('b6d10c3acb4011e7b965507b9dae4454', '15b4d22acb3311e7b965507b9dae4454', '732a522992a211e780f9507b9dae4454', null, '2017-11-17 10:40:47', '2017-11-17 10:40:47');
INSERT INTO `c_department_user` VALUES ('e8551ebae2f211e8b0e6507b9dae4454', '3248920bc8ee11e7b0f1507b9dae4454', '5e5cad819ea111e7a438507b9dae4454', null, '2018-11-08 09:09:10', '2018-11-08 09:09:10');
INSERT INTO `c_department_user` VALUES ('e857a33fe2f211e8b0e6507b9dae4454', '38f3abedc8ee11e7b0f1507b9dae4454', '5e5cad819ea111e7a438507b9dae4454', null, '2018-11-08 09:09:10', '2018-11-08 09:09:10');
INSERT INTO `c_department_user` VALUES ('e858ed45e2f211e8b0e6507b9dae4454', '16b35150e2f411e8b0e6507b9dae4454', '5e5cad819ea111e7a438507b9dae4454', null, '2018-11-08 09:09:10', '2018-11-08 09:09:10');
INSERT INTO `c_department_user` VALUES ('e85a3ddde2f211e8b0e6507b9dae4454', 'b1e46107c8ed11e7b0f1507b9dae4454', '5e5cad819ea111e7a438507b9dae4454', null, '2018-11-08 09:09:10', '2018-11-08 09:09:10');
INSERT INTO `c_department_user` VALUES ('ec70ba7ae2f211e8b0e6507b9dae4454', '38f3abedc8ee11e7b0f1507b9dae4454', '8da0fc4e936611e7aafe507b9dae4454', null, '2018-11-08 09:09:17', '2018-11-08 09:09:17');
INSERT INTO `c_department_user` VALUES ('ec72371ee2f211e8b0e6507b9dae4454', '3d410987c8ee11e7b0f1507b9dae4454', '8da0fc4e936611e7aafe507b9dae4454', null, '2018-11-08 09:09:17', '2018-11-08 09:09:17');
INSERT INTO `c_department_user` VALUES ('ec735221e2f211e8b0e6507b9dae4454', '16b35150e2f411e8b0e6507b9dae4454', '8da0fc4e936611e7aafe507b9dae4454', null, '2018-11-08 09:09:17', '2018-11-08 09:09:17');
INSERT INTO `c_department_user` VALUES ('efde159fe2f211e8b0e6507b9dae4454', '16b35150e2f411e8b0e6507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, '2018-11-08 09:09:23', '2018-11-08 09:09:23');
INSERT INTO `c_department_user` VALUES ('efdec5c2e27311e88f6f507b9dae4454', '3d410987c8ee11e7b0f1507b9dae4454', 'fea77a04c83e11e7a099507b9dae4454', null, '2018-11-07 18:00:19', '2018-11-07 18:00:19');
INSERT INTO `c_department_user` VALUES ('efe041e0e27311e88f6f507b9dae4454', 'b8444263c8ed11e7b0f1507b9dae4454', 'fea77a04c83e11e7a099507b9dae4454', null, '2018-11-07 18:00:19', '2018-11-07 18:00:19');
INSERT INTO `c_department_user` VALUES ('efe2099fe27311e88f6f507b9dae4454', '16b35150e2f411e8b0e6507b9dae4454', 'fea77a04c83e11e7a099507b9dae4454', null, '2018-11-07 18:00:19', '2018-11-07 18:00:19');
INSERT INTO `c_department_user` VALUES ('f3191b26e2f211e8b0e6507b9dae4454', '3d410987c8ee11e7b0f1507b9dae4454', '89efa57992d911e780f9507b9dae4454', null, '2018-11-08 09:09:28', '2018-11-08 09:09:28');
INSERT INTO `c_department_user` VALUES ('f31a82bde2f211e8b0e6507b9dae4454', 'b1e46107c8ed11e7b0f1507b9dae4454', '89efa57992d911e780f9507b9dae4454', null, '2018-11-08 09:09:28', '2018-11-08 09:09:28');
INSERT INTO `c_department_user` VALUES ('f31bda23e2f211e8b0e6507b9dae4454', '16b35150e2f411e8b0e6507b9dae4454', '89efa57992d911e780f9507b9dae4454', null, '2018-11-08 09:09:28', '2018-11-08 09:09:28');
INSERT INTO `c_department_user` VALUES ('f3ae3c71e27311e88f6f507b9dae4454', '16b35150e2f411e8b0e6507b9dae4454', '013171ed66b111e783a7507b9dae4454', null, '2018-11-07 18:00:26', '2018-11-07 18:00:26');
INSERT INTO `c_department_user` VALUES ('f64d8cabe2f211e8b0e6507b9dae4454', '3248920bc8ee11e7b0f1507b9dae4454', 'b3711856944311e7a354507b9dae4454', null, '2018-11-08 09:09:33', '2018-11-08 09:09:33');
INSERT INTO `c_department_user` VALUES ('f64f0ddfe2f211e8b0e6507b9dae4454', '38f3abedc8ee11e7b0f1507b9dae4454', 'b3711856944311e7a354507b9dae4454', null, '2018-11-08 09:09:33', '2018-11-08 09:09:33');
INSERT INTO `c_department_user` VALUES ('f65039cae2f211e8b0e6507b9dae4454', '16b35150e2f411e8b0e6507b9dae4454', 'b3711856944311e7a354507b9dae4454', null, '2018-11-08 09:09:33', '2018-11-08 09:09:33');
INSERT INTO `c_department_user` VALUES ('f65197fbe2f211e8b0e6507b9dae4454', 'b1e46107c8ed11e7b0f1507b9dae4454', 'b3711856944311e7a354507b9dae4454', null, '2018-11-08 09:09:33', '2018-11-08 09:09:33');

-- ----------------------------
-- Table structure for c_link_book
-- ----------------------------
DROP TABLE IF EXISTS `c_link_book`;
CREATE TABLE `c_link_book` (
  `id` varchar(32) NOT NULL,
  `sort` bigint(20) NOT NULL AUTO_INCREMENT,
  `sort_no` int(11) DEFAULT NULL COMMENT '排序号',
  `chinese_name` varchar(20) DEFAULT NULL COMMENT '姓名',
  `duty` varchar(50) DEFAULT NULL COMMENT '职务',
  `phone` varchar(50) DEFAULT NULL COMMENT '手机号码',
  `internal_tel` varchar(50) DEFAULT NULL COMMENT '内线电话',
  `short_tel` varchar(50) DEFAULT NULL COMMENT '短号',
  `email` varchar(100) DEFAULT NULL COMMENT '电子邮箱',
  `link_address` varchar(100) DEFAULT NULL COMMENT '联系地址',
  `note` varchar(255) DEFAULT NULL COMMENT '备注',
  `weixin_code` varchar(50) DEFAULT NULL,
  `bind_user_id` varchar(32) DEFAULT NULL COMMENT '关联用户id',
  `status` smallint(6) DEFAULT NULL COMMENT '状态',
  `flag` smallint(6) DEFAULT NULL COMMENT '标志',
  `company_id` varchar(32) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_linkbook_sort` (`sort`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=209 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of c_link_book
-- ----------------------------
INSERT INTO `c_link_book` VALUES ('05ed083f8efc11e7b1a4507b9dae4454', '39', null, '汤姆', '', '13800138000', '', '', '', '', '', 'zjr', null, null, null, 'a90fa9578ec411e7b1a4507b9dae4454', '2017-09-01 17:56:23', '2017-09-06 09:34:17');
INSERT INTO `c_link_book` VALUES ('1d7d7a979f3811e7b685507b9dae4454', '205', null, '托马斯', '', '13800138010', '', '', '578707139@qq.com', '', '', '', '5e5cad819ea111e7a438507b9dae4454', null, null, 'd5f60b0f8ec311e7b1a4507b9dae4454', '2017-09-22 09:46:21', '2018-11-08 08:44:58');
INSERT INTO `c_link_book` VALUES ('1d850f7c9f3811e7b685507b9dae4454', '206', null, '2323', '', '', '', '', '', '', '', '', 'b3711856944311e7a354507b9dae4454', null, null, 'd5f60b0f8ec311e7b1a4507b9dae4454', '2017-09-22 09:46:21', '2018-11-08 09:05:46');
INSERT INTO `c_link_book` VALUES ('1d8d10f59f3811e7b685507b9dae4454', '207', null, '', null, '13713096963', null, null, '', '', null, 'linlimei', 'e87b77fb99b411e79af8507b9dae4454', null, null, 'd5f60b0f8ec311e7b1a4507b9dae4454', '2017-09-22 09:46:21', '2017-09-22 09:46:21');
INSERT INTO `c_link_book` VALUES ('1d8e5d2a9f3811e7b685507b9dae4454', '208', null, 'bgs', '', '', '', '', '', '', '', '', 'ea5cd187943b11e7a354507b9dae4454', null, null, 'd5f60b0f8ec311e7b1a4507b9dae4454', '2017-09-22 09:46:21', '2018-11-08 09:00:56');
INSERT INTO `c_link_book` VALUES ('3c473cc592d411e780f9507b9dae4454', '189', null, '游客', '', '13800138008', '', '', '', '', '', 'lzx', '013171ed66b111e783a7507b9dae4454', null, null, 'd5f60b0f8ec311e7b1a4507b9dae4454', '2017-09-06 15:21:29', '2017-09-07 10:48:01');
INSERT INTO `c_link_book` VALUES ('3c4b3c6992d411e780f9507b9dae4454', '190', '2', '库大兴', '副主任', '18766789631', '', '', '', '', '', 'zjf', '5f4a9af092d211e780f9507b9dae4454', null, null, 'd5f60b0f8ec311e7b1a4507b9dae4454', '2017-09-06 15:21:29', '2018-11-08 09:18:02');
INSERT INTO `c_link_book` VALUES ('3c4edd8a92d411e780f9507b9dae4454', '191', null, '管理员', '', '15920231523', '', '', '454654654@qq.com', '', '', 'wanve_weixin', 'e20afce4b12511e68bc4507b9dae4454', null, null, 'd5f60b0f8ec311e7b1a4507b9dae4454', '2017-09-06 15:21:29', '2018-11-08 09:10:04');
INSERT INTO `c_link_book` VALUES ('823d52fc915911e7bd2b507b9dae4454', '63', null, '白羊', '软件设计师', '13800138001', '', '', '', '', '123', 'lzx', null, null, null, 'a90fa9578ec411e7b1a4507b9dae4454', '2017-09-04 18:10:33', '2017-09-05 17:27:07');
INSERT INTO `c_link_book` VALUES ('920574d8936611e7aafe507b9dae4454', '202', null, '11', '', '', '', '', '', '', '', '', '8da0fc4e936611e7aafe507b9dae4454', null, null, 'd5f60b0f8ec311e7b1a4507b9dae4454', '2017-09-07 08:50:10', '2018-11-08 09:09:57');
INSERT INTO `c_link_book` VALUES ('a51ea1779eb111e7a438507b9dae4454', '204', '1', '卢主任', '主任', '', '', '', '', '', '', '', null, null, null, 'd5f60b0f8ec311e7b1a4507b9dae4454', '2017-09-21 17:43:50', '2018-11-08 09:42:13');
INSERT INTO `c_link_book` VALUES ('bfdb2b15936611e7aafe507b9dae4454', '203', '1', '杨过', '', '', '845', '62350', '', '', '', '', '89efa57992d911e780f9507b9dae4454', null, null, 'd5f60b0f8ec311e7b1a4507b9dae4454', '2017-09-07 08:51:27', '2018-11-08 09:17:57');
INSERT INTO `c_link_book` VALUES ('c881b58791f811e79ff4507b9dae4454', '95', null, '测试手机号码不能重复', '修', '13800138002', '改', '没', '有', '问', '题', '宿舍', null, null, null, 'd5f60b0f8ec311e7b1a4507b9dae4454', '2017-09-05 13:11:49', '2018-11-08 09:42:36');
INSERT INTO `c_link_book` VALUES ('e816eecd92de11e780f9507b9dae4454', '193', null, '托马斯', null, '13800138005', null, null, '', '', null, null, '732a522992a211e780f9507b9dae4454', null, null, 'a90fa9578ec411e7b1a4507b9dae4454', '2017-09-06 16:37:52', '2017-09-06 16:37:52');
INSERT INTO `c_link_book` VALUES ('e81aa60692de11e780f9507b9dae4454', '194', null, 'sss', null, '13800138011', null, null, '', '', null, '', '7ebcb5a892ab11e780f9507b9dae4454', null, null, 'a90fa9578ec411e7b1a4507b9dae4454', '2017-09-06 16:37:52', '2017-09-06 16:37:52');
INSERT INTO `c_link_book` VALUES ('e820032592de11e780f9507b9dae4454', '195', null, '', null, '', null, null, '', '', null, null, '8544c5dc92a011e780f9507b9dae4454', null, null, 'a90fa9578ec411e7b1a4507b9dae4454', '2017-09-06 16:37:52', '2017-09-06 16:37:52');
INSERT INTO `c_link_book` VALUES ('e823224692de11e780f9507b9dae4454', '196', null, '测试1', null, '', null, null, '', '', null, null, '9ba4cc52929e11e780f9507b9dae4454', null, null, 'a90fa9578ec411e7b1a4507b9dae4454', '2017-09-06 16:37:52', '2017-09-06 16:37:52');
INSERT INTO `c_link_book` VALUES ('e829522a92de11e780f9507b9dae4454', '197', null, '测试', null, '', null, null, '', '', null, null, 'b030839992a011e780f9507b9dae4454', null, null, 'a90fa9578ec411e7b1a4507b9dae4454', '2017-09-06 16:37:52', '2017-09-06 16:37:52');
INSERT INTO `c_link_book` VALUES ('e82d79d892de11e780f9507b9dae4454', '198', null, '', null, '', null, null, '', '', null, '2332', 'd06792ec92ce11e780f9507b9dae4454', null, null, 'a90fa9578ec411e7b1a4507b9dae4454', '2017-09-06 16:37:52', '2017-09-06 16:37:52');
INSERT INTO `c_link_book` VALUES ('e832773c92de11e780f9507b9dae4454', '199', null, '', null, '', null, null, '', '', null, null, 'd2c75c3e921811e79ff4507b9dae4454', null, null, 'a90fa9578ec411e7b1a4507b9dae4454', '2017-09-06 16:37:52', '2017-09-06 16:37:52');
INSERT INTO `c_link_book` VALUES ('e8366d4d92de11e780f9507b9dae4454', '200', null, '', null, '', null, null, '', '', null, null, 'ded050e18efb11e7b1a4507b9dae4454', null, null, 'a90fa9578ec411e7b1a4507b9dae4454', '2017-09-06 16:37:52', '2017-09-06 16:37:52');

-- ----------------------------
-- Table structure for c_login_log
-- ----------------------------
DROP TABLE IF EXISTS `c_login_log`;
CREATE TABLE `c_login_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(32) DEFAULT NULL,
  `user_name` varchar(50) NOT NULL,
  `login_ip` bigint(20) NOT NULL,
  `log_details` varchar(255) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3305 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of c_login_log
-- ----------------------------
INSERT INTO `c_login_log` VALUES ('1375', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-20 16:19:22', '2017-03-20 16:19:22');
INSERT INTO `c_login_log` VALUES ('1376', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-20 16:20:37', '2017-03-20 16:20:37');
INSERT INTO `c_login_log` VALUES ('1377', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-21 17:27:18', '2017-03-21 17:27:18');
INSERT INTO `c_login_log` VALUES ('1378', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-21 18:00:32', '2017-03-21 18:00:32');
INSERT INTO `c_login_log` VALUES ('1379', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-21 18:01:53', '2017-03-21 18:01:53');
INSERT INTO `c_login_log` VALUES ('1380', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-21 18:02:39', '2017-03-21 18:02:39');
INSERT INTO `c_login_log` VALUES ('1381', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-21 18:06:44', '2017-03-21 18:06:44');
INSERT INTO `c_login_log` VALUES ('1382', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-21 18:12:58', '2017-03-21 18:12:58');
INSERT INTO `c_login_log` VALUES ('1383', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-22 10:11:55', '2017-03-22 10:11:55');
INSERT INTO `c_login_log` VALUES ('1384', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-22 10:15:47', '2017-03-22 10:15:47');
INSERT INTO `c_login_log` VALUES ('1385', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-22 10:19:22', '2017-03-22 10:19:22');
INSERT INTO `c_login_log` VALUES ('1386', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-22 12:34:30', '2017-03-22 12:34:30');
INSERT INTO `c_login_log` VALUES ('1387', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-22 17:39:07', '2017-03-22 17:39:07');
INSERT INTO `c_login_log` VALUES ('1388', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-22 18:14:12', '2017-03-22 18:14:12');
INSERT INTO `c_login_log` VALUES ('1389', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-22 18:14:41', '2017-03-22 18:14:41');
INSERT INTO `c_login_log` VALUES ('1390', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-23 09:08:55', '2017-03-23 09:08:55');
INSERT INTO `c_login_log` VALUES ('1391', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-23 09:09:44', '2017-03-23 09:09:44');
INSERT INTO `c_login_log` VALUES ('1392', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-23 09:10:34', '2017-03-23 09:10:34');
INSERT INTO `c_login_log` VALUES ('1393', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-23 09:15:14', '2017-03-23 09:15:14');
INSERT INTO `c_login_log` VALUES ('1394', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-23 09:19:08', '2017-03-23 09:19:08');
INSERT INTO `c_login_log` VALUES ('1395', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-27 09:26:39', '2017-03-27 09:26:39');
INSERT INTO `c_login_log` VALUES ('1396', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-27 09:28:19', '2017-03-27 09:28:19');
INSERT INTO `c_login_log` VALUES ('1397', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-27 09:32:21', '2017-03-27 09:32:21');
INSERT INTO `c_login_log` VALUES ('1398', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-27 09:33:59', '2017-03-27 09:33:59');
INSERT INTO `c_login_log` VALUES ('1399', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-27 09:44:55', '2017-03-27 09:44:55');
INSERT INTO `c_login_log` VALUES ('1400', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-27 10:19:01', '2017-03-27 10:19:01');
INSERT INTO `c_login_log` VALUES ('1401', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-27 10:21:48', '2017-03-27 10:21:48');
INSERT INTO `c_login_log` VALUES ('1402', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-27 10:26:03', '2017-03-27 10:26:03');
INSERT INTO `c_login_log` VALUES ('1403', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-27 10:39:32', '2017-03-27 10:39:32');
INSERT INTO `c_login_log` VALUES ('1404', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-27 10:45:56', '2017-03-27 10:45:56');
INSERT INTO `c_login_log` VALUES ('1405', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-27 10:48:14', '2017-03-27 10:48:14');
INSERT INTO `c_login_log` VALUES ('1406', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-27 10:52:07', '2017-03-27 10:52:07');
INSERT INTO `c_login_log` VALUES ('1407', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-27 11:20:24', '2017-03-27 11:20:24');
INSERT INTO `c_login_log` VALUES ('1408', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-28 08:47:34', '2017-03-28 08:47:34');
INSERT INTO `c_login_log` VALUES ('1409', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-28 08:47:58', '2017-03-28 08:47:58');
INSERT INTO `c_login_log` VALUES ('1410', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-28 08:48:29', '2017-03-28 08:48:29');
INSERT INTO `c_login_log` VALUES ('1411', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-28 08:49:18', '2017-03-28 08:49:18');
INSERT INTO `c_login_log` VALUES ('1412', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-28 08:51:06', '2017-03-28 08:51:06');
INSERT INTO `c_login_log` VALUES ('1413', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-28 08:57:27', '2017-03-28 08:57:27');
INSERT INTO `c_login_log` VALUES ('1414', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-28 09:19:21', '2017-03-28 09:19:21');
INSERT INTO `c_login_log` VALUES ('1415', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-29 10:39:57', '2017-03-29 10:39:57');
INSERT INTO `c_login_log` VALUES ('1416', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-29 11:21:01', '2017-03-29 11:21:01');
INSERT INTO `c_login_log` VALUES ('1417', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-29 15:29:59', '2017-03-29 15:29:59');
INSERT INTO `c_login_log` VALUES ('1418', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-30 10:36:02', '2017-03-30 10:36:02');
INSERT INTO `c_login_log` VALUES ('1419', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-30 10:40:29', '2017-03-30 10:40:29');
INSERT INTO `c_login_log` VALUES ('1420', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-30 10:51:15', '2017-03-30 10:51:15');
INSERT INTO `c_login_log` VALUES ('1421', null, 'admin', '2130706433', '用户成功登录系统', '2017-03-30 10:52:08', '2017-03-30 10:52:08');
INSERT INTO `c_login_log` VALUES ('1422', null, 'admin', '2130706433', '用户成功登录系统', '2017-04-01 17:40:24', '2017-04-01 17:40:24');
INSERT INTO `c_login_log` VALUES ('1423', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-11 10:09:19', '2017-07-11 10:09:19');
INSERT INTO `c_login_log` VALUES ('1424', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-11 10:11:07', '2017-07-11 10:11:07');
INSERT INTO `c_login_log` VALUES ('1425', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-11 10:15:16', '2017-07-11 10:15:16');
INSERT INTO `c_login_log` VALUES ('1426', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-11 10:30:08', '2017-07-11 10:30:08');
INSERT INTO `c_login_log` VALUES ('1427', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-11 10:35:57', '2017-07-11 10:35:57');
INSERT INTO `c_login_log` VALUES ('1428', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-11 12:14:38', '2017-07-11 12:14:38');
INSERT INTO `c_login_log` VALUES ('1429', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-11 12:23:21', '2017-07-11 12:23:21');
INSERT INTO `c_login_log` VALUES ('1430', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-11 15:39:54', '2017-07-11 15:39:54');
INSERT INTO `c_login_log` VALUES ('1431', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-11 15:44:05', '2017-07-11 15:44:05');
INSERT INTO `c_login_log` VALUES ('1432', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-11 15:44:41', '2017-07-11 15:44:41');
INSERT INTO `c_login_log` VALUES ('1433', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-11 15:51:36', '2017-07-11 15:51:36');
INSERT INTO `c_login_log` VALUES ('1434', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-11 15:57:17', '2017-07-11 15:57:17');
INSERT INTO `c_login_log` VALUES ('1435', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-11 16:13:55', '2017-07-11 16:13:55');
INSERT INTO `c_login_log` VALUES ('1436', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-12 10:34:12', '2017-07-12 10:34:12');
INSERT INTO `c_login_log` VALUES ('1437', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-12 11:00:02', '2017-07-12 11:00:02');
INSERT INTO `c_login_log` VALUES ('1438', null, 'guide', '2130706433', '用户成功登录系统', '2017-07-12 11:21:59', '2017-07-12 11:21:59');
INSERT INTO `c_login_log` VALUES ('1439', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-12 12:05:33', '2017-07-12 12:05:33');
INSERT INTO `c_login_log` VALUES ('1440', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-12 12:21:18', '2017-07-12 12:21:18');
INSERT INTO `c_login_log` VALUES ('1441', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-12 12:28:30', '2017-07-12 12:28:30');
INSERT INTO `c_login_log` VALUES ('1442', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-12 12:29:02', '2017-07-12 12:29:02');
INSERT INTO `c_login_log` VALUES ('1443', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-12 14:11:06', '2017-07-12 14:11:06');
INSERT INTO `c_login_log` VALUES ('1444', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-12 14:16:30', '2017-07-12 14:16:30');
INSERT INTO `c_login_log` VALUES ('1445', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-12 14:23:07', '2017-07-12 14:23:07');
INSERT INTO `c_login_log` VALUES ('1446', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-12 14:30:50', '2017-07-12 14:30:50');
INSERT INTO `c_login_log` VALUES ('1447', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-12 14:36:11', '2017-07-12 14:36:11');
INSERT INTO `c_login_log` VALUES ('1448', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-12 15:36:16', '2017-07-12 15:36:16');
INSERT INTO `c_login_log` VALUES ('1449', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-12 15:42:45', '2017-07-12 15:42:45');
INSERT INTO `c_login_log` VALUES ('1450', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-12 16:02:47', '2017-07-12 16:02:47');
INSERT INTO `c_login_log` VALUES ('1451', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-12 16:08:13', '2017-07-12 16:08:13');
INSERT INTO `c_login_log` VALUES ('1452', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-12 16:13:07', '2017-07-12 16:13:07');
INSERT INTO `c_login_log` VALUES ('1453', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-12 16:14:37', '2017-07-12 16:14:37');
INSERT INTO `c_login_log` VALUES ('1454', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-12 16:30:15', '2017-07-12 16:30:15');
INSERT INTO `c_login_log` VALUES ('1455', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-12 16:46:57', '2017-07-12 16:46:57');
INSERT INTO `c_login_log` VALUES ('1456', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-12 17:41:57', '2017-07-12 17:41:57');
INSERT INTO `c_login_log` VALUES ('1457', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-12 17:54:28', '2017-07-12 17:54:28');
INSERT INTO `c_login_log` VALUES ('1458', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-12 18:05:20', '2017-07-12 18:05:20');
INSERT INTO `c_login_log` VALUES ('1459', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-12 18:10:25', '2017-07-12 18:10:25');
INSERT INTO `c_login_log` VALUES ('1460', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-12 18:13:43', '2017-07-12 18:13:43');
INSERT INTO `c_login_log` VALUES ('1461', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-13 18:04:42', '2017-07-13 18:04:42');
INSERT INTO `c_login_log` VALUES ('1462', null, 'admin', '2130706433', '用户成功登录系统', '2017-07-26 17:29:39', '2017-07-26 17:29:39');
INSERT INTO `c_login_log` VALUES ('1463', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-21 11:09:02', '2017-08-21 11:09:02');
INSERT INTO `c_login_log` VALUES ('1464', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-21 11:26:16', '2017-08-21 11:26:16');
INSERT INTO `c_login_log` VALUES ('1465', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-21 11:30:53', '2017-08-21 11:30:53');
INSERT INTO `c_login_log` VALUES ('1466', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-21 11:31:22', '2017-08-21 11:31:22');
INSERT INTO `c_login_log` VALUES ('1467', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-21 15:24:33', '2017-08-21 15:24:33');
INSERT INTO `c_login_log` VALUES ('1468', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-21 18:09:49', '2017-08-21 18:09:49');
INSERT INTO `c_login_log` VALUES ('1469', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-22 16:49:56', '2017-08-22 16:49:56');
INSERT INTO `c_login_log` VALUES ('1470', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-22 17:03:04', '2017-08-22 17:03:04');
INSERT INTO `c_login_log` VALUES ('1471', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-23 09:21:29', '2017-08-23 09:21:29');
INSERT INTO `c_login_log` VALUES ('1472', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-24 09:44:59', '2017-08-24 09:44:59');
INSERT INTO `c_login_log` VALUES ('1473', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-24 09:46:11', '2017-08-24 09:46:11');
INSERT INTO `c_login_log` VALUES ('1474', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-24 10:29:17', '2017-08-24 10:29:17');
INSERT INTO `c_login_log` VALUES ('1475', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-24 10:36:22', '2017-08-24 10:36:22');
INSERT INTO `c_login_log` VALUES ('1476', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-24 10:37:45', '2017-08-24 10:37:45');
INSERT INTO `c_login_log` VALUES ('1477', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-24 11:14:40', '2017-08-24 11:14:40');
INSERT INTO `c_login_log` VALUES ('1478', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-24 11:40:01', '2017-08-24 11:40:01');
INSERT INTO `c_login_log` VALUES ('1479', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-24 12:16:20', '2017-08-24 12:16:20');
INSERT INTO `c_login_log` VALUES ('1480', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-24 14:25:55', '2017-08-24 14:25:55');
INSERT INTO `c_login_log` VALUES ('1481', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-24 16:18:04', '2017-08-24 16:18:04');
INSERT INTO `c_login_log` VALUES ('1482', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-25 09:04:10', '2017-08-25 09:04:10');
INSERT INTO `c_login_log` VALUES ('1483', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-25 09:22:12', '2017-08-25 09:22:12');
INSERT INTO `c_login_log` VALUES ('1484', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-25 09:42:47', '2017-08-25 09:42:47');
INSERT INTO `c_login_log` VALUES ('1485', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-25 09:44:17', '2017-08-25 09:44:17');
INSERT INTO `c_login_log` VALUES ('1486', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-25 09:44:37', '2017-08-25 09:44:37');
INSERT INTO `c_login_log` VALUES ('1487', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-25 09:44:37', '2017-08-25 09:44:37');
INSERT INTO `c_login_log` VALUES ('1488', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-25 09:49:11', '2017-08-25 09:49:11');
INSERT INTO `c_login_log` VALUES ('1489', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-25 09:51:23', '2017-08-25 09:51:23');
INSERT INTO `c_login_log` VALUES ('1490', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-25 09:51:48', '2017-08-25 09:51:48');
INSERT INTO `c_login_log` VALUES ('1491', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-25 09:53:33', '2017-08-25 09:53:33');
INSERT INTO `c_login_log` VALUES ('1492', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-25 09:55:04', '2017-08-25 09:55:04');
INSERT INTO `c_login_log` VALUES ('1493', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-25 09:57:33', '2017-08-25 09:57:33');
INSERT INTO `c_login_log` VALUES ('1494', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-25 10:14:08', '2017-08-25 10:14:08');
INSERT INTO `c_login_log` VALUES ('1495', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-25 10:21:04', '2017-08-25 10:21:04');
INSERT INTO `c_login_log` VALUES ('1496', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-25 10:35:07', '2017-08-25 10:35:07');
INSERT INTO `c_login_log` VALUES ('1497', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-25 10:40:42', '2017-08-25 10:40:42');
INSERT INTO `c_login_log` VALUES ('1498', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-25 10:41:44', '2017-08-25 10:41:44');
INSERT INTO `c_login_log` VALUES ('1499', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-25 10:43:15', '2017-08-25 10:43:15');
INSERT INTO `c_login_log` VALUES ('1500', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-25 10:57:30', '2017-08-25 10:57:30');
INSERT INTO `c_login_log` VALUES ('1501', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-25 11:01:57', '2017-08-25 11:01:57');
INSERT INTO `c_login_log` VALUES ('1502', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-25 11:16:23', '2017-08-25 11:16:23');
INSERT INTO `c_login_log` VALUES ('1503', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-25 12:17:43', '2017-08-25 12:17:43');
INSERT INTO `c_login_log` VALUES ('1504', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-25 12:18:26', '2017-08-25 12:18:26');
INSERT INTO `c_login_log` VALUES ('1505', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-25 12:21:59', '2017-08-25 12:21:59');
INSERT INTO `c_login_log` VALUES ('1506', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-25 14:06:26', '2017-08-25 14:06:26');
INSERT INTO `c_login_log` VALUES ('1507', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-25 14:09:06', '2017-08-25 14:09:06');
INSERT INTO `c_login_log` VALUES ('1508', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-25 14:23:13', '2017-08-25 14:23:13');
INSERT INTO `c_login_log` VALUES ('1509', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-25 14:23:37', '2017-08-25 14:23:37');
INSERT INTO `c_login_log` VALUES ('1510', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-25 14:34:20', '2017-08-25 14:34:20');
INSERT INTO `c_login_log` VALUES ('1511', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-25 14:39:01', '2017-08-25 14:39:01');
INSERT INTO `c_login_log` VALUES ('1512', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-25 16:34:26', '2017-08-25 16:34:26');
INSERT INTO `c_login_log` VALUES ('1513', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-25 16:40:42', '2017-08-25 16:40:42');
INSERT INTO `c_login_log` VALUES ('1514', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-25 17:25:19', '2017-08-25 17:25:19');
INSERT INTO `c_login_log` VALUES ('1515', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-28 08:43:07', '2017-08-28 08:43:07');
INSERT INTO `c_login_log` VALUES ('1516', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-28 08:47:47', '2017-08-28 08:47:47');
INSERT INTO `c_login_log` VALUES ('1517', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-28 08:53:37', '2017-08-28 08:53:37');
INSERT INTO `c_login_log` VALUES ('1518', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-28 09:12:28', '2017-08-28 09:12:28');
INSERT INTO `c_login_log` VALUES ('1519', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-28 09:19:32', '2017-08-28 09:19:32');
INSERT INTO `c_login_log` VALUES ('1520', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-28 09:28:23', '2017-08-28 09:28:23');
INSERT INTO `c_login_log` VALUES ('1521', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-28 09:33:30', '2017-08-28 09:33:30');
INSERT INTO `c_login_log` VALUES ('1522', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-28 09:33:44', '2017-08-28 09:33:44');
INSERT INTO `c_login_log` VALUES ('1523', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-28 10:05:05', '2017-08-28 10:05:05');
INSERT INTO `c_login_log` VALUES ('1524', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-28 10:07:16', '2017-08-28 10:07:16');
INSERT INTO `c_login_log` VALUES ('1525', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-28 10:18:53', '2017-08-28 10:18:53');
INSERT INTO `c_login_log` VALUES ('1526', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-28 10:22:25', '2017-08-28 10:22:25');
INSERT INTO `c_login_log` VALUES ('1527', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-28 10:25:36', '2017-08-28 10:25:36');
INSERT INTO `c_login_log` VALUES ('1528', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-28 11:09:38', '2017-08-28 11:09:38');
INSERT INTO `c_login_log` VALUES ('1529', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-28 11:40:20', '2017-08-28 11:40:20');
INSERT INTO `c_login_log` VALUES ('1530', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-28 12:22:15', '2017-08-28 12:22:15');
INSERT INTO `c_login_log` VALUES ('1531', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-28 15:00:28', '2017-08-28 15:00:28');
INSERT INTO `c_login_log` VALUES ('1532', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-28 15:28:34', '2017-08-28 15:28:34');
INSERT INTO `c_login_log` VALUES ('1533', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-28 15:32:26', '2017-08-28 15:32:26');
INSERT INTO `c_login_log` VALUES ('1534', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-28 15:32:31', '2017-08-28 15:32:31');
INSERT INTO `c_login_log` VALUES ('1535', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-28 15:34:00', '2017-08-28 15:34:00');
INSERT INTO `c_login_log` VALUES ('1536', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-28 15:47:28', '2017-08-28 15:47:28');
INSERT INTO `c_login_log` VALUES ('1537', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-28 16:10:48', '2017-08-28 16:10:48');
INSERT INTO `c_login_log` VALUES ('1538', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-28 16:20:00', '2017-08-28 16:20:00');
INSERT INTO `c_login_log` VALUES ('1539', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-28 16:31:46', '2017-08-28 16:31:46');
INSERT INTO `c_login_log` VALUES ('1540', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-28 16:48:46', '2017-08-28 16:48:46');
INSERT INTO `c_login_log` VALUES ('1541', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-28 17:45:27', '2017-08-28 17:45:27');
INSERT INTO `c_login_log` VALUES ('1542', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-29 08:39:59', '2017-08-29 08:39:59');
INSERT INTO `c_login_log` VALUES ('1543', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-29 08:45:52', '2017-08-29 08:45:52');
INSERT INTO `c_login_log` VALUES ('1544', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-29 09:00:03', '2017-08-29 09:00:03');
INSERT INTO `c_login_log` VALUES ('1545', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-29 09:33:22', '2017-08-29 09:33:22');
INSERT INTO `c_login_log` VALUES ('1546', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-29 09:38:17', '2017-08-29 09:38:17');
INSERT INTO `c_login_log` VALUES ('1547', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-29 09:55:20', '2017-08-29 09:55:20');
INSERT INTO `c_login_log` VALUES ('1548', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-29 11:23:25', '2017-08-29 11:23:25');
INSERT INTO `c_login_log` VALUES ('1549', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-29 15:38:00', '2017-08-29 15:38:00');
INSERT INTO `c_login_log` VALUES ('1550', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-29 17:05:23', '2017-08-29 17:05:23');
INSERT INTO `c_login_log` VALUES ('1551', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-29 17:11:43', '2017-08-29 17:11:43');
INSERT INTO `c_login_log` VALUES ('1552', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-29 17:16:56', '2017-08-29 17:16:56');
INSERT INTO `c_login_log` VALUES ('1553', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-29 17:26:32', '2017-08-29 17:26:32');
INSERT INTO `c_login_log` VALUES ('1554', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-29 18:09:33', '2017-08-29 18:09:33');
INSERT INTO `c_login_log` VALUES ('1555', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-29 18:13:37', '2017-08-29 18:13:37');
INSERT INTO `c_login_log` VALUES ('1556', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 08:56:08', '2017-08-30 08:56:08');
INSERT INTO `c_login_log` VALUES ('1557', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 08:58:30', '2017-08-30 08:58:30');
INSERT INTO `c_login_log` VALUES ('1558', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 09:01:18', '2017-08-30 09:01:18');
INSERT INTO `c_login_log` VALUES ('1559', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 09:05:10', '2017-08-30 09:05:10');
INSERT INTO `c_login_log` VALUES ('1560', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 09:09:19', '2017-08-30 09:09:19');
INSERT INTO `c_login_log` VALUES ('1561', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 09:14:35', '2017-08-30 09:14:35');
INSERT INTO `c_login_log` VALUES ('1562', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 09:22:24', '2017-08-30 09:22:24');
INSERT INTO `c_login_log` VALUES ('1563', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 09:37:30', '2017-08-30 09:37:30');
INSERT INTO `c_login_log` VALUES ('1564', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 09:46:16', '2017-08-30 09:46:16');
INSERT INTO `c_login_log` VALUES ('1565', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 09:47:40', '2017-08-30 09:47:40');
INSERT INTO `c_login_log` VALUES ('1566', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 09:50:03', '2017-08-30 09:50:03');
INSERT INTO `c_login_log` VALUES ('1567', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 09:50:33', '2017-08-30 09:50:33');
INSERT INTO `c_login_log` VALUES ('1568', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 09:55:12', '2017-08-30 09:55:12');
INSERT INTO `c_login_log` VALUES ('1569', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 09:59:40', '2017-08-30 09:59:40');
INSERT INTO `c_login_log` VALUES ('1570', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 10:00:42', '2017-08-30 10:00:42');
INSERT INTO `c_login_log` VALUES ('1571', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 10:09:27', '2017-08-30 10:09:27');
INSERT INTO `c_login_log` VALUES ('1572', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 10:09:00', '2017-08-30 10:09:00');
INSERT INTO `c_login_log` VALUES ('1573', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 10:23:50', '2017-08-30 10:23:50');
INSERT INTO `c_login_log` VALUES ('1574', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 10:43:16', '2017-08-30 10:43:16');
INSERT INTO `c_login_log` VALUES ('1575', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 10:45:17', '2017-08-30 10:45:17');
INSERT INTO `c_login_log` VALUES ('1576', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 10:47:40', '2017-08-30 10:47:40');
INSERT INTO `c_login_log` VALUES ('1577', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 10:47:57', '2017-08-30 10:47:57');
INSERT INTO `c_login_log` VALUES ('1578', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 11:02:22', '2017-08-30 11:02:22');
INSERT INTO `c_login_log` VALUES ('1579', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 11:12:42', '2017-08-30 11:12:42');
INSERT INTO `c_login_log` VALUES ('1580', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 11:46:21', '2017-08-30 11:46:21');
INSERT INTO `c_login_log` VALUES ('1581', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 11:46:00', '2017-08-30 11:46:00');
INSERT INTO `c_login_log` VALUES ('1582', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 11:50:13', '2017-08-30 11:50:13');
INSERT INTO `c_login_log` VALUES ('1583', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 12:03:22', '2017-08-30 12:03:22');
INSERT INTO `c_login_log` VALUES ('1584', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 12:11:23', '2017-08-30 12:11:23');
INSERT INTO `c_login_log` VALUES ('1585', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 12:20:04', '2017-08-30 12:20:04');
INSERT INTO `c_login_log` VALUES ('1586', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 12:22:29', '2017-08-30 12:22:29');
INSERT INTO `c_login_log` VALUES ('1587', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 12:29:26', '2017-08-30 12:29:26');
INSERT INTO `c_login_log` VALUES ('1588', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 14:13:38', '2017-08-30 14:13:38');
INSERT INTO `c_login_log` VALUES ('1589', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 14:25:46', '2017-08-30 14:25:46');
INSERT INTO `c_login_log` VALUES ('1590', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 14:33:06', '2017-08-30 14:33:06');
INSERT INTO `c_login_log` VALUES ('1591', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 14:33:45', '2017-08-30 14:33:45');
INSERT INTO `c_login_log` VALUES ('1592', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 14:35:36', '2017-08-30 14:35:36');
INSERT INTO `c_login_log` VALUES ('1593', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 14:36:18', '2017-08-30 14:36:18');
INSERT INTO `c_login_log` VALUES ('1594', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 14:44:57', '2017-08-30 14:44:57');
INSERT INTO `c_login_log` VALUES ('1595', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 15:00:39', '2017-08-30 15:00:39');
INSERT INTO `c_login_log` VALUES ('1596', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 15:11:59', '2017-08-30 15:11:59');
INSERT INTO `c_login_log` VALUES ('1597', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 15:28:16', '2017-08-30 15:28:16');
INSERT INTO `c_login_log` VALUES ('1598', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 15:39:37', '2017-08-30 15:39:37');
INSERT INTO `c_login_log` VALUES ('1599', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 15:40:14', '2017-08-30 15:40:14');
INSERT INTO `c_login_log` VALUES ('1600', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 15:49:03', '2017-08-30 15:49:03');
INSERT INTO `c_login_log` VALUES ('1601', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 15:57:23', '2017-08-30 15:57:23');
INSERT INTO `c_login_log` VALUES ('1602', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 16:45:19', '2017-08-30 16:45:19');
INSERT INTO `c_login_log` VALUES ('1603', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 16:49:29', '2017-08-30 16:49:29');
INSERT INTO `c_login_log` VALUES ('1604', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 17:22:46', '2017-08-30 17:22:46');
INSERT INTO `c_login_log` VALUES ('1605', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 17:35:04', '2017-08-30 17:35:04');
INSERT INTO `c_login_log` VALUES ('1606', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 17:35:47', '2017-08-30 17:35:47');
INSERT INTO `c_login_log` VALUES ('1607', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 17:40:57', '2017-08-30 17:40:57');
INSERT INTO `c_login_log` VALUES ('1608', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 17:50:02', '2017-08-30 17:50:02');
INSERT INTO `c_login_log` VALUES ('1609', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-30 17:55:10', '2017-08-30 17:55:10');
INSERT INTO `c_login_log` VALUES ('1610', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 08:57:48', '2017-08-31 08:57:48');
INSERT INTO `c_login_log` VALUES ('1611', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:00:32', '2017-08-31 09:00:32');
INSERT INTO `c_login_log` VALUES ('1612', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:03:03', '2017-08-31 09:03:03');
INSERT INTO `c_login_log` VALUES ('1613', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:02:33', '2017-08-31 09:02:33');
INSERT INTO `c_login_log` VALUES ('1614', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:04:52', '2017-08-31 09:04:52');
INSERT INTO `c_login_log` VALUES ('1615', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:05:43', '2017-08-31 09:05:43');
INSERT INTO `c_login_log` VALUES ('1616', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:04:36', '2017-08-31 09:04:36');
INSERT INTO `c_login_log` VALUES ('1617', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:07:49', '2017-08-31 09:07:49');
INSERT INTO `c_login_log` VALUES ('1618', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:08:30', '2017-08-31 09:08:30');
INSERT INTO `c_login_log` VALUES ('1619', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:08:50', '2017-08-31 09:08:50');
INSERT INTO `c_login_log` VALUES ('1620', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:08:49', '2017-08-31 09:08:49');
INSERT INTO `c_login_log` VALUES ('1621', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:12:07', '2017-08-31 09:12:07');
INSERT INTO `c_login_log` VALUES ('1622', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:12:00', '2017-08-31 09:12:00');
INSERT INTO `c_login_log` VALUES ('1623', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:16:23', '2017-08-31 09:16:23');
INSERT INTO `c_login_log` VALUES ('1624', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:17:45', '2017-08-31 09:17:45');
INSERT INTO `c_login_log` VALUES ('1625', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:18:31', '2017-08-31 09:18:31');
INSERT INTO `c_login_log` VALUES ('1626', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:19:06', '2017-08-31 09:19:06');
INSERT INTO `c_login_log` VALUES ('1627', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:22:04', '2017-08-31 09:22:04');
INSERT INTO `c_login_log` VALUES ('1628', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:25:38', '2017-08-31 09:25:38');
INSERT INTO `c_login_log` VALUES ('1629', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:27:49', '2017-08-31 09:27:49');
INSERT INTO `c_login_log` VALUES ('1630', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:28:19', '2017-08-31 09:28:19');
INSERT INTO `c_login_log` VALUES ('1631', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:28:34', '2017-08-31 09:28:34');
INSERT INTO `c_login_log` VALUES ('1632', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:29:14', '2017-08-31 09:29:14');
INSERT INTO `c_login_log` VALUES ('1633', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:30:43', '2017-08-31 09:30:43');
INSERT INTO `c_login_log` VALUES ('1634', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:31:23', '2017-08-31 09:31:23');
INSERT INTO `c_login_log` VALUES ('1635', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:34:46', '2017-08-31 09:34:46');
INSERT INTO `c_login_log` VALUES ('1636', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:38:52', '2017-08-31 09:38:52');
INSERT INTO `c_login_log` VALUES ('1637', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:39:35', '2017-08-31 09:39:35');
INSERT INTO `c_login_log` VALUES ('1638', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:39:38', '2017-08-31 09:39:38');
INSERT INTO `c_login_log` VALUES ('1639', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:41:53', '2017-08-31 09:41:53');
INSERT INTO `c_login_log` VALUES ('1640', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:42:38', '2017-08-31 09:42:38');
INSERT INTO `c_login_log` VALUES ('1641', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:43:47', '2017-08-31 09:43:47');
INSERT INTO `c_login_log` VALUES ('1642', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:44:42', '2017-08-31 09:44:42');
INSERT INTO `c_login_log` VALUES ('1643', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:45:08', '2017-08-31 09:45:08');
INSERT INTO `c_login_log` VALUES ('1644', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:45:50', '2017-08-31 09:45:50');
INSERT INTO `c_login_log` VALUES ('1645', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:47:50', '2017-08-31 09:47:50');
INSERT INTO `c_login_log` VALUES ('1646', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:48:55', '2017-08-31 09:48:55');
INSERT INTO `c_login_log` VALUES ('1647', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:52:50', '2017-08-31 09:52:50');
INSERT INTO `c_login_log` VALUES ('1648', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:56:34', '2017-08-31 09:56:34');
INSERT INTO `c_login_log` VALUES ('1649', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:57:35', '2017-08-31 09:57:35');
INSERT INTO `c_login_log` VALUES ('1650', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:58:04', '2017-08-31 09:58:04');
INSERT INTO `c_login_log` VALUES ('1651', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:58:43', '2017-08-31 09:58:43');
INSERT INTO `c_login_log` VALUES ('1652', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 09:59:02', '2017-08-31 09:59:02');
INSERT INTO `c_login_log` VALUES ('1653', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 10:00:16', '2017-08-31 10:00:16');
INSERT INTO `c_login_log` VALUES ('1654', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 10:06:12', '2017-08-31 10:06:12');
INSERT INTO `c_login_log` VALUES ('1655', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 10:08:57', '2017-08-31 10:08:57');
INSERT INTO `c_login_log` VALUES ('1656', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 10:12:47', '2017-08-31 10:12:47');
INSERT INTO `c_login_log` VALUES ('1657', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 10:13:54', '2017-08-31 10:13:54');
INSERT INTO `c_login_log` VALUES ('1658', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 10:17:27', '2017-08-31 10:17:27');
INSERT INTO `c_login_log` VALUES ('1659', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 10:19:49', '2017-08-31 10:19:49');
INSERT INTO `c_login_log` VALUES ('1660', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 10:21:38', '2017-08-31 10:21:38');
INSERT INTO `c_login_log` VALUES ('1661', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 10:28:31', '2017-08-31 10:28:31');
INSERT INTO `c_login_log` VALUES ('1662', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 10:28:12', '2017-08-31 10:28:12');
INSERT INTO `c_login_log` VALUES ('1663', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 10:33:04', '2017-08-31 10:33:04');
INSERT INTO `c_login_log` VALUES ('1664', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 10:35:15', '2017-08-31 10:35:15');
INSERT INTO `c_login_log` VALUES ('1665', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 10:35:40', '2017-08-31 10:35:40');
INSERT INTO `c_login_log` VALUES ('1666', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 10:39:43', '2017-08-31 10:39:43');
INSERT INTO `c_login_log` VALUES ('1667', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 10:49:22', '2017-08-31 10:49:22');
INSERT INTO `c_login_log` VALUES ('1668', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 10:54:02', '2017-08-31 10:54:02');
INSERT INTO `c_login_log` VALUES ('1669', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 10:54:45', '2017-08-31 10:54:45');
INSERT INTO `c_login_log` VALUES ('1670', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 10:59:33', '2017-08-31 10:59:33');
INSERT INTO `c_login_log` VALUES ('1671', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 10:58:54', '2017-08-31 10:58:54');
INSERT INTO `c_login_log` VALUES ('1672', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 11:05:28', '2017-08-31 11:05:28');
INSERT INTO `c_login_log` VALUES ('1673', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 11:06:03', '2017-08-31 11:06:03');
INSERT INTO `c_login_log` VALUES ('1674', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 11:09:01', '2017-08-31 11:09:01');
INSERT INTO `c_login_log` VALUES ('1675', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 11:13:47', '2017-08-31 11:13:47');
INSERT INTO `c_login_log` VALUES ('1676', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 11:22:31', '2017-08-31 11:22:31');
INSERT INTO `c_login_log` VALUES ('1677', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 11:26:04', '2017-08-31 11:26:04');
INSERT INTO `c_login_log` VALUES ('1678', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 11:29:09', '2017-08-31 11:29:09');
INSERT INTO `c_login_log` VALUES ('1679', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 11:29:46', '2017-08-31 11:29:46');
INSERT INTO `c_login_log` VALUES ('1680', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 11:32:27', '2017-08-31 11:32:27');
INSERT INTO `c_login_log` VALUES ('1681', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 11:31:28', '2017-08-31 11:31:28');
INSERT INTO `c_login_log` VALUES ('1682', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 11:34:52', '2017-08-31 11:34:52');
INSERT INTO `c_login_log` VALUES ('1683', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 11:40:51', '2017-08-31 11:40:51');
INSERT INTO `c_login_log` VALUES ('1684', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 11:44:23', '2017-08-31 11:44:23');
INSERT INTO `c_login_log` VALUES ('1685', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 11:45:07', '2017-08-31 11:45:07');
INSERT INTO `c_login_log` VALUES ('1686', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 11:45:41', '2017-08-31 11:45:41');
INSERT INTO `c_login_log` VALUES ('1687', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 11:51:42', '2017-08-31 11:51:42');
INSERT INTO `c_login_log` VALUES ('1688', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 12:25:24', '2017-08-31 12:25:24');
INSERT INTO `c_login_log` VALUES ('1689', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 12:32:46', '2017-08-31 12:32:46');
INSERT INTO `c_login_log` VALUES ('1690', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 12:34:42', '2017-08-31 12:34:42');
INSERT INTO `c_login_log` VALUES ('1691', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 14:03:41', '2017-08-31 14:03:41');
INSERT INTO `c_login_log` VALUES ('1692', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 14:07:22', '2017-08-31 14:07:22');
INSERT INTO `c_login_log` VALUES ('1693', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 14:24:59', '2017-08-31 14:24:59');
INSERT INTO `c_login_log` VALUES ('1694', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 14:24:38', '2017-08-31 14:24:38');
INSERT INTO `c_login_log` VALUES ('1695', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 14:28:41', '2017-08-31 14:28:41');
INSERT INTO `c_login_log` VALUES ('1696', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 14:43:08', '2017-08-31 14:43:08');
INSERT INTO `c_login_log` VALUES ('1697', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 14:49:05', '2017-08-31 14:49:05');
INSERT INTO `c_login_log` VALUES ('1698', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 15:01:09', '2017-08-31 15:01:09');
INSERT INTO `c_login_log` VALUES ('1699', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 15:07:31', '2017-08-31 15:07:31');
INSERT INTO `c_login_log` VALUES ('1700', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 15:13:25', '2017-08-31 15:13:25');
INSERT INTO `c_login_log` VALUES ('1701', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 15:13:53', '2017-08-31 15:13:53');
INSERT INTO `c_login_log` VALUES ('1702', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 15:15:51', '2017-08-31 15:15:51');
INSERT INTO `c_login_log` VALUES ('1703', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 15:16:32', '2017-08-31 15:16:32');
INSERT INTO `c_login_log` VALUES ('1704', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 15:17:16', '2017-08-31 15:17:16');
INSERT INTO `c_login_log` VALUES ('1705', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 15:17:39', '2017-08-31 15:17:39');
INSERT INTO `c_login_log` VALUES ('1706', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 15:19:10', '2017-08-31 15:19:10');
INSERT INTO `c_login_log` VALUES ('1707', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 15:19:49', '2017-08-31 15:19:49');
INSERT INTO `c_login_log` VALUES ('1708', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 15:20:13', '2017-08-31 15:20:13');
INSERT INTO `c_login_log` VALUES ('1709', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 15:20:45', '2017-08-31 15:20:45');
INSERT INTO `c_login_log` VALUES ('1710', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 15:21:13', '2017-08-31 15:21:13');
INSERT INTO `c_login_log` VALUES ('1711', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 15:21:51', '2017-08-31 15:21:51');
INSERT INTO `c_login_log` VALUES ('1712', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 15:22:26', '2017-08-31 15:22:26');
INSERT INTO `c_login_log` VALUES ('1713', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 15:23:06', '2017-08-31 15:23:06');
INSERT INTO `c_login_log` VALUES ('1714', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 15:23:44', '2017-08-31 15:23:44');
INSERT INTO `c_login_log` VALUES ('1715', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 15:25:44', '2017-08-31 15:25:44');
INSERT INTO `c_login_log` VALUES ('1716', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 15:31:18', '2017-08-31 15:31:18');
INSERT INTO `c_login_log` VALUES ('1717', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 15:35:53', '2017-08-31 15:35:53');
INSERT INTO `c_login_log` VALUES ('1718', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 15:37:43', '2017-08-31 15:37:43');
INSERT INTO `c_login_log` VALUES ('1719', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 15:44:11', '2017-08-31 15:44:11');
INSERT INTO `c_login_log` VALUES ('1720', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 15:44:55', '2017-08-31 15:44:55');
INSERT INTO `c_login_log` VALUES ('1721', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 15:46:01', '2017-08-31 15:46:01');
INSERT INTO `c_login_log` VALUES ('1722', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 15:48:24', '2017-08-31 15:48:24');
INSERT INTO `c_login_log` VALUES ('1723', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 15:59:48', '2017-08-31 15:59:48');
INSERT INTO `c_login_log` VALUES ('1724', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 16:51:54', '2017-08-31 16:51:54');
INSERT INTO `c_login_log` VALUES ('1725', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 16:54:39', '2017-08-31 16:54:39');
INSERT INTO `c_login_log` VALUES ('1726', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 17:08:23', '2017-08-31 17:08:23');
INSERT INTO `c_login_log` VALUES ('1727', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 17:08:23', '2017-08-31 17:08:23');
INSERT INTO `c_login_log` VALUES ('1728', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 17:24:13', '2017-08-31 17:24:13');
INSERT INTO `c_login_log` VALUES ('1729', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 17:38:25', '2017-08-31 17:38:25');
INSERT INTO `c_login_log` VALUES ('1730', null, 'admin', '2130706433', '用户成功登录系统', '2017-08-31 17:54:25', '2017-08-31 17:54:25');
INSERT INTO `c_login_log` VALUES ('1731', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 08:45:48', '2017-09-01 08:45:48');
INSERT INTO `c_login_log` VALUES ('1732', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 08:50:59', '2017-09-01 08:50:59');
INSERT INTO `c_login_log` VALUES ('1733', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 08:51:45', '2017-09-01 08:51:45');
INSERT INTO `c_login_log` VALUES ('1734', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 08:58:21', '2017-09-01 08:58:21');
INSERT INTO `c_login_log` VALUES ('1735', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 08:59:59', '2017-09-01 08:59:59');
INSERT INTO `c_login_log` VALUES ('1736', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 09:01:32', '2017-09-01 09:01:32');
INSERT INTO `c_login_log` VALUES ('1737', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 09:05:17', '2017-09-01 09:05:17');
INSERT INTO `c_login_log` VALUES ('1738', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 09:05:04', '2017-09-01 09:05:04');
INSERT INTO `c_login_log` VALUES ('1739', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 09:06:16', '2017-09-01 09:06:16');
INSERT INTO `c_login_log` VALUES ('1740', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 09:07:01', '2017-09-01 09:07:01');
INSERT INTO `c_login_log` VALUES ('1741', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 09:07:31', '2017-09-01 09:07:31');
INSERT INTO `c_login_log` VALUES ('1742', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 09:08:12', '2017-09-01 09:08:12');
INSERT INTO `c_login_log` VALUES ('1743', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 09:09:43', '2017-09-01 09:09:43');
INSERT INTO `c_login_log` VALUES ('1744', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 09:26:03', '2017-09-01 09:26:03');
INSERT INTO `c_login_log` VALUES ('1745', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 09:45:36', '2017-09-01 09:45:36');
INSERT INTO `c_login_log` VALUES ('1746', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 09:57:05', '2017-09-01 09:57:05');
INSERT INTO `c_login_log` VALUES ('1747', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 09:59:58', '2017-09-01 09:59:58');
INSERT INTO `c_login_log` VALUES ('1748', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 10:01:13', '2017-09-01 10:01:13');
INSERT INTO `c_login_log` VALUES ('1749', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 10:02:19', '2017-09-01 10:02:19');
INSERT INTO `c_login_log` VALUES ('1750', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 10:04:14', '2017-09-01 10:04:14');
INSERT INTO `c_login_log` VALUES ('1751', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 10:06:13', '2017-09-01 10:06:13');
INSERT INTO `c_login_log` VALUES ('1752', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 10:06:39', '2017-09-01 10:06:39');
INSERT INTO `c_login_log` VALUES ('1753', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 10:07:46', '2017-09-01 10:07:46');
INSERT INTO `c_login_log` VALUES ('1754', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 10:08:15', '2017-09-01 10:08:15');
INSERT INTO `c_login_log` VALUES ('1755', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 10:09:28', '2017-09-01 10:09:28');
INSERT INTO `c_login_log` VALUES ('1756', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 10:10:00', '2017-09-01 10:10:00');
INSERT INTO `c_login_log` VALUES ('1757', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 10:11:29', '2017-09-01 10:11:29');
INSERT INTO `c_login_log` VALUES ('1758', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 10:13:01', '2017-09-01 10:13:01');
INSERT INTO `c_login_log` VALUES ('1759', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 10:13:04', '2017-09-01 10:13:04');
INSERT INTO `c_login_log` VALUES ('1760', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 10:15:11', '2017-09-01 10:15:11');
INSERT INTO `c_login_log` VALUES ('1761', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 10:16:35', '2017-09-01 10:16:35');
INSERT INTO `c_login_log` VALUES ('1762', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 10:16:59', '2017-09-01 10:16:59');
INSERT INTO `c_login_log` VALUES ('1763', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 10:17:23', '2017-09-01 10:17:23');
INSERT INTO `c_login_log` VALUES ('1764', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 10:18:13', '2017-09-01 10:18:13');
INSERT INTO `c_login_log` VALUES ('1765', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 10:19:35', '2017-09-01 10:19:35');
INSERT INTO `c_login_log` VALUES ('1766', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 10:20:49', '2017-09-01 10:20:49');
INSERT INTO `c_login_log` VALUES ('1767', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 10:21:13', '2017-09-01 10:21:13');
INSERT INTO `c_login_log` VALUES ('1768', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 10:24:05', '2017-09-01 10:24:05');
INSERT INTO `c_login_log` VALUES ('1769', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 10:24:37', '2017-09-01 10:24:37');
INSERT INTO `c_login_log` VALUES ('1770', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 10:25:30', '2017-09-01 10:25:30');
INSERT INTO `c_login_log` VALUES ('1771', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 10:26:05', '2017-09-01 10:26:05');
INSERT INTO `c_login_log` VALUES ('1772', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 10:26:40', '2017-09-01 10:26:40');
INSERT INTO `c_login_log` VALUES ('1773', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 10:30:33', '2017-09-01 10:30:33');
INSERT INTO `c_login_log` VALUES ('1774', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 10:32:20', '2017-09-01 10:32:20');
INSERT INTO `c_login_log` VALUES ('1775', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 10:33:52', '2017-09-01 10:33:52');
INSERT INTO `c_login_log` VALUES ('1776', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 10:34:52', '2017-09-01 10:34:52');
INSERT INTO `c_login_log` VALUES ('1777', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 10:38:34', '2017-09-01 10:38:34');
INSERT INTO `c_login_log` VALUES ('1778', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 10:39:21', '2017-09-01 10:39:21');
INSERT INTO `c_login_log` VALUES ('1779', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 10:41:56', '2017-09-01 10:41:56');
INSERT INTO `c_login_log` VALUES ('1780', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 10:43:38', '2017-09-01 10:43:38');
INSERT INTO `c_login_log` VALUES ('1781', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 10:47:08', '2017-09-01 10:47:08');
INSERT INTO `c_login_log` VALUES ('1782', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 10:58:26', '2017-09-01 10:58:26');
INSERT INTO `c_login_log` VALUES ('1783', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 11:00:03', '2017-09-01 11:00:03');
INSERT INTO `c_login_log` VALUES ('1784', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 11:15:15', '2017-09-01 11:15:15');
INSERT INTO `c_login_log` VALUES ('1785', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 11:16:01', '2017-09-01 11:16:01');
INSERT INTO `c_login_log` VALUES ('1786', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 11:16:36', '2017-09-01 11:16:36');
INSERT INTO `c_login_log` VALUES ('1787', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 11:29:06', '2017-09-01 11:29:06');
INSERT INTO `c_login_log` VALUES ('1788', null, 'tomas', '2130706433', '用户成功登录系统', '2017-09-01 11:30:32', '2017-09-01 11:30:32');
INSERT INTO `c_login_log` VALUES ('1789', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 11:39:37', '2017-09-01 11:39:37');
INSERT INTO `c_login_log` VALUES ('1790', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 11:40:58', '2017-09-01 11:40:58');
INSERT INTO `c_login_log` VALUES ('1791', null, 'admin', '3232235581', '用户成功登录系统', '2017-09-01 11:49:50', '2017-09-01 11:49:50');
INSERT INTO `c_login_log` VALUES ('1792', null, 'admin', '3232235574', '用户成功登录系统', '2017-09-01 11:50:31', '2017-09-01 11:50:31');
INSERT INTO `c_login_log` VALUES ('1793', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 11:50:09', '2017-09-01 11:50:09');
INSERT INTO `c_login_log` VALUES ('1794', null, 'tomas', '2130706433', '用户成功登录系统', '2017-09-01 11:50:37', '2017-09-01 11:50:37');
INSERT INTO `c_login_log` VALUES ('1795', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 11:57:13', '2017-09-01 11:57:13');
INSERT INTO `c_login_log` VALUES ('1796', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 12:01:22', '2017-09-01 12:01:22');
INSERT INTO `c_login_log` VALUES ('1797', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 12:00:26', '2017-09-01 12:00:26');
INSERT INTO `c_login_log` VALUES ('1798', null, 'tomas', '2130706433', '用户成功登录系统', '2017-09-01 12:01:13', '2017-09-01 12:01:13');
INSERT INTO `c_login_log` VALUES ('1799', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 12:18:00', '2017-09-01 12:18:00');
INSERT INTO `c_login_log` VALUES ('1800', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 12:21:00', '2017-09-01 12:21:00');
INSERT INTO `c_login_log` VALUES ('1801', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 12:24:12', '2017-09-01 12:24:12');
INSERT INTO `c_login_log` VALUES ('1802', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 12:26:39', '2017-09-01 12:26:39');
INSERT INTO `c_login_log` VALUES ('1803', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 12:33:26', '2017-09-01 12:33:26');
INSERT INTO `c_login_log` VALUES ('1804', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 12:33:57', '2017-09-01 12:33:57');
INSERT INTO `c_login_log` VALUES ('1805', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 12:35:33', '2017-09-01 12:35:33');
INSERT INTO `c_login_log` VALUES ('1806', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 14:06:51', '2017-09-01 14:06:51');
INSERT INTO `c_login_log` VALUES ('1807', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 14:07:07', '2017-09-01 14:07:07');
INSERT INTO `c_login_log` VALUES ('1808', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 14:16:33', '2017-09-01 14:16:33');
INSERT INTO `c_login_log` VALUES ('1809', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 14:22:44', '2017-09-01 14:22:44');
INSERT INTO `c_login_log` VALUES ('1810', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 14:24:20', '2017-09-01 14:24:20');
INSERT INTO `c_login_log` VALUES ('1811', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 14:27:19', '2017-09-01 14:27:19');
INSERT INTO `c_login_log` VALUES ('1812', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 14:26:49', '2017-09-01 14:26:49');
INSERT INTO `c_login_log` VALUES ('1813', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 14:28:52', '2017-09-01 14:28:52');
INSERT INTO `c_login_log` VALUES ('1814', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 14:28:38', '2017-09-01 14:28:38');
INSERT INTO `c_login_log` VALUES ('1815', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 14:29:24', '2017-09-01 14:29:24');
INSERT INTO `c_login_log` VALUES ('1816', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 14:30:13', '2017-09-01 14:30:13');
INSERT INTO `c_login_log` VALUES ('1817', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 14:31:45', '2017-09-01 14:31:45');
INSERT INTO `c_login_log` VALUES ('1818', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 14:32:15', '2017-09-01 14:32:15');
INSERT INTO `c_login_log` VALUES ('1819', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 14:33:13', '2017-09-01 14:33:13');
INSERT INTO `c_login_log` VALUES ('1820', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 14:34:27', '2017-09-01 14:34:27');
INSERT INTO `c_login_log` VALUES ('1821', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 14:35:17', '2017-09-01 14:35:17');
INSERT INTO `c_login_log` VALUES ('1822', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 14:37:33', '2017-09-01 14:37:33');
INSERT INTO `c_login_log` VALUES ('1823', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 14:38:20', '2017-09-01 14:38:20');
INSERT INTO `c_login_log` VALUES ('1824', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 14:57:46', '2017-09-01 14:57:46');
INSERT INTO `c_login_log` VALUES ('1825', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 14:59:06', '2017-09-01 14:59:06');
INSERT INTO `c_login_log` VALUES ('1826', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 15:02:10', '2017-09-01 15:02:10');
INSERT INTO `c_login_log` VALUES ('1827', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 15:06:52', '2017-09-01 15:06:52');
INSERT INTO `c_login_log` VALUES ('1828', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 15:15:09', '2017-09-01 15:15:09');
INSERT INTO `c_login_log` VALUES ('1829', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 15:22:22', '2017-09-01 15:22:22');
INSERT INTO `c_login_log` VALUES ('1830', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 15:24:14', '2017-09-01 15:24:14');
INSERT INTO `c_login_log` VALUES ('1831', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 15:29:50', '2017-09-01 15:29:50');
INSERT INTO `c_login_log` VALUES ('1832', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 15:32:09', '2017-09-01 15:32:09');
INSERT INTO `c_login_log` VALUES ('1833', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 15:34:33', '2017-09-01 15:34:33');
INSERT INTO `c_login_log` VALUES ('1834', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 15:46:19', '2017-09-01 15:46:19');
INSERT INTO `c_login_log` VALUES ('1835', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 15:46:19', '2017-09-01 15:46:19');
INSERT INTO `c_login_log` VALUES ('1836', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 15:47:53', '2017-09-01 15:47:53');
INSERT INTO `c_login_log` VALUES ('1837', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 15:53:20', '2017-09-01 15:53:20');
INSERT INTO `c_login_log` VALUES ('1838', null, 'admin', '3232235574', '用户成功登录系统', '2017-09-01 15:56:15', '2017-09-01 15:56:15');
INSERT INTO `c_login_log` VALUES ('1839', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 15:57:59', '2017-09-01 15:57:59');
INSERT INTO `c_login_log` VALUES ('1840', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 16:01:25', '2017-09-01 16:01:25');
INSERT INTO `c_login_log` VALUES ('1841', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 16:16:41', '2017-09-01 16:16:41');
INSERT INTO `c_login_log` VALUES ('1842', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 16:26:26', '2017-09-01 16:26:26');
INSERT INTO `c_login_log` VALUES ('1843', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 16:28:45', '2017-09-01 16:28:45');
INSERT INTO `c_login_log` VALUES ('1844', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 16:32:28', '2017-09-01 16:32:28');
INSERT INTO `c_login_log` VALUES ('1845', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 16:38:33', '2017-09-01 16:38:33');
INSERT INTO `c_login_log` VALUES ('1846', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 16:41:21', '2017-09-01 16:41:21');
INSERT INTO `c_login_log` VALUES ('1847', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 16:49:27', '2017-09-01 16:49:27');
INSERT INTO `c_login_log` VALUES ('1848', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 16:49:47', '2017-09-01 16:49:47');
INSERT INTO `c_login_log` VALUES ('1849', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 16:50:56', '2017-09-01 16:50:56');
INSERT INTO `c_login_log` VALUES ('1850', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 16:56:25', '2017-09-01 16:56:25');
INSERT INTO `c_login_log` VALUES ('1851', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 17:01:35', '2017-09-01 17:01:35');
INSERT INTO `c_login_log` VALUES ('1852', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 17:05:39', '2017-09-01 17:05:39');
INSERT INTO `c_login_log` VALUES ('1853', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 17:10:31', '2017-09-01 17:10:31');
INSERT INTO `c_login_log` VALUES ('1854', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 17:11:19', '2017-09-01 17:11:19');
INSERT INTO `c_login_log` VALUES ('1855', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 17:13:25', '2017-09-01 17:13:25');
INSERT INTO `c_login_log` VALUES ('1856', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 17:33:29', '2017-09-01 17:33:29');
INSERT INTO `c_login_log` VALUES ('1857', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 17:37:51', '2017-09-01 17:37:51');
INSERT INTO `c_login_log` VALUES ('1858', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 17:40:19', '2017-09-01 17:40:19');
INSERT INTO `c_login_log` VALUES ('1859', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 17:40:41', '2017-09-01 17:40:41');
INSERT INTO `c_login_log` VALUES ('1860', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 17:53:52', '2017-09-01 17:53:52');
INSERT INTO `c_login_log` VALUES ('1861', null, 'tomas', '2130706433', '用户成功登录系统', '2017-09-01 17:52:44', '2017-09-01 17:52:44');
INSERT INTO `c_login_log` VALUES ('1862', null, 'mary', '2130706433', '用户成功登录系统', '2017-09-01 17:55:47', '2017-09-01 17:55:47');
INSERT INTO `c_login_log` VALUES ('1863', null, 'tomas', '2130706433', '用户成功登录系统', '2017-09-01 17:57:01', '2017-09-01 17:57:01');
INSERT INTO `c_login_log` VALUES ('1864', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 18:00:22', '2017-09-01 18:00:22');
INSERT INTO `c_login_log` VALUES ('1865', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 18:05:42', '2017-09-01 18:05:42');
INSERT INTO `c_login_log` VALUES ('1866', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 18:06:46', '2017-09-01 18:06:46');
INSERT INTO `c_login_log` VALUES ('1867', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 18:09:52', '2017-09-01 18:09:52');
INSERT INTO `c_login_log` VALUES ('1868', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-01 18:13:59', '2017-09-01 18:13:59');
INSERT INTO `c_login_log` VALUES ('1869', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 08:48:07', '2017-09-04 08:48:07');
INSERT INTO `c_login_log` VALUES ('1870', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 08:58:29', '2017-09-04 08:58:29');
INSERT INTO `c_login_log` VALUES ('1871', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 09:08:21', '2017-09-04 09:08:21');
INSERT INTO `c_login_log` VALUES ('1872', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 09:12:39', '2017-09-04 09:12:39');
INSERT INTO `c_login_log` VALUES ('1873', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 09:18:48', '2017-09-04 09:18:48');
INSERT INTO `c_login_log` VALUES ('1874', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 09:18:14', '2017-09-04 09:18:14');
INSERT INTO `c_login_log` VALUES ('1875', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 09:25:53', '2017-09-04 09:25:53');
INSERT INTO `c_login_log` VALUES ('1876', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 09:28:59', '2017-09-04 09:28:59');
INSERT INTO `c_login_log` VALUES ('1877', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 09:30:04', '2017-09-04 09:30:04');
INSERT INTO `c_login_log` VALUES ('1878', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 09:37:16', '2017-09-04 09:37:16');
INSERT INTO `c_login_log` VALUES ('1879', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 09:41:39', '2017-09-04 09:41:39');
INSERT INTO `c_login_log` VALUES ('1880', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 09:51:16', '2017-09-04 09:51:16');
INSERT INTO `c_login_log` VALUES ('1881', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 10:02:26', '2017-09-04 10:02:26');
INSERT INTO `c_login_log` VALUES ('1882', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 10:03:37', '2017-09-04 10:03:37');
INSERT INTO `c_login_log` VALUES ('1883', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 10:07:35', '2017-09-04 10:07:35');
INSERT INTO `c_login_log` VALUES ('1884', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 10:23:42', '2017-09-04 10:23:42');
INSERT INTO `c_login_log` VALUES ('1885', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 10:25:00', '2017-09-04 10:25:00');
INSERT INTO `c_login_log` VALUES ('1886', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 10:28:15', '2017-09-04 10:28:15');
INSERT INTO `c_login_log` VALUES ('1887', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 10:27:37', '2017-09-04 10:27:37');
INSERT INTO `c_login_log` VALUES ('1888', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 10:29:03', '2017-09-04 10:29:03');
INSERT INTO `c_login_log` VALUES ('1889', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 10:34:08', '2017-09-04 10:34:08');
INSERT INTO `c_login_log` VALUES ('1890', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 10:36:59', '2017-09-04 10:36:59');
INSERT INTO `c_login_log` VALUES ('1891', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 10:39:03', '2017-09-04 10:39:03');
INSERT INTO `c_login_log` VALUES ('1892', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 10:40:09', '2017-09-04 10:40:09');
INSERT INTO `c_login_log` VALUES ('1893', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 10:43:31', '2017-09-04 10:43:31');
INSERT INTO `c_login_log` VALUES ('1894', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 10:49:36', '2017-09-04 10:49:36');
INSERT INTO `c_login_log` VALUES ('1895', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 10:50:34', '2017-09-04 10:50:34');
INSERT INTO `c_login_log` VALUES ('1896', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 10:50:47', '2017-09-04 10:50:47');
INSERT INTO `c_login_log` VALUES ('1897', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 10:55:16', '2017-09-04 10:55:16');
INSERT INTO `c_login_log` VALUES ('1898', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 10:58:34', '2017-09-04 10:58:34');
INSERT INTO `c_login_log` VALUES ('1899', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 11:15:11', '2017-09-04 11:15:11');
INSERT INTO `c_login_log` VALUES ('1900', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 11:16:11', '2017-09-04 11:16:11');
INSERT INTO `c_login_log` VALUES ('1901', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 11:17:23', '2017-09-04 11:17:23');
INSERT INTO `c_login_log` VALUES ('1902', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 11:19:49', '2017-09-04 11:19:49');
INSERT INTO `c_login_log` VALUES ('1903', null, 'king', '2130706433', '用户成功登录系统', '2017-09-04 11:20:51', '2017-09-04 11:20:51');
INSERT INTO `c_login_log` VALUES ('1904', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 11:21:48', '2017-09-04 11:21:48');
INSERT INTO `c_login_log` VALUES ('1905', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 11:22:05', '2017-09-04 11:22:05');
INSERT INTO `c_login_log` VALUES ('1906', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 11:21:51', '2017-09-04 11:21:51');
INSERT INTO `c_login_log` VALUES ('1907', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 11:20:42', '2017-09-04 11:20:42');
INSERT INTO `c_login_log` VALUES ('1908', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 11:24:35', '2017-09-04 11:24:35');
INSERT INTO `c_login_log` VALUES ('1909', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 11:26:27', '2017-09-04 11:26:27');
INSERT INTO `c_login_log` VALUES ('1910', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 11:27:56', '2017-09-04 11:27:56');
INSERT INTO `c_login_log` VALUES ('1911', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 11:33:57', '2017-09-04 11:33:57');
INSERT INTO `c_login_log` VALUES ('1912', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 11:35:56', '2017-09-04 11:35:56');
INSERT INTO `c_login_log` VALUES ('1913', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 11:38:11', '2017-09-04 11:38:11');
INSERT INTO `c_login_log` VALUES ('1914', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 11:41:46', '2017-09-04 11:41:46');
INSERT INTO `c_login_log` VALUES ('1915', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 11:42:56', '2017-09-04 11:42:56');
INSERT INTO `c_login_log` VALUES ('1916', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 11:43:57', '2017-09-04 11:43:57');
INSERT INTO `c_login_log` VALUES ('1917', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 11:44:43', '2017-09-04 11:44:43');
INSERT INTO `c_login_log` VALUES ('1918', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 11:47:29', '2017-09-04 11:47:29');
INSERT INTO `c_login_log` VALUES ('1919', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 11:47:52', '2017-09-04 11:47:52');
INSERT INTO `c_login_log` VALUES ('1920', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 11:56:27', '2017-09-04 11:56:27');
INSERT INTO `c_login_log` VALUES ('1921', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 12:21:15', '2017-09-04 12:21:15');
INSERT INTO `c_login_log` VALUES ('1922', null, 'admin', '3232235585', '用户成功登录系统', '2017-09-04 12:25:10', '2017-09-04 12:25:10');
INSERT INTO `c_login_log` VALUES ('1923', null, 'admin', '3232235585', '用户成功登录系统', '2017-09-04 14:05:37', '2017-09-04 14:05:37');
INSERT INTO `c_login_log` VALUES ('1924', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 14:13:12', '2017-09-04 14:13:12');
INSERT INTO `c_login_log` VALUES ('1925', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 14:19:44', '2017-09-04 14:19:44');
INSERT INTO `c_login_log` VALUES ('1926', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 14:35:57', '2017-09-04 14:35:57');
INSERT INTO `c_login_log` VALUES ('1927', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 14:41:07', '2017-09-04 14:41:07');
INSERT INTO `c_login_log` VALUES ('1928', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 14:42:16', '2017-09-04 14:42:16');
INSERT INTO `c_login_log` VALUES ('1929', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 14:46:00', '2017-09-04 14:46:00');
INSERT INTO `c_login_log` VALUES ('1930', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 14:47:33', '2017-09-04 14:47:33');
INSERT INTO `c_login_log` VALUES ('1931', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 14:48:35', '2017-09-04 14:48:35');
INSERT INTO `c_login_log` VALUES ('1932', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 14:51:49', '2017-09-04 14:51:49');
INSERT INTO `c_login_log` VALUES ('1933', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 15:01:45', '2017-09-04 15:01:45');
INSERT INTO `c_login_log` VALUES ('1934', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 15:04:58', '2017-09-04 15:04:58');
INSERT INTO `c_login_log` VALUES ('1935', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 15:06:31', '2017-09-04 15:06:31');
INSERT INTO `c_login_log` VALUES ('1936', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 15:07:13', '2017-09-04 15:07:13');
INSERT INTO `c_login_log` VALUES ('1937', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 15:07:55', '2017-09-04 15:07:55');
INSERT INTO `c_login_log` VALUES ('1938', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 15:08:25', '2017-09-04 15:08:25');
INSERT INTO `c_login_log` VALUES ('1939', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 15:09:41', '2017-09-04 15:09:41');
INSERT INTO `c_login_log` VALUES ('1940', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 15:09:48', '2017-09-04 15:09:48');
INSERT INTO `c_login_log` VALUES ('1941', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 15:10:02', '2017-09-04 15:10:02');
INSERT INTO `c_login_log` VALUES ('1942', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 15:08:59', '2017-09-04 15:08:59');
INSERT INTO `c_login_log` VALUES ('1943', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 15:10:51', '2017-09-04 15:10:51');
INSERT INTO `c_login_log` VALUES ('1944', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 15:15:59', '2017-09-04 15:15:59');
INSERT INTO `c_login_log` VALUES ('1945', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 15:16:41', '2017-09-04 15:16:41');
INSERT INTO `c_login_log` VALUES ('1946', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 15:17:12', '2017-09-04 15:17:12');
INSERT INTO `c_login_log` VALUES ('1947', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 15:19:36', '2017-09-04 15:19:36');
INSERT INTO `c_login_log` VALUES ('1948', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 15:20:03', '2017-09-04 15:20:03');
INSERT INTO `c_login_log` VALUES ('1949', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 15:22:11', '2017-09-04 15:22:11');
INSERT INTO `c_login_log` VALUES ('1950', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 15:21:38', '2017-09-04 15:21:38');
INSERT INTO `c_login_log` VALUES ('1951', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 15:24:33', '2017-09-04 15:24:33');
INSERT INTO `c_login_log` VALUES ('1952', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 15:25:22', '2017-09-04 15:25:22');
INSERT INTO `c_login_log` VALUES ('1953', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 15:30:19', '2017-09-04 15:30:19');
INSERT INTO `c_login_log` VALUES ('1954', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 15:31:46', '2017-09-04 15:31:46');
INSERT INTO `c_login_log` VALUES ('1955', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 15:33:28', '2017-09-04 15:33:28');
INSERT INTO `c_login_log` VALUES ('1956', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 15:35:23', '2017-09-04 15:35:23');
INSERT INTO `c_login_log` VALUES ('1957', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 15:37:51', '2017-09-04 15:37:51');
INSERT INTO `c_login_log` VALUES ('1958', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 15:39:28', '2017-09-04 15:39:28');
INSERT INTO `c_login_log` VALUES ('1959', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 15:47:06', '2017-09-04 15:47:06');
INSERT INTO `c_login_log` VALUES ('1960', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 15:49:04', '2017-09-04 15:49:04');
INSERT INTO `c_login_log` VALUES ('1961', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 15:50:20', '2017-09-04 15:50:20');
INSERT INTO `c_login_log` VALUES ('1962', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 15:53:20', '2017-09-04 15:53:20');
INSERT INTO `c_login_log` VALUES ('1963', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 15:54:27', '2017-09-04 15:54:27');
INSERT INTO `c_login_log` VALUES ('1964', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 15:58:05', '2017-09-04 15:58:05');
INSERT INTO `c_login_log` VALUES ('1965', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 15:59:24', '2017-09-04 15:59:24');
INSERT INTO `c_login_log` VALUES ('1966', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 16:00:35', '2017-09-04 16:00:35');
INSERT INTO `c_login_log` VALUES ('1967', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 16:01:57', '2017-09-04 16:01:57');
INSERT INTO `c_login_log` VALUES ('1968', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 16:05:26', '2017-09-04 16:05:26');
INSERT INTO `c_login_log` VALUES ('1969', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 16:05:55', '2017-09-04 16:05:55');
INSERT INTO `c_login_log` VALUES ('1970', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 16:07:15', '2017-09-04 16:07:15');
INSERT INTO `c_login_log` VALUES ('1971', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 16:08:11', '2017-09-04 16:08:11');
INSERT INTO `c_login_log` VALUES ('1972', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 16:08:41', '2017-09-04 16:08:41');
INSERT INTO `c_login_log` VALUES ('1973', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 16:10:01', '2017-09-04 16:10:01');
INSERT INTO `c_login_log` VALUES ('1974', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 16:11:25', '2017-09-04 16:11:25');
INSERT INTO `c_login_log` VALUES ('1975', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 16:16:50', '2017-09-04 16:16:50');
INSERT INTO `c_login_log` VALUES ('1976', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 16:17:56', '2017-09-04 16:17:56');
INSERT INTO `c_login_log` VALUES ('1977', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 16:19:48', '2017-09-04 16:19:48');
INSERT INTO `c_login_log` VALUES ('1978', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 16:23:14', '2017-09-04 16:23:14');
INSERT INTO `c_login_log` VALUES ('1979', null, 'mary', '2130706433', '用户成功登录系统', '2017-09-04 16:23:15', '2017-09-04 16:23:15');
INSERT INTO `c_login_log` VALUES ('1980', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 16:25:25', '2017-09-04 16:25:25');
INSERT INTO `c_login_log` VALUES ('1981', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 16:25:36', '2017-09-04 16:25:36');
INSERT INTO `c_login_log` VALUES ('1982', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 16:30:41', '2017-09-04 16:30:41');
INSERT INTO `c_login_log` VALUES ('1983', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 16:33:33', '2017-09-04 16:33:33');
INSERT INTO `c_login_log` VALUES ('1984', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 16:37:28', '2017-09-04 16:37:28');
INSERT INTO `c_login_log` VALUES ('1985', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 16:38:18', '2017-09-04 16:38:18');
INSERT INTO `c_login_log` VALUES ('1986', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 16:38:40', '2017-09-04 16:38:40');
INSERT INTO `c_login_log` VALUES ('1987', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 16:51:41', '2017-09-04 16:51:41');
INSERT INTO `c_login_log` VALUES ('1988', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 16:56:48', '2017-09-04 16:56:48');
INSERT INTO `c_login_log` VALUES ('1989', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 16:59:06', '2017-09-04 16:59:06');
INSERT INTO `c_login_log` VALUES ('1990', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 17:01:05', '2017-09-04 17:01:05');
INSERT INTO `c_login_log` VALUES ('1991', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 17:01:46', '2017-09-04 17:01:46');
INSERT INTO `c_login_log` VALUES ('1992', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 17:03:35', '2017-09-04 17:03:35');
INSERT INTO `c_login_log` VALUES ('1993', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 17:12:31', '2017-09-04 17:12:31');
INSERT INTO `c_login_log` VALUES ('1994', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 17:15:16', '2017-09-04 17:15:16');
INSERT INTO `c_login_log` VALUES ('1995', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 17:19:27', '2017-09-04 17:19:27');
INSERT INTO `c_login_log` VALUES ('1996', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 17:24:21', '2017-09-04 17:24:21');
INSERT INTO `c_login_log` VALUES ('1997', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 17:28:22', '2017-09-04 17:28:22');
INSERT INTO `c_login_log` VALUES ('1998', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 17:28:44', '2017-09-04 17:28:44');
INSERT INTO `c_login_log` VALUES ('1999', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 17:31:29', '2017-09-04 17:31:29');
INSERT INTO `c_login_log` VALUES ('2000', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 17:31:50', '2017-09-04 17:31:50');
INSERT INTO `c_login_log` VALUES ('2001', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 17:32:12', '2017-09-04 17:32:12');
INSERT INTO `c_login_log` VALUES ('2002', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 17:37:24', '2017-09-04 17:37:24');
INSERT INTO `c_login_log` VALUES ('2003', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 17:39:00', '2017-09-04 17:39:00');
INSERT INTO `c_login_log` VALUES ('2004', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 17:40:39', '2017-09-04 17:40:39');
INSERT INTO `c_login_log` VALUES ('2005', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 17:42:05', '2017-09-04 17:42:05');
INSERT INTO `c_login_log` VALUES ('2006', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 17:43:52', '2017-09-04 17:43:52');
INSERT INTO `c_login_log` VALUES ('2007', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 17:45:28', '2017-09-04 17:45:28');
INSERT INTO `c_login_log` VALUES ('2008', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 17:48:23', '2017-09-04 17:48:23');
INSERT INTO `c_login_log` VALUES ('2009', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 17:50:16', '2017-09-04 17:50:16');
INSERT INTO `c_login_log` VALUES ('2010', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 17:54:40', '2017-09-04 17:54:40');
INSERT INTO `c_login_log` VALUES ('2011', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 17:55:42', '2017-09-04 17:55:42');
INSERT INTO `c_login_log` VALUES ('2012', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 17:56:48', '2017-09-04 17:56:48');
INSERT INTO `c_login_log` VALUES ('2013', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 17:57:25', '2017-09-04 17:57:25');
INSERT INTO `c_login_log` VALUES ('2014', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 17:58:51', '2017-09-04 17:58:51');
INSERT INTO `c_login_log` VALUES ('2015', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 18:05:05', '2017-09-04 18:05:05');
INSERT INTO `c_login_log` VALUES ('2016', null, 'mary', '2130706433', '用户成功登录系统', '2017-09-04 18:09:59', '2017-09-04 18:09:59');
INSERT INTO `c_login_log` VALUES ('2017', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 18:14:14', '2017-09-04 18:14:14');
INSERT INTO `c_login_log` VALUES ('2018', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 18:17:12', '2017-09-04 18:17:12');
INSERT INTO `c_login_log` VALUES ('2019', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 18:18:51', '2017-09-04 18:18:51');
INSERT INTO `c_login_log` VALUES ('2020', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 18:21:42', '2017-09-04 18:21:42');
INSERT INTO `c_login_log` VALUES ('2021', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 18:22:33', '2017-09-04 18:22:33');
INSERT INTO `c_login_log` VALUES ('2022', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-04 18:23:38', '2017-09-04 18:23:38');
INSERT INTO `c_login_log` VALUES ('2023', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 08:41:50', '2017-09-05 08:41:50');
INSERT INTO `c_login_log` VALUES ('2024', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 08:43:00', '2017-09-05 08:43:00');
INSERT INTO `c_login_log` VALUES ('2025', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 08:45:13', '2017-09-05 08:45:13');
INSERT INTO `c_login_log` VALUES ('2026', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 08:46:11', '2017-09-05 08:46:11');
INSERT INTO `c_login_log` VALUES ('2027', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 08:48:28', '2017-09-05 08:48:28');
INSERT INTO `c_login_log` VALUES ('2028', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 08:50:20', '2017-09-05 08:50:20');
INSERT INTO `c_login_log` VALUES ('2029', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 08:49:53', '2017-09-05 08:49:53');
INSERT INTO `c_login_log` VALUES ('2030', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 08:53:16', '2017-09-05 08:53:16');
INSERT INTO `c_login_log` VALUES ('2031', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 08:55:17', '2017-09-05 08:55:17');
INSERT INTO `c_login_log` VALUES ('2032', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 09:01:48', '2017-09-05 09:01:48');
INSERT INTO `c_login_log` VALUES ('2033', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 09:06:15', '2017-09-05 09:06:15');
INSERT INTO `c_login_log` VALUES ('2034', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 09:07:16', '2017-09-05 09:07:16');
INSERT INTO `c_login_log` VALUES ('2035', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 09:07:47', '2017-09-05 09:07:47');
INSERT INTO `c_login_log` VALUES ('2036', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 09:09:59', '2017-09-05 09:09:59');
INSERT INTO `c_login_log` VALUES ('2037', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 09:14:08', '2017-09-05 09:14:08');
INSERT INTO `c_login_log` VALUES ('2038', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 09:14:49', '2017-09-05 09:14:49');
INSERT INTO `c_login_log` VALUES ('2039', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 09:15:30', '2017-09-05 09:15:30');
INSERT INTO `c_login_log` VALUES ('2040', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 09:16:59', '2017-09-05 09:16:59');
INSERT INTO `c_login_log` VALUES ('2041', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 09:17:42', '2017-09-05 09:17:42');
INSERT INTO `c_login_log` VALUES ('2042', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 09:18:15', '2017-09-05 09:18:15');
INSERT INTO `c_login_log` VALUES ('2043', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 09:24:33', '2017-09-05 09:24:33');
INSERT INTO `c_login_log` VALUES ('2044', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 09:25:29', '2017-09-05 09:25:29');
INSERT INTO `c_login_log` VALUES ('2045', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 09:25:58', '2017-09-05 09:25:58');
INSERT INTO `c_login_log` VALUES ('2046', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 09:26:32', '2017-09-05 09:26:32');
INSERT INTO `c_login_log` VALUES ('2047', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 09:27:06', '2017-09-05 09:27:06');
INSERT INTO `c_login_log` VALUES ('2048', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 09:30:53', '2017-09-05 09:30:53');
INSERT INTO `c_login_log` VALUES ('2049', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 09:31:31', '2017-09-05 09:31:31');
INSERT INTO `c_login_log` VALUES ('2050', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 10:12:33', '2017-09-05 10:12:33');
INSERT INTO `c_login_log` VALUES ('2051', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 10:13:22', '2017-09-05 10:13:22');
INSERT INTO `c_login_log` VALUES ('2052', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 10:14:48', '2017-09-05 10:14:48');
INSERT INTO `c_login_log` VALUES ('2053', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 10:15:14', '2017-09-05 10:15:14');
INSERT INTO `c_login_log` VALUES ('2054', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 10:16:24', '2017-09-05 10:16:24');
INSERT INTO `c_login_log` VALUES ('2055', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 10:17:27', '2017-09-05 10:17:27');
INSERT INTO `c_login_log` VALUES ('2056', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 10:18:22', '2017-09-05 10:18:22');
INSERT INTO `c_login_log` VALUES ('2057', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 10:18:11', '2017-09-05 10:18:11');
INSERT INTO `c_login_log` VALUES ('2058', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 10:22:42', '2017-09-05 10:22:42');
INSERT INTO `c_login_log` VALUES ('2059', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 10:23:20', '2017-09-05 10:23:20');
INSERT INTO `c_login_log` VALUES ('2060', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 10:23:28', '2017-09-05 10:23:28');
INSERT INTO `c_login_log` VALUES ('2061', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 10:29:39', '2017-09-05 10:29:39');
INSERT INTO `c_login_log` VALUES ('2062', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 10:30:02', '2017-09-05 10:30:02');
INSERT INTO `c_login_log` VALUES ('2063', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 10:41:21', '2017-09-05 10:41:21');
INSERT INTO `c_login_log` VALUES ('2064', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 10:43:13', '2017-09-05 10:43:13');
INSERT INTO `c_login_log` VALUES ('2065', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 10:44:27', '2017-09-05 10:44:27');
INSERT INTO `c_login_log` VALUES ('2066', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 10:45:12', '2017-09-05 10:45:12');
INSERT INTO `c_login_log` VALUES ('2067', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 10:45:44', '2017-09-05 10:45:44');
INSERT INTO `c_login_log` VALUES ('2068', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 10:46:34', '2017-09-05 10:46:34');
INSERT INTO `c_login_log` VALUES ('2069', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 10:47:02', '2017-09-05 10:47:02');
INSERT INTO `c_login_log` VALUES ('2070', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 10:47:40', '2017-09-05 10:47:40');
INSERT INTO `c_login_log` VALUES ('2071', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 10:48:22', '2017-09-05 10:48:22');
INSERT INTO `c_login_log` VALUES ('2072', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 10:50:20', '2017-09-05 10:50:20');
INSERT INTO `c_login_log` VALUES ('2073', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 10:51:09', '2017-09-05 10:51:09');
INSERT INTO `c_login_log` VALUES ('2074', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 10:51:41', '2017-09-05 10:51:41');
INSERT INTO `c_login_log` VALUES ('2075', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 10:51:15', '2017-09-05 10:51:15');
INSERT INTO `c_login_log` VALUES ('2076', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 10:52:54', '2017-09-05 10:52:54');
INSERT INTO `c_login_log` VALUES ('2077', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 10:53:28', '2017-09-05 10:53:28');
INSERT INTO `c_login_log` VALUES ('2078', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 10:53:50', '2017-09-05 10:53:50');
INSERT INTO `c_login_log` VALUES ('2079', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 10:54:17', '2017-09-05 10:54:17');
INSERT INTO `c_login_log` VALUES ('2080', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 10:54:35', '2017-09-05 10:54:35');
INSERT INTO `c_login_log` VALUES ('2081', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 10:55:38', '2017-09-05 10:55:38');
INSERT INTO `c_login_log` VALUES ('2082', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 10:56:48', '2017-09-05 10:56:48');
INSERT INTO `c_login_log` VALUES ('2083', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 10:58:43', '2017-09-05 10:58:43');
INSERT INTO `c_login_log` VALUES ('2084', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 10:59:20', '2017-09-05 10:59:20');
INSERT INTO `c_login_log` VALUES ('2085', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 11:00:04', '2017-09-05 11:00:04');
INSERT INTO `c_login_log` VALUES ('2086', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 11:01:16', '2017-09-05 11:01:16');
INSERT INTO `c_login_log` VALUES ('2087', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 11:02:00', '2017-09-05 11:02:00');
INSERT INTO `c_login_log` VALUES ('2088', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 11:05:49', '2017-09-05 11:05:49');
INSERT INTO `c_login_log` VALUES ('2089', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 11:07:48', '2017-09-05 11:07:48');
INSERT INTO `c_login_log` VALUES ('2090', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 11:10:14', '2017-09-05 11:10:14');
INSERT INTO `c_login_log` VALUES ('2091', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 11:11:13', '2017-09-05 11:11:13');
INSERT INTO `c_login_log` VALUES ('2092', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 11:12:23', '2017-09-05 11:12:23');
INSERT INTO `c_login_log` VALUES ('2093', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 11:14:25', '2017-09-05 11:14:25');
INSERT INTO `c_login_log` VALUES ('2094', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 11:15:34', '2017-09-05 11:15:34');
INSERT INTO `c_login_log` VALUES ('2095', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 11:16:53', '2017-09-05 11:16:53');
INSERT INTO `c_login_log` VALUES ('2096', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 11:17:15', '2017-09-05 11:17:15');
INSERT INTO `c_login_log` VALUES ('2097', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 11:18:04', '2017-09-05 11:18:04');
INSERT INTO `c_login_log` VALUES ('2098', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 11:18:06', '2017-09-05 11:18:06');
INSERT INTO `c_login_log` VALUES ('2099', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 11:19:09', '2017-09-05 11:19:09');
INSERT INTO `c_login_log` VALUES ('2100', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 11:19:54', '2017-09-05 11:19:54');
INSERT INTO `c_login_log` VALUES ('2101', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 11:23:40', '2017-09-05 11:23:40');
INSERT INTO `c_login_log` VALUES ('2102', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 11:25:07', '2017-09-05 11:25:07');
INSERT INTO `c_login_log` VALUES ('2103', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 11:26:05', '2017-09-05 11:26:05');
INSERT INTO `c_login_log` VALUES ('2104', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 11:27:28', '2017-09-05 11:27:28');
INSERT INTO `c_login_log` VALUES ('2105', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 11:28:27', '2017-09-05 11:28:27');
INSERT INTO `c_login_log` VALUES ('2106', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 11:30:43', '2017-09-05 11:30:43');
INSERT INTO `c_login_log` VALUES ('2107', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 11:31:46', '2017-09-05 11:31:46');
INSERT INTO `c_login_log` VALUES ('2108', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 11:33:33', '2017-09-05 11:33:33');
INSERT INTO `c_login_log` VALUES ('2109', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 11:36:25', '2017-09-05 11:36:25');
INSERT INTO `c_login_log` VALUES ('2110', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 11:36:53', '2017-09-05 11:36:53');
INSERT INTO `c_login_log` VALUES ('2111', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 11:37:54', '2017-09-05 11:37:54');
INSERT INTO `c_login_log` VALUES ('2112', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 11:38:26', '2017-09-05 11:38:26');
INSERT INTO `c_login_log` VALUES ('2113', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 11:43:34', '2017-09-05 11:43:34');
INSERT INTO `c_login_log` VALUES ('2114', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 11:48:07', '2017-09-05 11:48:07');
INSERT INTO `c_login_log` VALUES ('2115', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 11:49:47', '2017-09-05 11:49:47');
INSERT INTO `c_login_log` VALUES ('2116', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 11:51:10', '2017-09-05 11:51:10');
INSERT INTO `c_login_log` VALUES ('2117', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 11:53:13', '2017-09-05 11:53:13');
INSERT INTO `c_login_log` VALUES ('2118', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 11:55:54', '2017-09-05 11:55:54');
INSERT INTO `c_login_log` VALUES ('2119', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 11:58:04', '2017-09-05 11:58:04');
INSERT INTO `c_login_log` VALUES ('2120', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 11:59:46', '2017-09-05 11:59:46');
INSERT INTO `c_login_log` VALUES ('2121', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:01:33', '2017-09-05 12:01:33');
INSERT INTO `c_login_log` VALUES ('2122', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:03:12', '2017-09-05 12:03:12');
INSERT INTO `c_login_log` VALUES ('2123', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:04:46', '2017-09-05 12:04:46');
INSERT INTO `c_login_log` VALUES ('2124', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:05:47', '2017-09-05 12:05:47');
INSERT INTO `c_login_log` VALUES ('2125', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:09:12', '2017-09-05 12:09:12');
INSERT INTO `c_login_log` VALUES ('2126', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:12:31', '2017-09-05 12:12:31');
INSERT INTO `c_login_log` VALUES ('2127', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:11:45', '2017-09-05 12:11:45');
INSERT INTO `c_login_log` VALUES ('2128', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:11:59', '2017-09-05 12:11:59');
INSERT INTO `c_login_log` VALUES ('2129', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:15:06', '2017-09-05 12:15:06');
INSERT INTO `c_login_log` VALUES ('2130', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:14:18', '2017-09-05 12:14:18');
INSERT INTO `c_login_log` VALUES ('2131', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:16:12', '2017-09-05 12:16:12');
INSERT INTO `c_login_log` VALUES ('2132', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:18:44', '2017-09-05 12:18:44');
INSERT INTO `c_login_log` VALUES ('2133', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:18:49', '2017-09-05 12:18:49');
INSERT INTO `c_login_log` VALUES ('2134', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:19:29', '2017-09-05 12:19:29');
INSERT INTO `c_login_log` VALUES ('2135', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:19:09', '2017-09-05 12:19:09');
INSERT INTO `c_login_log` VALUES ('2136', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:24:15', '2017-09-05 12:24:15');
INSERT INTO `c_login_log` VALUES ('2137', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:25:05', '2017-09-05 12:25:05');
INSERT INTO `c_login_log` VALUES ('2138', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:25:41', '2017-09-05 12:25:41');
INSERT INTO `c_login_log` VALUES ('2139', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:26:06', '2017-09-05 12:26:06');
INSERT INTO `c_login_log` VALUES ('2140', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:26:41', '2017-09-05 12:26:41');
INSERT INTO `c_login_log` VALUES ('2141', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:27:05', '2017-09-05 12:27:05');
INSERT INTO `c_login_log` VALUES ('2142', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:26:27', '2017-09-05 12:26:27');
INSERT INTO `c_login_log` VALUES ('2143', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:28:33', '2017-09-05 12:28:33');
INSERT INTO `c_login_log` VALUES ('2144', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:27:37', '2017-09-05 12:27:37');
INSERT INTO `c_login_log` VALUES ('2145', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:29:13', '2017-09-05 12:29:13');
INSERT INTO `c_login_log` VALUES ('2146', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:30:02', '2017-09-05 12:30:02');
INSERT INTO `c_login_log` VALUES ('2147', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:30:56', '2017-09-05 12:30:56');
INSERT INTO `c_login_log` VALUES ('2148', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:31:16', '2017-09-05 12:31:16');
INSERT INTO `c_login_log` VALUES ('2149', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:34:31', '2017-09-05 12:34:31');
INSERT INTO `c_login_log` VALUES ('2150', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:34:56', '2017-09-05 12:34:56');
INSERT INTO `c_login_log` VALUES ('2151', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:35:20', '2017-09-05 12:35:20');
INSERT INTO `c_login_log` VALUES ('2152', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:36:07', '2017-09-05 12:36:07');
INSERT INTO `c_login_log` VALUES ('2153', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:36:28', '2017-09-05 12:36:28');
INSERT INTO `c_login_log` VALUES ('2154', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:39:48', '2017-09-05 12:39:48');
INSERT INTO `c_login_log` VALUES ('2155', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:40:32', '2017-09-05 12:40:32');
INSERT INTO `c_login_log` VALUES ('2156', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:40:59', '2017-09-05 12:40:59');
INSERT INTO `c_login_log` VALUES ('2157', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:41:20', '2017-09-05 12:41:20');
INSERT INTO `c_login_log` VALUES ('2158', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:43:46', '2017-09-05 12:43:46');
INSERT INTO `c_login_log` VALUES ('2159', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:44:19', '2017-09-05 12:44:19');
INSERT INTO `c_login_log` VALUES ('2160', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:45:32', '2017-09-05 12:45:32');
INSERT INTO `c_login_log` VALUES ('2161', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:45:55', '2017-09-05 12:45:55');
INSERT INTO `c_login_log` VALUES ('2162', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:52:38', '2017-09-05 12:52:38');
INSERT INTO `c_login_log` VALUES ('2163', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:55:18', '2017-09-05 12:55:18');
INSERT INTO `c_login_log` VALUES ('2164', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:57:00', '2017-09-05 12:57:00');
INSERT INTO `c_login_log` VALUES ('2165', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 12:58:25', '2017-09-05 12:58:25');
INSERT INTO `c_login_log` VALUES ('2166', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 13:05:32', '2017-09-05 13:05:32');
INSERT INTO `c_login_log` VALUES ('2167', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 13:09:44', '2017-09-05 13:09:44');
INSERT INTO `c_login_log` VALUES ('2168', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 13:10:42', '2017-09-05 13:10:42');
INSERT INTO `c_login_log` VALUES ('2169', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 13:18:15', '2017-09-05 13:18:15');
INSERT INTO `c_login_log` VALUES ('2170', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 13:21:51', '2017-09-05 13:21:51');
INSERT INTO `c_login_log` VALUES ('2171', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 13:31:03', '2017-09-05 13:31:03');
INSERT INTO `c_login_log` VALUES ('2172', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 13:35:55', '2017-09-05 13:35:55');
INSERT INTO `c_login_log` VALUES ('2173', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 13:37:49', '2017-09-05 13:37:49');
INSERT INTO `c_login_log` VALUES ('2174', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 13:39:52', '2017-09-05 13:39:52');
INSERT INTO `c_login_log` VALUES ('2175', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 14:06:46', '2017-09-05 14:06:46');
INSERT INTO `c_login_log` VALUES ('2176', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 14:08:23', '2017-09-05 14:08:23');
INSERT INTO `c_login_log` VALUES ('2177', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 14:07:45', '2017-09-05 14:07:45');
INSERT INTO `c_login_log` VALUES ('2178', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 14:07:56', '2017-09-05 14:07:56');
INSERT INTO `c_login_log` VALUES ('2179', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 14:09:40', '2017-09-05 14:09:40');
INSERT INTO `c_login_log` VALUES ('2180', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 14:10:10', '2017-09-05 14:10:10');
INSERT INTO `c_login_log` VALUES ('2181', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 14:10:12', '2017-09-05 14:10:12');
INSERT INTO `c_login_log` VALUES ('2182', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 14:15:16', '2017-09-05 14:15:16');
INSERT INTO `c_login_log` VALUES ('2183', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 14:18:17', '2017-09-05 14:18:17');
INSERT INTO `c_login_log` VALUES ('2184', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 14:18:48', '2017-09-05 14:18:48');
INSERT INTO `c_login_log` VALUES ('2185', null, 'admin', '3232235585', '用户成功登录系统', '2017-09-05 14:19:24', '2017-09-05 14:19:24');
INSERT INTO `c_login_log` VALUES ('2186', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 14:23:03', '2017-09-05 14:23:03');
INSERT INTO `c_login_log` VALUES ('2187', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 14:26:13', '2017-09-05 14:26:13');
INSERT INTO `c_login_log` VALUES ('2188', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 14:28:31', '2017-09-05 14:28:31');
INSERT INTO `c_login_log` VALUES ('2189', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 14:36:11', '2017-09-05 14:36:11');
INSERT INTO `c_login_log` VALUES ('2190', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 14:36:54', '2017-09-05 14:36:54');
INSERT INTO `c_login_log` VALUES ('2191', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 14:38:34', '2017-09-05 14:38:34');
INSERT INTO `c_login_log` VALUES ('2192', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 14:38:34', '2017-09-05 14:38:34');
INSERT INTO `c_login_log` VALUES ('2193', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 14:42:48', '2017-09-05 14:42:48');
INSERT INTO `c_login_log` VALUES ('2194', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 14:43:46', '2017-09-05 14:43:46');
INSERT INTO `c_login_log` VALUES ('2195', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 14:46:06', '2017-09-05 14:46:06');
INSERT INTO `c_login_log` VALUES ('2196', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 14:48:27', '2017-09-05 14:48:27');
INSERT INTO `c_login_log` VALUES ('2197', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 14:48:34', '2017-09-05 14:48:34');
INSERT INTO `c_login_log` VALUES ('2198', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 14:49:50', '2017-09-05 14:49:50');
INSERT INTO `c_login_log` VALUES ('2199', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 14:58:22', '2017-09-05 14:58:22');
INSERT INTO `c_login_log` VALUES ('2200', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 14:58:26', '2017-09-05 14:58:26');
INSERT INTO `c_login_log` VALUES ('2201', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 14:58:24', '2017-09-05 14:58:24');
INSERT INTO `c_login_log` VALUES ('2202', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 15:22:04', '2017-09-05 15:22:04');
INSERT INTO `c_login_log` VALUES ('2203', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 15:23:10', '2017-09-05 15:23:10');
INSERT INTO `c_login_log` VALUES ('2204', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 15:23:57', '2017-09-05 15:23:57');
INSERT INTO `c_login_log` VALUES ('2205', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 15:24:28', '2017-09-05 15:24:28');
INSERT INTO `c_login_log` VALUES ('2206', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 15:25:35', '2017-09-05 15:25:35');
INSERT INTO `c_login_log` VALUES ('2207', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 15:25:55', '2017-09-05 15:25:55');
INSERT INTO `c_login_log` VALUES ('2208', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 15:27:09', '2017-09-05 15:27:09');
INSERT INTO `c_login_log` VALUES ('2209', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 15:28:15', '2017-09-05 15:28:15');
INSERT INTO `c_login_log` VALUES ('2210', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 15:30:07', '2017-09-05 15:30:07');
INSERT INTO `c_login_log` VALUES ('2211', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 15:32:26', '2017-09-05 15:32:26');
INSERT INTO `c_login_log` VALUES ('2212', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 15:33:10', '2017-09-05 15:33:10');
INSERT INTO `c_login_log` VALUES ('2213', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 15:33:47', '2017-09-05 15:33:47');
INSERT INTO `c_login_log` VALUES ('2214', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 15:34:51', '2017-09-05 15:34:51');
INSERT INTO `c_login_log` VALUES ('2215', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 15:34:25', '2017-09-05 15:34:25');
INSERT INTO `c_login_log` VALUES ('2216', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 15:35:48', '2017-09-05 15:35:48');
INSERT INTO `c_login_log` VALUES ('2217', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 15:37:19', '2017-09-05 15:37:19');
INSERT INTO `c_login_log` VALUES ('2218', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 15:38:04', '2017-09-05 15:38:04');
INSERT INTO `c_login_log` VALUES ('2219', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 15:39:30', '2017-09-05 15:39:30');
INSERT INTO `c_login_log` VALUES ('2220', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 15:39:56', '2017-09-05 15:39:56');
INSERT INTO `c_login_log` VALUES ('2221', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 15:43:50', '2017-09-05 15:43:50');
INSERT INTO `c_login_log` VALUES ('2222', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 15:44:04', '2017-09-05 15:44:04');
INSERT INTO `c_login_log` VALUES ('2223', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 15:45:59', '2017-09-05 15:45:59');
INSERT INTO `c_login_log` VALUES ('2224', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 15:47:41', '2017-09-05 15:47:41');
INSERT INTO `c_login_log` VALUES ('2225', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 15:48:32', '2017-09-05 15:48:32');
INSERT INTO `c_login_log` VALUES ('2226', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 15:49:38', '2017-09-05 15:49:38');
INSERT INTO `c_login_log` VALUES ('2227', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 15:50:27', '2017-09-05 15:50:27');
INSERT INTO `c_login_log` VALUES ('2228', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 15:51:03', '2017-09-05 15:51:03');
INSERT INTO `c_login_log` VALUES ('2229', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 15:50:44', '2017-09-05 15:50:44');
INSERT INTO `c_login_log` VALUES ('2230', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 15:55:45', '2017-09-05 15:55:45');
INSERT INTO `c_login_log` VALUES ('2231', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:05:16', '2017-09-05 16:05:16');
INSERT INTO `c_login_log` VALUES ('2232', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:06:01', '2017-09-05 16:06:01');
INSERT INTO `c_login_log` VALUES ('2233', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:07:18', '2017-09-05 16:07:18');
INSERT INTO `c_login_log` VALUES ('2234', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:08:52', '2017-09-05 16:08:52');
INSERT INTO `c_login_log` VALUES ('2235', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:11:08', '2017-09-05 16:11:08');
INSERT INTO `c_login_log` VALUES ('2236', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:10:49', '2017-09-05 16:10:49');
INSERT INTO `c_login_log` VALUES ('2237', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:14:38', '2017-09-05 16:14:38');
INSERT INTO `c_login_log` VALUES ('2238', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:15:06', '2017-09-05 16:15:06');
INSERT INTO `c_login_log` VALUES ('2239', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:14:16', '2017-09-05 16:14:16');
INSERT INTO `c_login_log` VALUES ('2240', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:16:38', '2017-09-05 16:16:38');
INSERT INTO `c_login_log` VALUES ('2241', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:18:30', '2017-09-05 16:18:30');
INSERT INTO `c_login_log` VALUES ('2242', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:17:53', '2017-09-05 16:17:53');
INSERT INTO `c_login_log` VALUES ('2243', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:22:01', '2017-09-05 16:22:01');
INSERT INTO `c_login_log` VALUES ('2244', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:22:32', '2017-09-05 16:22:32');
INSERT INTO `c_login_log` VALUES ('2245', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:30:05', '2017-09-05 16:30:05');
INSERT INTO `c_login_log` VALUES ('2246', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:28:56', '2017-09-05 16:28:56');
INSERT INTO `c_login_log` VALUES ('2247', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:30:54', '2017-09-05 16:30:54');
INSERT INTO `c_login_log` VALUES ('2248', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:31:56', '2017-09-05 16:31:56');
INSERT INTO `c_login_log` VALUES ('2249', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:31:50', '2017-09-05 16:31:50');
INSERT INTO `c_login_log` VALUES ('2250', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:36:23', '2017-09-05 16:36:23');
INSERT INTO `c_login_log` VALUES ('2251', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:36:42', '2017-09-05 16:36:42');
INSERT INTO `c_login_log` VALUES ('2252', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:37:20', '2017-09-05 16:37:20');
INSERT INTO `c_login_log` VALUES ('2253', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:42:34', '2017-09-05 16:42:34');
INSERT INTO `c_login_log` VALUES ('2254', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:44:24', '2017-09-05 16:44:24');
INSERT INTO `c_login_log` VALUES ('2255', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:44:35', '2017-09-05 16:44:35');
INSERT INTO `c_login_log` VALUES ('2256', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:46:40', '2017-09-05 16:46:40');
INSERT INTO `c_login_log` VALUES ('2257', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:47:34', '2017-09-05 16:47:34');
INSERT INTO `c_login_log` VALUES ('2258', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:48:15', '2017-09-05 16:48:15');
INSERT INTO `c_login_log` VALUES ('2259', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:50:59', '2017-09-05 16:50:59');
INSERT INTO `c_login_log` VALUES ('2260', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:51:28', '2017-09-05 16:51:28');
INSERT INTO `c_login_log` VALUES ('2261', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:52:15', '2017-09-05 16:52:15');
INSERT INTO `c_login_log` VALUES ('2262', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:53:21', '2017-09-05 16:53:21');
INSERT INTO `c_login_log` VALUES ('2263', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:54:59', '2017-09-05 16:54:59');
INSERT INTO `c_login_log` VALUES ('2264', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:56:25', '2017-09-05 16:56:25');
INSERT INTO `c_login_log` VALUES ('2265', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:56:26', '2017-09-05 16:56:26');
INSERT INTO `c_login_log` VALUES ('2266', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:57:52', '2017-09-05 16:57:52');
INSERT INTO `c_login_log` VALUES ('2267', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-05 16:58:41', '2017-09-05 16:58:41');
INSERT INTO `c_login_log` VALUES ('2268', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 16:59:10', '2017-09-05 16:59:10');
INSERT INTO `c_login_log` VALUES ('2269', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 17:02:57', '2017-09-05 17:02:57');
INSERT INTO `c_login_log` VALUES ('2270', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-05 17:04:17', '2017-09-05 17:04:17');
INSERT INTO `c_login_log` VALUES ('2271', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 17:04:28', '2017-09-05 17:04:28');
INSERT INTO `c_login_log` VALUES ('2272', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-05 17:05:34', '2017-09-05 17:05:34');
INSERT INTO `c_login_log` VALUES ('2273', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 17:07:23', '2017-09-05 17:07:23');
INSERT INTO `c_login_log` VALUES ('2274', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 17:08:06', '2017-09-05 17:08:06');
INSERT INTO `c_login_log` VALUES ('2275', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-05 17:08:23', '2017-09-05 17:08:23');
INSERT INTO `c_login_log` VALUES ('2276', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-05 17:08:15', '2017-09-05 17:08:15');
INSERT INTO `c_login_log` VALUES ('2277', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 17:09:42', '2017-09-05 17:09:42');
INSERT INTO `c_login_log` VALUES ('2278', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-05 17:08:47', '2017-09-05 17:08:47');
INSERT INTO `c_login_log` VALUES ('2279', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 17:13:37', '2017-09-05 17:13:37');
INSERT INTO `c_login_log` VALUES ('2280', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 17:16:56', '2017-09-05 17:16:56');
INSERT INTO `c_login_log` VALUES ('2281', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 17:19:18', '2017-09-05 17:19:18');
INSERT INTO `c_login_log` VALUES ('2282', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 17:22:59', '2017-09-05 17:22:59');
INSERT INTO `c_login_log` VALUES ('2283', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 17:28:31', '2017-09-05 17:28:31');
INSERT INTO `c_login_log` VALUES ('2284', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 17:30:40', '2017-09-05 17:30:40');
INSERT INTO `c_login_log` VALUES ('2285', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-05 17:41:25', '2017-09-05 17:41:25');
INSERT INTO `c_login_log` VALUES ('2286', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 17:44:08', '2017-09-05 17:44:08');
INSERT INTO `c_login_log` VALUES ('2287', null, 'admin', '3232235574', '用户成功登录系统', '2017-09-05 17:45:36', '2017-09-05 17:45:36');
INSERT INTO `c_login_log` VALUES ('2288', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 17:47:20', '2017-09-05 17:47:20');
INSERT INTO `c_login_log` VALUES ('2289', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 17:47:32', '2017-09-05 17:47:32');
INSERT INTO `c_login_log` VALUES ('2290', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 17:50:58', '2017-09-05 17:50:58');
INSERT INTO `c_login_log` VALUES ('2291', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 17:50:44', '2017-09-05 17:50:44');
INSERT INTO `c_login_log` VALUES ('2292', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 17:51:41', '2017-09-05 17:51:41');
INSERT INTO `c_login_log` VALUES ('2293', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 17:56:49', '2017-09-05 17:56:49');
INSERT INTO `c_login_log` VALUES ('2294', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 17:56:58', '2017-09-05 17:56:58');
INSERT INTO `c_login_log` VALUES ('2295', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 18:06:15', '2017-09-05 18:06:15');
INSERT INTO `c_login_log` VALUES ('2296', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 18:06:58', '2017-09-05 18:06:58');
INSERT INTO `c_login_log` VALUES ('2297', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 18:11:30', '2017-09-05 18:11:30');
INSERT INTO `c_login_log` VALUES ('2298', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 18:13:28', '2017-09-05 18:13:28');
INSERT INTO `c_login_log` VALUES ('2299', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 18:17:22', '2017-09-05 18:17:22');
INSERT INTO `c_login_log` VALUES ('2300', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 18:22:38', '2017-09-05 18:22:38');
INSERT INTO `c_login_log` VALUES ('2301', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-05 18:29:18', '2017-09-05 18:29:18');
INSERT INTO `c_login_log` VALUES ('2302', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 08:43:48', '2017-09-06 08:43:48');
INSERT INTO `c_login_log` VALUES ('2303', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 08:45:52', '2017-09-06 08:45:52');
INSERT INTO `c_login_log` VALUES ('2304', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 08:45:12', '2017-09-06 08:45:12');
INSERT INTO `c_login_log` VALUES ('2305', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 08:49:27', '2017-09-06 08:49:27');
INSERT INTO `c_login_log` VALUES ('2306', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 08:51:52', '2017-09-06 08:51:52');
INSERT INTO `c_login_log` VALUES ('2307', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 08:50:20', '2017-09-06 08:50:20');
INSERT INTO `c_login_log` VALUES ('2308', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 08:57:44', '2017-09-06 08:57:44');
INSERT INTO `c_login_log` VALUES ('2309', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 08:58:16', '2017-09-06 08:58:16');
INSERT INTO `c_login_log` VALUES ('2310', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 09:01:38', '2017-09-06 09:01:38');
INSERT INTO `c_login_log` VALUES ('2311', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 09:03:59', '2017-09-06 09:03:59');
INSERT INTO `c_login_log` VALUES ('2312', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 09:03:50', '2017-09-06 09:03:50');
INSERT INTO `c_login_log` VALUES ('2313', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 09:04:24', '2017-09-06 09:04:24');
INSERT INTO `c_login_log` VALUES ('2314', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 09:23:32', '2017-09-06 09:23:32');
INSERT INTO `c_login_log` VALUES ('2315', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 09:28:55', '2017-09-06 09:28:55');
INSERT INTO `c_login_log` VALUES ('2316', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 09:36:35', '2017-09-06 09:36:35');
INSERT INTO `c_login_log` VALUES ('2317', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 09:37:45', '2017-09-06 09:37:45');
INSERT INTO `c_login_log` VALUES ('2318', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 09:41:06', '2017-09-06 09:41:06');
INSERT INTO `c_login_log` VALUES ('2319', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 09:41:52', '2017-09-06 09:41:52');
INSERT INTO `c_login_log` VALUES ('2320', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 09:49:13', '2017-09-06 09:49:13');
INSERT INTO `c_login_log` VALUES ('2321', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 09:56:41', '2017-09-06 09:56:41');
INSERT INTO `c_login_log` VALUES ('2322', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 10:01:24', '2017-09-06 10:01:24');
INSERT INTO `c_login_log` VALUES ('2323', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 10:05:44', '2017-09-06 10:05:44');
INSERT INTO `c_login_log` VALUES ('2324', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 10:11:45', '2017-09-06 10:11:45');
INSERT INTO `c_login_log` VALUES ('2325', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 10:18:27', '2017-09-06 10:18:27');
INSERT INTO `c_login_log` VALUES ('2326', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 10:27:57', '2017-09-06 10:27:57');
INSERT INTO `c_login_log` VALUES ('2327', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 10:40:53', '2017-09-06 10:40:53');
INSERT INTO `c_login_log` VALUES ('2328', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 10:55:37', '2017-09-06 10:55:37');
INSERT INTO `c_login_log` VALUES ('2329', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 11:23:58', '2017-09-06 11:23:58');
INSERT INTO `c_login_log` VALUES ('2330', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 11:25:36', '2017-09-06 11:25:36');
INSERT INTO `c_login_log` VALUES ('2331', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 11:32:40', '2017-09-06 11:32:40');
INSERT INTO `c_login_log` VALUES ('2332', null, 'king', '2130706433', '用户成功登录系统', '2017-09-06 11:33:41', '2017-09-06 11:33:41');
INSERT INTO `c_login_log` VALUES ('2333', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 11:33:53', '2017-09-06 11:33:53');
INSERT INTO `c_login_log` VALUES ('2334', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 11:34:19', '2017-09-06 11:34:19');
INSERT INTO `c_login_log` VALUES ('2335', null, 'king', '2130706433', '用户成功登录系统', '2017-09-06 11:35:58', '2017-09-06 11:35:58');
INSERT INTO `c_login_log` VALUES ('2336', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 11:40:02', '2017-09-06 11:40:02');
INSERT INTO `c_login_log` VALUES ('2337', null, 'king', '2130706433', '用户成功登录系统', '2017-09-06 11:40:20', '2017-09-06 11:40:20');
INSERT INTO `c_login_log` VALUES ('2338', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 11:44:11', '2017-09-06 11:44:11');
INSERT INTO `c_login_log` VALUES ('2339', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 11:45:37', '2017-09-06 11:45:37');
INSERT INTO `c_login_log` VALUES ('2340', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 11:47:41', '2017-09-06 11:47:41');
INSERT INTO `c_login_log` VALUES ('2341', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 11:51:28', '2017-09-06 11:51:28');
INSERT INTO `c_login_log` VALUES ('2342', null, 'qiuzl', '2130706433', '用户成功登录系统', '2017-09-06 11:52:01', '2017-09-06 11:52:01');
INSERT INTO `c_login_log` VALUES ('2343', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 11:51:42', '2017-09-06 11:51:42');
INSERT INTO `c_login_log` VALUES ('2344', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 11:52:46', '2017-09-06 11:52:46');
INSERT INTO `c_login_log` VALUES ('2345', null, 'qiuzl', '2130706433', '用户成功登录系统', '2017-09-06 11:54:08', '2017-09-06 11:54:08');
INSERT INTO `c_login_log` VALUES ('2346', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 11:54:49', '2017-09-06 11:54:49');
INSERT INTO `c_login_log` VALUES ('2347', null, 'king', '2130706433', '用户成功登录系统', '2017-09-06 11:54:41', '2017-09-06 11:54:41');
INSERT INTO `c_login_log` VALUES ('2348', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 11:56:12', '2017-09-06 11:56:12');
INSERT INTO `c_login_log` VALUES ('2349', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 12:00:40', '2017-09-06 12:00:40');
INSERT INTO `c_login_log` VALUES ('2350', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 12:05:32', '2017-09-06 12:05:32');
INSERT INTO `c_login_log` VALUES ('2351', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 12:10:05', '2017-09-06 12:10:05');
INSERT INTO `c_login_log` VALUES ('2352', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 12:16:53', '2017-09-06 12:16:53');
INSERT INTO `c_login_log` VALUES ('2353', null, 'qiuzl', '2130706433', '用户成功登录系统', '2017-09-06 12:17:11', '2017-09-06 12:17:11');
INSERT INTO `c_login_log` VALUES ('2354', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 12:18:55', '2017-09-06 12:18:55');
INSERT INTO `c_login_log` VALUES ('2355', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 12:19:22', '2017-09-06 12:19:22');
INSERT INTO `c_login_log` VALUES ('2356', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 12:23:18', '2017-09-06 12:23:18');
INSERT INTO `c_login_log` VALUES ('2357', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 12:25:08', '2017-09-06 12:25:08');
INSERT INTO `c_login_log` VALUES ('2358', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 12:25:54', '2017-09-06 12:25:54');
INSERT INTO `c_login_log` VALUES ('2359', null, 'tomas', '2130706433', '用户成功登录系统', '2017-09-06 12:27:19', '2017-09-06 12:27:19');
INSERT INTO `c_login_log` VALUES ('2360', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-06 12:30:02', '2017-09-06 12:30:02');
INSERT INTO `c_login_log` VALUES ('2361', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 12:29:24', '2017-09-06 12:29:24');
INSERT INTO `c_login_log` VALUES ('2362', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 12:30:07', '2017-09-06 12:30:07');
INSERT INTO `c_login_log` VALUES ('2363', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 12:30:49', '2017-09-06 12:30:49');
INSERT INTO `c_login_log` VALUES ('2364', null, 'tomas', '2130706433', '用户成功登录系统', '2017-09-06 12:31:11', '2017-09-06 12:31:11');
INSERT INTO `c_login_log` VALUES ('2365', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 12:34:20', '2017-09-06 12:34:20');
INSERT INTO `c_login_log` VALUES ('2366', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 14:06:27', '2017-09-06 14:06:27');
INSERT INTO `c_login_log` VALUES ('2367', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 14:22:57', '2017-09-06 14:22:57');
INSERT INTO `c_login_log` VALUES ('2368', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 14:23:39', '2017-09-06 14:23:39');
INSERT INTO `c_login_log` VALUES ('2369', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 14:24:52', '2017-09-06 14:24:52');
INSERT INTO `c_login_log` VALUES ('2370', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 14:25:09', '2017-09-06 14:25:09');
INSERT INTO `c_login_log` VALUES ('2371', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 14:39:00', '2017-09-06 14:39:00');
INSERT INTO `c_login_log` VALUES ('2372', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 14:43:43', '2017-09-06 14:43:43');
INSERT INTO `c_login_log` VALUES ('2373', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 14:44:27', '2017-09-06 14:44:27');
INSERT INTO `c_login_log` VALUES ('2374', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 14:50:28', '2017-09-06 14:50:28');
INSERT INTO `c_login_log` VALUES ('2375', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 14:50:28', '2017-09-06 14:50:28');
INSERT INTO `c_login_log` VALUES ('2376', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 14:51:15', '2017-09-06 14:51:15');
INSERT INTO `c_login_log` VALUES ('2377', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 14:51:59', '2017-09-06 14:51:59');
INSERT INTO `c_login_log` VALUES ('2378', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 14:52:56', '2017-09-06 14:52:56');
INSERT INTO `c_login_log` VALUES ('2379', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 14:53:46', '2017-09-06 14:53:46');
INSERT INTO `c_login_log` VALUES ('2380', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 14:54:32', '2017-09-06 14:54:32');
INSERT INTO `c_login_log` VALUES ('2381', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 14:59:30', '2017-09-06 14:59:30');
INSERT INTO `c_login_log` VALUES ('2382', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 14:59:43', '2017-09-06 14:59:43');
INSERT INTO `c_login_log` VALUES ('2383', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 15:01:52', '2017-09-06 15:01:52');
INSERT INTO `c_login_log` VALUES ('2384', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 15:05:45', '2017-09-06 15:05:45');
INSERT INTO `c_login_log` VALUES ('2385', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 15:06:41', '2017-09-06 15:06:41');
INSERT INTO `c_login_log` VALUES ('2386', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 15:06:26', '2017-09-06 15:06:26');
INSERT INTO `c_login_log` VALUES ('2387', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 15:06:32', '2017-09-06 15:06:32');
INSERT INTO `c_login_log` VALUES ('2388', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 15:07:13', '2017-09-06 15:07:13');
INSERT INTO `c_login_log` VALUES ('2389', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 15:07:55', '2017-09-06 15:07:55');
INSERT INTO `c_login_log` VALUES ('2390', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 15:08:31', '2017-09-06 15:08:31');
INSERT INTO `c_login_log` VALUES ('2391', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 15:09:04', '2017-09-06 15:09:04');
INSERT INTO `c_login_log` VALUES ('2392', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 15:11:35', '2017-09-06 15:11:35');
INSERT INTO `c_login_log` VALUES ('2393', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 15:17:24', '2017-09-06 15:17:24');
INSERT INTO `c_login_log` VALUES ('2394', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 15:19:29', '2017-09-06 15:19:29');
INSERT INTO `c_login_log` VALUES ('2395', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 15:20:38', '2017-09-06 15:20:38');
INSERT INTO `c_login_log` VALUES ('2396', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 15:23:45', '2017-09-06 15:23:45');
INSERT INTO `c_login_log` VALUES ('2397', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-06 15:28:07', '2017-09-06 15:28:07');
INSERT INTO `c_login_log` VALUES ('2398', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 15:27:49', '2017-09-06 15:27:49');
INSERT INTO `c_login_log` VALUES ('2399', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 15:43:25', '2017-09-06 15:43:25');
INSERT INTO `c_login_log` VALUES ('2400', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-06 15:44:04', '2017-09-06 15:44:04');
INSERT INTO `c_login_log` VALUES ('2401', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-06 15:44:42', '2017-09-06 15:44:42');
INSERT INTO `c_login_log` VALUES ('2402', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-06 15:45:43', '2017-09-06 15:45:43');
INSERT INTO `c_login_log` VALUES ('2403', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-06 15:49:33', '2017-09-06 15:49:33');
INSERT INTO `c_login_log` VALUES ('2404', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-06 15:53:20', '2017-09-06 15:53:20');
INSERT INTO `c_login_log` VALUES ('2405', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-06 15:53:40', '2017-09-06 15:53:40');
INSERT INTO `c_login_log` VALUES ('2406', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-06 15:55:06', '2017-09-06 15:55:06');
INSERT INTO `c_login_log` VALUES ('2407', null, 'system', '2130706433', '用户成功登录系统', '2017-09-06 16:03:20', '2017-09-06 16:03:20');
INSERT INTO `c_login_log` VALUES ('2408', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 16:05:22', '2017-09-06 16:05:22');
INSERT INTO `c_login_log` VALUES ('2409', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 16:06:17', '2017-09-06 16:06:17');
INSERT INTO `c_login_log` VALUES ('2410', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-06 16:08:06', '2017-09-06 16:08:06');
INSERT INTO `c_login_log` VALUES ('2411', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-06 16:10:30', '2017-09-06 16:10:30');
INSERT INTO `c_login_log` VALUES ('2412', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-06 16:11:54', '2017-09-06 16:11:54');
INSERT INTO `c_login_log` VALUES ('2413', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-06 16:15:35', '2017-09-06 16:15:35');
INSERT INTO `c_login_log` VALUES ('2414', null, 'qiuzl', '2130706433', '用户成功登录系统', '2017-09-06 16:17:56', '2017-09-06 16:17:56');
INSERT INTO `c_login_log` VALUES ('2415', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 16:20:23', '2017-09-06 16:20:23');
INSERT INTO `c_login_log` VALUES ('2416', null, 'qiuzl', '2130706433', '用户成功登录系统', '2017-09-06 16:20:39', '2017-09-06 16:20:39');
INSERT INTO `c_login_log` VALUES ('2417', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 16:20:15', '2017-09-06 16:20:15');
INSERT INTO `c_login_log` VALUES ('2418', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-06 16:20:33', '2017-09-06 16:20:33');
INSERT INTO `c_login_log` VALUES ('2419', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 16:34:43', '2017-09-06 16:34:43');
INSERT INTO `c_login_log` VALUES ('2420', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 16:35:00', '2017-09-06 16:35:00');
INSERT INTO `c_login_log` VALUES ('2421', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-06 16:35:09', '2017-09-06 16:35:09');
INSERT INTO `c_login_log` VALUES ('2422', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 16:37:25', '2017-09-06 16:37:25');
INSERT INTO `c_login_log` VALUES ('2423', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-06 16:37:43', '2017-09-06 16:37:43');
INSERT INTO `c_login_log` VALUES ('2424', null, 'tomas', '2130706433', '用户成功登录系统', '2017-09-06 16:38:31', '2017-09-06 16:38:31');
INSERT INTO `c_login_log` VALUES ('2425', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 16:42:06', '2017-09-06 16:42:06');
INSERT INTO `c_login_log` VALUES ('2426', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-06 16:44:08', '2017-09-06 16:44:08');
INSERT INTO `c_login_log` VALUES ('2427', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 16:47:19', '2017-09-06 16:47:19');
INSERT INTO `c_login_log` VALUES ('2428', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-06 16:49:32', '2017-09-06 16:49:32');
INSERT INTO `c_login_log` VALUES ('2429', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 16:55:00', '2017-09-06 16:55:00');
INSERT INTO `c_login_log` VALUES ('2430', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-06 16:56:37', '2017-09-06 16:56:37');
INSERT INTO `c_login_log` VALUES ('2431', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 16:57:00', '2017-09-06 16:57:00');
INSERT INTO `c_login_log` VALUES ('2432', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 16:59:12', '2017-09-06 16:59:12');
INSERT INTO `c_login_log` VALUES ('2433', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 17:00:02', '2017-09-06 17:00:02');
INSERT INTO `c_login_log` VALUES ('2434', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-06 17:11:47', '2017-09-06 17:11:47');
INSERT INTO `c_login_log` VALUES ('2435', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 17:18:54', '2017-09-06 17:18:54');
INSERT INTO `c_login_log` VALUES ('2436', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 17:19:47', '2017-09-06 17:19:47');
INSERT INTO `c_login_log` VALUES ('2437', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 17:20:53', '2017-09-06 17:20:53');
INSERT INTO `c_login_log` VALUES ('2438', null, 'qiuzl', '2130706433', '用户成功登录系统', '2017-09-06 17:22:12', '2017-09-06 17:22:12');
INSERT INTO `c_login_log` VALUES ('2439', null, 'qiuzl', '2130706433', '用户成功登录系统', '2017-09-06 17:22:45', '2017-09-06 17:22:45');
INSERT INTO `c_login_log` VALUES ('2440', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 17:28:22', '2017-09-06 17:28:22');
INSERT INTO `c_login_log` VALUES ('2441', null, 'qiuzl', '2130706433', '用户成功登录系统', '2017-09-06 17:29:59', '2017-09-06 17:29:59');
INSERT INTO `c_login_log` VALUES ('2442', null, 'qiuzl', '2130706433', '用户成功登录系统', '2017-09-06 17:30:41', '2017-09-06 17:30:41');
INSERT INTO `c_login_log` VALUES ('2443', null, 'qiuzl', '2130706433', '用户成功登录系统', '2017-09-06 17:34:31', '2017-09-06 17:34:31');
INSERT INTO `c_login_log` VALUES ('2444', null, 'qiuzl', '2130706433', '用户成功登录系统', '2017-09-06 17:36:42', '2017-09-06 17:36:42');
INSERT INTO `c_login_log` VALUES ('2445', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 17:49:53', '2017-09-06 17:49:53');
INSERT INTO `c_login_log` VALUES ('2446', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-06 17:52:10', '2017-09-06 17:52:10');
INSERT INTO `c_login_log` VALUES ('2447', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 17:51:52', '2017-09-06 17:51:52');
INSERT INTO `c_login_log` VALUES ('2448', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 17:52:25', '2017-09-06 17:52:25');
INSERT INTO `c_login_log` VALUES ('2449', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 17:52:37', '2017-09-06 17:52:37');
INSERT INTO `c_login_log` VALUES ('2450', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 17:54:49', '2017-09-06 17:54:49');
INSERT INTO `c_login_log` VALUES ('2451', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 17:59:56', '2017-09-06 17:59:56');
INSERT INTO `c_login_log` VALUES ('2452', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 18:00:18', '2017-09-06 18:00:18');
INSERT INTO `c_login_log` VALUES ('2453', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 18:11:45', '2017-09-06 18:11:45');
INSERT INTO `c_login_log` VALUES ('2454', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-06 18:29:57', '2017-09-06 18:29:57');
INSERT INTO `c_login_log` VALUES ('2455', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 08:48:43', '2017-09-07 08:48:43');
INSERT INTO `c_login_log` VALUES ('2456', null, 'qiuzl', '2130706433', '用户成功登录系统', '2017-09-07 08:49:36', '2017-09-07 08:49:36');
INSERT INTO `c_login_log` VALUES ('2457', null, 'qiuzl', '2130706433', '用户成功登录系统', '2017-09-07 09:03:43', '2017-09-07 09:03:43');
INSERT INTO `c_login_log` VALUES ('2458', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 09:04:00', '2017-09-07 09:04:00');
INSERT INTO `c_login_log` VALUES ('2459', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 09:05:06', '2017-09-07 09:05:06');
INSERT INTO `c_login_log` VALUES ('2460', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 09:12:24', '2017-09-07 09:12:24');
INSERT INTO `c_login_log` VALUES ('2461', null, 'qiuzl', '2130706433', '用户成功登录系统', '2017-09-07 09:13:09', '2017-09-07 09:13:09');
INSERT INTO `c_login_log` VALUES ('2462', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 09:13:45', '2017-09-07 09:13:45');
INSERT INTO `c_login_log` VALUES ('2463', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 09:21:59', '2017-09-07 09:21:59');
INSERT INTO `c_login_log` VALUES ('2464', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 10:30:23', '2017-09-07 10:30:23');
INSERT INTO `c_login_log` VALUES ('2465', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 10:33:29', '2017-09-07 10:33:29');
INSERT INTO `c_login_log` VALUES ('2466', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 10:47:44', '2017-09-07 10:47:44');
INSERT INTO `c_login_log` VALUES ('2467', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 11:25:28', '2017-09-07 11:25:28');
INSERT INTO `c_login_log` VALUES ('2468', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 11:28:33', '2017-09-07 11:28:33');
INSERT INTO `c_login_log` VALUES ('2469', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 11:45:36', '2017-09-07 11:45:36');
INSERT INTO `c_login_log` VALUES ('2470', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 11:54:09', '2017-09-07 11:54:09');
INSERT INTO `c_login_log` VALUES ('2471', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 11:58:10', '2017-09-07 11:58:10');
INSERT INTO `c_login_log` VALUES ('2472', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 11:57:06', '2017-09-07 11:57:06');
INSERT INTO `c_login_log` VALUES ('2473', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 12:02:12', '2017-09-07 12:02:12');
INSERT INTO `c_login_log` VALUES ('2474', null, 'qiuzl', '2130706433', '用户成功登录系统', '2017-09-07 12:04:15', '2017-09-07 12:04:15');
INSERT INTO `c_login_log` VALUES ('2475', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 12:08:17', '2017-09-07 12:08:17');
INSERT INTO `c_login_log` VALUES ('2476', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 12:11:45', '2017-09-07 12:11:45');
INSERT INTO `c_login_log` VALUES ('2477', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 12:12:36', '2017-09-07 12:12:36');
INSERT INTO `c_login_log` VALUES ('2478', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 12:12:36', '2017-09-07 12:12:36');
INSERT INTO `c_login_log` VALUES ('2479', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 12:19:01', '2017-09-07 12:19:01');
INSERT INTO `c_login_log` VALUES ('2480', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 12:19:38', '2017-09-07 12:19:38');
INSERT INTO `c_login_log` VALUES ('2481', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 14:04:14', '2017-09-07 14:04:14');
INSERT INTO `c_login_log` VALUES ('2482', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 14:10:46', '2017-09-07 14:10:46');
INSERT INTO `c_login_log` VALUES ('2483', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 14:13:33', '2017-09-07 14:13:33');
INSERT INTO `c_login_log` VALUES ('2484', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 14:18:59', '2017-09-07 14:18:59');
INSERT INTO `c_login_log` VALUES ('2485', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 14:19:49', '2017-09-07 14:19:49');
INSERT INTO `c_login_log` VALUES ('2486', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 14:22:47', '2017-09-07 14:22:47');
INSERT INTO `c_login_log` VALUES ('2487', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 14:25:42', '2017-09-07 14:25:42');
INSERT INTO `c_login_log` VALUES ('2488', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 14:36:17', '2017-09-07 14:36:17');
INSERT INTO `c_login_log` VALUES ('2489', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 14:48:31', '2017-09-07 14:48:31');
INSERT INTO `c_login_log` VALUES ('2490', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 14:48:24', '2017-09-07 14:48:24');
INSERT INTO `c_login_log` VALUES ('2491', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 15:04:50', '2017-09-07 15:04:50');
INSERT INTO `c_login_log` VALUES ('2492', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 15:07:43', '2017-09-07 15:07:43');
INSERT INTO `c_login_log` VALUES ('2493', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 15:30:21', '2017-09-07 15:30:21');
INSERT INTO `c_login_log` VALUES ('2494', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 16:21:30', '2017-09-07 16:21:30');
INSERT INTO `c_login_log` VALUES ('2495', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 16:48:41', '2017-09-07 16:48:41');
INSERT INTO `c_login_log` VALUES ('2496', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 16:53:03', '2017-09-07 16:53:03');
INSERT INTO `c_login_log` VALUES ('2497', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 17:08:37', '2017-09-07 17:08:37');
INSERT INTO `c_login_log` VALUES ('2498', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 17:11:14', '2017-09-07 17:11:14');
INSERT INTO `c_login_log` VALUES ('2499', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 17:30:47', '2017-09-07 17:30:47');
INSERT INTO `c_login_log` VALUES ('2500', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-07 17:47:48', '2017-09-07 17:47:48');
INSERT INTO `c_login_log` VALUES ('2501', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 08:42:47', '2017-09-08 08:42:47');
INSERT INTO `c_login_log` VALUES ('2502', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 08:43:44', '2017-09-08 08:43:44');
INSERT INTO `c_login_log` VALUES ('2503', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 08:47:35', '2017-09-08 08:47:35');
INSERT INTO `c_login_log` VALUES ('2504', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 08:58:51', '2017-09-08 08:58:51');
INSERT INTO `c_login_log` VALUES ('2505', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 09:10:07', '2017-09-08 09:10:07');
INSERT INTO `c_login_log` VALUES ('2506', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 09:08:41', '2017-09-08 09:08:41');
INSERT INTO `c_login_log` VALUES ('2507', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 09:14:36', '2017-09-08 09:14:36');
INSERT INTO `c_login_log` VALUES ('2508', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 09:27:04', '2017-09-08 09:27:04');
INSERT INTO `c_login_log` VALUES ('2509', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 09:27:40', '2017-09-08 09:27:40');
INSERT INTO `c_login_log` VALUES ('2510', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 09:35:02', '2017-09-08 09:35:02');
INSERT INTO `c_login_log` VALUES ('2511', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 09:35:46', '2017-09-08 09:35:46');
INSERT INTO `c_login_log` VALUES ('2512', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 09:38:12', '2017-09-08 09:38:12');
INSERT INTO `c_login_log` VALUES ('2513', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 09:37:57', '2017-09-08 09:37:57');
INSERT INTO `c_login_log` VALUES ('2514', null, 'qiuzl', '2130706433', '用户成功登录系统', '2017-09-08 09:49:05', '2017-09-08 09:49:05');
INSERT INTO `c_login_log` VALUES ('2515', null, 'qiuzl', '2130706433', '用户成功登录系统', '2017-09-08 09:51:04', '2017-09-08 09:51:04');
INSERT INTO `c_login_log` VALUES ('2516', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 09:49:21', '2017-09-08 09:49:21');
INSERT INTO `c_login_log` VALUES ('2517', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 10:11:34', '2017-09-08 10:11:34');
INSERT INTO `c_login_log` VALUES ('2518', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 10:17:07', '2017-09-08 10:17:07');
INSERT INTO `c_login_log` VALUES ('2519', null, 'bgs', '2130706433', '用户成功登录系统', '2017-09-08 10:18:30', '2017-09-08 10:18:30');
INSERT INTO `c_login_log` VALUES ('2520', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 10:27:28', '2017-09-08 10:27:28');
INSERT INTO `c_login_log` VALUES ('2521', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 10:49:54', '2017-09-08 10:49:54');
INSERT INTO `c_login_log` VALUES ('2522', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 11:01:38', '2017-09-08 11:01:38');
INSERT INTO `c_login_log` VALUES ('2523', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 11:09:39', '2017-09-08 11:09:39');
INSERT INTO `c_login_log` VALUES ('2524', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 11:11:47', '2017-09-08 11:11:47');
INSERT INTO `c_login_log` VALUES ('2525', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 11:12:11', '2017-09-08 11:12:11');
INSERT INTO `c_login_log` VALUES ('2526', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 11:13:25', '2017-09-08 11:13:25');
INSERT INTO `c_login_log` VALUES ('2527', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-08 11:15:14', '2017-09-08 11:15:14');
INSERT INTO `c_login_log` VALUES ('2528', null, 'bgs', '2130706433', '用户成功登录系统', '2017-09-08 11:16:11', '2017-09-08 11:16:11');
INSERT INTO `c_login_log` VALUES ('2529', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-08 11:18:42', '2017-09-08 11:18:42');
INSERT INTO `c_login_log` VALUES ('2530', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-08 11:22:11', '2017-09-08 11:22:11');
INSERT INTO `c_login_log` VALUES ('2531', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-08 11:24:46', '2017-09-08 11:24:46');
INSERT INTO `c_login_log` VALUES ('2532', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-08 11:30:37', '2017-09-08 11:30:37');
INSERT INTO `c_login_log` VALUES ('2533', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 11:32:35', '2017-09-08 11:32:35');
INSERT INTO `c_login_log` VALUES ('2534', null, 'bgs', '2130706433', '用户成功登录系统', '2017-09-08 11:33:14', '2017-09-08 11:33:14');
INSERT INTO `c_login_log` VALUES ('2535', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 11:44:44', '2017-09-08 11:44:44');
INSERT INTO `c_login_log` VALUES ('2536', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 11:46:14', '2017-09-08 11:46:14');
INSERT INTO `c_login_log` VALUES ('2537', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 11:55:46', '2017-09-08 11:55:46');
INSERT INTO `c_login_log` VALUES ('2538', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 11:58:16', '2017-09-08 11:58:16');
INSERT INTO `c_login_log` VALUES ('2539', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 12:04:16', '2017-09-08 12:04:16');
INSERT INTO `c_login_log` VALUES ('2540', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 12:10:48', '2017-09-08 12:10:48');
INSERT INTO `c_login_log` VALUES ('2541', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 12:23:14', '2017-09-08 12:23:14');
INSERT INTO `c_login_log` VALUES ('2542', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 12:25:45', '2017-09-08 12:25:45');
INSERT INTO `c_login_log` VALUES ('2543', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 12:27:31', '2017-09-08 12:27:31');
INSERT INTO `c_login_log` VALUES ('2544', null, 'bgs', '2130706433', '用户成功登录系统', '2017-09-08 12:33:47', '2017-09-08 12:33:47');
INSERT INTO `c_login_log` VALUES ('2545', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 12:32:26', '2017-09-08 12:32:26');
INSERT INTO `c_login_log` VALUES ('2546', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 14:05:14', '2017-09-08 14:05:14');
INSERT INTO `c_login_log` VALUES ('2547', null, 'bgs', '2130706433', '用户成功登录系统', '2017-09-08 14:08:39', '2017-09-08 14:08:39');
INSERT INTO `c_login_log` VALUES ('2548', null, 'bgs', '2130706433', '用户成功登录系统', '2017-09-08 14:17:10', '2017-09-08 14:17:10');
INSERT INTO `c_login_log` VALUES ('2549', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-08 14:22:02', '2017-09-08 14:22:02');
INSERT INTO `c_login_log` VALUES ('2550', null, 'bgs', '2130706433', '用户成功登录系统', '2017-09-08 14:25:17', '2017-09-08 14:25:17');
INSERT INTO `c_login_log` VALUES ('2551', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-08 14:28:59', '2017-09-08 14:28:59');
INSERT INTO `c_login_log` VALUES ('2552', null, 'bgs', '2130706433', '用户成功登录系统', '2017-09-08 14:33:43', '2017-09-08 14:33:43');
INSERT INTO `c_login_log` VALUES ('2553', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-08 14:37:22', '2017-09-08 14:37:22');
INSERT INTO `c_login_log` VALUES ('2554', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-09-08 14:44:11', '2017-09-08 14:44:11');
INSERT INTO `c_login_log` VALUES ('2555', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 14:49:46', '2017-09-08 14:49:46');
INSERT INTO `c_login_log` VALUES ('2556', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 15:45:38', '2017-09-08 15:45:38');
INSERT INTO `c_login_log` VALUES ('2557', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 16:09:35', '2017-09-08 16:09:35');
INSERT INTO `c_login_log` VALUES ('2558', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-08 17:23:49', '2017-09-08 17:23:49');
INSERT INTO `c_login_log` VALUES ('2559', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-11 09:03:38', '2017-09-11 09:03:38');
INSERT INTO `c_login_log` VALUES ('2560', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-12 09:34:41', '2017-09-12 09:34:41');
INSERT INTO `c_login_log` VALUES ('2561', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-12 09:35:59', '2017-09-12 09:35:59');
INSERT INTO `c_login_log` VALUES ('2562', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-12 10:17:20', '2017-09-12 10:17:20');
INSERT INTO `c_login_log` VALUES ('2563', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-12 10:17:35', '2017-09-12 10:17:35');
INSERT INTO `c_login_log` VALUES ('2564', null, 'system', '2130706433', '用户成功登录系统', '2017-09-12 11:20:16', '2017-09-12 11:20:16');
INSERT INTO `c_login_log` VALUES ('2565', null, 'system', '2130706433', '用户成功登录系统', '2017-09-12 11:35:14', '2017-09-12 11:35:14');
INSERT INTO `c_login_log` VALUES ('2566', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-14 09:26:14', '2017-09-14 09:26:14');
INSERT INTO `c_login_log` VALUES ('2567', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-14 09:29:52', '2017-09-14 09:29:52');
INSERT INTO `c_login_log` VALUES ('2568', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-14 09:30:15', '2017-09-14 09:30:15');
INSERT INTO `c_login_log` VALUES ('2569', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-14 10:18:03', '2017-09-14 10:18:03');
INSERT INTO `c_login_log` VALUES ('2570', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-14 10:18:56', '2017-09-14 10:18:56');
INSERT INTO `c_login_log` VALUES ('2571', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-14 10:20:42', '2017-09-14 10:20:42');
INSERT INTO `c_login_log` VALUES ('2572', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-14 11:13:04', '2017-09-14 11:13:04');
INSERT INTO `c_login_log` VALUES ('2573', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-14 12:06:24', '2017-09-14 12:06:24');
INSERT INTO `c_login_log` VALUES ('2574', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-14 12:04:43', '2017-09-14 12:04:43');
INSERT INTO `c_login_log` VALUES ('2575', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-14 12:12:06', '2017-09-14 12:12:06');
INSERT INTO `c_login_log` VALUES ('2576', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-14 12:15:09', '2017-09-14 12:15:09');
INSERT INTO `c_login_log` VALUES ('2577', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-14 14:08:54', '2017-09-14 14:08:54');
INSERT INTO `c_login_log` VALUES ('2578', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-14 14:26:12', '2017-09-14 14:26:12');
INSERT INTO `c_login_log` VALUES ('2579', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-14 14:28:52', '2017-09-14 14:28:52');
INSERT INTO `c_login_log` VALUES ('2580', null, 'system', '2130706433', '用户成功登录系统', '2017-09-14 14:48:21', '2017-09-14 14:48:21');
INSERT INTO `c_login_log` VALUES ('2581', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-14 14:56:11', '2017-09-14 14:56:11');
INSERT INTO `c_login_log` VALUES ('2582', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-14 15:43:56', '2017-09-14 15:43:56');
INSERT INTO `c_login_log` VALUES ('2583', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-15 09:03:30', '2017-09-15 09:03:30');
INSERT INTO `c_login_log` VALUES ('2584', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-15 09:26:09', '2017-09-15 09:26:09');
INSERT INTO `c_login_log` VALUES ('2585', null, 'linlimei', '2130706433', '用户成功登录系统', '2017-09-15 09:27:11', '2017-09-15 09:27:11');
INSERT INTO `c_login_log` VALUES ('2586', null, 'linlimei', '2130706433', '用户成功登录系统', '2017-09-15 09:31:45', '2017-09-15 09:31:45');
INSERT INTO `c_login_log` VALUES ('2587', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-15 09:36:33', '2017-09-15 09:36:33');
INSERT INTO `c_login_log` VALUES ('2588', null, 'linlimei', '2130706433', '用户成功登录系统', '2017-09-15 09:39:53', '2017-09-15 09:39:53');
INSERT INTO `c_login_log` VALUES ('2589', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-15 11:14:26', '2017-09-15 11:14:26');
INSERT INTO `c_login_log` VALUES ('2590', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-15 11:28:10', '2017-09-15 11:28:10');
INSERT INTO `c_login_log` VALUES ('2591', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-15 11:36:24', '2017-09-15 11:36:24');
INSERT INTO `c_login_log` VALUES ('2592', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-15 11:42:44', '2017-09-15 11:42:44');
INSERT INTO `c_login_log` VALUES ('2593', null, 'system', '2130706433', '用户成功登录系统', '2017-09-15 11:43:22', '2017-09-15 11:43:22');
INSERT INTO `c_login_log` VALUES ('2594', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-15 11:45:34', '2017-09-15 11:45:34');
INSERT INTO `c_login_log` VALUES ('2595', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-15 11:46:01', '2017-09-15 11:46:01');
INSERT INTO `c_login_log` VALUES ('2596', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-15 12:11:36', '2017-09-15 12:11:36');
INSERT INTO `c_login_log` VALUES ('2597', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-15 12:19:29', '2017-09-15 12:19:29');
INSERT INTO `c_login_log` VALUES ('2598', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-15 12:19:48', '2017-09-15 12:19:48');
INSERT INTO `c_login_log` VALUES ('2599', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-15 14:17:50', '2017-09-15 14:17:50');
INSERT INTO `c_login_log` VALUES ('2600', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-15 14:54:13', '2017-09-15 14:54:13');
INSERT INTO `c_login_log` VALUES ('2601', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-15 15:15:56', '2017-09-15 15:15:56');
INSERT INTO `c_login_log` VALUES ('2602', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-15 15:25:33', '2017-09-15 15:25:33');
INSERT INTO `c_login_log` VALUES ('2603', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-15 15:34:27', '2017-09-15 15:34:27');
INSERT INTO `c_login_log` VALUES ('2604', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-15 15:58:28', '2017-09-15 15:58:28');
INSERT INTO `c_login_log` VALUES ('2605', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-15 17:40:57', '2017-09-15 17:40:57');
INSERT INTO `c_login_log` VALUES ('2606', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-18 08:51:46', '2017-09-18 08:51:46');
INSERT INTO `c_login_log` VALUES ('2607', null, 'bgs', '2130706433', '用户成功登录系统', '2017-09-18 10:47:34', '2017-09-18 10:47:34');
INSERT INTO `c_login_log` VALUES ('2608', null, 'bgs', '2130706433', '用户成功登录系统', '2017-09-18 10:53:25', '2017-09-18 10:53:25');
INSERT INTO `c_login_log` VALUES ('2609', null, 'bgs', '2130706433', '用户成功登录系统', '2017-09-18 11:04:30', '2017-09-18 11:04:30');
INSERT INTO `c_login_log` VALUES ('2610', null, 'bgs', '2130706433', '用户成功登录系统', '2017-09-18 11:04:52', '2017-09-18 11:04:52');
INSERT INTO `c_login_log` VALUES ('2611', null, 'bgs', '2130706433', '用户成功登录系统', '2017-09-18 11:09:06', '2017-09-18 11:09:06');
INSERT INTO `c_login_log` VALUES ('2612', null, 'bgs', '2130706433', '用户成功登录系统', '2017-09-18 11:09:23', '2017-09-18 11:09:23');
INSERT INTO `c_login_log` VALUES ('2613', null, 'bgs', '2130706433', '用户成功登录系统', '2017-09-18 11:10:56', '2017-09-18 11:10:56');
INSERT INTO `c_login_log` VALUES ('2614', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-18 11:12:34', '2017-09-18 11:12:34');
INSERT INTO `c_login_log` VALUES ('2615', null, 'bgs', '2130706433', '用户成功登录系统', '2017-09-18 11:13:05', '2017-09-18 11:13:05');
INSERT INTO `c_login_log` VALUES ('2616', null, 'bgs', '2130706433', '用户成功登录系统', '2017-09-18 11:13:22', '2017-09-18 11:13:22');
INSERT INTO `c_login_log` VALUES ('2617', null, 'bgs', '2130706433', '用户成功登录系统', '2017-09-18 11:14:56', '2017-09-18 11:14:56');
INSERT INTO `c_login_log` VALUES ('2618', null, 'bgs', '2130706433', '用户成功登录系统', '2017-09-18 11:15:12', '2017-09-18 11:15:12');
INSERT INTO `c_login_log` VALUES ('2619', null, 'bgs', '2130706433', '用户成功登录系统', '2017-09-18 11:15:34', '2017-09-18 11:15:34');
INSERT INTO `c_login_log` VALUES ('2620', null, 'bgs', '2130706433', '用户成功登录系统', '2017-09-18 11:18:36', '2017-09-18 11:18:36');
INSERT INTO `c_login_log` VALUES ('2621', null, 'bgs', '2130706433', '用户成功登录系统', '2017-09-18 11:34:42', '2017-09-18 11:34:42');
INSERT INTO `c_login_log` VALUES ('2622', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-18 12:05:08', '2017-09-18 12:05:08');
INSERT INTO `c_login_log` VALUES ('2623', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-18 12:26:41', '2017-09-18 12:26:41');
INSERT INTO `c_login_log` VALUES ('2624', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-18 14:31:54', '2017-09-18 14:31:54');
INSERT INTO `c_login_log` VALUES ('2625', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-18 14:38:53', '2017-09-18 14:38:53');
INSERT INTO `c_login_log` VALUES ('2626', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-18 16:00:32', '2017-09-18 16:00:32');
INSERT INTO `c_login_log` VALUES ('2627', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-18 16:14:35', '2017-09-18 16:14:35');
INSERT INTO `c_login_log` VALUES ('2628', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-18 16:16:44', '2017-09-18 16:16:44');
INSERT INTO `c_login_log` VALUES ('2629', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-18 16:18:43', '2017-09-18 16:18:43');
INSERT INTO `c_login_log` VALUES ('2630', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-18 16:20:25', '2017-09-18 16:20:25');
INSERT INTO `c_login_log` VALUES ('2631', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-20 09:21:15', '2017-09-20 09:21:15');
INSERT INTO `c_login_log` VALUES ('2632', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-21 10:40:11', '2017-09-21 10:40:11');
INSERT INTO `c_login_log` VALUES ('2633', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-21 10:44:40', '2017-09-21 10:44:40');
INSERT INTO `c_login_log` VALUES ('2634', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-21 11:18:56', '2017-09-21 11:18:56');
INSERT INTO `c_login_log` VALUES ('2635', null, 'bgs', '2130706433', '用户成功登录系统', '2017-09-21 11:29:11', '2017-09-21 11:29:11');
INSERT INTO `c_login_log` VALUES ('2636', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-21 11:53:56', '2017-09-21 11:53:56');
INSERT INTO `c_login_log` VALUES ('2637', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-21 12:06:24', '2017-09-21 12:06:24');
INSERT INTO `c_login_log` VALUES ('2638', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-21 14:29:24', '2017-09-21 14:29:24');
INSERT INTO `c_login_log` VALUES ('2639', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-21 15:58:42', '2017-09-21 15:58:42');
INSERT INTO `c_login_log` VALUES ('2640', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-21 17:45:56', '2017-09-21 17:45:56');
INSERT INTO `c_login_log` VALUES ('2641', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-21 17:46:17', '2017-09-21 17:46:17');
INSERT INTO `c_login_log` VALUES ('2642', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-21 18:14:52', '2017-09-21 18:14:52');
INSERT INTO `c_login_log` VALUES ('2643', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-21 18:16:30', '2017-09-21 18:16:30');
INSERT INTO `c_login_log` VALUES ('2644', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-21 18:17:41', '2017-09-21 18:17:41');
INSERT INTO `c_login_log` VALUES ('2645', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-22 08:46:55', '2017-09-22 08:46:55');
INSERT INTO `c_login_log` VALUES ('2646', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-22 08:59:51', '2017-09-22 08:59:51');
INSERT INTO `c_login_log` VALUES ('2647', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-22 09:19:48', '2017-09-22 09:19:48');
INSERT INTO `c_login_log` VALUES ('2648', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-28 10:17:33', '2017-09-28 10:17:33');
INSERT INTO `c_login_log` VALUES ('2649', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-29 09:34:18', '2017-09-29 09:34:18');
INSERT INTO `c_login_log` VALUES ('2650', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-29 17:59:13', '2017-09-29 17:59:13');
INSERT INTO `c_login_log` VALUES ('2651', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-30 08:47:03', '2017-09-30 08:47:03');
INSERT INTO `c_login_log` VALUES ('2652', null, 'admin', '2130706433', '用户成功登录系统', '2017-09-30 14:45:05', '2017-09-30 14:45:05');
INSERT INTO `c_login_log` VALUES ('2653', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-19 15:17:04', '2017-10-19 15:17:04');
INSERT INTO `c_login_log` VALUES ('2654', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-19 16:01:03', '2017-10-19 16:01:03');
INSERT INTO `c_login_log` VALUES ('2655', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-19 16:23:27', '2017-10-19 16:23:27');
INSERT INTO `c_login_log` VALUES ('2656', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-19 16:31:45', '2017-10-19 16:31:45');
INSERT INTO `c_login_log` VALUES ('2657', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-19 16:45:40', '2017-10-19 16:45:40');
INSERT INTO `c_login_log` VALUES ('2658', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-19 17:01:32', '2017-10-19 17:01:32');
INSERT INTO `c_login_log` VALUES ('2659', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-19 17:05:03', '2017-10-19 17:05:03');
INSERT INTO `c_login_log` VALUES ('2660', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-19 17:13:36', '2017-10-19 17:13:36');
INSERT INTO `c_login_log` VALUES ('2661', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-19 17:25:41', '2017-10-19 17:25:41');
INSERT INTO `c_login_log` VALUES ('2662', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-19 17:32:09', '2017-10-19 17:32:09');
INSERT INTO `c_login_log` VALUES ('2663', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-19 17:39:49', '2017-10-19 17:39:49');
INSERT INTO `c_login_log` VALUES ('2664', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-19 17:44:39', '2017-10-19 17:44:39');
INSERT INTO `c_login_log` VALUES ('2665', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-19 17:50:07', '2017-10-19 17:50:07');
INSERT INTO `c_login_log` VALUES ('2666', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-19 17:56:46', '2017-10-19 17:56:46');
INSERT INTO `c_login_log` VALUES ('2667', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-19 17:57:59', '2017-10-19 17:57:59');
INSERT INTO `c_login_log` VALUES ('2668', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-19 18:14:03', '2017-10-19 18:14:03');
INSERT INTO `c_login_log` VALUES ('2669', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-19 18:21:48', '2017-10-19 18:21:48');
INSERT INTO `c_login_log` VALUES ('2670', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-19 18:51:45', '2017-10-19 18:51:45');
INSERT INTO `c_login_log` VALUES ('2671', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-19 18:56:27', '2017-10-19 18:56:27');
INSERT INTO `c_login_log` VALUES ('2672', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 08:50:31', '2017-10-20 08:50:31');
INSERT INTO `c_login_log` VALUES ('2673', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 09:23:01', '2017-10-20 09:23:01');
INSERT INTO `c_login_log` VALUES ('2674', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 09:46:57', '2017-10-20 09:46:57');
INSERT INTO `c_login_log` VALUES ('2675', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 09:55:05', '2017-10-20 09:55:05');
INSERT INTO `c_login_log` VALUES ('2676', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 10:06:39', '2017-10-20 10:06:39');
INSERT INTO `c_login_log` VALUES ('2677', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 10:11:07', '2017-10-20 10:11:07');
INSERT INTO `c_login_log` VALUES ('2678', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 10:13:20', '2017-10-20 10:13:20');
INSERT INTO `c_login_log` VALUES ('2679', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 10:15:57', '2017-10-20 10:15:57');
INSERT INTO `c_login_log` VALUES ('2680', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 10:22:29', '2017-10-20 10:22:29');
INSERT INTO `c_login_log` VALUES ('2681', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 10:27:55', '2017-10-20 10:27:55');
INSERT INTO `c_login_log` VALUES ('2682', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 10:48:33', '2017-10-20 10:48:33');
INSERT INTO `c_login_log` VALUES ('2683', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 11:00:39', '2017-10-20 11:00:39');
INSERT INTO `c_login_log` VALUES ('2684', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 11:03:25', '2017-10-20 11:03:25');
INSERT INTO `c_login_log` VALUES ('2685', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 11:16:31', '2017-10-20 11:16:31');
INSERT INTO `c_login_log` VALUES ('2686', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 11:19:25', '2017-10-20 11:19:25');
INSERT INTO `c_login_log` VALUES ('2687', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 11:45:29', '2017-10-20 11:45:29');
INSERT INTO `c_login_log` VALUES ('2688', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 12:25:37', '2017-10-20 12:25:37');
INSERT INTO `c_login_log` VALUES ('2689', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 12:26:18', '2017-10-20 12:26:18');
INSERT INTO `c_login_log` VALUES ('2690', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 12:27:04', '2017-10-20 12:27:04');
INSERT INTO `c_login_log` VALUES ('2691', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 12:27:27', '2017-10-20 12:27:27');
INSERT INTO `c_login_log` VALUES ('2692', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 12:35:46', '2017-10-20 12:35:46');
INSERT INTO `c_login_log` VALUES ('2693', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 14:07:29', '2017-10-20 14:07:29');
INSERT INTO `c_login_log` VALUES ('2694', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 14:08:35', '2017-10-20 14:08:35');
INSERT INTO `c_login_log` VALUES ('2695', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 14:09:23', '2017-10-20 14:09:23');
INSERT INTO `c_login_log` VALUES ('2696', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 14:09:40', '2017-10-20 14:09:40');
INSERT INTO `c_login_log` VALUES ('2697', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 14:20:27', '2017-10-20 14:20:27');
INSERT INTO `c_login_log` VALUES ('2698', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 14:22:02', '2017-10-20 14:22:02');
INSERT INTO `c_login_log` VALUES ('2699', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 14:24:15', '2017-10-20 14:24:15');
INSERT INTO `c_login_log` VALUES ('2700', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 14:28:50', '2017-10-20 14:28:50');
INSERT INTO `c_login_log` VALUES ('2701', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 14:45:17', '2017-10-20 14:45:17');
INSERT INTO `c_login_log` VALUES ('2702', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 14:46:39', '2017-10-20 14:46:39');
INSERT INTO `c_login_log` VALUES ('2703', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 14:59:25', '2017-10-20 14:59:25');
INSERT INTO `c_login_log` VALUES ('2704', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 15:01:55', '2017-10-20 15:01:55');
INSERT INTO `c_login_log` VALUES ('2705', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 15:04:57', '2017-10-20 15:04:57');
INSERT INTO `c_login_log` VALUES ('2706', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 15:07:19', '2017-10-20 15:07:19');
INSERT INTO `c_login_log` VALUES ('2707', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 15:10:41', '2017-10-20 15:10:41');
INSERT INTO `c_login_log` VALUES ('2708', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 15:10:45', '2017-10-20 15:10:45');
INSERT INTO `c_login_log` VALUES ('2709', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 15:11:19', '2017-10-20 15:11:19');
INSERT INTO `c_login_log` VALUES ('2710', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 15:14:16', '2017-10-20 15:14:16');
INSERT INTO `c_login_log` VALUES ('2711', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 15:15:38', '2017-10-20 15:15:38');
INSERT INTO `c_login_log` VALUES ('2712', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 15:16:21', '2017-10-20 15:16:21');
INSERT INTO `c_login_log` VALUES ('2713', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 15:16:55', '2017-10-20 15:16:55');
INSERT INTO `c_login_log` VALUES ('2714', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 15:17:40', '2017-10-20 15:17:40');
INSERT INTO `c_login_log` VALUES ('2715', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 15:18:50', '2017-10-20 15:18:50');
INSERT INTO `c_login_log` VALUES ('2716', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 15:25:35', '2017-10-20 15:25:35');
INSERT INTO `c_login_log` VALUES ('2717', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 15:43:26', '2017-10-20 15:43:26');
INSERT INTO `c_login_log` VALUES ('2718', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 15:58:10', '2017-10-20 15:58:10');
INSERT INTO `c_login_log` VALUES ('2719', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 16:03:12', '2017-10-20 16:03:12');
INSERT INTO `c_login_log` VALUES ('2720', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 16:05:26', '2017-10-20 16:05:26');
INSERT INTO `c_login_log` VALUES ('2721', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 16:09:28', '2017-10-20 16:09:28');
INSERT INTO `c_login_log` VALUES ('2722', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 16:10:45', '2017-10-20 16:10:45');
INSERT INTO `c_login_log` VALUES ('2723', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 16:16:14', '2017-10-20 16:16:14');
INSERT INTO `c_login_log` VALUES ('2724', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 16:22:29', '2017-10-20 16:22:29');
INSERT INTO `c_login_log` VALUES ('2725', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 16:26:52', '2017-10-20 16:26:52');
INSERT INTO `c_login_log` VALUES ('2726', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 16:31:20', '2017-10-20 16:31:20');
INSERT INTO `c_login_log` VALUES ('2727', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 16:33:15', '2017-10-20 16:33:15');
INSERT INTO `c_login_log` VALUES ('2728', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 16:36:26', '2017-10-20 16:36:26');
INSERT INTO `c_login_log` VALUES ('2729', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 16:40:04', '2017-10-20 16:40:04');
INSERT INTO `c_login_log` VALUES ('2730', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 16:42:27', '2017-10-20 16:42:27');
INSERT INTO `c_login_log` VALUES ('2731', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 16:43:21', '2017-10-20 16:43:21');
INSERT INTO `c_login_log` VALUES ('2732', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 16:48:21', '2017-10-20 16:48:21');
INSERT INTO `c_login_log` VALUES ('2733', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 16:48:30', '2017-10-20 16:48:30');
INSERT INTO `c_login_log` VALUES ('2734', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 16:49:53', '2017-10-20 16:49:53');
INSERT INTO `c_login_log` VALUES ('2735', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 16:52:13', '2017-10-20 16:52:13');
INSERT INTO `c_login_log` VALUES ('2736', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 16:52:55', '2017-10-20 16:52:55');
INSERT INTO `c_login_log` VALUES ('2737', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 16:55:09', '2017-10-20 16:55:09');
INSERT INTO `c_login_log` VALUES ('2738', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 16:58:49', '2017-10-20 16:58:49');
INSERT INTO `c_login_log` VALUES ('2739', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 17:03:50', '2017-10-20 17:03:50');
INSERT INTO `c_login_log` VALUES ('2740', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 17:24:46', '2017-10-20 17:24:46');
INSERT INTO `c_login_log` VALUES ('2741', null, 'bgs', '2130706433', '用户成功登录系统', '2017-10-20 17:25:16', '2017-10-20 17:25:16');
INSERT INTO `c_login_log` VALUES ('2742', null, 'bgs', '2130706433', '用户成功登录系统', '2017-10-20 17:30:25', '2017-10-20 17:30:25');
INSERT INTO `c_login_log` VALUES ('2743', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 17:30:40', '2017-10-20 17:30:40');
INSERT INTO `c_login_log` VALUES ('2744', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-20 18:16:11', '2017-10-20 18:16:11');
INSERT INTO `c_login_log` VALUES ('2745', null, 'bgs', '2130706433', '用户成功登录系统', '2017-10-23 08:57:43', '2017-10-23 08:57:43');
INSERT INTO `c_login_log` VALUES ('2746', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 09:11:11', '2017-10-23 09:11:11');
INSERT INTO `c_login_log` VALUES ('2747', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 10:24:34', '2017-10-23 10:24:34');
INSERT INTO `c_login_log` VALUES ('2748', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 10:29:06', '2017-10-23 10:29:06');
INSERT INTO `c_login_log` VALUES ('2749', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 10:58:32', '2017-10-23 10:58:32');
INSERT INTO `c_login_log` VALUES ('2750', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 14:29:28', '2017-10-23 14:29:28');
INSERT INTO `c_login_log` VALUES ('2751', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 14:30:43', '2017-10-23 14:30:43');
INSERT INTO `c_login_log` VALUES ('2752', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 14:33:34', '2017-10-23 14:33:34');
INSERT INTO `c_login_log` VALUES ('2753', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 14:47:50', '2017-10-23 14:47:50');
INSERT INTO `c_login_log` VALUES ('2754', null, 'bgs', '2130706433', '用户成功登录系统', '2017-10-23 14:49:31', '2017-10-23 14:49:31');
INSERT INTO `c_login_log` VALUES ('2755', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 14:57:32', '2017-10-23 14:57:32');
INSERT INTO `c_login_log` VALUES ('2756', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 15:05:01', '2017-10-23 15:05:01');
INSERT INTO `c_login_log` VALUES ('2757', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 15:14:06', '2017-10-23 15:14:06');
INSERT INTO `c_login_log` VALUES ('2758', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 15:14:28', '2017-10-23 15:14:28');
INSERT INTO `c_login_log` VALUES ('2759', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 15:20:20', '2017-10-23 15:20:20');
INSERT INTO `c_login_log` VALUES ('2760', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 15:27:24', '2017-10-23 15:27:24');
INSERT INTO `c_login_log` VALUES ('2761', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 15:28:02', '2017-10-23 15:28:02');
INSERT INTO `c_login_log` VALUES ('2762', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 15:30:00', '2017-10-23 15:30:00');
INSERT INTO `c_login_log` VALUES ('2763', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 15:32:18', '2017-10-23 15:32:18');
INSERT INTO `c_login_log` VALUES ('2764', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 15:38:07', '2017-10-23 15:38:07');
INSERT INTO `c_login_log` VALUES ('2765', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 15:41:36', '2017-10-23 15:41:36');
INSERT INTO `c_login_log` VALUES ('2766', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 15:42:15', '2017-10-23 15:42:15');
INSERT INTO `c_login_log` VALUES ('2767', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 15:42:53', '2017-10-23 15:42:53');
INSERT INTO `c_login_log` VALUES ('2768', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 15:46:36', '2017-10-23 15:46:36');
INSERT INTO `c_login_log` VALUES ('2769', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 15:47:26', '2017-10-23 15:47:26');
INSERT INTO `c_login_log` VALUES ('2770', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 15:47:41', '2017-10-23 15:47:41');
INSERT INTO `c_login_log` VALUES ('2771', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 15:50:41', '2017-10-23 15:50:41');
INSERT INTO `c_login_log` VALUES ('2772', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 15:56:58', '2017-10-23 15:56:58');
INSERT INTO `c_login_log` VALUES ('2773', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 16:00:35', '2017-10-23 16:00:35');
INSERT INTO `c_login_log` VALUES ('2774', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 16:03:47', '2017-10-23 16:03:47');
INSERT INTO `c_login_log` VALUES ('2775', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 16:34:14', '2017-10-23 16:34:14');
INSERT INTO `c_login_log` VALUES ('2776', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 16:54:13', '2017-10-23 16:54:13');
INSERT INTO `c_login_log` VALUES ('2777', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 16:59:19', '2017-10-23 16:59:19');
INSERT INTO `c_login_log` VALUES ('2778', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 17:07:27', '2017-10-23 17:07:27');
INSERT INTO `c_login_log` VALUES ('2779', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 17:13:31', '2017-10-23 17:13:31');
INSERT INTO `c_login_log` VALUES ('2780', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 17:20:50', '2017-10-23 17:20:50');
INSERT INTO `c_login_log` VALUES ('2781', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 17:40:50', '2017-10-23 17:40:50');
INSERT INTO `c_login_log` VALUES ('2782', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 17:41:37', '2017-10-23 17:41:37');
INSERT INTO `c_login_log` VALUES ('2783', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 17:56:38', '2017-10-23 17:56:38');
INSERT INTO `c_login_log` VALUES ('2784', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 18:06:24', '2017-10-23 18:06:24');
INSERT INTO `c_login_log` VALUES ('2785', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 18:13:06', '2017-10-23 18:13:06');
INSERT INTO `c_login_log` VALUES ('2786', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 18:19:08', '2017-10-23 18:19:08');
INSERT INTO `c_login_log` VALUES ('2787', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-23 18:26:32', '2017-10-23 18:26:32');
INSERT INTO `c_login_log` VALUES ('2788', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-24 08:43:32', '2017-10-24 08:43:32');
INSERT INTO `c_login_log` VALUES ('2789', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-24 08:52:24', '2017-10-24 08:52:24');
INSERT INTO `c_login_log` VALUES ('2790', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-24 09:01:33', '2017-10-24 09:01:33');
INSERT INTO `c_login_log` VALUES ('2791', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-24 09:07:37', '2017-10-24 09:07:37');
INSERT INTO `c_login_log` VALUES ('2792', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-24 09:09:17', '2017-10-24 09:09:17');
INSERT INTO `c_login_log` VALUES ('2793', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-24 09:14:20', '2017-10-24 09:14:20');
INSERT INTO `c_login_log` VALUES ('2794', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-24 09:15:53', '2017-10-24 09:15:53');
INSERT INTO `c_login_log` VALUES ('2795', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-24 10:08:56', '2017-10-24 10:08:56');
INSERT INTO `c_login_log` VALUES ('2796', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-24 10:20:46', '2017-10-24 10:20:46');
INSERT INTO `c_login_log` VALUES ('2797', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-24 10:21:23', '2017-10-24 10:21:23');
INSERT INTO `c_login_log` VALUES ('2798', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-24 11:27:42', '2017-10-24 11:27:42');
INSERT INTO `c_login_log` VALUES ('2799', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-24 11:40:52', '2017-10-24 11:40:52');
INSERT INTO `c_login_log` VALUES ('2800', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-24 11:45:05', '2017-10-24 11:45:05');
INSERT INTO `c_login_log` VALUES ('2801', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-24 11:55:43', '2017-10-24 11:55:43');
INSERT INTO `c_login_log` VALUES ('2802', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-24 11:58:25', '2017-10-24 11:58:25');
INSERT INTO `c_login_log` VALUES ('2803', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-24 12:08:30', '2017-10-24 12:08:30');
INSERT INTO `c_login_log` VALUES ('2804', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-24 12:33:06', '2017-10-24 12:33:06');
INSERT INTO `c_login_log` VALUES ('2805', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-24 13:07:17', '2017-10-24 13:07:17');
INSERT INTO `c_login_log` VALUES ('2806', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-24 14:13:27', '2017-10-24 14:13:27');
INSERT INTO `c_login_log` VALUES ('2807', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-24 14:15:57', '2017-10-24 14:15:57');
INSERT INTO `c_login_log` VALUES ('2808', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-24 15:02:29', '2017-10-24 15:02:29');
INSERT INTO `c_login_log` VALUES ('2809', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-24 15:07:00', '2017-10-24 15:07:00');
INSERT INTO `c_login_log` VALUES ('2810', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-24 15:16:04', '2017-10-24 15:16:04');
INSERT INTO `c_login_log` VALUES ('2811', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-24 15:21:36', '2017-10-24 15:21:36');
INSERT INTO `c_login_log` VALUES ('2812', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-24 15:27:25', '2017-10-24 15:27:25');
INSERT INTO `c_login_log` VALUES ('2813', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-24 15:35:59', '2017-10-24 15:35:59');
INSERT INTO `c_login_log` VALUES ('2814', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-24 15:42:58', '2017-10-24 15:42:58');
INSERT INTO `c_login_log` VALUES ('2815', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-24 15:47:05', '2017-10-24 15:47:05');
INSERT INTO `c_login_log` VALUES ('2816', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-24 16:39:21', '2017-10-24 16:39:21');
INSERT INTO `c_login_log` VALUES ('2817', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-24 16:47:38', '2017-10-24 16:47:38');
INSERT INTO `c_login_log` VALUES ('2818', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-24 17:12:57', '2017-10-24 17:12:57');
INSERT INTO `c_login_log` VALUES ('2819', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-24 17:20:39', '2017-10-24 17:20:39');
INSERT INTO `c_login_log` VALUES ('2820', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-24 17:23:35', '2017-10-24 17:23:35');
INSERT INTO `c_login_log` VALUES ('2821', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-24 17:37:31', '2017-10-24 17:37:31');
INSERT INTO `c_login_log` VALUES ('2822', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-24 17:37:36', '2017-10-24 17:37:36');
INSERT INTO `c_login_log` VALUES ('2823', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-24 17:45:42', '2017-10-24 17:45:42');
INSERT INTO `c_login_log` VALUES ('2824', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-25 08:48:05', '2017-10-25 08:48:05');
INSERT INTO `c_login_log` VALUES ('2825', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-25 09:04:07', '2017-10-25 09:04:07');
INSERT INTO `c_login_log` VALUES ('2826', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-25 09:30:07', '2017-10-25 09:30:07');
INSERT INTO `c_login_log` VALUES ('2827', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-25 11:12:30', '2017-10-25 11:12:30');
INSERT INTO `c_login_log` VALUES ('2828', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-25 12:04:37', '2017-10-25 12:04:37');
INSERT INTO `c_login_log` VALUES ('2829', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-25 12:15:09', '2017-10-25 12:15:09');
INSERT INTO `c_login_log` VALUES ('2830', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-25 12:20:24', '2017-10-25 12:20:24');
INSERT INTO `c_login_log` VALUES ('2831', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-25 12:32:48', '2017-10-25 12:32:48');
INSERT INTO `c_login_log` VALUES ('2832', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-25 14:20:37', '2017-10-25 14:20:37');
INSERT INTO `c_login_log` VALUES ('2833', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-25 14:24:28', '2017-10-25 14:24:28');
INSERT INTO `c_login_log` VALUES ('2834', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-25 15:01:48', '2017-10-25 15:01:48');
INSERT INTO `c_login_log` VALUES ('2835', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-25 15:03:33', '2017-10-25 15:03:33');
INSERT INTO `c_login_log` VALUES ('2836', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-25 15:32:23', '2017-10-25 15:32:23');
INSERT INTO `c_login_log` VALUES ('2837', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-25 15:32:25', '2017-10-25 15:32:25');
INSERT INTO `c_login_log` VALUES ('2838', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-25 15:59:43', '2017-10-25 15:59:43');
INSERT INTO `c_login_log` VALUES ('2839', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-25 16:03:10', '2017-10-25 16:03:10');
INSERT INTO `c_login_log` VALUES ('2840', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-25 16:05:56', '2017-10-25 16:05:56');
INSERT INTO `c_login_log` VALUES ('2841', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-25 16:08:13', '2017-10-25 16:08:13');
INSERT INTO `c_login_log` VALUES ('2842', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-25 16:12:07', '2017-10-25 16:12:07');
INSERT INTO `c_login_log` VALUES ('2843', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-25 16:13:43', '2017-10-25 16:13:43');
INSERT INTO `c_login_log` VALUES ('2844', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-25 16:23:30', '2017-10-25 16:23:30');
INSERT INTO `c_login_log` VALUES ('2845', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-25 16:36:00', '2017-10-25 16:36:00');
INSERT INTO `c_login_log` VALUES ('2846', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-25 17:16:51', '2017-10-25 17:16:51');
INSERT INTO `c_login_log` VALUES ('2847', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-25 17:18:22', '2017-10-25 17:18:22');
INSERT INTO `c_login_log` VALUES ('2848', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-25 17:26:49', '2017-10-25 17:26:49');
INSERT INTO `c_login_log` VALUES ('2849', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-25 17:27:09', '2017-10-25 17:27:09');
INSERT INTO `c_login_log` VALUES ('2850', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-25 17:34:37', '2017-10-25 17:34:37');
INSERT INTO `c_login_log` VALUES ('2851', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-25 17:35:07', '2017-10-25 17:35:07');
INSERT INTO `c_login_log` VALUES ('2852', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-25 17:49:10', '2017-10-25 17:49:10');
INSERT INTO `c_login_log` VALUES ('2853', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-25 17:49:31', '2017-10-25 17:49:31');
INSERT INTO `c_login_log` VALUES ('2854', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-25 17:55:44', '2017-10-25 17:55:44');
INSERT INTO `c_login_log` VALUES ('2855', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-25 18:12:45', '2017-10-25 18:12:45');
INSERT INTO `c_login_log` VALUES ('2856', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-25 18:32:16', '2017-10-25 18:32:16');
INSERT INTO `c_login_log` VALUES ('2857', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-26 10:32:50', '2017-10-26 10:32:50');
INSERT INTO `c_login_log` VALUES ('2858', null, 'bgs', '2130706433', '用户成功登录系统', '2017-10-26 10:53:09', '2017-10-26 10:53:09');
INSERT INTO `c_login_log` VALUES ('2859', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-26 11:48:26', '2017-10-26 11:48:26');
INSERT INTO `c_login_log` VALUES ('2860', null, 'bgs', '2130706433', '用户成功登录系统', '2017-10-26 11:59:03', '2017-10-26 11:59:03');
INSERT INTO `c_login_log` VALUES ('2861', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-26 12:02:36', '2017-10-26 12:02:36');
INSERT INTO `c_login_log` VALUES ('2862', null, 'bgs', '2130706433', '用户成功登录系统', '2017-10-26 12:13:25', '2017-10-26 12:13:25');
INSERT INTO `c_login_log` VALUES ('2863', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-26 12:28:19', '2017-10-26 12:28:19');
INSERT INTO `c_login_log` VALUES ('2864', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-26 12:35:52', '2017-10-26 12:35:52');
INSERT INTO `c_login_log` VALUES ('2865', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-26 12:37:59', '2017-10-26 12:37:59');
INSERT INTO `c_login_log` VALUES ('2866', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-26 14:12:51', '2017-10-26 14:12:51');
INSERT INTO `c_login_log` VALUES ('2867', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-26 15:55:10', '2017-10-26 15:55:10');
INSERT INTO `c_login_log` VALUES ('2868', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-26 16:16:05', '2017-10-26 16:16:05');
INSERT INTO `c_login_log` VALUES ('2869', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-26 16:17:21', '2017-10-26 16:17:21');
INSERT INTO `c_login_log` VALUES ('2870', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-26 16:20:04', '2017-10-26 16:20:04');
INSERT INTO `c_login_log` VALUES ('2871', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-26 16:39:13', '2017-10-26 16:39:13');
INSERT INTO `c_login_log` VALUES ('2872', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-26 16:48:02', '2017-10-26 16:48:02');
INSERT INTO `c_login_log` VALUES ('2873', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-26 16:54:18', '2017-10-26 16:54:18');
INSERT INTO `c_login_log` VALUES ('2874', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-26 17:12:18', '2017-10-26 17:12:18');
INSERT INTO `c_login_log` VALUES ('2875', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-26 17:30:10', '2017-10-26 17:30:10');
INSERT INTO `c_login_log` VALUES ('2876', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 08:58:26', '2017-10-27 08:58:26');
INSERT INTO `c_login_log` VALUES ('2877', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 09:34:43', '2017-10-27 09:34:43');
INSERT INTO `c_login_log` VALUES ('2878', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 09:48:50', '2017-10-27 09:48:50');
INSERT INTO `c_login_log` VALUES ('2879', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 09:51:45', '2017-10-27 09:51:45');
INSERT INTO `c_login_log` VALUES ('2880', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 09:52:23', '2017-10-27 09:52:23');
INSERT INTO `c_login_log` VALUES ('2881', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 09:53:16', '2017-10-27 09:53:16');
INSERT INTO `c_login_log` VALUES ('2882', null, 'admin', '3232235626', '用户成功登录系统', '2017-10-27 09:56:25', '2017-10-27 09:56:25');
INSERT INTO `c_login_log` VALUES ('2883', null, 'admin', '3232235570', '用户成功登录系统', '2017-10-27 09:57:48', '2017-10-27 09:57:48');
INSERT INTO `c_login_log` VALUES ('2884', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 10:07:57', '2017-10-27 10:07:57');
INSERT INTO `c_login_log` VALUES ('2885', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 10:18:32', '2017-10-27 10:18:32');
INSERT INTO `c_login_log` VALUES ('2886', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 10:40:26', '2017-10-27 10:40:26');
INSERT INTO `c_login_log` VALUES ('2887', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 11:01:46', '2017-10-27 11:01:46');
INSERT INTO `c_login_log` VALUES ('2888', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 12:00:27', '2017-10-27 12:00:27');
INSERT INTO `c_login_log` VALUES ('2889', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 12:12:48', '2017-10-27 12:12:48');
INSERT INTO `c_login_log` VALUES ('2890', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 12:19:08', '2017-10-27 12:19:08');
INSERT INTO `c_login_log` VALUES ('2891', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 12:33:17', '2017-10-27 12:33:17');
INSERT INTO `c_login_log` VALUES ('2892', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 12:36:18', '2017-10-27 12:36:18');
INSERT INTO `c_login_log` VALUES ('2893', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 14:35:23', '2017-10-27 14:35:23');
INSERT INTO `c_login_log` VALUES ('2894', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 14:36:24', '2017-10-27 14:36:24');
INSERT INTO `c_login_log` VALUES ('2895', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 14:45:55', '2017-10-27 14:45:55');
INSERT INTO `c_login_log` VALUES ('2896', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 15:12:06', '2017-10-27 15:12:06');
INSERT INTO `c_login_log` VALUES ('2897', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 15:13:49', '2017-10-27 15:13:49');
INSERT INTO `c_login_log` VALUES ('2898', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 15:19:19', '2017-10-27 15:19:19');
INSERT INTO `c_login_log` VALUES ('2899', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 15:23:51', '2017-10-27 15:23:51');
INSERT INTO `c_login_log` VALUES ('2900', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 15:25:46', '2017-10-27 15:25:46');
INSERT INTO `c_login_log` VALUES ('2901', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 15:29:35', '2017-10-27 15:29:35');
INSERT INTO `c_login_log` VALUES ('2902', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 15:32:00', '2017-10-27 15:32:00');
INSERT INTO `c_login_log` VALUES ('2903', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 15:34:52', '2017-10-27 15:34:52');
INSERT INTO `c_login_log` VALUES ('2904', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 15:36:56', '2017-10-27 15:36:56');
INSERT INTO `c_login_log` VALUES ('2905', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 15:39:21', '2017-10-27 15:39:21');
INSERT INTO `c_login_log` VALUES ('2906', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 16:03:54', '2017-10-27 16:03:54');
INSERT INTO `c_login_log` VALUES ('2907', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 16:20:30', '2017-10-27 16:20:30');
INSERT INTO `c_login_log` VALUES ('2908', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 16:24:02', '2017-10-27 16:24:02');
INSERT INTO `c_login_log` VALUES ('2909', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 16:25:23', '2017-10-27 16:25:23');
INSERT INTO `c_login_log` VALUES ('2910', null, 'bgs', '2130706433', '用户成功登录系统', '2017-10-27 16:26:38', '2017-10-27 16:26:38');
INSERT INTO `c_login_log` VALUES ('2911', null, 'bgs', '2130706433', '用户成功登录系统', '2017-10-27 16:27:05', '2017-10-27 16:27:05');
INSERT INTO `c_login_log` VALUES ('2912', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 16:36:35', '2017-10-27 16:36:35');
INSERT INTO `c_login_log` VALUES ('2913', null, 'bgs', '2130706433', '用户成功登录系统', '2017-10-27 16:45:05', '2017-10-27 16:45:05');
INSERT INTO `c_login_log` VALUES ('2914', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 16:51:41', '2017-10-27 16:51:41');
INSERT INTO `c_login_log` VALUES ('2915', null, 'bgs', '2130706433', '用户成功登录系统', '2017-10-27 17:04:59', '2017-10-27 17:04:59');
INSERT INTO `c_login_log` VALUES ('2916', null, 'bgs', '2130706433', '用户成功登录系统', '2017-10-27 17:39:52', '2017-10-27 17:39:52');
INSERT INTO `c_login_log` VALUES ('2917', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 17:40:03', '2017-10-27 17:40:03');
INSERT INTO `c_login_log` VALUES ('2918', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 18:06:17', '2017-10-27 18:06:17');
INSERT INTO `c_login_log` VALUES ('2919', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-27 18:10:23', '2017-10-27 18:10:23');
INSERT INTO `c_login_log` VALUES ('2920', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 08:50:10', '2017-10-30 08:50:10');
INSERT INTO `c_login_log` VALUES ('2921', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 08:50:46', '2017-10-30 08:50:46');
INSERT INTO `c_login_log` VALUES ('2922', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 08:53:22', '2017-10-30 08:53:22');
INSERT INTO `c_login_log` VALUES ('2923', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 08:58:53', '2017-10-30 08:58:53');
INSERT INTO `c_login_log` VALUES ('2924', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 08:59:56', '2017-10-30 08:59:56');
INSERT INTO `c_login_log` VALUES ('2925', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 09:12:27', '2017-10-30 09:12:27');
INSERT INTO `c_login_log` VALUES ('2926', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 09:13:51', '2017-10-30 09:13:51');
INSERT INTO `c_login_log` VALUES ('2927', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 09:17:37', '2017-10-30 09:17:37');
INSERT INTO `c_login_log` VALUES ('2928', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 09:30:31', '2017-10-30 09:30:31');
INSERT INTO `c_login_log` VALUES ('2929', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 09:33:09', '2017-10-30 09:33:09');
INSERT INTO `c_login_log` VALUES ('2930', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 09:49:22', '2017-10-30 09:49:22');
INSERT INTO `c_login_log` VALUES ('2931', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 10:12:39', '2017-10-30 10:12:39');
INSERT INTO `c_login_log` VALUES ('2932', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 10:25:24', '2017-10-30 10:25:24');
INSERT INTO `c_login_log` VALUES ('2933', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 10:26:21', '2017-10-30 10:26:21');
INSERT INTO `c_login_log` VALUES ('2934', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 10:27:54', '2017-10-30 10:27:54');
INSERT INTO `c_login_log` VALUES ('2935', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 10:31:08', '2017-10-30 10:31:08');
INSERT INTO `c_login_log` VALUES ('2936', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 10:36:43', '2017-10-30 10:36:43');
INSERT INTO `c_login_log` VALUES ('2937', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 10:59:49', '2017-10-30 10:59:49');
INSERT INTO `c_login_log` VALUES ('2938', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 11:30:28', '2017-10-30 11:30:28');
INSERT INTO `c_login_log` VALUES ('2939', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 11:31:06', '2017-10-30 11:31:06');
INSERT INTO `c_login_log` VALUES ('2940', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 11:49:56', '2017-10-30 11:49:56');
INSERT INTO `c_login_log` VALUES ('2941', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 11:55:20', '2017-10-30 11:55:20');
INSERT INTO `c_login_log` VALUES ('2942', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 12:33:38', '2017-10-30 12:33:38');
INSERT INTO `c_login_log` VALUES ('2943', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 14:37:19', '2017-10-30 14:37:19');
INSERT INTO `c_login_log` VALUES ('2944', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 14:44:54', '2017-10-30 14:44:54');
INSERT INTO `c_login_log` VALUES ('2945', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 15:24:51', '2017-10-30 15:24:51');
INSERT INTO `c_login_log` VALUES ('2946', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 15:57:13', '2017-10-30 15:57:13');
INSERT INTO `c_login_log` VALUES ('2947', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 16:22:59', '2017-10-30 16:22:59');
INSERT INTO `c_login_log` VALUES ('2948', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 16:31:07', '2017-10-30 16:31:07');
INSERT INTO `c_login_log` VALUES ('2949', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 16:52:05', '2017-10-30 16:52:05');
INSERT INTO `c_login_log` VALUES ('2950', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 17:04:50', '2017-10-30 17:04:50');
INSERT INTO `c_login_log` VALUES ('2951', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 17:04:52', '2017-10-30 17:04:52');
INSERT INTO `c_login_log` VALUES ('2952', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 17:30:38', '2017-10-30 17:30:38');
INSERT INTO `c_login_log` VALUES ('2953', null, 'system', '2130706433', '用户成功登录系统', '2017-10-30 17:31:13', '2017-10-30 17:31:13');
INSERT INTO `c_login_log` VALUES ('2954', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 17:39:45', '2017-10-30 17:39:45');
INSERT INTO `c_login_log` VALUES ('2955', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 17:58:58', '2017-10-30 17:58:58');
INSERT INTO `c_login_log` VALUES ('2956', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 18:07:56', '2017-10-30 18:07:56');
INSERT INTO `c_login_log` VALUES ('2957', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 18:38:36', '2017-10-30 18:38:36');
INSERT INTO `c_login_log` VALUES ('2958', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-30 18:42:08', '2017-10-30 18:42:08');
INSERT INTO `c_login_log` VALUES ('2959', null, 'bgs', '2130706433', '用户成功登录系统', '2017-10-30 19:09:02', '2017-10-30 19:09:02');
INSERT INTO `c_login_log` VALUES ('2960', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-31 08:45:46', '2017-10-31 08:45:46');
INSERT INTO `c_login_log` VALUES ('2961', null, 'bgs', '2130706433', '用户成功登录系统', '2017-10-31 08:45:48', '2017-10-31 08:45:48');
INSERT INTO `c_login_log` VALUES ('2962', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-31 08:50:13', '2017-10-31 08:50:13');
INSERT INTO `c_login_log` VALUES ('2963', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-31 09:25:05', '2017-10-31 09:25:05');
INSERT INTO `c_login_log` VALUES ('2964', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-31 09:57:08', '2017-10-31 09:57:08');
INSERT INTO `c_login_log` VALUES ('2965', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-31 10:05:12', '2017-10-31 10:05:12');
INSERT INTO `c_login_log` VALUES ('2966', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-31 12:23:53', '2017-10-31 12:23:53');
INSERT INTO `c_login_log` VALUES ('2967', null, 'bgs', '2130706433', '用户成功登录系统', '2017-10-31 14:14:15', '2017-10-31 14:14:15');
INSERT INTO `c_login_log` VALUES ('2968', null, 'bgs', '2130706433', '用户成功登录系统', '2017-10-31 14:14:54', '2017-10-31 14:14:54');
INSERT INTO `c_login_log` VALUES ('2969', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-31 14:21:25', '2017-10-31 14:21:25');
INSERT INTO `c_login_log` VALUES ('2970', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-31 14:55:37', '2017-10-31 14:55:37');
INSERT INTO `c_login_log` VALUES ('2971', null, 'bgs', '2130706433', '用户成功登录系统', '2017-10-31 14:56:19', '2017-10-31 14:56:19');
INSERT INTO `c_login_log` VALUES ('2972', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-31 15:20:55', '2017-10-31 15:20:55');
INSERT INTO `c_login_log` VALUES ('2973', null, 'bgs', '2130706433', '用户成功登录系统', '2017-10-31 15:21:52', '2017-10-31 15:21:52');
INSERT INTO `c_login_log` VALUES ('2974', null, 'bgs', '2130706433', '用户成功登录系统', '2017-10-31 15:35:38', '2017-10-31 15:35:38');
INSERT INTO `c_login_log` VALUES ('2975', null, 'bgs', '2130706433', '用户成功登录系统', '2017-10-31 15:56:17', '2017-10-31 15:56:17');
INSERT INTO `c_login_log` VALUES ('2976', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-31 16:08:31', '2017-10-31 16:08:31');
INSERT INTO `c_login_log` VALUES ('2977', null, 'bgs', '2130706433', '用户成功登录系统', '2017-10-31 16:09:20', '2017-10-31 16:09:20');
INSERT INTO `c_login_log` VALUES ('2978', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-31 17:09:38', '2017-10-31 17:09:38');
INSERT INTO `c_login_log` VALUES ('2979', null, 'admin', '2130706433', '用户成功登录系统', '2017-10-31 17:38:57', '2017-10-31 17:38:57');
INSERT INTO `c_login_log` VALUES ('2980', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-01 09:00:21', '2017-11-01 09:00:21');
INSERT INTO `c_login_log` VALUES ('2981', null, 'bgs', '2130706433', '用户成功登录系统', '2017-11-01 09:01:44', '2017-11-01 09:01:44');
INSERT INTO `c_login_log` VALUES ('2982', null, 'system', '2130706433', '用户成功登录系统', '2017-11-01 09:02:11', '2017-11-01 09:02:11');
INSERT INTO `c_login_log` VALUES ('2983', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-01 10:26:11', '2017-11-01 10:26:11');
INSERT INTO `c_login_log` VALUES ('2984', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-01 10:36:48', '2017-11-01 10:36:48');
INSERT INTO `c_login_log` VALUES ('2985', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-01 10:42:05', '2017-11-01 10:42:05');
INSERT INTO `c_login_log` VALUES ('2986', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-01 10:46:38', '2017-11-01 10:46:38');
INSERT INTO `c_login_log` VALUES ('2987', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-01 11:41:13', '2017-11-01 11:41:13');
INSERT INTO `c_login_log` VALUES ('2988', null, 'system', '2130706433', '用户成功登录系统', '2017-11-01 11:42:23', '2017-11-01 11:42:23');
INSERT INTO `c_login_log` VALUES ('2989', null, 'system', '2130706433', '用户成功登录系统', '2017-11-01 11:59:04', '2017-11-01 11:59:04');
INSERT INTO `c_login_log` VALUES ('2990', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-01 11:59:36', '2017-11-01 11:59:36');
INSERT INTO `c_login_log` VALUES ('2991', null, 'system', '2130706433', '用户成功登录系统', '2017-11-01 12:11:55', '2017-11-01 12:11:55');
INSERT INTO `c_login_log` VALUES ('2992', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-01 12:12:04', '2017-11-01 12:12:04');
INSERT INTO `c_login_log` VALUES ('2993', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-01 12:30:01', '2017-11-01 12:30:01');
INSERT INTO `c_login_log` VALUES ('2994', null, 'system', '2130706433', '用户成功登录系统', '2017-11-01 12:30:14', '2017-11-01 12:30:14');
INSERT INTO `c_login_log` VALUES ('2995', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-01 12:31:34', '2017-11-01 12:31:34');
INSERT INTO `c_login_log` VALUES ('2996', null, 'system', '2130706433', '用户成功登录系统', '2017-11-01 12:31:46', '2017-11-01 12:31:46');
INSERT INTO `c_login_log` VALUES ('2997', null, 'bgs', '2130706433', '用户成功登录系统', '2017-11-01 16:03:18', '2017-11-01 16:03:18');
INSERT INTO `c_login_log` VALUES ('2998', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-01 16:31:40', '2017-11-01 16:31:40');
INSERT INTO `c_login_log` VALUES ('2999', null, 'bgs', '2130706433', '用户成功登录系统', '2017-11-01 17:04:16', '2017-11-01 17:04:16');
INSERT INTO `c_login_log` VALUES ('3000', null, 'bgs', '2130706433', '用户成功登录系统', '2017-11-01 17:11:20', '2017-11-01 17:11:20');
INSERT INTO `c_login_log` VALUES ('3001', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-01 17:11:41', '2017-11-01 17:11:41');
INSERT INTO `c_login_log` VALUES ('3002', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-01 17:49:43', '2017-11-01 17:49:43');
INSERT INTO `c_login_log` VALUES ('3003', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-01 18:00:08', '2017-11-01 18:00:08');
INSERT INTO `c_login_log` VALUES ('3004', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-01 18:12:35', '2017-11-01 18:12:35');
INSERT INTO `c_login_log` VALUES ('3005', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-01 18:15:25', '2017-11-01 18:15:25');
INSERT INTO `c_login_log` VALUES ('3006', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-01 18:27:14', '2017-11-01 18:27:14');
INSERT INTO `c_login_log` VALUES ('3007', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-01 18:30:54', '2017-11-01 18:30:54');
INSERT INTO `c_login_log` VALUES ('3008', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-01 18:37:50', '2017-11-01 18:37:50');
INSERT INTO `c_login_log` VALUES ('3009', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-01 18:45:53', '2017-11-01 18:45:53');
INSERT INTO `c_login_log` VALUES ('3010', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-01 19:17:20', '2017-11-01 19:17:20');
INSERT INTO `c_login_log` VALUES ('3011', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-01 19:20:59', '2017-11-01 19:20:59');
INSERT INTO `c_login_log` VALUES ('3012', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-01 19:24:29', '2017-11-01 19:24:29');
INSERT INTO `c_login_log` VALUES ('3013', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-01 19:27:22', '2017-11-01 19:27:22');
INSERT INTO `c_login_log` VALUES ('3014', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-02 08:47:02', '2017-11-02 08:47:02');
INSERT INTO `c_login_log` VALUES ('3015', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-02 08:50:33', '2017-11-02 08:50:33');
INSERT INTO `c_login_log` VALUES ('3016', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-02 08:52:35', '2017-11-02 08:52:35');
INSERT INTO `c_login_log` VALUES ('3017', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-02 09:00:39', '2017-11-02 09:00:39');
INSERT INTO `c_login_log` VALUES ('3018', null, 'bgs', '2130706433', '用户成功登录系统', '2017-11-02 09:00:59', '2017-11-02 09:00:59');
INSERT INTO `c_login_log` VALUES ('3019', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-02 10:43:11', '2017-11-02 10:43:11');
INSERT INTO `c_login_log` VALUES ('3020', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-02 10:45:00', '2017-11-02 10:45:00');
INSERT INTO `c_login_log` VALUES ('3021', null, 'system', '2130706433', '用户成功登录系统', '2017-11-02 11:00:55', '2017-11-02 11:00:55');
INSERT INTO `c_login_log` VALUES ('3022', null, 'system', '2130706433', '用户成功登录系统', '2017-11-02 11:06:33', '2017-11-02 11:06:33');
INSERT INTO `c_login_log` VALUES ('3023', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-02 11:08:45', '2017-11-02 11:08:45');
INSERT INTO `c_login_log` VALUES ('3024', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-02 11:13:44', '2017-11-02 11:13:44');
INSERT INTO `c_login_log` VALUES ('3025', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-02 11:35:33', '2017-11-02 11:35:33');
INSERT INTO `c_login_log` VALUES ('3026', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-02 11:45:44', '2017-11-02 11:45:44');
INSERT INTO `c_login_log` VALUES ('3027', null, 'bgs', '2130706433', '用户成功登录系统', '2017-11-02 11:48:11', '2017-11-02 11:48:11');
INSERT INTO `c_login_log` VALUES ('3028', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-02 11:51:11', '2017-11-02 11:51:11');
INSERT INTO `c_login_log` VALUES ('3029', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-02 11:57:00', '2017-11-02 11:57:00');
INSERT INTO `c_login_log` VALUES ('3030', null, 'system', '2130706433', '用户成功登录系统', '2017-11-02 12:05:37', '2017-11-02 12:05:37');
INSERT INTO `c_login_log` VALUES ('3031', null, 'system', '2130706433', '用户成功登录系统', '2017-11-02 12:07:30', '2017-11-02 12:07:30');
INSERT INTO `c_login_log` VALUES ('3032', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-02 12:14:08', '2017-11-02 12:14:08');
INSERT INTO `c_login_log` VALUES ('3033', null, 'system', '2130706433', '用户成功登录系统', '2017-11-02 12:14:23', '2017-11-02 12:14:23');
INSERT INTO `c_login_log` VALUES ('3034', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-02 12:18:07', '2017-11-02 12:18:07');
INSERT INTO `c_login_log` VALUES ('3035', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-02 12:20:24', '2017-11-02 12:20:24');
INSERT INTO `c_login_log` VALUES ('3036', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-02 12:30:18', '2017-11-02 12:30:18');
INSERT INTO `c_login_log` VALUES ('3037', null, 'system', '2130706433', '用户成功登录系统', '2017-11-02 12:30:36', '2017-11-02 12:30:36');
INSERT INTO `c_login_log` VALUES ('3038', null, 'system', '2130706433', '用户成功登录系统', '2017-11-02 12:33:59', '2017-11-02 12:33:59');
INSERT INTO `c_login_log` VALUES ('3039', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-02 12:34:36', '2017-11-02 12:34:36');
INSERT INTO `c_login_log` VALUES ('3040', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-02 16:03:29', '2017-11-02 16:03:29');
INSERT INTO `c_login_log` VALUES ('3041', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-02 16:31:06', '2017-11-02 16:31:06');
INSERT INTO `c_login_log` VALUES ('3042', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-02 16:53:36', '2017-11-02 16:53:36');
INSERT INTO `c_login_log` VALUES ('3043', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-02 16:59:55', '2017-11-02 16:59:55');
INSERT INTO `c_login_log` VALUES ('3044', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-02 17:19:02', '2017-11-02 17:19:02');
INSERT INTO `c_login_log` VALUES ('3045', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-02 17:20:16', '2017-11-02 17:20:16');
INSERT INTO `c_login_log` VALUES ('3046', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-02 17:27:51', '2017-11-02 17:27:51');
INSERT INTO `c_login_log` VALUES ('3047', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-02 17:31:58', '2017-11-02 17:31:58');
INSERT INTO `c_login_log` VALUES ('3048', null, 'system', '2130706433', '用户成功登录系统', '2017-11-02 17:32:54', '2017-11-02 17:32:54');
INSERT INTO `c_login_log` VALUES ('3049', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-02 17:46:49', '2017-11-02 17:46:49');
INSERT INTO `c_login_log` VALUES ('3050', null, 'system', '2130706433', '用户成功登录系统', '2017-11-02 17:47:53', '2017-11-02 17:47:53');
INSERT INTO `c_login_log` VALUES ('3051', null, 'bgs', '2130706433', '用户成功登录系统', '2017-11-02 17:53:22', '2017-11-02 17:53:22');
INSERT INTO `c_login_log` VALUES ('3052', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-02 18:01:27', '2017-11-02 18:01:27');
INSERT INTO `c_login_log` VALUES ('3053', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-02 18:09:51', '2017-11-02 18:09:51');
INSERT INTO `c_login_log` VALUES ('3054', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-02 18:28:58', '2017-11-02 18:28:58');
INSERT INTO `c_login_log` VALUES ('3055', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-02 18:29:38', '2017-11-02 18:29:38');
INSERT INTO `c_login_log` VALUES ('3056', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-02 18:34:10', '2017-11-02 18:34:10');
INSERT INTO `c_login_log` VALUES ('3057', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-02 18:34:10', '2017-11-02 18:34:10');
INSERT INTO `c_login_log` VALUES ('3058', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-03 09:02:39', '2017-11-03 09:02:39');
INSERT INTO `c_login_log` VALUES ('3059', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-03 10:12:17', '2017-11-03 10:12:17');
INSERT INTO `c_login_log` VALUES ('3060', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-03 10:22:51', '2017-11-03 10:22:51');
INSERT INTO `c_login_log` VALUES ('3061', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-03 10:32:17', '2017-11-03 10:32:17');
INSERT INTO `c_login_log` VALUES ('3062', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-03 10:49:06', '2017-11-03 10:49:06');
INSERT INTO `c_login_log` VALUES ('3063', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-03 11:03:05', '2017-11-03 11:03:05');
INSERT INTO `c_login_log` VALUES ('3064', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-03 11:11:09', '2017-11-03 11:11:09');
INSERT INTO `c_login_log` VALUES ('3065', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-03 11:16:47', '2017-11-03 11:16:47');
INSERT INTO `c_login_log` VALUES ('3066', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-03 11:19:54', '2017-11-03 11:19:54');
INSERT INTO `c_login_log` VALUES ('3067', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-03 11:20:36', '2017-11-03 11:20:36');
INSERT INTO `c_login_log` VALUES ('3068', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-03 11:45:30', '2017-11-03 11:45:30');
INSERT INTO `c_login_log` VALUES ('3069', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-03 12:02:39', '2017-11-03 12:02:39');
INSERT INTO `c_login_log` VALUES ('3070', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-03 12:32:48', '2017-11-03 12:32:48');
INSERT INTO `c_login_log` VALUES ('3071', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-03 14:11:30', '2017-11-03 14:11:30');
INSERT INTO `c_login_log` VALUES ('3072', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-03 14:13:05', '2017-11-03 14:13:05');
INSERT INTO `c_login_log` VALUES ('3073', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-03 14:19:28', '2017-11-03 14:19:28');
INSERT INTO `c_login_log` VALUES ('3074', null, 'bgs', '2130706433', '用户成功登录系统', '2017-11-03 14:22:56', '2017-11-03 14:22:56');
INSERT INTO `c_login_log` VALUES ('3075', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-03 14:24:26', '2017-11-03 14:24:26');
INSERT INTO `c_login_log` VALUES ('3076', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-03 16:00:48', '2017-11-03 16:00:48');
INSERT INTO `c_login_log` VALUES ('3077', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-03 16:11:14', '2017-11-03 16:11:14');
INSERT INTO `c_login_log` VALUES ('3078', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-03 16:14:11', '2017-11-03 16:14:11');
INSERT INTO `c_login_log` VALUES ('3079', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-03 16:19:18', '2017-11-03 16:19:18');
INSERT INTO `c_login_log` VALUES ('3080', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-03 16:19:33', '2017-11-03 16:19:33');
INSERT INTO `c_login_log` VALUES ('3081', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-03 16:26:24', '2017-11-03 16:26:24');
INSERT INTO `c_login_log` VALUES ('3082', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-03 16:29:48', '2017-11-03 16:29:48');
INSERT INTO `c_login_log` VALUES ('3083', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-03 16:33:37', '2017-11-03 16:33:37');
INSERT INTO `c_login_log` VALUES ('3084', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-03 17:06:39', '2017-11-03 17:06:39');
INSERT INTO `c_login_log` VALUES ('3085', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-03 17:21:07', '2017-11-03 17:21:07');
INSERT INTO `c_login_log` VALUES ('3086', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-03 17:33:29', '2017-11-03 17:33:29');
INSERT INTO `c_login_log` VALUES ('3087', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-03 17:40:03', '2017-11-03 17:40:03');
INSERT INTO `c_login_log` VALUES ('3088', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-06 08:48:48', '2017-11-06 08:48:48');
INSERT INTO `c_login_log` VALUES ('3089', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-06 09:31:12', '2017-11-06 09:31:12');
INSERT INTO `c_login_log` VALUES ('3090', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-06 09:35:03', '2017-11-06 09:35:03');
INSERT INTO `c_login_log` VALUES ('3091', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-06 09:45:09', '2017-11-06 09:45:09');
INSERT INTO `c_login_log` VALUES ('3092', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-06 10:02:44', '2017-11-06 10:02:44');
INSERT INTO `c_login_log` VALUES ('3093', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-06 11:23:13', '2017-11-06 11:23:13');
INSERT INTO `c_login_log` VALUES ('3094', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-06 11:28:57', '2017-11-06 11:28:57');
INSERT INTO `c_login_log` VALUES ('3095', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-07 14:24:02', '2017-11-07 14:24:02');
INSERT INTO `c_login_log` VALUES ('3096', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-08 17:20:07', '2017-11-08 17:20:07');
INSERT INTO `c_login_log` VALUES ('3097', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-08 17:30:08', '2017-11-08 17:30:08');
INSERT INTO `c_login_log` VALUES ('3098', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-08 17:54:19', '2017-11-08 17:54:19');
INSERT INTO `c_login_log` VALUES ('3099', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-08 18:13:19', '2017-11-08 18:13:19');
INSERT INTO `c_login_log` VALUES ('3100', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-09 08:45:18', '2017-11-09 08:45:18');
INSERT INTO `c_login_log` VALUES ('3101', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-09 08:50:48', '2017-11-09 08:50:48');
INSERT INTO `c_login_log` VALUES ('3102', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-09 10:30:34', '2017-11-09 10:30:34');
INSERT INTO `c_login_log` VALUES ('3103', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-09 10:47:08', '2017-11-09 10:47:08');
INSERT INTO `c_login_log` VALUES ('3104', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-09 10:50:59', '2017-11-09 10:50:59');
INSERT INTO `c_login_log` VALUES ('3105', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-09 11:18:43', '2017-11-09 11:18:43');
INSERT INTO `c_login_log` VALUES ('3106', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-09 12:01:24', '2017-11-09 12:01:24');
INSERT INTO `c_login_log` VALUES ('3107', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-09 12:12:01', '2017-11-09 12:12:01');
INSERT INTO `c_login_log` VALUES ('3108', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-09 12:29:52', '2017-11-09 12:29:52');
INSERT INTO `c_login_log` VALUES ('3109', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-09 14:15:09', '2017-11-09 14:15:09');
INSERT INTO `c_login_log` VALUES ('3110', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-09 16:14:16', '2017-11-09 16:14:16');
INSERT INTO `c_login_log` VALUES ('3111', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-09 17:17:40', '2017-11-09 17:17:40');
INSERT INTO `c_login_log` VALUES ('3112', null, 'bgs', '2130706433', '用户成功登录系统', '2017-11-09 17:18:12', '2017-11-09 17:18:12');
INSERT INTO `c_login_log` VALUES ('3113', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-09 17:31:35', '2017-11-09 17:31:35');
INSERT INTO `c_login_log` VALUES ('3114', null, 'bgs', '2130706433', '用户成功登录系统', '2017-11-10 08:54:03', '2017-11-10 08:54:03');
INSERT INTO `c_login_log` VALUES ('3115', null, 'bgs', '2130706433', '用户成功登录系统', '2017-11-10 12:26:14', '2017-11-10 12:26:14');
INSERT INTO `c_login_log` VALUES ('3116', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-13 14:32:09', '2017-11-13 14:32:09');
INSERT INTO `c_login_log` VALUES ('3117', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-13 14:37:26', '2017-11-13 14:37:26');
INSERT INTO `c_login_log` VALUES ('3118', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-13 14:45:01', '2017-11-13 14:45:01');
INSERT INTO `c_login_log` VALUES ('3119', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-13 14:48:38', '2017-11-13 14:48:38');
INSERT INTO `c_login_log` VALUES ('3120', null, 'lx', '2130706433', '用户成功登录系统', '2017-11-13 14:50:51', '2017-11-13 14:50:51');
INSERT INTO `c_login_log` VALUES ('3121', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-13 14:51:58', '2017-11-13 14:51:58');
INSERT INTO `c_login_log` VALUES ('3122', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-13 15:34:33', '2017-11-13 15:34:33');
INSERT INTO `c_login_log` VALUES ('3123', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-13 15:39:00', '2017-11-13 15:39:00');
INSERT INTO `c_login_log` VALUES ('3124', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-13 15:57:40', '2017-11-13 15:57:40');
INSERT INTO `c_login_log` VALUES ('3125', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-13 15:57:45', '2017-11-13 15:57:45');
INSERT INTO `c_login_log` VALUES ('3126', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-13 16:16:49', '2017-11-13 16:16:49');
INSERT INTO `c_login_log` VALUES ('3127', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-13 16:24:30', '2017-11-13 16:24:30');
INSERT INTO `c_login_log` VALUES ('3128', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-13 16:51:13', '2017-11-13 16:51:13');
INSERT INTO `c_login_log` VALUES ('3129', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-13 16:58:05', '2017-11-13 16:58:05');
INSERT INTO `c_login_log` VALUES ('3130', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-13 17:48:56', '2017-11-13 17:48:56');
INSERT INTO `c_login_log` VALUES ('3131', null, 'lx', '2130706433', '用户成功登录系统', '2017-11-13 17:56:25', '2017-11-13 17:56:25');
INSERT INTO `c_login_log` VALUES ('3132', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-14 08:52:30', '2017-11-14 08:52:30');
INSERT INTO `c_login_log` VALUES ('3133', null, 'bgs', '2130706433', '用户成功登录系统', '2017-11-14 08:58:44', '2017-11-14 08:58:44');
INSERT INTO `c_login_log` VALUES ('3134', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-14 10:05:02', '2017-11-14 10:05:02');
INSERT INTO `c_login_log` VALUES ('3135', null, 'jin', '2130706433', '用户成功登录系统', '2017-11-14 10:07:56', '2017-11-14 10:07:56');
INSERT INTO `c_login_log` VALUES ('3136', null, 'jin', '2130706433', '用户成功登录系统', '2017-11-14 11:02:22', '2017-11-14 11:02:22');
INSERT INTO `c_login_log` VALUES ('3137', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-14 11:33:30', '2017-11-14 11:33:30');
INSERT INTO `c_login_log` VALUES ('3138', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-14 12:00:26', '2017-11-14 12:00:26');
INSERT INTO `c_login_log` VALUES ('3139', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-14 12:04:36', '2017-11-14 12:04:36');
INSERT INTO `c_login_log` VALUES ('3140', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-14 14:12:50', '2017-11-14 14:12:50');
INSERT INTO `c_login_log` VALUES ('3141', null, 'bgs', '2130706433', '用户成功登录系统', '2017-11-14 14:14:34', '2017-11-14 14:14:34');
INSERT INTO `c_login_log` VALUES ('3142', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-14 14:22:04', '2017-11-14 14:22:04');
INSERT INTO `c_login_log` VALUES ('3143', null, 'bgs', '2130706433', '用户成功登录系统', '2017-11-14 14:43:45', '2017-11-14 14:43:45');
INSERT INTO `c_login_log` VALUES ('3144', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-14 15:08:00', '2017-11-14 15:08:00');
INSERT INTO `c_login_log` VALUES ('3145', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-14 15:22:58', '2017-11-14 15:22:58');
INSERT INTO `c_login_log` VALUES ('3146', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-14 16:02:11', '2017-11-14 16:02:11');
INSERT INTO `c_login_log` VALUES ('3147', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-14 16:21:11', '2017-11-14 16:21:11');
INSERT INTO `c_login_log` VALUES ('3148', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-14 16:33:01', '2017-11-14 16:33:01');
INSERT INTO `c_login_log` VALUES ('3149', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-14 16:49:19', '2017-11-14 16:49:19');
INSERT INTO `c_login_log` VALUES ('3150', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-14 17:03:12', '2017-11-14 17:03:12');
INSERT INTO `c_login_log` VALUES ('3151', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-14 17:16:25', '2017-11-14 17:16:25');
INSERT INTO `c_login_log` VALUES ('3152', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-15 08:56:58', '2017-11-15 08:56:58');
INSERT INTO `c_login_log` VALUES ('3153', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-15 09:07:28', '2017-11-15 09:07:28');
INSERT INTO `c_login_log` VALUES ('3154', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-15 09:09:34', '2017-11-15 09:09:34');
INSERT INTO `c_login_log` VALUES ('3155', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-15 09:25:06', '2017-11-15 09:25:06');
INSERT INTO `c_login_log` VALUES ('3156', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-15 10:12:59', '2017-11-15 10:12:59');
INSERT INTO `c_login_log` VALUES ('3157', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-15 10:20:31', '2017-11-15 10:20:31');
INSERT INTO `c_login_log` VALUES ('3158', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-15 11:00:36', '2017-11-15 11:00:36');
INSERT INTO `c_login_log` VALUES ('3159', null, 'bgs', '2130706433', '用户成功登录系统', '2017-11-15 11:31:59', '2017-11-15 11:31:59');
INSERT INTO `c_login_log` VALUES ('3160', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-15 11:31:37', '2017-11-15 11:31:37');
INSERT INTO `c_login_log` VALUES ('3161', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-15 11:35:42', '2017-11-15 11:35:42');
INSERT INTO `c_login_log` VALUES ('3162', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-15 12:02:37', '2017-11-15 12:02:37');
INSERT INTO `c_login_log` VALUES ('3163', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-15 12:10:56', '2017-11-15 12:10:56');
INSERT INTO `c_login_log` VALUES ('3164', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-15 14:08:41', '2017-11-15 14:08:41');
INSERT INTO `c_login_log` VALUES ('3165', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-15 14:18:30', '2017-11-15 14:18:30');
INSERT INTO `c_login_log` VALUES ('3166', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-15 14:25:18', '2017-11-15 14:25:18');
INSERT INTO `c_login_log` VALUES ('3167', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-15 14:29:53', '2017-11-15 14:29:53');
INSERT INTO `c_login_log` VALUES ('3168', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-15 14:33:13', '2017-11-15 14:33:13');
INSERT INTO `c_login_log` VALUES ('3169', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-15 15:00:04', '2017-11-15 15:00:04');
INSERT INTO `c_login_log` VALUES ('3170', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-15 15:04:16', '2017-11-15 15:04:16');
INSERT INTO `c_login_log` VALUES ('3171', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-15 15:37:06', '2017-11-15 15:37:06');
INSERT INTO `c_login_log` VALUES ('3172', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-15 15:39:41', '2017-11-15 15:39:41');
INSERT INTO `c_login_log` VALUES ('3173', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-15 15:44:27', '2017-11-15 15:44:27');
INSERT INTO `c_login_log` VALUES ('3174', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-15 16:17:55', '2017-11-15 16:17:55');
INSERT INTO `c_login_log` VALUES ('3175', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-15 16:26:59', '2017-11-15 16:26:59');
INSERT INTO `c_login_log` VALUES ('3176', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-15 16:50:10', '2017-11-15 16:50:10');
INSERT INTO `c_login_log` VALUES ('3177', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-15 17:50:42', '2017-11-15 17:50:42');
INSERT INTO `c_login_log` VALUES ('3178', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-16 09:14:21', '2017-11-16 09:14:21');
INSERT INTO `c_login_log` VALUES ('3179', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-16 09:15:28', '2017-11-16 09:15:28');
INSERT INTO `c_login_log` VALUES ('3180', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-16 09:15:51', '2017-11-16 09:15:51');
INSERT INTO `c_login_log` VALUES ('3181', null, 'linlimei', '2130706433', '用户成功登录系统', '2017-11-16 09:16:08', '2017-11-16 09:16:08');
INSERT INTO `c_login_log` VALUES ('3182', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-16 09:17:10', '2017-11-16 09:17:10');
INSERT INTO `c_login_log` VALUES ('3183', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-16 09:17:46', '2017-11-16 09:17:46');
INSERT INTO `c_login_log` VALUES ('3184', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-16 09:26:44', '2017-11-16 09:26:44');
INSERT INTO `c_login_log` VALUES ('3185', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-16 09:43:04', '2017-11-16 09:43:04');
INSERT INTO `c_login_log` VALUES ('3186', null, 'bgs', '2130706433', '用户成功登录系统', '2017-11-16 09:50:55', '2017-11-16 09:50:55');
INSERT INTO `c_login_log` VALUES ('3187', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-16 10:18:10', '2017-11-16 10:18:10');
INSERT INTO `c_login_log` VALUES ('3188', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-16 10:26:26', '2017-11-16 10:26:26');
INSERT INTO `c_login_log` VALUES ('3189', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-16 11:31:43', '2017-11-16 11:31:43');
INSERT INTO `c_login_log` VALUES ('3190', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-16 11:31:43', '2017-11-16 11:31:43');
INSERT INTO `c_login_log` VALUES ('3191', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-16 11:40:46', '2017-11-16 11:40:46');
INSERT INTO `c_login_log` VALUES ('3192', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-16 11:43:22', '2017-11-16 11:43:22');
INSERT INTO `c_login_log` VALUES ('3193', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-16 15:23:08', '2017-11-16 15:23:08');
INSERT INTO `c_login_log` VALUES ('3194', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-16 15:42:47', '2017-11-16 15:42:47');
INSERT INTO `c_login_log` VALUES ('3195', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-16 15:46:21', '2017-11-16 15:46:21');
INSERT INTO `c_login_log` VALUES ('3196', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-16 16:04:11', '2017-11-16 16:04:11');
INSERT INTO `c_login_log` VALUES ('3197', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-16 16:06:53', '2017-11-16 16:06:53');
INSERT INTO `c_login_log` VALUES ('3198', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-16 16:07:00', '2017-11-16 16:07:00');
INSERT INTO `c_login_log` VALUES ('3199', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-16 16:11:09', '2017-11-16 16:11:09');
INSERT INTO `c_login_log` VALUES ('3200', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-16 16:27:44', '2017-11-16 16:27:44');
INSERT INTO `c_login_log` VALUES ('3201', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-16 16:34:36', '2017-11-16 16:34:36');
INSERT INTO `c_login_log` VALUES ('3202', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-16 16:37:41', '2017-11-16 16:37:41');
INSERT INTO `c_login_log` VALUES ('3203', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-16 16:38:45', '2017-11-16 16:38:45');
INSERT INTO `c_login_log` VALUES ('3204', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-16 16:40:11', '2017-11-16 16:40:11');
INSERT INTO `c_login_log` VALUES ('3205', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-16 16:41:46', '2017-11-16 16:41:46');
INSERT INTO `c_login_log` VALUES ('3206', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-16 16:58:30', '2017-11-16 16:58:30');
INSERT INTO `c_login_log` VALUES ('3207', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-17 08:55:37', '2017-11-17 08:55:37');
INSERT INTO `c_login_log` VALUES ('3208', null, 'bgs', '2130706433', '用户成功登录系统', '2017-11-17 08:59:05', '2017-11-17 08:59:05');
INSERT INTO `c_login_log` VALUES ('3209', null, 'lsgcb', '2130706433', '用户成功登录系统', '2017-11-17 09:02:08', '2017-11-17 09:02:08');
INSERT INTO `c_login_log` VALUES ('3210', null, 'tomas1', '2130706433', '用户成功登录系统', '2017-11-17 09:04:04', '2017-11-17 09:04:04');
INSERT INTO `c_login_log` VALUES ('3211', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-17 09:19:01', '2017-11-17 09:19:01');
INSERT INTO `c_login_log` VALUES ('3212', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-17 09:24:32', '2017-11-17 09:24:32');
INSERT INTO `c_login_log` VALUES ('3213', null, 'guide', '2130706433', '用户成功登录系统', '2017-11-17 09:26:10', '2017-11-17 09:26:10');
INSERT INTO `c_login_log` VALUES ('3214', null, 'tomas1', '2130706433', '用户成功登录系统', '2017-11-17 09:33:30', '2017-11-17 09:33:30');
INSERT INTO `c_login_log` VALUES ('3215', null, 'guide', '2130706433', '用户成功登录系统', '2017-11-17 09:38:05', '2017-11-17 09:38:05');
INSERT INTO `c_login_log` VALUES ('3216', null, 'tomas1', '2130706433', '用户成功登录系统', '2017-11-17 09:47:11', '2017-11-17 09:47:11');
INSERT INTO `c_login_log` VALUES ('3217', null, 'tomas1', '2130706433', '用户成功登录系统', '2017-11-17 09:54:21', '2017-11-17 09:54:21');
INSERT INTO `c_login_log` VALUES ('3218', null, 'tomas1', '2130706433', '用户成功登录系统', '2017-11-17 09:59:02', '2017-11-17 09:59:02');
INSERT INTO `c_login_log` VALUES ('3219', null, 'tomas1', '2130706433', '用户成功登录系统', '2017-11-17 10:01:54', '2017-11-17 10:01:54');
INSERT INTO `c_login_log` VALUES ('3220', null, 'tomas1', '2130706433', '用户成功登录系统', '2017-11-17 10:39:28', '2017-11-17 10:39:28');
INSERT INTO `c_login_log` VALUES ('3221', null, 'tomas1', '2130706433', '用户成功登录系统', '2017-11-17 10:43:15', '2017-11-17 10:43:15');
INSERT INTO `c_login_log` VALUES ('3222', null, 'tomas1', '2130706433', '用户成功登录系统', '2017-11-17 11:27:24', '2017-11-17 11:27:24');
INSERT INTO `c_login_log` VALUES ('3223', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-17 11:30:35', '2017-11-17 11:30:35');
INSERT INTO `c_login_log` VALUES ('3224', null, 'tomas1', '2130706433', '用户成功登录系统', '2017-11-17 11:30:53', '2017-11-17 11:30:53');
INSERT INTO `c_login_log` VALUES ('3225', null, 'guide', '2130706433', '用户成功登录系统', '2017-11-17 11:32:23', '2017-11-17 11:32:23');
INSERT INTO `c_login_log` VALUES ('3226', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-17 14:15:13', '2017-11-17 14:15:13');
INSERT INTO `c_login_log` VALUES ('3227', null, 'system', '2130706433', '用户成功登录系统', '2017-11-17 14:16:14', '2017-11-17 14:16:14');
INSERT INTO `c_login_log` VALUES ('3228', null, 'system', '2130706433', '用户成功登录系统', '2017-11-17 14:18:13', '2017-11-17 14:18:13');
INSERT INTO `c_login_log` VALUES ('3229', null, 'system', '2130706433', '用户成功登录系统', '2017-11-17 14:18:34', '2017-11-17 14:18:34');
INSERT INTO `c_login_log` VALUES ('3230', null, 'tomas1', '2130706433', '用户成功登录系统', '2017-11-17 14:22:08', '2017-11-17 14:22:08');
INSERT INTO `c_login_log` VALUES ('3231', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-17 14:22:46', '2017-11-17 14:22:46');
INSERT INTO `c_login_log` VALUES ('3232', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-17 14:38:08', '2017-11-17 14:38:08');
INSERT INTO `c_login_log` VALUES ('3233', null, 'tomas1', '2130706433', '用户成功登录系统', '2017-11-17 14:48:37', '2017-11-17 14:48:37');
INSERT INTO `c_login_log` VALUES ('3234', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-17 14:51:26', '2017-11-17 14:51:26');
INSERT INTO `c_login_log` VALUES ('3235', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-17 14:52:04', '2017-11-17 14:52:04');
INSERT INTO `c_login_log` VALUES ('3236', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-17 14:52:15', '2017-11-17 14:52:15');
INSERT INTO `c_login_log` VALUES ('3237', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-17 15:04:57', '2017-11-17 15:04:57');
INSERT INTO `c_login_log` VALUES ('3238', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-17 15:05:16', '2017-11-17 15:05:16');
INSERT INTO `c_login_log` VALUES ('3239', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-17 15:05:25', '2017-11-17 15:05:25');
INSERT INTO `c_login_log` VALUES ('3240', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-17 15:05:54', '2017-11-17 15:05:54');
INSERT INTO `c_login_log` VALUES ('3241', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-17 15:06:29', '2017-11-17 15:06:29');
INSERT INTO `c_login_log` VALUES ('3242', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-17 15:08:59', '2017-11-17 15:08:59');
INSERT INTO `c_login_log` VALUES ('3243', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-17 15:09:08', '2017-11-17 15:09:08');
INSERT INTO `c_login_log` VALUES ('3244', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-17 15:09:32', '2017-11-17 15:09:32');
INSERT INTO `c_login_log` VALUES ('3245', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-17 15:09:44', '2017-11-17 15:09:44');
INSERT INTO `c_login_log` VALUES ('3246', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-17 15:11:15', '2017-11-17 15:11:15');
INSERT INTO `c_login_log` VALUES ('3247', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-17 15:11:49', '2017-11-17 15:11:49');
INSERT INTO `c_login_log` VALUES ('3248', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-17 15:16:45', '2017-11-17 15:16:45');
INSERT INTO `c_login_log` VALUES ('3249', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-17 15:17:50', '2017-11-17 15:17:50');
INSERT INTO `c_login_log` VALUES ('3250', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-17 15:19:37', '2017-11-17 15:19:37');
INSERT INTO `c_login_log` VALUES ('3251', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-17 15:19:48', '2017-11-17 15:19:48');
INSERT INTO `c_login_log` VALUES ('3252', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-17 15:19:55', '2017-11-17 15:19:55');
INSERT INTO `c_login_log` VALUES ('3253', null, 'tomas1', '2130706433', '用户成功登录系统', '2017-11-17 15:42:45', '2017-11-17 15:42:45');
INSERT INTO `c_login_log` VALUES ('3254', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-17 15:42:54', '2017-11-17 15:42:54');
INSERT INTO `c_login_log` VALUES ('3255', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-17 16:33:13', '2017-11-17 16:33:13');
INSERT INTO `c_login_log` VALUES ('3256', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-17 16:54:16', '2017-11-17 16:54:16');
INSERT INTO `c_login_log` VALUES ('3257', null, 'guide', '2130706433', '用户成功登录系统', '2017-11-21 09:09:34', '2017-11-21 09:09:34');
INSERT INTO `c_login_log` VALUES ('3258', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-21 14:48:55', '2017-11-21 14:48:55');
INSERT INTO `c_login_log` VALUES ('3259', null, 'bgs', '2130706433', '用户成功登录系统', '2017-11-21 15:22:05', '2017-11-21 15:22:05');
INSERT INTO `c_login_log` VALUES ('3260', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-21 15:42:04', '2017-11-21 15:42:04');
INSERT INTO `c_login_log` VALUES ('3261', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-21 15:52:28', '2017-11-21 15:52:28');
INSERT INTO `c_login_log` VALUES ('3262', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-21 16:01:40', '2017-11-21 16:01:40');
INSERT INTO `c_login_log` VALUES ('3263', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-21 16:29:05', '2017-11-21 16:29:05');
INSERT INTO `c_login_log` VALUES ('3264', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-21 16:35:07', '2017-11-21 16:35:07');
INSERT INTO `c_login_log` VALUES ('3265', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-21 16:36:17', '2017-11-21 16:36:17');
INSERT INTO `c_login_log` VALUES ('3266', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-21 17:16:51', '2017-11-21 17:16:51');
INSERT INTO `c_login_log` VALUES ('3267', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-21 17:20:26', '2017-11-21 17:20:26');
INSERT INTO `c_login_log` VALUES ('3268', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-24 11:27:58', '2017-11-24 11:27:58');
INSERT INTO `c_login_log` VALUES ('3269', null, 'bgs', '2130706433', '用户成功登录系统', '2017-11-24 17:20:28', '2017-11-24 17:20:28');
INSERT INTO `c_login_log` VALUES ('3270', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-24 17:44:37', '2017-11-24 17:44:37');
INSERT INTO `c_login_log` VALUES ('3271', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-27 11:47:05', '2017-11-27 11:47:05');
INSERT INTO `c_login_log` VALUES ('3272', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-27 11:50:24', '2017-11-27 11:50:24');
INSERT INTO `c_login_log` VALUES ('3273', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-27 11:52:24', '2017-11-27 11:52:24');
INSERT INTO `c_login_log` VALUES ('3274', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-27 12:06:05', '2017-11-27 12:06:05');
INSERT INTO `c_login_log` VALUES ('3275', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-27 12:07:53', '2017-11-27 12:07:53');
INSERT INTO `c_login_log` VALUES ('3276', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-27 12:14:26', '2017-11-27 12:14:26');
INSERT INTO `c_login_log` VALUES ('3277', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-27 12:21:02', '2017-11-27 12:21:02');
INSERT INTO `c_login_log` VALUES ('3278', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-28 10:46:37', '2017-11-28 10:46:37');
INSERT INTO `c_login_log` VALUES ('3279', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-28 11:06:37', '2017-11-28 11:06:37');
INSERT INTO `c_login_log` VALUES ('3280', null, 'admin', '2130706433', '用户成功登录系统', '2017-11-30 12:04:56', '2017-11-30 12:04:56');
INSERT INTO `c_login_log` VALUES ('3281', null, 'admin', '2130706433', '用户成功登录系统', '2017-12-07 16:44:13', '2017-12-07 16:44:13');
INSERT INTO `c_login_log` VALUES ('3282', null, 'admin', '2130706433', '用户成功登录系统', '2017-12-07 16:57:37', '2017-12-07 16:57:37');
INSERT INTO `c_login_log` VALUES ('3283', null, 'admin', '2130706433', '用户成功登录系统', '2017-12-21 15:09:24', '2017-12-21 15:09:24');
INSERT INTO `c_login_log` VALUES ('3284', null, 'admin', '2130706433', '用户成功登录系统', '2017-12-21 15:11:31', '2017-12-21 15:11:31');
INSERT INTO `c_login_log` VALUES ('3285', null, 'admin', '2130706433', '用户成功登录系统', '2017-12-29 18:01:23', '2017-12-29 18:01:23');
INSERT INTO `c_login_log` VALUES ('3286', null, 'admin', '2130706433', '用户成功登录系统', '2018-01-12 09:12:37', '2018-01-12 09:12:37');
INSERT INTO `c_login_log` VALUES ('3287', null, 'admin', '2130706433', '用户成功登录系统', '2018-01-15 08:57:08', '2018-01-15 08:57:08');
INSERT INTO `c_login_log` VALUES ('3288', null, 'admin', '2130706433', '用户成功登录系统', '2018-01-15 09:34:16', '2018-01-15 09:34:16');
INSERT INTO `c_login_log` VALUES ('3289', null, 'admin', '2130706433', '用户成功登录系统', '2018-01-15 09:35:34', '2018-01-15 09:35:34');
INSERT INTO `c_login_log` VALUES ('3290', null, 'system', '2130706433', '用户成功登录系统', '2018-01-15 09:35:57', '2018-01-15 09:35:57');
INSERT INTO `c_login_log` VALUES ('3291', null, 'system', '2130706433', '用户成功登录系统', '2018-01-15 09:39:40', '2018-01-15 09:39:40');
INSERT INTO `c_login_log` VALUES ('3292', null, 'system', '2130706433', '用户成功登录系统', '2018-01-15 09:42:21', '2018-01-15 09:42:21');
INSERT INTO `c_login_log` VALUES ('3293', null, 'system', '2130706433', '用户成功登录系统', '2018-01-15 09:42:56', '2018-01-15 09:42:56');
INSERT INTO `c_login_log` VALUES ('3294', null, 'admin', '2130706433', '用户成功登录系统', '2018-01-15 18:08:04', '2018-01-15 18:08:04');
INSERT INTO `c_login_log` VALUES ('3295', null, 'admin', '2130706433', '用户成功登录系统', '2018-09-29 16:13:57', '2018-09-29 16:13:57');
INSERT INTO `c_login_log` VALUES ('3296', null, 'admin', '2130706433', '用户成功登录系统', '2018-10-18 14:51:42', '2018-10-18 14:51:42');
INSERT INTO `c_login_log` VALUES ('3297', null, 'admin', '2130706433', '用户成功登录系统', '2018-11-07 15:53:22', '2018-11-07 15:53:22');
INSERT INTO `c_login_log` VALUES ('3298', null, 'admin', '2130706433', '用户成功登录系统', '2018-11-07 17:51:12', '2018-11-07 17:51:12');
INSERT INTO `c_login_log` VALUES ('3299', null, 'admin', '2130706433', '用户成功登录系统', '2018-11-08 08:42:43', '2018-11-08 08:42:43');
INSERT INTO `c_login_log` VALUES ('3300', null, 'admin', '2130706433', '用户成功登录系统', '2018-11-08 09:35:20', '2018-11-08 09:35:20');
INSERT INTO `c_login_log` VALUES ('3301', null, 'admin', '2130706433', '用户成功登录系统', '2018-11-08 10:19:07', '2018-11-08 10:19:07');
INSERT INTO `c_login_log` VALUES ('3302', null, 'admin', '2130706433', '用户成功登录系统', '2018-11-08 10:41:57', '2018-11-08 10:41:57');
INSERT INTO `c_login_log` VALUES ('3303', null, 'admin', '3232235558', '用户成功登录系统', '2018-11-08 10:43:56', '2018-11-08 10:43:56');
INSERT INTO `c_login_log` VALUES ('3304', null, 'admin', '2130706433', '用户成功登录系统', '2018-11-08 10:44:33', '2018-11-08 10:44:33');

-- ----------------------------
-- Table structure for c_msg_receiver
-- ----------------------------
DROP TABLE IF EXISTS `c_msg_receiver`;
CREATE TABLE `c_msg_receiver` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `msg_id` varchar(32) DEFAULT NULL,
  `user_id` varchar(32) DEFAULT NULL,
  `user_name` varchar(50) DEFAULT NULL,
  `chinese_name` varchar(255) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `weixin_code` varchar(50) DEFAULT NULL,
  `status` smallint(6) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of c_msg_receiver
-- ----------------------------
INSERT INTO `c_msg_receiver` VALUES ('44', '030b0cc3922311e79ff4507b9dae4454', '05ed083f8efc11e7b1a4507b9dae4454', null, '汤姆', null, 'zjr', null, '2017-09-05 18:14:10', '2017-09-05 18:14:10');
INSERT INTO `c_msg_receiver` VALUES ('45', '030b0cc3922311e79ff4507b9dae4454', '823d52fc915911e7bd2b507b9dae4454', null, '白羊', null, 'lzx', null, '2017-09-05 18:14:10', '2017-09-05 18:14:10');
INSERT INTO `c_msg_receiver` VALUES ('46', '6afd54de922311e79ff4507b9dae4454', '05ed083f8efc11e7b1a4507b9dae4454', null, '汤姆', null, 'zjr', null, '2017-09-05 18:17:05', '2017-09-05 18:17:05');
INSERT INTO `c_msg_receiver` VALUES ('47', '6afd54de922311e79ff4507b9dae4454', '823d52fc915911e7bd2b507b9dae4454', null, '白羊', null, 'lzx', null, '2017-09-05 18:17:05', '2017-09-05 18:17:05');
INSERT INTO `c_msg_receiver` VALUES ('48', '6afd54de922311e79ff4507b9dae4454', 'b165e37d921c11e79ff4507b9dae4454', null, '新的多多', null, 'zxh', null, '2017-09-05 18:17:05', '2017-09-05 18:17:05');
INSERT INTO `c_msg_receiver` VALUES ('49', 'd30a1524922311e79ff4507b9dae4454', '05ed083f8efc11e7b1a4507b9dae4454', null, '汤姆', null, 'zjr', null, '2017-09-05 18:19:59', '2017-09-05 18:19:59');
INSERT INTO `c_msg_receiver` VALUES ('50', 'd30a1524922311e79ff4507b9dae4454', '823d52fc915911e7bd2b507b9dae4454', null, '白羊', null, 'lzx', null, '2017-09-05 18:19:59', '2017-09-05 18:19:59');
INSERT INTO `c_msg_receiver` VALUES ('51', 'd30a1524922311e79ff4507b9dae4454', 'b165e37d921c11e79ff4507b9dae4454', null, '新的多多', null, 'zxh', null, '2017-09-05 18:19:59', '2017-09-05 18:19:59');
INSERT INTO `c_msg_receiver` VALUES ('52', '3944c95a922411e79ff4507b9dae4454', '05ed083f8efc11e7b1a4507b9dae4454', null, '汤姆', null, 'zjr', null, '2017-09-05 18:22:51', '2017-09-05 18:22:51');
INSERT INTO `c_msg_receiver` VALUES ('53', '3944c95a922411e79ff4507b9dae4454', '823d52fc915911e7bd2b507b9dae4454', null, '白羊', null, 'lzx', null, '2017-09-05 18:22:51', '2017-09-05 18:22:51');
INSERT INTO `c_msg_receiver` VALUES ('54', '3944c95a922411e79ff4507b9dae4454', 'b165e37d921c11e79ff4507b9dae4454', null, '新的多多', null, 'zxh', null, '2017-09-05 18:22:51', '2017-09-05 18:22:51');
INSERT INTO `c_msg_receiver` VALUES ('56', '1c21e2be92ab11e780f9507b9dae4454', '05ed083f8efc11e7b1a4507b9dae4454', null, '汤姆', null, 'zjr', null, '2017-09-06 10:28:18', '2017-09-06 10:28:18');
INSERT INTO `c_msg_receiver` VALUES ('57', '7707fc69937711e7aafe507b9dae4454', '3c473cc592d411e780f9507b9dae4454', null, '游客', null, 'lzx', null, '2017-09-07 10:51:13', '2017-09-07 10:51:13');
INSERT INTO `c_msg_receiver` VALUES ('58', 'a7a1bae29f2f11e7b685507b9dae4454', '3c473cc592d411e780f9507b9dae4454', null, '游客', null, 'lzx', null, '2017-09-22 08:47:29', '2017-09-22 08:47:29');
INSERT INTO `c_msg_receiver` VALUES ('59', '4820bb0f9f3011e7b685507b9dae4454', '3c473cc592d411e780f9507b9dae4454', null, '游客', null, 'lzx', null, '2017-09-22 08:51:51', '2017-09-22 08:51:51');

-- ----------------------------
-- Table structure for c_msg_record
-- ----------------------------
DROP TABLE IF EXISTS `c_msg_record`;
CREATE TABLE `c_msg_record` (
  `id` varchar(32) NOT NULL,
  `sort` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '序号',
  `content` varchar(2000) DEFAULT NULL COMMENT '内容',
  `sender` varchar(50) DEFAULT NULL COMMENT '发送用户',
  `send_user_id` varchar(32) DEFAULT NULL COMMENT '发送用户id',
  `result_note` varchar(255) DEFAULT NULL COMMENT '返回结果',
  `type` smallint(6) DEFAULT NULL COMMENT '类型',
  `status` smallint(6) DEFAULT NULL,
  `company_id` varchar(32) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_msg_sort` (`sort`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of c_msg_record
-- ----------------------------
INSERT INTO `c_msg_record` VALUES ('030b0cc3922311e79ff4507b9dae4454', '35', '测试发送 2017-9-5', '管理员', 'e20afce4b12511e68bc4507b9dae4454', '{\"errcode\":0,\"errmsg\":\"ok\",\"invaliduser\":\"\"}', '1', '3', null, '2017-09-05 18:14:09', '2017-09-05 18:14:09');
INSERT INTO `c_msg_record` VALUES ('1c21e2be92ab11e780f9507b9dae4454', '40', '测试发送', '管理员', 'e20afce4b12511e68bc4507b9dae4454', '{\"errcode\":0,\"errmsg\":\"ok\",\"invaliduser\":\"\"}', '1', '3', null, '2017-09-06 10:28:17', '2017-09-06 10:28:17');
INSERT INTO `c_msg_record` VALUES ('3944c95a922411e79ff4507b9dae4454', '38', '测试发送微信 18.22', '管理员', 'e20afce4b12511e68bc4507b9dae4454', '{\"errcode\":0,\"errmsg\":\"ok\",\"invaliduser\":\"\"}', '1', '3', null, '2017-09-05 18:22:49', '2017-09-05 18:22:49');
INSERT INTO `c_msg_record` VALUES ('4820bb0f9f3011e7b685507b9dae4454', '43', '测试发送2', '管理员2', 'e20afce4b12511e68bc4507b9dae4454', '{\"errcode\":0,\"errmsg\":\"ok\",\"invaliduser\":\"\"}', '1', '3', 'd5f60b0f8ec311e7b1a4507b9dae4454', '2017-09-22 08:51:51', '2017-09-22 08:51:51');
INSERT INTO `c_msg_record` VALUES ('6afd54de922311e79ff4507b9dae4454', '36', '测试发送微信', '管理员', 'e20afce4b12511e68bc4507b9dae4454', '{\"errcode\":0,\"errmsg\":\"ok\",\"invaliduser\":\"\"}', '1', '3', null, '2017-09-05 18:17:04', '2017-09-05 18:17:04');
INSERT INTO `c_msg_record` VALUES ('7707fc69937711e7aafe507b9dae4454', '41', 'ddd', '管理员', 'e20afce4b12511e68bc4507b9dae4454', '{\"errcode\":0,\"errmsg\":\"ok\",\"invaliduser\":\"\"}', '1', '3', 'd5f60b0f8ec311e7b1a4507b9dae4454', '2017-09-07 10:51:12', '2017-09-07 10:51:12');
INSERT INTO `c_msg_record` VALUES ('a7a1bae29f2f11e7b685507b9dae4454', '42', '测试发送', '管理员2', 'e20afce4b12511e68bc4507b9dae4454', null, '1', '1', 'd5f60b0f8ec311e7b1a4507b9dae4454', '2017-09-22 08:47:21', '2017-09-22 08:47:21');
INSERT INTO `c_msg_record` VALUES ('d30a1524922311e79ff4507b9dae4454', '37', '2017-9-5', '管理员', 'e20afce4b12511e68bc4507b9dae4454', '{\"errcode\":0,\"errmsg\":\"ok\",\"invaliduser\":\"\"}', '1', '3', null, '2017-09-05 18:19:58', '2017-09-05 18:19:58');

-- ----------------------------
-- Table structure for c_role
-- ----------------------------
DROP TABLE IF EXISTS `c_role`;
CREATE TABLE `c_role` (
  `id` varchar(32) NOT NULL,
  `sort` bigint(20) NOT NULL AUTO_INCREMENT,
  `role_text` varchar(50) NOT NULL,
  `role_name` varchar(50) NOT NULL,
  `role_memo` varchar(255) DEFAULT NULL,
  `flag` smallint(6) DEFAULT NULL,
  `role_type` smallint(6) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_sort_key` (`sort`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of c_role
-- ----------------------------
INSERT INTO `c_role` VALUES ('08a0ad2b9e7411e784005254003f140b', '6', '栏目编辑角色', 'ROLE_TOPIC', '', '0', '0', '2017-09-21 10:25:03', '2017-10-20 18:17:21');
INSERT INTO `c_role` VALUES ('14065dccb12011e68bc4507b9dae4454', '1', '管理员', 'ROLE_ADMIN', '系统管理员', '1', '0', '2017-03-30 10:39:34', '2017-11-16 11:43:15');
INSERT INTO `c_role` VALUES ('348d11f866b111e783a7507b9dae4454', '2', '普通成员', 'ROLE_MEMBER', '', '1', '0', '2017-07-12 11:21:34', '2017-09-08 11:45:57');
INSERT INTO `c_role` VALUES ('9cd17854976e11e79c2b507b9dae4454', '3', 'OA系统角色', 'ROLE_OA', '拥有登录oa系统的权限', '0', '0', '2017-09-12 11:58:19', '2017-09-14 09:29:07');
INSERT INTO `c_role` VALUES ('bcc612b8976e11e79c2b507b9dae4454', '4', '档案系统角色', 'ROLE_DMS', '拥有登录档案系统的权限', '0', '0', '2017-09-12 11:59:13', '2017-09-14 09:29:23');
INSERT INTO `c_role` VALUES ('c9b99e43cb3a11e7b965507b9dae4454', '7', '账号切换角色', 'ROLE_SWITCH_USER', '', '0', '0', '2017-11-17 09:58:21', '2017-11-17 09:58:21');
INSERT INTO `c_role` VALUES ('edcea2ef991311e781ec507b9dae4454', '5', '设置栏目权限角色', 'ROLE_TOPIC_AUTH', '', '0', '0', '2017-09-14 14:14:14', '2017-09-14 14:14:14');

-- ----------------------------
-- Table structure for c_toll_station
-- ----------------------------
DROP TABLE IF EXISTS `c_toll_station`;
CREATE TABLE `c_toll_station` (
  `id` varchar(32) NOT NULL,
  `sort` bigint(20) NOT NULL AUTO_INCREMENT,
  `station_name` varchar(50) DEFAULT NULL,
  `status` smallint(6) DEFAULT NULL COMMENT '状态',
  `create_by` varchar(50) DEFAULT NULL,
  `update_by` varchar(50) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_station_sort` (`sort`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of c_toll_station
-- ----------------------------
INSERT INTO `c_toll_station` VALUES ('25088975c04511e7ab51507b9dae4454', '4', '虎门大桥', '1', null, null, null, '2017-11-03 11:14:48');
INSERT INTO `c_toll_station` VALUES ('a8bbccb3c04111e7ab51507b9dae4454', '1', '虎门收费站', '1', null, null, null, '2017-11-03 10:49:51');
INSERT INTO `c_toll_station` VALUES ('ef28ed8ec04111e7ab51507b9dae4454', '2', '长安收费站', '1', null, null, null, '2017-11-03 11:13:31');

-- ----------------------------
-- Table structure for c_user
-- ----------------------------
DROP TABLE IF EXISTS `c_user`;
CREATE TABLE `c_user` (
  `id` varchar(32) NOT NULL,
  `sort` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) NOT NULL,
  `chinese_name` varchar(50) DEFAULT NULL,
  `pass_word` varchar(64) NOT NULL,
  `encrypt_pwd` varchar(500) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `tel` varchar(20) DEFAULT NULL,
  `link_address` varchar(200) DEFAULT NULL,
  `skin` varchar(10) DEFAULT NULL,
  `photo_id` bigint(20) DEFAULT NULL,
  `photo_path` varchar(200) DEFAULT NULL,
  `memo` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL,
  `credentials_non_expired` tinyint(1) NOT NULL,
  `account_non_locked` tinyint(1) NOT NULL,
  `account_non_expired` tinyint(1) NOT NULL,
  `user_type` smallint(6) DEFAULT NULL,
  `ucode` varchar(32) DEFAULT NULL,
  `company_id` varchar(32) DEFAULT NULL COMMENT '所属公司',
  `weixin_code` varchar(50) DEFAULT NULL,
  `take_sort_no` int(11) DEFAULT NULL,
  `take_depart_id` varchar(32) DEFAULT NULL,
  `main_accoun_id` varchar(32) DEFAULT NULL,
  `account_type` smallint(6) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_user_sort` (`sort`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of c_user
-- ----------------------------
INSERT INTO `c_user` VALUES ('013171ed66b111e783a7507b9dae4454', '2', 'guide', '游客', 'fa70f0a2586419227db0d096791e99d3c86ba749622864a7d86deb5a34f3c142', null, '', '13800138008', '', '', null, null, null, '', '1', '1', '1', '1', '0', '4ade87e8fd26420baaf2b18e996a76e8', 'd5f60b0f8ec311e7b1a4507b9dae4454', '', null, null, null, null, '2017-07-12 11:20:07', '2018-11-07 18:00:26');
INSERT INTO `c_user` VALUES ('2bd445a5cb3311e7b965507b9dae4454', '60', 'tomas1-328060', '托马斯', 'f4dda04e147c693f8ab9ec0a042ea3c8754b4f0162449042d6a5d0db68e7058a', 'EP2zxOagtJqdYqO0aETaew==', '', '13800138205', '', '', null, null, null, '', '1', '1', '1', '1', '0', '9a05f7bcd147444197c756e2c1ea89aa', 'a90fa9578ec411e7b1a4507b9dae4454', '', '1', '1a41ad04cb3311e7b965507b9dae4454', '732a522992a211e780f9507b9dae4454', '0', '2017-11-17 09:03:50', '2017-11-17 10:50:05');
INSERT INTO `c_user` VALUES ('5e5cad819ea111e7a438507b9dae4454', '57', 'thomas', '托马斯', '91a9138149fcb2722db72011179eef8999896cc73e0d8fda71a75c35d475470c', 'wbs3dKkKnZw=', '578707139@qq.com', '13800138010', '', '', null, null, null, '', '1', '1', '1', '1', '0', '8fbac91968724363b302c124f998227b', 'd5f60b0f8ec311e7b1a4507b9dae4454', '', null, null, null, null, '2017-09-21 15:47:19', '2018-11-08 09:09:10');
INSERT INTO `c_user` VALUES ('5f4a9af092d211e780f9507b9dae4454', '50', '18766789631', '库大兴', '6f9c4f925b521e493587099211b3feac6e7f7f505be95f94be59da6076426b34', null, '', '15217126379', '', '', null, null, null, '', '1', '1', '1', '1', '0', '7a26b00b1f494198bf0845c636bfc472', 'd5f60b0f8ec311e7b1a4507b9dae4454', 'zjf', null, null, null, null, '2017-09-21 11:20:30', '2017-11-10 12:27:56');
INSERT INTO `c_user` VALUES ('6fb27411cb4211e7b965507b9dae4454', '61', 'tomas1-046315', '托马斯', 'f4dda04e147c693f8ab9ec0a042ea3c8754b4f0162449042d6a5d0db68e7058a', 'EP2zxOagtJqdYqO0aETaew==', '', '13800138204', '', '', null, null, null, '', '1', '1', '1', '1', '0', '9a05f7bcd147444197c756e2c1ea89aa', 'd5f60b0f8ec311e7b1a4507b9dae4454', '', '2', '38f3abedc8ee11e7b0f1507b9dae4454', '732a522992a211e780f9507b9dae4454', '0', '2017-11-17 10:53:06', '2017-11-17 10:53:06');
INSERT INTO `c_user` VALUES ('732a522992a211e780f9507b9dae4454', '47', 'tomas1', '托马斯', 'f4dda04e147c693f8ab9ec0a042ea3c8754b4f0162449042d6a5d0db68e7058a', 'EP2zxOagtJqdYqO0aETaew==', '', '13800138204', '', '', null, null, null, '', '1', '1', '1', '1', '0', '9a05f7bcd147444197c756e2c1ea89aa', 'a90fa9578ec411e7b1a4507b9dae4454', '', null, null, null, null, '2017-09-06 09:25:06', '2017-11-17 10:40:46');
INSERT INTO `c_user` VALUES ('8544c5dc92a011e780f9507b9dae4454', '45', 'cmd', '张三', '958a0dbaf2eba88ea7272d96ca4983c9a2d130a24ade5b4574afe4aa5b2b7a53', null, '', '', '', '', null, null, null, '', '1', '1', '1', '1', '0', '29a38ac5117f4d0aa96858d014033294', 'a90fa9578ec411e7b1a4507b9dae4454', '', null, null, null, null, '2017-09-06 09:12:59', '2017-09-06 17:30:36');
INSERT INTO `c_user` VALUES ('89efa57992d911e780f9507b9dae4454', '51', 'system', '系统', '0c143db1f8847efcdcbb3cd0a916144f331adb1fb8379603d769e849a0467adf', 'wbs3dKkKnZw=', '', '', '', '', null, null, null, '', '1', '1', '1', '1', '0', '2430db21ba0745b1ba39fc7ea2e10ff5', 'd5f60b0f8ec311e7b1a4507b9dae4454', '', null, null, null, null, '2017-09-06 16:01:08', '2018-11-08 09:09:28');
INSERT INTO `c_user` VALUES ('8da0fc4e936611e7aafe507b9dae4454', '52', 'jin', '11', '76620262b91a797b85d18a5a3dbd40cb30d348d6282274df51a1366d113ae64d', null, '', '13800138002', '', '', null, null, null, '', '1', '1', '1', '1', '0', 'f8d2cefd58a049cb860a620606d689b1', 'd5f60b0f8ec311e7b1a4507b9dae4454', '', null, null, null, null, '2017-09-07 08:50:03', '2018-11-08 09:09:17');
INSERT INTO `c_user` VALUES ('b3711856944311e7a354507b9dae4454', '54', 'test', '2323', '4cf999aef3426359c0df229108d3db1003a536b1342957dad3e5247f69d8f323', null, '', '', '', '', null, null, null, '', '1', '1', '1', '1', '0', '6e2c752d038347eca8c6a05e56869501', 'd5f60b0f8ec311e7b1a4507b9dae4454', '', null, null, null, null, '2017-09-08 11:13:35', '2018-11-08 09:09:33');
INSERT INTO `c_user` VALUES ('b6516b6bcaa311e7b5d7507b9dae4454', '59', 'thomas-563698', '托马斯', '91a9138149fcb2722db72011179eef8999896cc73e0d8fda71a75c35d475470c', 'wbs3dKkKnZw=', '578707139@qq.com', '13800138010', '', '', null, null, null, '', '1', '1', '1', '1', '0', '8fbac91968724363b302c124f998227b', '3b93bf528ca211e78adb507b9dae4454', 'zjr', '1', '44d630c592b511e780f9507b9dae4454', '5e5cad819ea111e7a438507b9dae4454', '0', '2017-11-16 15:56:55', '2017-12-21 15:11:42');
INSERT INTO `c_user` VALUES ('bd96c38acb5e11e7b965507b9dae4454', '62', '999.01_28_system', '系统', 'b150bd19864c3080d566921ad38972d3abc88d7c50756d95d50f86f547fbec8a', 'EP2zxOagtJqdYqO0aETaew==', '', '', '', '', null, null, null, '', '1', '1', '1', '1', '0', '2430db21ba0745b1ba39fc7ea2e10ff5', 'a90fa9578ec411e7b1a4507b9dae4454', '', '1', '1a41ad04cb3311e7b965507b9dae4454', '89efa57992d911e780f9507b9dae4454', '0', '2017-11-17 14:15:43', '2017-11-17 14:15:43');
INSERT INTO `c_user` VALUES ('d2c75c3e921811e79ff4507b9dae4454', '38', 'qiuzl', '李四', 'f77c6d5a7bc6eb34c270bde461941affe0302f92114f678cad5d8a60b5bb8266', null, '', '', '', '', null, null, null, '', '1', '1', '1', '1', '0', '4f472b2458684054a36e56a948dee97a', 'a90fa9578ec411e7b1a4507b9dae4454', '', null, null, null, null, '2017-09-05 17:01:38', '2017-09-06 17:29:44');
INSERT INTO `c_user` VALUES ('ded050e18efb11e7b1a4507b9dae4454', '17', 'lsgcb', '3232', '89a0c4cfd851277a72ec1cb525634ca6dd83f3a4469b038ca6dd46d06e6eb0c6', null, '', '', '', '', null, null, null, '', '1', '1', '1', '1', '0', '6285dfc4704a44b2ba906f84e667d709', 'a90fa9578ec411e7b1a4507b9dae4454', '', null, null, null, null, '2017-09-01 17:55:17', '2017-09-06 17:29:55');
INSERT INTO `c_user` VALUES ('e20afce4b12511e68bc4507b9dae4454', '1', 'admin', '管理员2', '01bb92d4684274ca5685738031621046495621d620f8dc78026dd291b700dd8e', null, '454654654@qq.com', '15920231521', '', '', null, null, null, '', '1', '1', '1', '1', '0', null, 'd5f60b0f8ec311e7b1a4507b9dae4454', 'wanve_weixin', null, null, null, null, '2016-11-23 10:38:15', '2018-11-08 09:09:23');
INSERT INTO `c_user` VALUES ('e87b77fb99b411e79af8507b9dae4454', '56', 'linlimei', '林丽', '92941782dc00c4ce98cc573eef7915d4a980cf3dbbe501dd5e319e165fcd62c7', 'wbs3dKkKnZw=', '', '13713096963', '', '', null, null, null, '', '1', '1', '1', '1', '0', 'e007a26691de4d5b973d3ce9c18b02b0', 'd5f60b0f8ec311e7b1a4507b9dae4454', 'linlimei', null, null, null, null, '2017-09-21 11:28:35', '2017-11-14 11:46:26');
INSERT INTO `c_user` VALUES ('ea5cd187943b11e7a354507b9dae4454', '53', 'bgs', 'bgs', '6d54a37a96911ce09a81dfad9a9003f76265788f4c04e46566ae634a39e7b7ab', 'wbs3dKkKnZw=', '', '', '', '', null, null, null, '', '1', '1', '1', '1', '0', '6182a368c096430f8ef072d70b74fe96', 'd5f60b0f8ec311e7b1a4507b9dae4454', '', null, null, null, null, '2017-09-08 10:18:14', '2017-11-14 11:46:45');
INSERT INTO `c_user` VALUES ('f8c6bd59944311e7a354507b9dae4454', '55', 'xll', '', 'b8683c43113165ca54a4d32c40c60e7da23f02d8164fe1763c381f22bcee068d', null, '', '', '', '', null, null, null, '', '1', '1', '1', '1', '0', 'cfacf0ffa33343feb37e46f169edbaa2', 'a90fa9578ec411e7b1a4507b9dae4454', '', null, null, null, null, '2017-09-08 11:15:32', '2017-09-08 11:15:32');
INSERT INTO `c_user` VALUES ('fea77a04c83e11e7a099507b9dae4454', '58', 'lx', '来了', '0a704cfb848ff2d5645b91f8f8cdf6e65aa03df3d11aa361df5f697c717e8f8b', 'wbs3dKkKnZw=', '', '', '', '', null, null, null, '', '1', '1', '1', '1', '0', 'e76fa72847a34f3e878475bec2e784a1', 'd5f60b0f8ec311e7b1a4507b9dae4454', '', null, null, null, null, '2017-11-13 14:50:31', '2018-11-07 18:00:19');

-- ----------------------------
-- Table structure for c_user_role
-- ----------------------------
DROP TABLE IF EXISTS `c_user_role`;
CREATE TABLE `c_user_role` (
  `user_id` varchar(32) NOT NULL,
  `role_id` varchar(32) NOT NULL,
  PRIMARY KEY (`role_id`,`user_id`),
  KEY `FK_ryx81a2lxs8gia9b88uqx16y6` (`role_id`) USING BTREE,
  KEY `FK_pnmkqxfhkfoup945qhjst4k4r` (`user_id`) USING BTREE,
  CONSTRAINT `c_user_role_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `c_user` (`id`) ON DELETE CASCADE,
  CONSTRAINT `c_user_role_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `c_role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of c_user_role
-- ----------------------------
INSERT INTO `c_user_role` VALUES ('5e5cad819ea111e7a438507b9dae4454', '14065dccb12011e68bc4507b9dae4454');
INSERT INTO `c_user_role` VALUES ('732a522992a211e780f9507b9dae4454', '14065dccb12011e68bc4507b9dae4454');
INSERT INTO `c_user_role` VALUES ('89efa57992d911e780f9507b9dae4454', '14065dccb12011e68bc4507b9dae4454');
INSERT INTO `c_user_role` VALUES ('8da0fc4e936611e7aafe507b9dae4454', '14065dccb12011e68bc4507b9dae4454');
INSERT INTO `c_user_role` VALUES ('b6516b6bcaa311e7b5d7507b9dae4454', '14065dccb12011e68bc4507b9dae4454');
INSERT INTO `c_user_role` VALUES ('bd96c38acb5e11e7b965507b9dae4454', '14065dccb12011e68bc4507b9dae4454');
INSERT INTO `c_user_role` VALUES ('ded050e18efb11e7b1a4507b9dae4454', '14065dccb12011e68bc4507b9dae4454');
INSERT INTO `c_user_role` VALUES ('e20afce4b12511e68bc4507b9dae4454', '14065dccb12011e68bc4507b9dae4454');
INSERT INTO `c_user_role` VALUES ('ea5cd187943b11e7a354507b9dae4454', '14065dccb12011e68bc4507b9dae4454');
INSERT INTO `c_user_role` VALUES ('f8c6bd59944311e7a354507b9dae4454', '14065dccb12011e68bc4507b9dae4454');
INSERT INTO `c_user_role` VALUES ('fea77a04c83e11e7a099507b9dae4454', '14065dccb12011e68bc4507b9dae4454');
INSERT INTO `c_user_role` VALUES ('013171ed66b111e783a7507b9dae4454', '348d11f866b111e783a7507b9dae4454');
INSERT INTO `c_user_role` VALUES ('2bd445a5cb3311e7b965507b9dae4454', '348d11f866b111e783a7507b9dae4454');
INSERT INTO `c_user_role` VALUES ('5e5cad819ea111e7a438507b9dae4454', '348d11f866b111e783a7507b9dae4454');
INSERT INTO `c_user_role` VALUES ('5f4a9af092d211e780f9507b9dae4454', '348d11f866b111e783a7507b9dae4454');
INSERT INTO `c_user_role` VALUES ('6fb27411cb4211e7b965507b9dae4454', '348d11f866b111e783a7507b9dae4454');
INSERT INTO `c_user_role` VALUES ('8544c5dc92a011e780f9507b9dae4454', '348d11f866b111e783a7507b9dae4454');
INSERT INTO `c_user_role` VALUES ('8da0fc4e936611e7aafe507b9dae4454', '348d11f866b111e783a7507b9dae4454');
INSERT INTO `c_user_role` VALUES ('b3711856944311e7a354507b9dae4454', '348d11f866b111e783a7507b9dae4454');
INSERT INTO `c_user_role` VALUES ('bd96c38acb5e11e7b965507b9dae4454', '348d11f866b111e783a7507b9dae4454');
INSERT INTO `c_user_role` VALUES ('d2c75c3e921811e79ff4507b9dae4454', '348d11f866b111e783a7507b9dae4454');
INSERT INTO `c_user_role` VALUES ('ded050e18efb11e7b1a4507b9dae4454', '348d11f866b111e783a7507b9dae4454');
INSERT INTO `c_user_role` VALUES ('e87b77fb99b411e79af8507b9dae4454', '348d11f866b111e783a7507b9dae4454');
INSERT INTO `c_user_role` VALUES ('ea5cd187943b11e7a354507b9dae4454', '348d11f866b111e783a7507b9dae4454');
INSERT INTO `c_user_role` VALUES ('013171ed66b111e783a7507b9dae4454', '9cd17854976e11e79c2b507b9dae4454');
INSERT INTO `c_user_role` VALUES ('2bd445a5cb3311e7b965507b9dae4454', '9cd17854976e11e79c2b507b9dae4454');
INSERT INTO `c_user_role` VALUES ('5e5cad819ea111e7a438507b9dae4454', '9cd17854976e11e79c2b507b9dae4454');
INSERT INTO `c_user_role` VALUES ('5f4a9af092d211e780f9507b9dae4454', '9cd17854976e11e79c2b507b9dae4454');
INSERT INTO `c_user_role` VALUES ('6fb27411cb4211e7b965507b9dae4454', '9cd17854976e11e79c2b507b9dae4454');
INSERT INTO `c_user_role` VALUES ('732a522992a211e780f9507b9dae4454', '9cd17854976e11e79c2b507b9dae4454');
INSERT INTO `c_user_role` VALUES ('8544c5dc92a011e780f9507b9dae4454', '9cd17854976e11e79c2b507b9dae4454');
INSERT INTO `c_user_role` VALUES ('89efa57992d911e780f9507b9dae4454', '9cd17854976e11e79c2b507b9dae4454');
INSERT INTO `c_user_role` VALUES ('8da0fc4e936611e7aafe507b9dae4454', '9cd17854976e11e79c2b507b9dae4454');
INSERT INTO `c_user_role` VALUES ('b3711856944311e7a354507b9dae4454', '9cd17854976e11e79c2b507b9dae4454');
INSERT INTO `c_user_role` VALUES ('bd96c38acb5e11e7b965507b9dae4454', '9cd17854976e11e79c2b507b9dae4454');
INSERT INTO `c_user_role` VALUES ('d2c75c3e921811e79ff4507b9dae4454', '9cd17854976e11e79c2b507b9dae4454');
INSERT INTO `c_user_role` VALUES ('e20afce4b12511e68bc4507b9dae4454', '9cd17854976e11e79c2b507b9dae4454');
INSERT INTO `c_user_role` VALUES ('e87b77fb99b411e79af8507b9dae4454', '9cd17854976e11e79c2b507b9dae4454');
INSERT INTO `c_user_role` VALUES ('ea5cd187943b11e7a354507b9dae4454', '9cd17854976e11e79c2b507b9dae4454');
INSERT INTO `c_user_role` VALUES ('f8c6bd59944311e7a354507b9dae4454', '9cd17854976e11e79c2b507b9dae4454');
INSERT INTO `c_user_role` VALUES ('5e5cad819ea111e7a438507b9dae4454', 'bcc612b8976e11e79c2b507b9dae4454');
INSERT INTO `c_user_role` VALUES ('e20afce4b12511e68bc4507b9dae4454', 'bcc612b8976e11e79c2b507b9dae4454');
INSERT INTO `c_user_role` VALUES ('e87b77fb99b411e79af8507b9dae4454', 'bcc612b8976e11e79c2b507b9dae4454');
INSERT INTO `c_user_role` VALUES ('2bd445a5cb3311e7b965507b9dae4454', 'c9b99e43cb3a11e7b965507b9dae4454');
INSERT INTO `c_user_role` VALUES ('6fb27411cb4211e7b965507b9dae4454', 'c9b99e43cb3a11e7b965507b9dae4454');
INSERT INTO `c_user_role` VALUES ('732a522992a211e780f9507b9dae4454', 'c9b99e43cb3a11e7b965507b9dae4454');
INSERT INTO `c_user_role` VALUES ('89efa57992d911e780f9507b9dae4454', 'c9b99e43cb3a11e7b965507b9dae4454');
INSERT INTO `c_user_role` VALUES ('5e5cad819ea111e7a438507b9dae4454', 'edcea2ef991311e781ec507b9dae4454');
INSERT INTO `c_user_role` VALUES ('b3711856944311e7a354507b9dae4454', 'edcea2ef991311e781ec507b9dae4454');

-- ----------------------------
-- Table structure for d_content
-- ----------------------------
DROP TABLE IF EXISTS `d_content`;
CREATE TABLE `d_content` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `topic_id` bigint(20) DEFAULT NULL,
  `index_no` int(11) DEFAULT NULL COMMENT '序号',
  `title` varchar(100) DEFAULT NULL COMMENT '标题',
  `content` text COMMENT '文章内容',
  `author` varchar(50) DEFAULT NULL COMMENT '作者',
  `source` varchar(50) DEFAULT NULL COMMENT '作者',
  `input_time` datetime DEFAULT NULL,
  `base_file_id` bigint(20) DEFAULT NULL,
  `video_file_id` bigint(20) DEFAULT NULL,
  `base_pattern` varchar(255) DEFAULT NULL,
  `vido_pattern` varchar(255) DEFAULT NULL,
  `type` smallint(6) DEFAULT NULL,
  `status` smallint(6) DEFAULT NULL COMMENT '状态',
  `company_id` varchar(32) DEFAULT NULL COMMENT '所属公司',
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of d_content
-- ----------------------------
INSERT INTO `d_content` VALUES ('4', '1', '1', '新的', '<p>1</p><p>2</p><p>3</p><p>4</p><p>5</p><p style=\"line-height: 16px;\"><img style=\"vertical-align: middle; margin-right: 2px;\" src=\"http://localhost:8080/rbib/plug-in/h-ui/lib/ueditor/1.4.3.3/dialogs/attachment/fileTypeImages/icon_txt.gif\"/><a style=\"font-size:12px; color:#0066cc;\" href=\"file/downloadFile.do?code=3n1hVo1uAE0=\" title=\"万维智慧工务平台单用户数据同步及单点登录接口文档-20170720.docx\">万维智慧工务平台单用户数据同步及单点登录接口文档-20170720.docx</a></p><p><br/></p>', '新的', '新的', '2017-08-28 00:00:00', null, null, null, null, null, '1', 'd5f60b0f8ec311e7b1a4507b9dae4454', '2017-08-28 08:48:28', '2017-09-15 11:14:56');
INSERT INTO `d_content` VALUES ('5', '1', '2', '第二', '<p style=\"line-height: 16px;\"><img style=\"vertical-align: middle; margin-right: 2px;\" src=\"http://localhost:8080/rbib/plug-in/h-ui/lib/ueditor/1.4.3.3/dialogs/attachment/fileTypeImages/icon_txt.gif\"/><a style=\"font-size:12px; color:#0066cc;\" href=\"file/downloadFile.do?code=axmqCnDlCb4%3D\" title=\"wrap.pdf\">wrap.pdf</a></p><p style=\"line-height: 16px;\"><img style=\"vertical-align: middle; margin-right: 2px;\" src=\"http://localhost:8080/rbib/plug-in/h-ui/lib/ueditor/1.4.3.3/dialogs/attachment/fileTypeImages/icon_txt.gif\"/><a style=\"font-size:12px; color:#0066cc;\" href=\"file/downloadFile.do?code=gXVEN27TW4U%3D\" title=\"test.pdf\">test.pdf</a><br/></p><p style=\"line-height: 16px;\"><img style=\"vertical-align: middle; margin-right: 2px;\" src=\"http://localhost:8080/rbib/plug-in/h-ui/lib/ueditor/1.4.3.3/dialogs/attachment/fileTypeImages/icon_txt.gif\"/><a style=\"font-size:12px; color:#0066cc;\" href=\"file/downloadFile.do?code=Dwwa%2Bi%2Bj%2Fp4%3D\" title=\"指导平台接口说明.doc\">指导平台接口说明.doc</a><br/></p><p style=\"line-height: 16px;\"><img style=\"vertical-align: middle; margin-right: 2px;\" src=\"http://localhost:8080/rbib/plug-in/h-ui/lib/ueditor/1.4.3.3/dialogs/attachment/fileTypeImages/icon_txt.gif\"/><a style=\"font-size:12px; color:#0066cc;\" href=\"file/downloadFile.do?code=A9H%2BwBS9JVM%3D\" title=\"路桥投资建议平台接口说明.docx\">路桥投资建议平台接口说明.docx</a><br/></p><p>asfac aa sda<br/></p><p style=\"line-height: 16px;\"><img style=\"vertical-align: middle; margin-right: 2px;\" src=\"http://localhost:8080/rbib/plug-in/h-ui/lib/ueditor/1.4.3.3/dialogs/attachment/fileTypeImages/icon_txt.gif\"/><a style=\"font-size:12px; color:#0066cc;\" href=\"file/downloadFile.do?code=wIkItEAHdao=\" title=\"test.txt\">test.txt</a></p><p style=\"line-height: 16px;\"><a style=\"font-size:12px; color:#0066cc;\" href=\"file/downloadFile.do?code=wIkItEAHdao=\" title=\"test.txt\"><br/></a></p><p style=\"line-height: 16px;\"><img style=\"vertical-align: middle; margin-right: 2px;\" src=\"http://localhost:8080/rbib/plug-in/h-ui/lib/ueditor/1.4.3.3/dialogs/attachment/fileTypeImages/icon_txt.gif\"/><a style=\"font-size:12px; color:#0066cc;\" href=\"file%2FdownloadFile.do%3Fcode%3DTvzFQeO82Co%3D\" title=\"监督登记表.docx\">监督登记表.docx</a></p><p style=\"line-height: 16px;\"><br/></p><p style=\"line-height: 16px;\"><img style=\"vertical-align: middle; margin-right: 2px;\" src=\"http://localhost:8080/rbib/plug-in/h-ui/lib/ueditor/1.4.3.3/dialogs/attachment/fileTypeImages/icon_txt.gif\"/><a style=\"font-size:12px; color:#0066cc;\" href=\"file/downloadFile.do?code=WjP7SvIB8Qg%3D\" title=\"template.pdf\">template.pdf</a></p><p><br/></p>', 'asca', 'asd', '2017-08-15 00:00:00', null, null, null, null, null, '1', 'd5f60b0f8ec311e7b1a4507b9dae4454', '2017-08-30 14:41:48', '2017-09-18 11:20:49');
INSERT INTO `d_content` VALUES ('6', '1', '3', '第三', '<p>abdadb<br/></p>', 'xzvzxv', 'zxvzx', '2017-08-14 00:00:00', null, null, null, null, null, '1', 'd5f60b0f8ec311e7b1a4507b9dae4454', '2017-08-30 14:42:18', '2017-08-30 14:42:18');
INSERT INTO `d_content` VALUES ('7', '2', '1', '头条新闻', '<p><img src=\"http://n.sinaimg.cn/news/crawl/20170904/0yAo-fykpyua5372385.jpg\" alt=\"资料图：在新西兰首都惠灵顿街头拍摄的共享单车。 新华社记者宿亮摄\"/><span class=\"img_descr\">资料图：在新西兰首都惠灵顿街头拍摄的共享单车。 新华社记者宿亮摄</span></p><p>　　参考消息网9月4日报道 英国广播公司8月30日刊登记者约翰·萨德沃思的文章，题为《中国共享经济是否达到顶峰？》。文章摘编如下：</p><p>　　共享汽车，非常合理。我们也能懂共享单车的好处。不过，共享篮球是怎样一回事？</p><p>　　在北京的一个运动场上，王会恩用他的智能手机扫描储物柜上的二维码。</p><p>　　储物柜的门打开后，用户就可以使用里面的篮球。租借费用是每小时大概2元人民币。</p><p>　　王会恩是一元体育的首席执行官。他计划在全中国推行共享服务，总共提供2000万个足球及篮球。</p><p>　　王会恩对我说：“共享（经济）现在是有点热啊。”“不是为了共享而共享。是为用户带来极致体验而共享。”</p><p>　　<strong>共享经济火爆发展</strong></p><p>　　中国使用智能手机支付的普遍程度，世上没有其他国家可媲美。手机支付亦令共享经济起飞。</p><p>　　有些共享经济项目配对用户，例如有人驾车时空出了位子，可以利用程式去配对前往同样地点的乘客。</p><p>　　一些则是高科技的租赁项目，例如是单车、计程车或者球类。费用积少成多，为公司带来庞大的收入。</p><p>　　共享经济在中国火爆非常、极速增长，也吸引了以十亿元计的创业投资的资金。</p><p>　　<strong>共享面临挑战</strong></p><p>　　不过所有崭新的商业模式都会带来新挑战，而共享经济也不例外。</p><p>　　有公司发起提供共享雨伞的服务，但当30万把雨伞都不见之后，营业陷入困难。</p><p>　　“共享睡眠舱”让用户可以租用空间睡觉休息。不过睡眠舱违反酒店规定，现时被停业。</p><p>　　共享单车用户人数众多，是共享经济最成功的模式。不过就算是共享单车，经营上也遇到一定困难──包括盗窃、恶意破坏等。</p><p>　　在合肥，成千上万的单车因非法停放，被关在一个运动场上。这显示，除了吸引足够用户外，共享经济的成功还需要其他因素。</p><p>　　虽然发展遇上不少困难，但共享经济还是有丰富的潜力。</p><p>　　共享单车的追踪技术让用户可以随处停放单车，而并非只能停在单车停靠点上。</p><p>　　在一些中国城市，共享单车红火，令使用单车的人数在一两年之内增长一倍。</p><p>　　<strong>“革命性的潜力”</strong></p><p></p><p>　　卡尔·菲耶尔斯特伦（音）是远东BRT规划的城市交通顾问。他认为，共享单车在短时间内鼓励使用单车的效用，远比数十年的宣传教育要强。</p><p>　　“我十年来推动使用单车。不仅在中国，而是在全世界。这很困难。”</p><p>　　“共享单车出现，带来革命性的效果。我认为这是历史性的机会。”</p><p>　　在一幢住宅大楼的前面，李小群（音）在跑步机上跑步。共享运动舱是最新的共享热潮，而李小群首次使用这一服务。</p><p>　　对比一般的健身房，共用运动舱没有洗澡的地方，也没有更衣室，设备不算太理想。</p><p>　　不过共用运动舱每小时费用只需约13元人民币，令李小群印象深刻。</p><p>　　她说：“人们喜欢这些共享的主意。”</p><p>　　“我们希望看到更多共享经济的模式。它是惊喜。我们都希望共享模式可以发展得好。”</p><p>\r\n	</p><p class=\"article-editor\">责任编辑：张迪</p><p>\r\n\r\n\r\n\r\n			\r\n\r\n\r\n			</p><p>\r\n\r\n			</p><p>\r\n			文章关键词：\r\n			 &nbsp;<a href=\"http://tags.news.sina.com.cn/%E5%85%B1%E4%BA%AB%E7%BB%8F%E6%B5%8E\" target=\"_blank\">共享经济</a> <a href=\"http://tags.news.sina.com.cn/%E6%99%BA%E8%83%BD%E6%89%8B%E6%9C%BA\" target=\"_blank\">智能手机</a> <a href=\"http://tags.news.sina.com.cn/%E5%85%B1%E4%BA%AB%E5%8D%95%E8%BD%A6\" target=\"_blank\">共享单车</a> \r\n			</p><p><a href=\"http://comment5.news.sina.com.cn/comment/skin/feedback_1.html?channel=ly&newsid=3\" target=\"_blank\">我要反馈</a>\r\n &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<a href=\"http://roll.news.sina.com.cn/savepage/save.php?url=http%3A%2F%2Fnews.sina.com.cn%2Fo%2F2017-09-04%2Fdoc-ifykpzey4095974.shtml&ie=utf8\" target=\"_blank\">保存网页</a>\r\n &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p><p>\r\n			&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;			</p><p><span class=\"count\"><em><a href=\"http://comment5.news.sina.com.cn/comment/skin/default.html?channel=gn&newsid=comos-fykpzey4095974\">11</a></em>条评论|<em><a href=\"http://comment5.news.sina.com.cn/comment/skin/default.html?channel=gn&newsid=comos-fykpzey4095974\">33</a></em>人参与</span><span class=\"tip\">我有话说</span></p><p><span class=\"arrow\"></span></p><p><a href=\"http://weibo.com/\" target=\"_blank\"><img src=\"http://img.t.sinajs.cn/t5/style/images/face/male_180.png\" width=\"80\" height=\"80\"/></a></p><p><a class=\"trigger\">表情</a></p><p><a class=\"comment btn btn-red btn-disabled\">发布</a></p><p><a class=\"login-lnk\" title=\"登录\">登录</a>|<a class=\"register-lnk\" target=\"_blank\" href=\"https://login.sina.com.cn/signup/signup.php\">注册</a></p><p><span class=\"name\">最新评论</span> <a class=\"reflash\">刷新</a> </p><p><a href=\"http://weibo.com/u/3584154327\" title=\"ls705\" target=\"_blank\"><img src=\"http://tvax2.sinaimg.cn/crop.0.0.382.382.50/d5a1dad7ly8fhfxedlhyuj20c80amdgp.jpg\"/></a></p><p><span class=\"name name-weibo\"><span class=\"sina-comment-user-lnk-wrap\"><a target=\"_blank\" href=\"http://weibo.com/u/3584154327\" title=\"ls705\">ls705</a></span></span><span class=\"area\">[山东临沂]</span></p><p>从人类社会的长远角度讲，应该可以更深度挖掘“共享经济”的，最起码可以节约大量的消费性资源，避免浪费！</p><p><span class=\"time\">9月5日14:30</span><a class=\"report\" href=\"http://comment5.news.sina.com.cn/comment/skin/feedback_jb.html?mid=59AE4492-70E9F085-D5A1DAD7-8D2-8FA\" target=\"_blank\">举报</a><span class=\"btns\"><a class=\"vote\" title=\"赞\">赞</a><a class=\"reply\">回复</a></span></p><p><a href=\"http://weibo.com/u/2299247961\" title=\"青竹溪流\" target=\"_blank\"><img src=\"http://tvax2.sinaimg.cn/default/images/default_avatar_male_50.gif\"/></a></p><p><span class=\"name name-weibo\"><span class=\"sina-comment-user-lnk-wrap\"><a target=\"_blank\" href=\"http://weibo.com/u/2299247961\" title=\"青竹溪流\">青竹溪流</a></span></span><span class=\"area\">[北京海淀]</span></p><p>享受共享的人，如没有较高的素质做为基础，就会将共享的项目，搞砸，这个项目的最后结局，就是一堆垃圾！就如30万把雨伞的结局同样。什么项目，都是要把人的因素放在第一位！</p><p><span class=\"time\">9月4日15:56</span><a class=\"report\" href=\"http://comment5.news.sina.com.cn/comment/skin/feedback_jb.html?mid=59AD0740-DF66278B-890BBD59-8D2-840\" target=\"_blank\">举报</a><span class=\"btns\"><a class=\"vote\" title=\"赞\">赞<em>1</em></a><a class=\"reply\">回复</a></span></p><p><a target=\"_blank\" href=\"http://comment5.news.sina.com.cn/comment/skin/default.html?info_type=1&style=1&user_uid=1216312251\" title=\"hz212000\"><img src=\"http://portrait5.sinaimg.cn/1216312251/blog/50\"/></a></p><p><span class=\"name \"><span class=\"sina-comment-user-lnk-wrap\"><a target=\"_blank\" href=\"http://comment5.news.sina.com.cn/comment/skin/default.html?info_type=1&style=1&user_uid=1216312251\" title=\"hz212000\">hz212000</a></span></span><span class=\"area\">[广西钦州]</span></p><p>社会发展到了一个新阶段，加上信息网络的发达，资源的有效利用成为必然与结果。</p><p><span class=\"time\">9月4日15:49</span><a class=\"report\" href=\"http://comment5.news.sina.com.cn/comment/skin/feedback_jb.html?mid=59AD058E-AB683910-487F73BB-8D2-9A9\" target=\"_blank\">举报</a><span class=\"btns\"><a class=\"vote\" title=\"赞\">赞</a><a class=\"reply\">回复</a></span></p><p><a target=\"_blank\" href=\"http://comment5.news.sina.com.cn/comment/skin/default.html?channel=gn&newsid=comos-fykpzey4095974&group=0\">还有<em>8</em>条评论，更多精彩评论&gt;&gt;</a></p><p>\r\n			&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;			</p><p><img class=\"news_con_qrcode\" alt=\"新浪新闻\" src=\"http://n.sinaimg.cn/news/content2014/news_con_qrcode.jpg\"/></p><p>\r\n\r\n			</p><p>\r\n		</p><p><ins><ins><a style=\"display:block;line-height:0;\" href=\"http://saxn.sina.com.cn/dsp/click?t=MjAxNy0wOS0wNiAwODo1MjozNi4wMTYJMTEzLjc3LjE5Mi4yNDMJMTEzLjc3LjE5Mi4yNDNfMTUwNDY1OTE0Ni42MzgyNTAJZDM3YTQ2YWMtZjhkMC00YzcxLTllMmUtMWYxZjdhYTVjOWNmCTQxMjE5OAk1ODczMjU2OTQ0X1BJTlBBSS1DUEMJMTM1ODQ0CTE5NTk1Mgk3Ljc3MDQyMzVFLTQJMQl0cnVlCVBEUFMwMDAwMDAwNTUxNjQJMjAzMzQ1OAlQQwlpbWFnZQktCTB8NEd0Y1hmbzg0Z1BFNTV5Mk1DeW5jTHxudWxsfG51bGx8Ymp8NDEyMTk4fDZ4NndaWHJTcnNlYk9tN2JYMU5oZGt8MAludWxsCTEJLQktCS0JMAkxMTMuNzcuMTkyLjI0M18xNTA0NjU5MTQ2LjYzODI1MAlQQ19JTUFHRQktCW5vLXVzZXJhZ2V8dXZmbS1ydAktCXVzZXJfdGFnOjIwMTA3OjAuMHx1c2VyX2FnZTo2MDE6MC4xNTEwMXx1c2VyX2dlbmRlcjo1MDE6MC42MzIyMnx2X3pvbmU6MzA2MDAzOjAuMHxjcm93ZHM6OjAuMHxfY3Jvd2RzOjowLjAJMAkyMjMwMDAJNTAwMDAJLQ==&userid=113.77.192.243_1504659146.638250&auth=5d726779246200f3&p=NzFWG9cOOSyMJy6A8FRP65r2%2BJNpcqOPSOXmjw%3D%3D&url=http%3A%2F%2Fsax.sina.com.cn%2Fclick%3Ftype%3D2%26t%3DMzczMTU2MWItZDcwZS0zOTJjLThjMjctMmU4MGYwNTQ0ZmViCTE3CVBEUFMwMDAwMDAwNTUxNjQJMjAzMzQ1OAkxCVJUQgktCQk%253D%26id%3D17%26url%3Dhttp%253A%252F%252Fdan.lyhuapu.com%252F%253Fgzid%253DC64090%26sina_sign%3Db844b7e4090dd239&sign=07940cf29fe50f79\" target=\"_blank\"><img src=\"http://d7.sina.com.cn/pfpghc2/201709/01/b2386978c024434bbac1a51727906fab.jpg\" style=\"width:640px;height:90px;border:0\" alt=\"//d7.sina.com.cn/pfpghc2/201709/01/b2386978c024434bbac1a51727906fab.jpg\"/></a></ins></ins>\r\n				</p><p><br/></p><p>\r\n		</p><h3>相关阅读</h3><h2 class=\"undefined\"><a href=\"http://news.sina.com.cn/o/2017-09-05/doc-ifykpuui1138449.shtml?cre=newspagepc&mod=f&loc=1&r=9&doct=0&rfunc=86\" target=\"_blank\">押金半月不退 小鸣单车7日内退款承诺成一纸空文</a></h2><p><a href=\"http://news.sina.com.cn/o/2017-09-05/doc-ifykpuui1138449.shtml?cre=newspagepc&mod=f&loc=1&r=9&doct=0&rfunc=86\" class=\"feed-card-txt-summary\" target=\"_blank\">CFP图 【新民网·最新消息】在历经半个月的等待后，陆小姐还是没有收到退还的共享单车押金。新民晚报新民网记者发现，与陆小姐类似的情况在网上不在少数。</a><a href=\"http://news.sina.com.cn/o/2017-09-05/doc-ifykpuui1138449.shtml?cre=newspagepc&mod=f&loc=1&r=9&doct=0&rfunc=86\" class=\"feed-card-txt-detail\" target=\"_blank\">[详细]</a></p><p>9月5日 13:30</p><p><a href=\"http://tags.news.sina.com.cn/%E5%BE%AE%E5%8D%9A\" target=\"_blank\">微博</a><a href=\"http://tags.news.sina.com.cn/%E6%8A%BC%E9%87%91\" target=\"_blank\">押金</a><a href=\"http://tags.news.sina.com.cn/%E5%85%B1%E4%BA%AB%E5%8D%95%E8%BD%A6\" target=\"_blank\">共享单车</a></p><p><a class=\"feed-card-comment\" target=\"_blank\">评论(7)</a><span class=\"feed-card-spliter\">|</span><span class=\"bdshare_t bds_tools get-codes-bdshare feed-card-share\"><span class=\"bds_more\">分享</span></span></p><h2 class=\"undefined\"><a href=\"http://news.sina.com.cn/o/2017-09-05/doc-ifykpzey4441944.shtml?cre=newspagepc&mod=f&loc=2&r=9&doct=0&rfunc=86\" target=\"_blank\">女子单车扔路中间 竟称“我不方便大家都别方便”</a></h2><p><a href=\"http://news.sina.com.cn/o/2017-09-05/doc-ifykpzey4441944.shtml?cre=newspagepc&mod=f&loc=2&r=9&doct=0&rfunc=86\" class=\"feed-card-txt-summary\" target=\"_blank\">中国青年网讯 9月2日早上八点半，成都一公交站。因共享单车挡住了公交站台，一个女子把共享单车全甩在路中间，并称：我不方便就都别方便了！ &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 责编：金鑫</a><a href=\"http://news.sina.com.cn/o/2017-09-05/doc-ifykpzey4441944.shtml?cre=newspagepc&mod=f&loc=2&r=9&doct=0&rfunc=86\" class=\"feed-card-txt-detail\" target=\"_blank\">[详细]</a></p><p>9月5日 10:03</p><p><a href=\"http://tags.news.sina.com.cn/%E5%85%B1%E4%BA%AB%E5%8D%95%E8%BD%A6\" target=\"_blank\">共享单车</a><a href=\"http://tags.news.sina.com.cn/%E5%A5%B3%E5%AD%90\" target=\"_blank\">女子</a><a href=\"http://tags.news.sina.com.cn/%E5%85%AC%E4%BA%A4%E7%AB%99%E5%8F%B0\" target=\"_blank\">公交站台</a></p><p><a class=\"feed-card-comment\" target=\"_blank\">评论(8)</a><span class=\"feed-card-spliter\">|</span><span class=\"bdshare_t bds_tools get-codes-bdshare feed-card-share\"><span class=\"bds_more\">分享</span></span></p><h2 class=\"undefined\"><a href=\"http://news.sina.com.cn/o/2017-09-05/doc-ifykpuui1136884.shtml?cre=newspagepc&mod=f&loc=3&r=9&doct=0&rfunc=86\" target=\"_blank\">成都有大事发生！7家共享单车齐发大招啦~</a></h2><p><a href=\"http://news.sina.com.cn/o/2017-09-05/doc-ifykpuui1136884.shtml?cre=newspagepc&mod=f&loc=3&r=9&doct=0&rfunc=86\" class=\"feed-card-txt-summary\" target=\"_blank\">不知道这两天小伙伴有没有感觉到身边的各种共享单车多到数不清，各种小黄小红小黑都出来了！这到底是为什么呢？不急看这里！↓昨日...</a><a href=\"http://news.sina.com.cn/o/2017-09-05/doc-ifykpuui1136884.shtml?cre=newspagepc&mod=f&loc=3&r=9&doct=0&rfunc=86\" class=\"feed-card-txt-detail\" target=\"_blank\">[详细]</a></p><p>9月5日 13:35</p><p><a href=\"http://tags.news.sina.com.cn/%E5%85%B1%E4%BA%AB%E5%8D%95%E8%BD%A6\" target=\"_blank\">共享单车</a><a href=\"http://tags.news.sina.com.cn/%E7%BB%BF%E8%89%B2%E5%87%BA%E8%A1%8C\" target=\"_blank\">绿色出行</a><a href=\"http://tags.news.sina.com.cn/%E9%AA%91%E8%A1%8C\" target=\"_blank\">骑行</a></p><p><a class=\"feed-card-comment\" target=\"_blank\">评论(5)</a><span class=\"feed-card-spliter\">|</span><span class=\"bdshare_t bds_tools get-codes-bdshare feed-card-share\"><span class=\"bds_more\">分享</span></span></p><h2 class=\"undefined\"><a href=\"http://news.sina.com.cn/o/2017-09-05/doc-ifykpuui1157732.shtml?cre=newspagepc&mod=f&loc=4&r=9&doct=0&rfunc=86\" target=\"_blank\">超出承载能力近一倍 武汉暂停新增共享单车投放</a></h2><p><a href=\"http://news.sina.com.cn/o/2017-09-05/doc-ifykpuui1157732.shtml?cre=newspagepc&mod=f&loc=4&r=9&doct=0&rfunc=86\" class=\"feed-card-txt-summary\" target=\"_blank\">70万辆单车超出我市承载能力近一倍武汉暂停新增共享单车投放昨天下午，市文明办、市交委、市城管委、市公安交管局四部门联合召开新闻发布会...</a><a href=\"http://news.sina.com.cn/o/2017-09-05/doc-ifykpuui1157732.shtml?cre=newspagepc&mod=f&loc=4&r=9&doct=0&rfunc=86\" class=\"feed-card-txt-detail\" target=\"_blank\">[详细]</a></p><p>9月5日 14:42</p><p><a href=\"http://tags.news.sina.com.cn/%E5%85%B1%E4%BA%AB%E5%8D%95%E8%BD%A6\" target=\"_blank\">共享单车</a><a href=\"http://tags.news.sina.com.cn/%E6%89%BF%E8%BD%BD%E8%83%BD%E5%8A%9B\" target=\"_blank\">承载能力</a><a href=\"http://tags.news.sina.com.cn/%E5%B8%82%E4%BA%A4%E5%A7%94\" target=\"_blank\">市交委</a></p><p><a class=\"feed-card-comment\" target=\"_blank\">评论</a><span class=\"feed-card-spliter\">|</span><span class=\"bdshare_t bds_tools get-codes-bdshare feed-card-share\"><span class=\"bds_more\">分享</span></span></p><p>\r\n\r\n		&nbsp;\r\n\r\n &nbsp; &nbsp; &nbsp;		\r\n		</p><p><a href=\"http://slide.news.sina.com.cn/s/slide_1_2841_200269.html?cre=newspagepc&mod=picg&loc=1&r=0&doct=0&rfunc=86&tj=none\" target=\"_blank\">\r\n &nbsp; &nbsp; &nbsp; &nbsp;<img src=\"http://n.sinaimg.cn/news/1_img/upload/c4b46437/20170905/VynC-fykqmrv9893373.jpg\" width=\"150\" height=\"100\"/>\r\n &nbsp; &nbsp; &nbsp; &nbsp;院方建议剖腹产被家属拒绝 孕妇跳楼身亡\r\n &nbsp; &nbsp; &nbsp;</a>\r\n &nbsp; &nbsp;</p><p><a href=\"http://slide.news.sina.com.cn/s/slide_1_2841_200236.html?cre=newspagepc&mod=picg&loc=2&r=0&doct=0&rfunc=86&tj=none\" target=\"_blank\">\r\n &nbsp; &nbsp; &nbsp; &nbsp;<img src=\"http://n.sinaimg.cn/news/1_img/upload/e4fb714e/20170905/5-gD-fykqmrv9662422.jpg\" width=\"150\" height=\"100\"/>\r\n &nbsp; &nbsp; &nbsp; &nbsp;当战友踏入安检门的那一刻，他哭了\r\n &nbsp; &nbsp; &nbsp;</a>\r\n &nbsp; &nbsp;</p><p><a href=\"http://slide.zx.sina.com.cn/slide_79_87056_124794.html?cre=newspagepc&mod=picg&loc=3&r=0&doct=0&rfunc=86&tj=none\" target=\"_blank\">\r\n &nbsp; &nbsp; &nbsp; &nbsp;<img src=\"http://n.sinaimg.cn/default/99_img/upload/94f4deff/20170905/ZnaD-fykqmrw0382542.jpg\" width=\"150\" height=\"100\"/>\r\n &nbsp; &nbsp; &nbsp; &nbsp;货车运鲸鲨送酒店遭拒 在路边用锯子切割\r\n &nbsp; &nbsp; &nbsp;</a>\r\n &nbsp; &nbsp;</p><p>\r\n	</p><p>\r\n		\r\n		&nbsp;	</p><p>\r\n\r\n\r\n	</p><h2><strong>聚焦</strong></h2><ul class=\" list-paddingleft-2\"></ul><ul class=\" list-paddingleft-2\"><li><p><br/></p></li><li><p><br/></p></li><li><p><br/></p></li><li><p><br/></p></li></ul><p><ins><ins><a style=\"display:block;line-height:0;\" href=\"http://saxn.sina.com.cn/dsp/click?t=MjAxNy0wOS0wNiAwODo1MjozNi4xOTcJMTEzLjc3LjE5Mi4yNDMJMTEzLjc3LjE5Mi4yNDNfMTUwNDY1OTE0Ni42MzgyNTAJOGE4MDkwZWItNDRkMi00M2I0LTk1NTItYTQ1Y2Q5MzljZjRjCTg1Mzk1Mwk1ODk4Nzc2MzI4X1BJTlBBSS1DUEMJMzA1ODE2CTE3MzAwMAkzLjcyNTUyMjVFLTQJMQl0cnVlCVBEUFMwMDAwMDAwNTc5MzYJMjAzMzIyNQlQQwlpbWFnZQktCTB8NkZqcjdtalpzQWNwSlc1cG1jQzVSUXxudWxsfG51bGx8Ymp8ODUzOTUzfDZVeXp3eTZ3S2hBRTF3VnZoaHZkV0J8MAludWxsCTEJLQktCS0JMAkxMTMuNzcuMTkyLjI0M18xNTA0NjU5MTQ2LjYzODI1MAlQQ19JTUFHRQktCW5vLXVzZXJhZ2V8dXZmbS1ydAktCXVzZXJfdGFnOjIwNzM2OjAuMHx1c2VyX2FnZTo2MDI6MC4zMDYzNXx1c2VyX2dlbmRlcjo1MDE6MC42MzIyMnx2X3pvbmU6MzA2MDAzOjAuMHxjcm93ZHM6OjAuMHxfY3Jvd2RzOjowLjAJMAkxNzMwMDAJNTAwMDAJLQ==&userid=113.77.192.243_1504659146.638250&auth=1634e58c37c9ac08&p=QyauCav%2FMn2RRuQROYw6YoAxLt%2BWNnedClQ%2FdQ%3D%3D&url=http%3A%2F%2Fsax.sina.com.cn%2Fclick%3Ftype%3D2%26t%3DNDMyNmFlMDktYWJmZi0zMjdkLTkxNDYtZTQxMTM5OGMzYTYyCTE3CVBEUFMwMDAwMDAwNTc5MzYJMjAzMzIyNQkxCVJUQgktCQk%253D%26id%3D17%26url%3Dhttp%253A%252F%252Fwww.dsdcytzc.cn%252Flsxlhcx.htm%253Fgzid%253D64090A%2526SET_A%253DPDPS000000057936%2526SET_B%253D853953%2526SET_C%253D2033225%2526SET_D%253D8a8090eb-44d2-43b4-9552-a45cd939cf4c%2526SET_E%253D305816%2526SET_F%253D1%26sina_sign%3D02f806b77137bee5&sign=72fb930e77144abe\" target=\"_blank\"><img src=\"http://d6.sina.com.cn/pfpghc2/201709/01/452bb0e398c94252a78b167013ee47d5.jpg\" style=\"width:640px;height:90px;border:0\" alt=\"//d6.sina.com.cn/pfpghc2/201709/01/452bb0e398c94252a78b167013ee47d5.jpg\"/></a></ins></ins></p><p>\r\n\r\n\r\n		</p><p><br/></p><p><br/></p><p>\r\n\r\n		&nbsp;\r\n		 &nbsp;\r\n &nbsp; &nbsp; &nbsp; &nbsp;		</p><p><span class=\"selected\">应用中心</span>\r\n &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;新浪公益\r\n &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;新浪游戏\r\n &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;互动活动\r\n &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;热点推荐\r\n &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p><p>\r\n	</p><ul class=\"clist cpot clearfix list-paddingleft-2\"><li><p><a href=\"http://app.sina.com.cn/appdetail.php?appID=126919&f=p_wenjiao&w=p_wenjiao\" target=\"_blank\">最萌贴图礼品：美图贴贴</a></p></li><li><p><a href=\"http://app.sina.com.cn/appdetail.php?appID=146866&f=p_wenjiao&w=p_wenjiao\" target=\"_blank\">权威体育赛事：新浪体育</a></p></li><li><p><a href=\"http://app.sina.com.cn/appdetail.php?appID=133449&f=p_wenjiao&w=p_wenjiao\" target=\"_blank\">备考最有效率：扇贝单词</a></p></li><li><p><a href=\"http://app.sina.com.cn/appdetail.php?appID=1918878&f=p_wenjiao&w=p_wenjiao\" target=\"_blank\">免费上网革命：wifi神器</a></p></li><li><p><a href=\"http://app.sina.com.cn/appdetail.php?appID=2387361&f=p_wenjiao&w=p_wenjiao\" target=\"_blank\">力量抗争：超自然逃脱2</a></p></li><li><p><a href=\"http://app.sina.com.cn/appdetail.php?appID=2387398&f=p_wenjiao&w=p_wenjiao\" target=\"_blank\">探金字塔：被遗忘的宝藏</a></p></li><li><p><a href=\"http://app.sina.com.cn/appdetail.php?appID=2387522&f=p_wenjiao&w=p_wenjiao\" target=\"_blank\">诡异树林：逃离死亡树林</a></p></li><li><p><a href=\"http://app.sina.com.cn/appdetail.php?appID=2387866&f=p_wenjiao&w=p_wenjiao\" target=\"_blank\">虐心游戏：囧囧侠大冒险</a></p></li><li><p><a href=\"http://app.sina.com.cn/appdetail.php?appID=101471&f=p_wenjiao&w=p_wenjiao\" target=\"_blank\">前沿文化精髓：掌上猫扑</a></p></li><li><p><a href=\"http://app.sina.com.cn/appdetail.php?appID=93240&f=p_wenjiao&w=p_wenjiao\" target=\"_blank\">移动阅读生活：塔读小说</a></p></li><li><p><a href=\"http://app.sina.com.cn/appdetail.php?appID=93310&f=p_wenjiao&w=p_wenjiao\" target=\"_blank\">订机票立减50：航班管家</a></p></li><li><p><a href=\"http://app.sina.com.cn/appdetail.php?appID=84551&f=p_wenjiao&w=p_wenjiao\" target=\"_blank\">手机的造型师：安卓壁纸</a></p></li><li><p><a href=\"http://app.sina.com.cn/appdetail.php?appID=2386721&f=p_wenjiao&w=p_wenjiao\" target=\"_blank\">穿隧道：霓虹灯轨道飞行</a></p></li><li><p><a href=\"http://app.sina.com.cn/appdetail.php?appID=2387671&f=p_wenjiao&w=p_wenjiao\" target=\"_blank\">虚与实：你的人生你做主</a></p></li><li><p><a href=\"http://app.sina.com.cn/appdetail.php?appID=2386874&f=p_wenjiao&w=p_wenjiao\" target=\"_blank\">怪：国夫君的热血躲避球</a></p></li><li><p><a href=\"http://app.sina.com.cn/appdetail.php?appID=2387673&f=p_wenjiao&w=p_wenjiao\" target=\"_blank\">狠：光头枪手打怪兽塔防</a></p></li></ul><p>\r\n\r\n\r\n\r\n\r\n\r\n\r\n				\r\n				</p><p>&nbsp; &nbsp; &nbsp; &nbsp;		</p><p>\r\n\r\n\r\n\r\n	</p><p>\r\n		</p><ul class=\" list-paddingleft-2\"><li><p>·<a href=\"http://city.finance.sina.com.cn/city/wlmp.html\" target=\"_blank\">城市热点节庆活动</a></p></li><li><p>·<a href=\"http://city.finance.sina.com.cn/city/dhcs.html\" target=\"_blank\">新浪《对话城市》</a></p></li><li><p>·<a href=\"http://mail.sina.net/daili/daili.htm\" target=\"_blank\">诚招合作伙伴</a></p></li><li><p>·<a href=\"http://www.sinanet.com\" target=\"_blank\">新企邮上线更优惠</a></p></li></ul><p>\r\n	</p><p>\r\n		</p><p>\r\n\r\n	</p><p>\r\n		</p><p> \r\n\r\n		</p><p><ins><ins><a style=\"display:block;line-height:0;\" href=\"http://saxn.sina.com.cn/dsp/click?t=MjAxNy0wOS0wNiAwODo1MjozNi4yOTUJMTEzLjc3LjE5Mi4yNDMJMTEzLjc3LjE5Mi4yNDNfMTUwNDY1OTE0Ni42MzgyNTAJNWVhNTkyNmYtN2M0YS00N2EyLTg4OTMtNmJjZWUzMjE4ZjY1CTg1MjkzNQk1OTM3MTIyODg4X1BJTlBBSS1DUEMJMzA1NjM3CTE2ODA3Ngk4LjEzMjE0MzRFLTQJMQl0cnVlCVBEUFMwMDAwMDAwNDIxMzMJMjAzMTcxOAlQQwlpbWFnZQktCTB8M3k3ajAzdzFjNkFBb1VWZUtySXRJSXxudWxsfG51bGx8Ymp8ODUyOTM1fGNrc0tmYmprYXBraW5DSmhidUVHTXwwCW51bGwJMQktCS0JLQkwCTExMy43Ny4xOTIuMjQzXzE1MDQ2NTkxNDYuNjM4MjUwCVBDX0lNQUdFCS0Jbm8tdXNlcmFnZXx1dmZtLXJ0CS0JdXNlcl90YWc6MjA5NTE6MC4wfHVzZXJfYWdlOjYwNjowLjB8dXNlcl9nZW5kZXI6NTAxOjAuNjMyMjJ8dl96b25lOjMwNjAwMzowLjB8Y3Jvd2RzOjowLjB8X2Nyb3dkczo6MC4wCTAJMTc1MDAwCTUwMDAwCS0=&userid=113.77.192.243_1504659146.638250&auth=66c1a50e135e5f3c&p=CZepwn0jOTGpwZlv%2BzeGrwKZfg34HNnCP5cHMA%3D%3D&url=http%3A%2F%2Fsax.sina.com.cn%2Fclick%3Ftype%3D2%26t%3DMDk5N2E5YzItN2QyMy0zOTMxLWE5YzEtOTk2ZmZiMzc4NmFmCTE3CVBEUFMwMDAwMDAwNDIxMzMJMjAzMTcxOAkxCVJUQgktCQk%253D%26id%3D17%26url%3Dhttp%253A%252F%252Fszhonjoy.com%252F%253Fgzid%253D0828-300500e%26sina_sign%3D34a7520d5a007a34&sign=5a224d711d2874ea\" target=\"_blank\"><img src=\"http://d8.sina.com.cn/pfpghc2/201708/29/ec154a47a2fb44d4b77cf144faffd300.jpg\" style=\"width:300px;height:500px;border:0\" alt=\"//d8.sina.com.cn/pfpghc2/201708/29/ec154a47a2fb44d4b77cf144faffd300.jpg\"/></a><a target=\"_blank\" href=\"http://amp.ad.sina.com.cn/ea/privacy.html\" style=\"position:absolute;left:0;top:0;z-index:20;\"><img src=\"http://d1.sina.com.cn/litong/zhitou/sinaads/release/gx_logo.png\" width=\"18\" height=\"18\"/></a></ins></ins></p><p>\r\n		</p><p>\r\n		</p><p><ins><ins><a style=\"display:block;line-height:0;\" href=\"http://saxn.sina.com.cn/dsp/click?t=MjAxNy0wOS0wNiAwODo1MjozNi4yOTgJMTEzLjc3LjE5Mi4yNDMJMTEzLjc3LjE5Mi4yNDNfMTUwNDY1OTE0Ni42MzgyNTAJOWQ0OTBjN2YtZjc2Ny00MmEyLWFjNjYtYzk3Y2E0NGVhNGZhCTgzMjIwNgk2MjgzODMyMjE1X1BJTlBBSS1DUEMJMzAwMjQ4CTI5MzA4Mgk1LjQ2MTM3MkUtNAkxCXRydWUJUERQUzAwMDAwMDAyODU3MAkxOTk3MDMxCVBDCWltYWdlCS0JMHw4MzIyMDZ8bnVsbHxudWxsfGJqfDgzMjIwNnwxOTk3MDMxfDAJbnVsbAkxCS0JLQktCTAJMTEzLjc3LjE5Mi4yNDNfMTUwNDY1OTE0Ni42MzgyNTAJUENfSU1BR0UJLQluby11c2VyYWdlfHV2Zm0tcnQJLQl1c2VyX3RhZzoyMDc0MzowLjB8dXNlcl9hZ2U6NjAyOjAuMzA2MzV8dXNlcl9nZW5kZXI6NTAxOjAuNjMyMjJ8dl96b25lOjMwNjAwMzowLjB8Y3Jvd2RzOjowLjB8X2Nyb3dkczo6MC4wCTEJMzAwMDAwCTUwMDAwCS0=&userid=113.77.192.243_1504659146.638250&auth=9f52d7e392c540bd&p=THunu8WYO3y7scSxJ6MF2iyvpYP%2BiLz0A3zq%2BA%3D%3D&url=http%3A%2F%2Fsax.sina.com.cn%2Fclick%3Ftype%3D2%26t%3DNGM3YmE3YmItYzU5OC0zYjdjLWJiYjEtYzRiMTI3YTMwNWRhCTE3CVBEUFMwMDAwMDAwMjg1NzAJMTk5NzAzMQkxCVJUQgktCQk%253D%26id%3D17%26url%3Dhttp%253A%252F%252Fwww.hrbhchb.com%252F%253Fgzid%253D32%26sina_sign%3Dd4177e05fe88896a&sign=9cd5af404dcd317e\" target=\"_blank\"><img src=\"http://d2.sina.com.cn/pfpghc2/201706/15/788d3bd65d74426a9bfdf90bc51a5d00.jpg\" style=\"width:300px;height:250px;border:0\" alt=\"//d2.sina.com.cn/pfpghc2/201706/15/788d3bd65d74426a9bfdf90bc51a5d00.jpg\"/></a></ins></ins></p><p><br/></p><p>\r\n		</p><p>\r\n\r\n\r\n	</p><p>\r\n\r\n		</p><p>\r\n		&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;		</p><p><br/></p><p>\r\n\r\n		</p><p><br/></p><p>\r\n\r\n		</p><p>\r\n		&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;		</p><p>\r\n\r\n		</p><p>&nbsp;\r\n &nbsp;	</p><p>\r\n		</p><p>\r\n\r\n		</p><p>\r\n		&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;		</p><p>\r\n\r\n		</p><p><span class=\"adNone\"></span></p><p><br/></p><p>\r\n\r\n		</p><p></p><p>\r\n\r\n		</p><p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;\r\n &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;		</p><p>\r\n\r\n\r\n		</p><p><ins><ins><a style=\"display:block;line-height:0;\" href=\"http://saxn.sina.com.cn/dsp/click?t=MjAxNy0wOS0wNiAwODo1MjozNi44MTgJMTEzLjc3LjE5Mi4yNDMJMTEzLjc3LjE5Mi4yNDNfMTUwNDY1OTE0Ni42MzgyNTAJNDY3MGViMGYtYjU0OC00ZjhiLWJlNjctYjk1NGMzNWZmNzNlCTg1MTM1MQk1ODUxMzc3MzgxX1BJTlBBSS1DUEMJMzA1MjQ0CTE4OTI0Mwk4Ljg1MTY5OTVFLTQJMQl0cnVlCVBEUFMwMDAwMDAwNTgxMDkJMjAyOTI4MQlQQwlpbWFnZQktCTB8NktSYlZRZ1lxc0d0elRKT2hneEFLTXxudWxsfG51bGx8Ymp8ODUxMzUxfDNWdFc0OTRUTVV4UlpLQ0RjUzRkcE98MAludWxsCTEJLQktCS0JMAkxMTMuNzcuMTkyLjI0M18xNTA0NjU5MTQ2LjYzODI1MAlQQ19JTUFHRQktCW5vLXVzZXJhZ2V8dXZmbS1ydAktCXVzZXJfdGFnOjIwMjEwOjAuMHx1c2VyX2FnZTo2MDM6MC4yOTMwNnx1c2VyX2dlbmRlcjo1MDE6MC42MzIyMnx2X3pvbmU6MzA2MDAzOjAuMHxjcm93ZHM6OjAuMHxfY3Jvd2RzOjowLjAJMAkxOTYwMDAJNTAwMDAJLQ==&userid=113.77.192.243_1504659146.638250&auth=8c7c9de73f1b9d57&p=nZF3ntJvO5KnuAFp3yComJvvcsmqtc%2F3K%2B%2BnIg%3D%3D&url=http%3A%2F%2Fsax.sina.com.cn%2Fclick%3Ftype%3D2%26t%3DOWQ5MTc3OWUtZDI2Zi0zYjkyLWE3YjgtMDE2OWRmMjBhODk4CTE3CVBEUFMwMDAwMDAwNTgxMDkJMjAyOTI4MQkxCVJUQgktCQk%253D%26id%3D17%26url%3Dhttp%253A%252F%252Fwww.shunq.cn%252F%253Fgzid%253DM-300250%26sina_sign%3De4350fc8a75980ec&sign=79907ad5ad0c85da\" target=\"_blank\"><img src=\"http://d6.sina.com.cn/pfpghc2/201708/22/d21f420497104e13b04c45fd69b7ec64.jpg\" style=\"width:300px;height:250px;border:0\" alt=\"//d6.sina.com.cn/pfpghc2/201708/22/d21f420497104e13b04c45fd69b7ec64.jpg\"/></a></ins></ins></p><p>\r\n\r\n		</p><p>\r\n\r\n		</p><p><span class=\"text\"><a href=\"http://sea.sina.com.cn\" style=\"color:black;\" target=\"_blank\">新浪扶翼</a></span>\r\n &nbsp; &nbsp; &nbsp; &nbsp;<span class=\"more\"><a href=\"http://sea.sina.com.cn\" target=\"_blank\">行业专区</a></span>\r\n &nbsp; &nbsp;</p><p><ins><ins><a style=\"display:block;line-height:0;\" href=\"http://saxn.sina.com.cn/dsp/click?t=MjAxNy0wOS0wNiAwODo1MjozNi44MjAJMTEzLjc3LjE5Mi4yNDMJMTEzLjc3LjE5Mi4yNDNfMTUwNDY1OTE0Ni42MzgyNTAJYzA0OWE1NDgtMGE4Mi00M2RkLWFiMTAtMGFjYWY2YTM5YWIxCTg1MTQ5Mgk2MzQ4MDQ2NjQxX1BJTlBBSS1DUEMJMzA1Mjc2CTI1ODQyOQkwLjAwMjA2Mzc5MQkxCXRydWUJUERQUzAwMDAwMDA1NzY2MQkyMDI5NTExCVBDCWltYWdlCS0JMHw1Q213aVpvanVtb29rME5lRm9ST0h0fG51bGx8bnVsbHxianw4NTE0OTJ8MlZCN2xHNHpDVUY3UVJSVmZGYURsYXwwCW51bGwJMQktCS0JLQkwCTExMy43Ny4xOTIuMjQzXzE1MDQ2NTkxNDYuNjM4MjUwCVBDX0lNQUdFCS0Jbm8tdXNlcmFnZXx1dmZtLXJ0CS0JdXNlcl90YWc6MjA5NTY6MC4wfHVzZXJfYWdlOjYwMjowLjMwNjM1fHVzZXJfZ2VuZGVyOjUwMTowLjYzMjIyfHZfem9uZTozMDYwMDM6MC4wfGNyb3dkczo6MC4wfF9jcm93ZHM6OjAuMAk0CTMwMDAwMAk1MDAwMAkt&userid=113.77.192.243_1504659146.638250&auth=820f5b100b1b1640&p=jbLsASeEOVCpG%2FpURBtV1zNse5KsaYFBryozCA%3D%3D&url=http%3A%2F%2Fsax.sina.com.cn%2Fclick%3Ftype%3D2%26t%3DOGRiMmVjMDEtMjc4NC0zOTUwLWE5MWItZmE1NDQ0MWI1NWQ3CTE3CVBEUFMwMDAwMDAwNTc2NjEJMjAyOTUxMQkxCVJUQgktCQk%253D%26id%3D17%26url%3Dhttp%253A%252F%252Fa.jiumaotai.com%252F%253Fgzid%253Dc7%26sina_sign%3D6fa4bd7635f379da&sign=57da530433842002\" target=\"_blank\"><img src=\"http://d4.sina.com.cn/pfpghc2/201708/23/c8085af015d14dcdb0ce70e85413f999.jpg\" style=\"width:300px;height:250px;border:0\" alt=\"//d4.sina.com.cn/pfpghc2/201708/23/c8085af015d14dcdb0ce70e85413f999.jpg\"/></a></ins></ins></p><p>\r\n\r\n		</p><p>\r\n\r\n	</p><p><br/></p>', '张三', '网络', '2017-10-07 00:00:00', null, null, null, null, null, '1', 'd5f60b0f8ec311e7b1a4507b9dae4454', '2017-09-06 08:53:58', '2017-09-06 09:04:02');
INSERT INTO `d_content` VALUES ('8', '5', '11', '测试系统1', '<p>12312312345671111111</p><p style=\"line-height: 16px;\"><img style=\"vertical-align: middle; margin-right: 2px;\" src=\"http://localhost:8080/rbib/plug-in/h-ui/lib/ueditor/1.4.3.3/dialogs/attachment/fileTypeImages/icon_jpg.gif\"/><a style=\"font-size:12px; color:#0066cc;\" href=\"/attachment/view\\2017/09-06/fcc9b2d7-94c0-4030-b9e9-ec97d2be1435.jpg\" title=\"Desert.jpg\">Desert.jpg</a></p><p><br/></p>', 'jin1', '后台数据1', '2017-09-16 00:00:00', null, null, null, null, null, '1', 'd5f60b0f8ec311e7b1a4507b9dae4454', '2017-09-06 09:17:23', '2017-09-06 15:13:13');
INSERT INTO `d_content` VALUES ('9', '4', '123213', '2122', '<p><img src=\"/attachment/view\\2017\\09-06\\2e10f77b-afaf-4ebb-ab7a-15accd1298bc.jpg\" style=\"\" title=\"9812955_195532282173_2.jpg\"/></p><p><img src=\"/attachment/view\\2017\\09-06\\b2471e79-faa3-4d08-8d5c-471ebfb16113.jpg\" style=\"\" title=\"u=659165267,1439470182&amp;fm=21&amp;gp=0.jpg\"/></p><p>3434343</p><p style=\"line-height: 16px;\"><img style=\"vertical-align: middle; margin-right: 2px;\" src=\"http://localhost:8080/rbib/plug-in/h-ui/lib/ueditor/1.4.3.3/dialogs/attachment/fileTypeImages/icon_jpg.gif\"/><a style=\"font-size:12px; color:#0066cc;\" href=\"/attachment/view\\2017/09-18/07af667b-7efb-4698-a065-d2f46f49cda5.jpg\" title=\"Desert.jpg\">Desert.jpg</a></p><p><br/></p>', '', '', '2017-09-06 00:00:00', null, null, null, null, null, '0', 'd5f60b0f8ec311e7b1a4507b9dae4454', '2017-09-06 12:26:41', '2017-09-18 12:20:56');
INSERT INTO `d_content` VALUES ('10', '6', '1', '2323', '<p style=\"line-height: 16px;\"><img style=\"vertical-align: middle; margin-right: 2px;\" src=\"http://localhost:8080/rbib/plug-in/h-ui/lib/ueditor/1.4.3.3/dialogs/attachment/fileTypeImages/icon_txt.gif\"/><a style=\"font-size:12px; color:#0066cc;\" href=\"/attachment/view\\null\" title=\"用户信息导入.xls\">用户信息导入.xls</a></p><p>123<br/></p>', '', '', '2017-09-06 00:00:00', null, null, null, null, null, '1', 'd5f60b0f8ec311e7b1a4507b9dae4454', '2017-09-06 15:07:05', '2017-09-06 15:13:35');
INSERT INTO `d_content` VALUES ('11', '7', '123', 'qwe', '<p>f1f1f1f<br/></p>', '123', '123123', '2017-09-06 00:00:00', null, null, null, null, null, '1', 'd5f60b0f8ec311e7b1a4507b9dae4454', '2017-09-06 15:07:43', '2017-09-06 15:07:43');
INSERT INTO `d_content` VALUES ('12', '1', '4', '最新添加', '<p style=\"line-height: 16px;\"><img style=\"vertical-align: middle; margin-right: 2px;\" src=\"http://localhost:8080/rbib/plug-in/h-ui/lib/ueditor/1.4.3.3/dialogs/attachment/fileTypeImages/icon_txt.gif\"/><a style=\"font-size:12px; color:#0066cc;\" href=\"file/downloadFile.do?code=cA4XZRJI%2Bm4%3D\" title=\"新建文本文档.txt\">新建文本文档.txt</a></p><p>cccas<br/></p><p style=\"line-height: 16px;\"><img style=\"vertical-align: middle; margin-right: 2px;\" src=\"http://localhost:8080/rbib/plug-in/h-ui/lib/ueditor/1.4.3.3/dialogs/attachment/fileTypeImages/icon_jpg.gif\"/><a style=\"font-size:12px; color:#0066cc;\" href=\"/attachment/view\\2017/09-18/9db99d9b-6397-4bb1-9459-82d280b9fd68.jpg\" title=\"Tulips.jpg\">Tulips.jpg</a></p><p style=\"line-height: 16px;\"><img style=\"vertical-align: middle; margin-right: 2px;\" src=\"http://localhost:8080/rbib/plug-in/h-ui/lib/ueditor/1.4.3.3/dialogs/attachment/fileTypeImages/icon_txt.gif\"/><a style=\"font-size:12px; color:#0066cc;\" href=\"file/viewFIle.do?code=LvFC%2B9HnzZI%3D\" title=\"新建文本文档.txt\">新建文本文档.txt</a></p><p style=\"line-height: 16px;\"><img style=\"vertical-align: middle; margin-right: 2px;\" src=\"http://localhost:8080/rbib/plug-in/h-ui/lib/ueditor/1.4.3.3/dialogs/attachment/fileTypeImages/icon_txt.gif\"/><a style=\"font-size:12px; color:#0066cc;\" href=\"file/viewFIle.do?code=IOqdKqXjWdg%3D\" title=\"zheng-环境搭建及系统部署文档20170213（修改版）.docx\">zheng-环境搭建及系统部署文档20170213（修改版）.docx</a></p><p style=\"line-height: 16px;\"><img style=\"vertical-align: middle; margin-right: 2px;\" src=\"http://localhost:8080/rbib/plug-in/h-ui/lib/ueditor/1.4.3.3/dialogs/attachment/fileTypeImages/icon_txt.gif\"/><a style=\"font-size:12px; color:#0066cc;\" href=\"javascript:open_window(\'file/viewFIle.do?code=aA%2Fb6mS9bpU%3D\')\" title=\"user-template.xls\">user-template.xls</a></p><p><br/></p>', '', '', '2017-09-15 00:00:00', null, null, null, null, null, '1', 'd5f60b0f8ec311e7b1a4507b9dae4454', '2017-09-15 15:32:20', '2017-09-18 15:47:26');

-- ----------------------------
-- Table structure for d_friend_link
-- ----------------------------
DROP TABLE IF EXISTS `d_friend_link`;
CREATE TABLE `d_friend_link` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `index_no` int(11) DEFAULT NULL COMMENT '序号',
  `company_id` varbinary(32) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL COMMENT '标题',
  `link_url` varchar(255) DEFAULT NULL COMMENT '链接地址',
  `status` smallint(6) DEFAULT NULL COMMENT '状态',
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of d_friend_link
-- ----------------------------
INSERT INTO `d_friend_link` VALUES ('3', '3', null, '东莞市路桥投资建设有限公司', 'http://localhost:8080/rbib/index.do', '1', '2017-08-25 10:15:07', '2017-08-25 10:32:58');
INSERT INTO `d_friend_link` VALUES ('4', '1', null, '百度', 'http://baidu.com', '1', '2017-08-25 10:23:14', '2017-08-25 15:13:28');
INSERT INTO `d_friend_link` VALUES ('5', '4', null, '台风路径实时发布系统', 'http://typhoon.zjwater.gov.cn/default.aspx', '1', '2017-08-25 10:42:47', '2017-08-28 17:50:29');
INSERT INTO `d_friend_link` VALUES ('6', '5', null, '广东省交通运输厅公众网', 'http://www.gdcd.gov.cn/', '1', '2017-08-25 15:05:04', '2017-08-25 15:05:04');
INSERT INTO `d_friend_link` VALUES ('7', '6', null, '东莞市交通投资集团有限公司', 'http://dgluqiao.dg.gov.cn/', '1', '2017-08-25 15:05:31', '2017-08-25 15:05:31');
INSERT INTO `d_friend_link` VALUES ('8', '7', null, '东莞市交通运输局', 'http://jtj.dg.gov.cn/', '1', null, '2017-08-28 08:54:14');
INSERT INTO `d_friend_link` VALUES ('9', '2', null, 'QQ导航', 'https://hao.qq.com/', null, '2017-08-28 09:24:41', '2017-09-08 09:35:18');

-- ----------------------------
-- Table structure for d_schedule
-- ----------------------------
DROP TABLE IF EXISTS `d_schedule`;
CREATE TABLE `d_schedule` (
  `id` varchar(32) NOT NULL,
  `sort` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '序号',
  `title` varchar(200) DEFAULT NULL COMMENT '概要',
  `content` varchar(500) DEFAULT NULL COMMENT '内容',
  `address` varchar(100) DEFAULT NULL COMMENT '地址',
  `start_time` datetime DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `status` smallint(6) DEFAULT NULL,
  `user_id` varchar(32) DEFAULT NULL,
  `company_id` varchar(32) DEFAULT NULL COMMENT '所属公司',
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_schedule_sort` (`sort`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of d_schedule
-- ----------------------------
INSERT INTO `d_schedule` VALUES ('1319737e8dfe11e78342507b9dae4454', '9', '修改', '修改1', '修改2', '2017-08-28 11:40:00', '2017-08-29 14:40:00', null, 'e20afce4b12511e68bc4507b9dae4454', null, '2017-08-31 11:40:23', '2017-08-31 11:43:34');
INSERT INTO `d_schedule` VALUES ('18c4c6aa920111e79ff4507b9dae4454', '11', '999', '', '999', '2017-09-05 14:11:00', '2017-09-05 18:11:00', null, 'e20afce4b12511e68bc4507b9dae4454', 'd5f60b0f8ec311e7b1a4507b9dae4454', '2017-09-05 14:11:47', '2017-09-05 14:11:47');
INSERT INTO `d_schedule` VALUES ('1b3d350a92a211e780f9507b9dae4454', '13', '主要工作', '工作的内容是什么', '', '2017-09-06 09:23:00', '2017-09-09 09:23:00', null, 'e20afce4b12511e68bc4507b9dae4454', 'd5f60b0f8ec311e7b1a4507b9dae4454', '2017-09-06 09:23:51', '2017-09-06 09:23:51');
INSERT INTO `d_schedule` VALUES ('598b25a8897011e7942f507b9dae4454', '6', 'asdadavas', 'asvasdasdc', 'asdasvavasv', '2017-08-16 00:00:00', '2017-08-22 00:00:00', null, 'e20afce4b12511e68bc4507b9dae4454', null, '2017-08-25 16:35:44', '2017-08-25 16:35:44');
INSERT INTO `d_schedule` VALUES ('5d75021b894311e7942f507b9dae4454', '1', '1111111111', '122222222222222', '333333333333333', '2017-08-14 00:00:00', '2017-08-25 00:00:00', null, 'e20afce4b12511e68bc4507b9dae4454', null, '2017-08-25 11:13:42', '2017-08-25 11:13:42');
INSERT INTO `d_schedule` VALUES ('84d60d5f894511e7942f507b9dae4454', '2', '1111111111', '122222222222222', '333333333333333', '2017-08-14 00:00:00', '2017-08-25 00:00:00', null, 'e20afce4b12511e68bc4507b9dae4454', null, '2017-08-25 11:29:08', '2017-08-25 11:29:08');
INSERT INTO `d_schedule` VALUES ('8a7ac8048ef911e7b1a4507b9dae4454', '10', '22', '22', '22', '2017-09-01 17:39:00', '2017-09-23 17:39:00', null, 'e20afce4b12511e68bc4507b9dae4454', 'd5f60b0f8ec311e7b1a4507b9dae4454', '2017-09-01 17:39:48', '2017-09-01 17:39:48');
INSERT INTO `d_schedule` VALUES ('b2a303b0921f11e79ff4507b9dae4454', '12', '123', '', '', '2017-09-05 17:51:00', '2017-09-06 17:51:00', null, 'ded050e18efb11e7b1a4507b9dae4454', 'a90fa9578ec411e7b1a4507b9dae4454', '2017-09-05 17:51:11', '2017-09-05 17:51:11');
INSERT INTO `d_schedule` VALUES ('c16cba84894511e7942f507b9dae4454', '3', 'aaaaaa', 'bbbbbbbbbb', 'cccccc', '2017-08-22 00:00:00', '2017-08-26 00:00:00', null, 'e20afce4b12511e68bc4507b9dae4454', null, '2017-08-25 11:30:49', '2017-08-25 11:30:49');

-- ----------------------------
-- Table structure for d_topic
-- ----------------------------
DROP TABLE IF EXISTS `d_topic`;
CREATE TABLE `d_topic` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `index_no` int(11) DEFAULT NULL COMMENT '序号',
  `title` varchar(100) DEFAULT NULL COMMENT '标题',
  `status` smallint(6) DEFAULT NULL COMMENT '状态',
  `company_id` varchar(32) DEFAULT NULL COMMENT '所属公司',
  `allow_user_id` varchar(3000) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of d_topic
-- ----------------------------
INSERT INTO `d_topic` VALUES ('1', '1', '通知公告', '1', 'd5f60b0f8ec311e7b1a4507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454,', '2017-07-12 15:36:33', '2017-09-06 08:49:15');
INSERT INTO `d_topic` VALUES ('2', '2', '工作信息', '1', 'd5f60b0f8ec311e7b1a4507b9dae4454', null, '2017-07-12 15:37:10', '2017-08-30 14:44:56');
INSERT INTO `d_topic` VALUES ('3', '3', '企业文化', '0', 'd5f60b0f8ec311e7b1a4507b9dae4454', null, '2017-08-28 10:32:00', '2017-09-06 15:13:50');
INSERT INTO `d_topic` VALUES ('4', '4', '在线互动', '0', 'd5f60b0f8ec311e7b1a4507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454,', '2017-09-06 08:49:28', '2017-09-06 15:13:58');
INSERT INTO `d_topic` VALUES ('5', '5', '公务办处', '1', 'd5f60b0f8ec311e7b1a4507b9dae4454', null, '2017-09-06 09:02:41', '2017-09-06 15:14:03');
INSERT INTO `d_topic` VALUES ('7', '6', '投诉建议', '0', 'd5f60b0f8ec311e7b1a4507b9dae4454', '', '2017-09-06 15:07:14', '2017-09-06 15:07:14');
INSERT INTO `d_topic` VALUES ('8', '1', '1', '1', 'a90fa9578ec411e7b1a4507b9dae4454', null, '2017-11-17 11:31:48', '2017-11-17 11:31:48');
INSERT INTO `d_topic` VALUES ('9', '2', '2', '1', 'a90fa9578ec411e7b1a4507b9dae4454', null, '2017-11-17 11:31:52', '2017-11-17 11:31:52');

-- ----------------------------
-- Table structure for flow_exec_attachment
-- ----------------------------
DROP TABLE IF EXISTS `flow_exec_attachment`;
CREATE TABLE `flow_exec_attachment` (
  `id` varchar(32) NOT NULL,
  `sort` bigint(20) NOT NULL AUTO_INCREMENT,
  `proc_inst_id` varchar(32) DEFAULT NULL,
  `proc_node_id` varchar(32) DEFAULT NULL,
  `user_id` varchar(32) DEFAULT NULL,
  `file_name` varchar(300) DEFAULT NULL,
  `type` smallint(6) DEFAULT NULL,
  `file_type` varchar(20) DEFAULT NULL,
  `base_file_id` bigint(20) DEFAULT NULL,
  `file_view` varchar(300) DEFAULT NULL,
  `back_file_view` varchar(300) DEFAULT NULL,
  `status` smallint(6) DEFAULT NULL COMMENT '状态',
  `create_by` varchar(50) DEFAULT NULL,
  `update_by` varchar(50) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_exec_attachment_sort` (`sort`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of flow_exec_attachment
-- ----------------------------
INSERT INTO `flow_exec_attachment` VALUES ('119e6727c05f11e7ab51507b9dae4454', '5', 'ca306762c04811e7ab51507b9dae4454', 'ca35e28ac04811e7ab51507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '88Q58PICasD_1024.jpg', null, 'jpg', '90', '/attachment/view/null', '/attachment/view/null', '1', 'admin', null, '2017-11-03 14:20:21', '2017-11-03 14:20:21');
INSERT INTO `flow_exec_attachment` VALUES ('1f9683b6bd5811e7be45507b9dae4454', '4', 'dbf289abbd5611e7be45507b9dae4454', 'dbf958edbd5611e7be45507b9dae4454', '89efa57992d911e780f9507b9dae4454', '21-niutuku.com-2055.jpg', null, 'jpg', '60', '/attachment/view/null', '/attachment/view/null', '1', 'system', null, '2017-10-30 17:53:05', '2017-10-30 17:53:05');
INSERT INTO `flow_exec_attachment` VALUES ('a5d0c657bd1411e7be45507b9dae4454', '1', '9127385ebd1111e7be45507b9dae4454', '912e6782bd1111e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1297256_1.jpg', null, 'jpg', '50', '/attachment/view/null', '/attachment/view/null', '1', 'admin', null, '2017-10-30 09:50:04', '2017-10-30 09:50:04');
INSERT INTO `flow_exec_attachment` VALUES ('a5d0ecf7bd1411e7be45507b9dae4454', '2', '9127385ebd1111e7be45507b9dae4454', '912e6782bd1111e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '88Q58PICasD_1024.jpg', null, 'jpg', '49', '/attachment/view/null', '/attachment/view/null', '1', 'admin', null, '2017-10-30 09:50:04', '2017-10-30 09:50:04');

-- ----------------------------
-- Table structure for flow_exec_comment
-- ----------------------------
DROP TABLE IF EXISTS `flow_exec_comment`;
CREATE TABLE `flow_exec_comment` (
  `id` varchar(32) NOT NULL,
  `sort` bigint(20) NOT NULL AUTO_INCREMENT,
  `proc_inst_id` varchar(32) DEFAULT NULL,
  `proc_node_id` varchar(32) DEFAULT NULL,
  `user_id` varchar(32) DEFAULT NULL,
  `type` smallint(6) DEFAULT NULL,
  `content` varchar(500) DEFAULT NULL,
  `note` varchar(300) DEFAULT NULL,
  `status` smallint(6) DEFAULT NULL COMMENT '状态',
  `create_by` varchar(50) DEFAULT NULL,
  `update_by` varchar(50) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_exec_comment_sort` (`sort`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of flow_exec_comment
-- ----------------------------
INSERT INTO `flow_exec_comment` VALUES ('001bf2c7bd5a11e7be45507b9dae4454', '80', '73d2e991bd5911e7be45507b9dae4454', '73daa08abd5911e7be45507b9dae4454', '89efa57992d911e780f9507b9dae4454', '1', 'ok', null, '1', 'system', null, '2017-10-30 18:06:31', '2017-10-30 18:06:31');
INSERT INTO `flow_exec_comment` VALUES ('0128b0a9bfb311e79515507b9dae4454', '102', 'bc562c92bfb011e79515507b9dae4454', 'bc64283abfb011e79515507b9dae4454', '89efa57992d911e780f9507b9dae4454', '1', 'ok', null, '1', 'system', null, '2017-11-02 17:48:40', '2017-11-02 17:48:40');
INSERT INTO `flow_exec_comment` VALUES ('0610be18bee811e7b827507b9dae4454', '94', '9e8c273ebee611e7b827507b9dae4454', '9e911902bee611e7b827507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '部门同意', null, '1', 'admin', null, '2017-11-01 17:35:46', '2017-11-01 17:35:46');
INSERT INTO `flow_exec_comment` VALUES ('0c7f4189beb911e7b827507b9dae4454', '89', '9f33816abeb611e7b827507b9dae4454', '9f374594beb611e7b827507b9dae4454', '89efa57992d911e780f9507b9dae4454', '1', '11', null, '1', 'system', null, '2017-11-01 11:59:25', '2017-11-01 11:59:25');
INSERT INTO `flow_exec_comment` VALUES ('0d1bd320bee811e7b827507b9dae4454', '95', '9e8c273ebee611e7b827507b9dae4454', '9e9fcfbbbee611e7b827507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '分管领导同意', null, '1', 'admin', null, '2017-11-01 17:35:58', '2017-11-01 17:35:58');
INSERT INTO `flow_exec_comment` VALUES ('0e146482bd1f11e7be45507b9dae4454', '45', 'e4fad48ebd1e11e7be45507b9dae4454', 'e5026f9cbd1e11e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '222222', null, '1', 'admin', null, '2017-10-30 11:04:34', '2017-10-30 11:04:34');
INSERT INTO `flow_exec_comment` VALUES ('10b61ae1bd1f11e7be45507b9dae4454', '46', 'e4fad48ebd1e11e7be45507b9dae4454', 'e509ce13bd1e11e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '1121212', null, '1', 'admin', null, '2017-10-30 11:04:38', '2017-10-30 11:04:38');
INSERT INTO `flow_exec_comment` VALUES ('13da66cfbd5a11e7be45507b9dae4454', '81', '3d381d7cbd5911e7be45507b9dae4454', '3d3d0819bd5911e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '通过', null, '1', 'admin', null, '2017-10-30 18:07:09', '2017-10-30 18:07:09');
INSERT INTO `flow_exec_comment` VALUES ('14bc9e44bd1f11e7be45507b9dae4454', '47', 'e4fad48ebd1e11e7be45507b9dae4454', 'e50b4d5abd1e11e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '1212', null, '1', 'admin', null, '2017-10-30 11:04:45', '2017-10-30 11:04:45');
INSERT INTO `flow_exec_comment` VALUES ('17b57970bd1511e7be45507b9dae4454', '41', '9127385ebd1111e7be45507b9dae4454', '912fcf16bd1111e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '领导批示', null, '1', 'admin', null, '2017-10-30 09:53:15', '2017-10-30 09:53:15');
INSERT INTO `flow_exec_comment` VALUES ('17bd082dc05f11e7ab51507b9dae4454', '103', 'ca306762c04811e7ab51507b9dae4454', 'ca35e28ac04811e7ab51507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '55555555', null, '1', 'admin', null, '2017-11-03 14:20:32', '2017-11-03 14:20:32');
INSERT INTO `flow_exec_comment` VALUES ('198a4d25bd5811e7be45507b9dae4454', '70', 'dbf289abbd5611e7be45507b9dae4454', 'dbf8089cbd5611e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '营运部意见', null, '1', 'admin', null, '2017-10-30 17:52:55', '2017-10-30 17:52:55');
INSERT INTO `flow_exec_comment` VALUES ('1a9e55e7bf6d11e79515507b9dae4454', '99', '93dce679bf6c11e79515507b9dae4454', '93e216e1bf6c11e79515507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '分管领导第二次同意', null, '1', 'admin', null, '2017-11-02 09:28:22', '2017-11-02 09:28:22');
INSERT INTO `flow_exec_comment` VALUES ('1e82bf4fbeb911e7b827507b9dae4454', '90', '9f33816abeb611e7b827507b9dae4454', '9f381125beb611e7b827507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '不喝啊', null, '1', 'admin', null, '2017-11-01 11:59:55', '2017-11-01 11:59:55');
INSERT INTO `flow_exec_comment` VALUES ('2153d711bd5911e7be45507b9dae4454', '73', 'dbf289abbd5611e7be45507b9dae4454', 'dc0fe0babd5611e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '领导批示', null, '1', 'admin', null, '2017-10-30 18:00:17', '2017-10-30 18:00:17');
INSERT INTO `flow_exec_comment` VALUES ('276c324fbeb911e7b827507b9dae4454', '91', '9f33816abeb611e7b827507b9dae4454', '9f374594beb611e7b827507b9dae4454', '89efa57992d911e780f9507b9dae4454', '1', 'o1', null, '1', 'system', null, '2017-11-01 12:00:10', '2017-11-01 12:00:10');
INSERT INTO `flow_exec_comment` VALUES ('32a84fedbd5211e7be45507b9dae4454', '57', 'd306ef3fbd4a11e7be45507b9dae4454', 'd30a2aebbd4a11e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '同意', null, '1', 'admin', null, '2017-10-30 17:10:45', '2017-10-30 17:10:45');
INSERT INTO `flow_exec_comment` VALUES ('3b88e6f9bd5211e7be45507b9dae4454', '58', 'd306ef3fbd4a11e7be45507b9dae4454', 'd30b5063bd4a11e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '同意', null, '1', 'admin', null, '2017-10-30 17:11:00', '2017-10-30 17:11:00');
INSERT INTO `flow_exec_comment` VALUES ('4468f00abd5911e7be45507b9dae4454', '74', '3d381d7cbd5911e7be45507b9dae4454', '3d3bb0cdbd5911e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '同意', null, '1', 'admin', null, '2017-10-30 18:01:21', '2017-10-30 18:01:21');
INSERT INTO `flow_exec_comment` VALUES ('4a276c59bd5811e7be45507b9dae4454', '71', 'dbf289abbd5611e7be45507b9dae4454', 'dbf958edbd5611e7be45507b9dae4454', '89efa57992d911e780f9507b9dae4454', '1', '相关部门意见', null, '1', 'system', null, '2017-10-30 17:54:16', '2017-10-30 17:54:16');
INSERT INTO `flow_exec_comment` VALUES ('4c614746bd5911e7be45507b9dae4454', '75', 'dbf289abbd5611e7be45507b9dae4454', 'dc0fe0babd5611e7be45507b9dae4454', '89efa57992d911e780f9507b9dae4454', '1', 'ok', null, '1', 'system', null, '2017-10-30 18:01:30', '2017-10-30 18:01:30');
INSERT INTO `flow_exec_comment` VALUES ('642263a0bd5511e7be45507b9dae4454', '59', 'd86257a9bd5411e7be45507b9dae4454', 'd86632aabd5411e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '同意', null, '1', 'admin', null, '2017-10-30 17:33:37', '2017-10-30 17:33:37');
INSERT INTO `flow_exec_comment` VALUES ('671d86cfbd5511e7be45507b9dae4454', '60', 'd86257a9bd5411e7be45507b9dae4454', 'd8677290bd5411e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '同意', null, '1', 'admin', null, '2017-10-30 17:33:42', '2017-10-30 17:33:42');
INSERT INTO `flow_exec_comment` VALUES ('78d800b2bf9511e79515507b9dae4454', '100', '6e379661bf9511e79515507b9dae4454', '6e3d3396bf9511e79515507b9dae4454', '89efa57992d911e780f9507b9dae4454', '1', '领导意见', null, '1', 'system', null, '2017-11-02 14:17:16', '2017-11-02 14:17:16');
INSERT INTO `flow_exec_comment` VALUES ('9bb999fbbd1411e7be45507b9dae4454', '39', '9127385ebd1111e7be45507b9dae4454', '912d1f39bd1111e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', 'ok', null, '1', 'admin', null, '2017-10-30 09:49:47', '2017-10-30 09:49:47');
INSERT INTO `flow_exec_comment` VALUES ('a28cc1d6bebd11e7b827507b9dae4454', '93', '9f33816abeb611e7b827507b9dae4454', '9f374594beb611e7b827507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '12', null, '1', 'admin', null, '2017-11-01 12:32:15', '2017-11-01 12:32:15');
INSERT INTO `flow_exec_comment` VALUES ('a8d7385cbd1411e7be45507b9dae4454', '40', '9127385ebd1111e7be45507b9dae4454', '912e6782bd1111e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '相关部门意见', null, '1', 'admin', null, '2017-10-30 09:50:09', '2017-10-30 09:50:09');
INSERT INTO `flow_exec_comment` VALUES ('b47838debeb611e7b827507b9dae4454', '87', '9f33816abeb611e7b827507b9dae4454', '9f374594beb611e7b827507b9dae4454', '89efa57992d911e780f9507b9dae4454', '1', '3333', null, '1', 'system', null, '2017-11-01 11:42:38', '2017-11-01 11:42:38');
INSERT INTO `flow_exec_comment` VALUES ('b638ac3dbd5811e7be45507b9dae4454', '72', 'dbf289abbd5611e7be45507b9dae4454', 'dbf958edbd5611e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', 'ppp', null, '1', 'admin', null, '2017-10-30 17:57:18', '2017-10-30 17:57:18');
INSERT INTO `flow_exec_comment` VALUES ('ba2d1de1bd5511e7be45507b9dae4454', '61', 'af6b3bcdbd5511e7be45507b9dae4454', 'af6f4603bd5511e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '同意', null, '1', 'admin', null, '2017-10-30 17:36:01', '2017-10-30 17:36:01');
INSERT INTO `flow_exec_comment` VALUES ('bbe7503ebeb611e7b827507b9dae4454', '88', '9f33816abeb611e7b827507b9dae4454', '9f381125beb611e7b827507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '不', null, '1', 'admin', null, '2017-11-01 11:42:51', '2017-11-01 11:42:51');
INSERT INTO `flow_exec_comment` VALUES ('c099a4bcbd5511e7be45507b9dae4454', '62', 'af6b3bcdbd5511e7be45507b9dae4454', 'af703740bd5511e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '不同意', null, '1', 'admin', null, '2017-10-30 17:36:12', '2017-10-30 17:36:12');
INSERT INTO `flow_exec_comment` VALUES ('c5f18ea3bd5911e7be45507b9dae4454', '76', '73d2e991bd5911e7be45507b9dae4454', '73d4aad9bd5911e7be45507b9dae4454', '89efa57992d911e780f9507b9dae4454', '1', 'ok', null, '1', 'system', null, '2017-10-30 18:04:54', '2017-10-30 18:04:54');
INSERT INTO `flow_exec_comment` VALUES ('cc36610cbd5711e7be45507b9dae4454', '69', 'dbf289abbd5611e7be45507b9dae4454', 'dbf65341bd5611e7be45507b9dae4454', '89efa57992d911e780f9507b9dae4454', '1', '没问题', null, '1', 'system', null, '2017-10-30 17:50:45', '2017-10-30 17:50:45');
INSERT INTO `flow_exec_comment` VALUES ('ccde0ed5bd4c11e7be45507b9dae4454', '56', '024b911dbd3c11e7be45507b9dae4454', '02530986bd3c11e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', 'zxc', null, '1', 'admin', null, '2017-10-30 16:32:07', '2017-10-30 16:32:07');
INSERT INTO `flow_exec_comment` VALUES ('ccfe9c58bd1111e7be45507b9dae4454', '35', '9127385ebd1111e7be45507b9dae4454', '912a45fdbd1111e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', 'ok', null, '1', 'admin', null, '2017-10-30 09:29:41', '2017-10-30 09:29:41');
INSERT INTO `flow_exec_comment` VALUES ('cfb86698bd5511e7be45507b9dae4454', '64', 'af6b3bcdbd5511e7be45507b9dae4454', 'af6f4603bd5511e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '同意', null, '1', 'admin', null, '2017-10-30 17:36:37', '2017-10-30 17:36:37');
INSERT INTO `flow_exec_comment` VALUES ('d1516d58bd5911e7be45507b9dae4454', '77', '73d2e991bd5911e7be45507b9dae4454', '73d67a9cbd5911e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '稽查意见', null, '1', 'admin', null, '2017-10-30 18:05:13', '2017-10-30 18:05:13');
INSERT INTO `flow_exec_comment` VALUES ('d28f4089bd5511e7be45507b9dae4454', '65', 'af6b3bcdbd5511e7be45507b9dae4454', 'af703740bd5511e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '同意', null, '1', 'admin', null, '2017-10-30 17:36:42', '2017-10-30 17:36:42');
INSERT INTO `flow_exec_comment` VALUES ('d476a886bd1111e7be45507b9dae4454', '36', '9127385ebd1111e7be45507b9dae4454', '912b86f8bd1111e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '稽查意见', null, '1', 'admin', null, '2017-10-30 09:29:54', '2017-10-30 09:29:54');
INSERT INTO `flow_exec_comment` VALUES ('da197371bd5911e7be45507b9dae4454', '78', '73d2e991bd5911e7be45507b9dae4454', '73d7f645bd5911e7be45507b9dae4454', '89efa57992d911e780f9507b9dae4454', '1', '营运部意见', null, '1', 'system', null, '2017-10-30 18:05:27', '2017-10-30 18:05:27');
INSERT INTO `flow_exec_comment` VALUES ('dc8127e9bd1111e7be45507b9dae4454', '37', '9127385ebd1111e7be45507b9dae4454', '912d1f39bd1111e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '营运部意见', null, '1', 'admin', null, '2017-10-30 09:30:07', '2017-10-30 09:30:07');
INSERT INTO `flow_exec_comment` VALUES ('deeda1b5bfb011e79515507b9dae4454', '101', 'bc562c92bfb011e79515507b9dae4454', 'bc64283abfb011e79515507b9dae4454', '89efa57992d911e780f9507b9dae4454', '1', '不行', null, '1', 'system', null, '2017-11-02 17:33:24', '2017-11-02 17:33:24');
INSERT INTO `flow_exec_comment` VALUES ('e1f3db44bd1111e7be45507b9dae4454', '38', '9127385ebd1111e7be45507b9dae4454', '912e6782bd1111e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '有点问题', null, '1', 'admin', null, '2017-10-30 09:30:16', '2017-10-30 09:30:16');
INSERT INTO `flow_exec_comment` VALUES ('e6ea566bbd5611e7be45507b9dae4454', '68', 'dbf289abbd5611e7be45507b9dae4454', 'dbf4c5b0bd5611e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '同意', null, '1', 'admin', null, '2017-10-30 17:44:20', '2017-10-30 17:44:20');
INSERT INTO `flow_exec_comment` VALUES ('e9d4ed32bf6c11e79515507b9dae4454', '96', '93dce679bf6c11e79515507b9dae4454', '93e0a61cbf6c11e79515507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '部门同意', null, '1', 'admin', null, '2017-11-02 09:27:00', '2017-11-02 09:27:00');
INSERT INTO `flow_exec_comment` VALUES ('ee87971abd2511e7be45507b9dae4454', '51', 'e3c2200cbd2511e7be45507b9dae4454', 'e3c43172bd2511e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '1', null, '1', 'admin', null, '2017-10-30 11:53:47', '2017-10-30 11:53:47');
INSERT INTO `flow_exec_comment` VALUES ('f0b0496bbd2511e7be45507b9dae4454', '52', 'e3c2200cbd2511e7be45507b9dae4454', 'e3c55ff6bd2511e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '2', null, '1', 'admin', null, '2017-10-30 11:53:51', '2017-10-30 11:53:51');
INSERT INTO `flow_exec_comment` VALUES ('f123f893bf6c11e79515507b9dae4454', '97', '93dce679bf6c11e79515507b9dae4454', '93e216e1bf6c11e79515507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '分管领导第一次不同意', null, '1', 'admin', null, '2017-11-02 09:27:13', '2017-11-02 09:27:13');
INSERT INTO `flow_exec_comment` VALUES ('f359dda4bd2511e7be45507b9dae4454', '53', 'e3c2200cbd2511e7be45507b9dae4454', 'e3c7e095bd2511e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '3', null, '1', 'admin', null, '2017-10-30 11:53:55', '2017-10-30 11:53:55');
INSERT INTO `flow_exec_comment` VALUES ('f595cb4ebd2511e7be45507b9dae4454', '54', 'e3c2200cbd2511e7be45507b9dae4454', 'e3c8e73dbd2511e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '4', null, '1', 'admin', null, '2017-10-30 11:53:59', '2017-10-30 11:53:59');
INSERT INTO `flow_exec_comment` VALUES ('f6e8eebbbf6c11e79515507b9dae4454', '98', '93dce679bf6c11e79515507b9dae4454', '93e0a61cbf6c11e79515507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '部门第二次同意', null, '1', 'admin', null, '2017-11-02 09:27:22', '2017-11-02 09:27:22');
INSERT INTO `flow_exec_comment` VALUES ('f871bd02bd2511e7be45507b9dae4454', '55', 'e3c2200cbd2511e7be45507b9dae4454', 'e3ca9620bd2511e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '5', null, '1', 'admin', null, '2017-10-30 11:54:04', '2017-10-30 11:54:04');
INSERT INTO `flow_exec_comment` VALUES ('fa31170fbd5911e7be45507b9dae4454', '79', '73d2e991bd5911e7be45507b9dae4454', '73d94963bd5911e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '相关部门意见', null, '1', 'admin', null, '2017-10-30 18:06:21', '2017-10-30 18:06:21');
INSERT INTO `flow_exec_comment` VALUES ('fbc6c72bbd2411e7be45507b9dae4454', '50', 'e4fad48ebd1e11e7be45507b9dae4454', 'e50dbaddbd1e11e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '哦哦哦·1', null, '1', 'admin', null, '2017-10-30 11:47:00', '2017-10-30 11:47:00');
INSERT INTO `flow_exec_comment` VALUES ('fc427280beba11e7b827507b9dae4454', '92', '9f33816abeb611e7b827507b9dae4454', '9f374594beb611e7b827507b9dae4454', '89efa57992d911e780f9507b9dae4454', '1', '999', null, '1', 'system', null, '2017-11-01 12:13:17', '2017-11-01 12:13:17');
INSERT INTO `flow_exec_comment` VALUES ('ff09b3c8bd1e11e7be45507b9dae4454', '44', 'e4fad48ebd1e11e7be45507b9dae4454', 'e5018dedbd1e11e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '111', null, '1', 'admin', null, '2017-10-30 11:04:09', '2017-10-30 11:04:09');

-- ----------------------------
-- Table structure for flow_exec_identitylink
-- ----------------------------
DROP TABLE IF EXISTS `flow_exec_identitylink`;
CREATE TABLE `flow_exec_identitylink` (
  `id` varchar(32) NOT NULL,
  `sort` bigint(20) NOT NULL AUTO_INCREMENT,
  `proc_def_id` varchar(32) DEFAULT NULL,
  `proc_inst_id` varchar(32) DEFAULT NULL,
  `node_id` varchar(32) DEFAULT NULL,
  `user_id` varchar(32) DEFAULT NULL,
  `depart_id` varchar(32) DEFAULT NULL,
  `type` smallint(6) DEFAULT NULL,
  `status` smallint(6) DEFAULT NULL COMMENT '状态',
  `create_by` varchar(50) DEFAULT NULL,
  `update_by` varchar(50) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_exec_idlink_sort` (`sort`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=137 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of flow_exec_identitylink
-- ----------------------------
INSERT INTO `flow_exec_identitylink` VALUES ('02663460bd3c11e7be45507b9dae4454', '78', '59dd99f3bd2911e7be45507b9dae4454', '024b911dbd3c11e7be45507b9dae4454', '02530986bd3c11e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '1', 'admin', 'admin', '2017-10-30 14:31:55', '2017-10-30 16:32:07');
INSERT INTO `flow_exec_identitylink` VALUES ('061779d0bee811e7b827507b9dae4454', '123', '8a3be65eb89911e783e5507b9dae4454', '9e8c273ebee611e7b827507b9dae4454', '9e9fcfbbbee611e7b827507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '1', 'admin', 'admin', '2017-11-01 17:35:46', '2017-11-01 17:35:58');
INSERT INTO `flow_exec_identitylink` VALUES ('0e1bf1cabd1f11e7be45507b9dae4454', '69', '9e40c480b54011e7a96c507b9dae4454', 'e4fad48ebd1e11e7be45507b9dae4454', 'e509ce13bd1e11e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '1', 'admin', 'admin', '2017-10-30 11:04:34', '2017-10-30 11:04:38');
INSERT INTO `flow_exec_identitylink` VALUES ('10ba642bbd1f11e7be45507b9dae4454', '70', '9e40c480b54011e7a96c507b9dae4454', 'e4fad48ebd1e11e7be45507b9dae4454', 'e50b4d5abd1e11e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '1', 'admin', 'admin', '2017-10-30 11:04:38', '2017-10-30 11:04:45');
INSERT INTO `flow_exec_identitylink` VALUES ('14c1f10ebd1f11e7be45507b9dae4454', '71', '9e40c480b54011e7a96c507b9dae4454', 'e4fad48ebd1e11e7be45507b9dae4454', 'e50dbaddbd1e11e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '1', 'admin', 'admin', '2017-10-30 11:04:45', '2017-10-30 11:47:00');
INSERT INTO `flow_exec_identitylink` VALUES ('17b9db37bd1511e7be45507b9dae4454', '65', '9e40c480b54011e7a96c507b9dae4454', '9127385ebd1111e7be45507b9dae4454', '913106aebd1111e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '0', 'admin', null, '2017-10-30 09:53:15', '2017-10-30 09:53:15');
INSERT INTO `flow_exec_identitylink` VALUES ('17c3fa97c05f11e7ab51507b9dae4454', '136', '8a3be65eb89911e783e5507b9dae4454', 'ca306762c04811e7ab51507b9dae4454', 'ca374d59c04811e7ab51507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '0', 'admin', null, '2017-11-03 14:20:32', '2017-11-03 14:20:32');
INSERT INTO `flow_exec_identitylink` VALUES ('1990e9f4bd5811e7be45507b9dae4454', '97', '9e40c480b54011e7a96c507b9dae4454', 'dbf289abbd5611e7be45507b9dae4454', 'dbf958edbd5611e7be45507b9dae4454', '89efa57992d911e780f9507b9dae4454', null, null, '1', 'admin', 'system', '2017-10-30 17:52:55', '2017-10-30 17:54:16');
INSERT INTO `flow_exec_identitylink` VALUES ('19935a37bd5811e7be45507b9dae4454', '98', '9e40c480b54011e7a96c507b9dae4454', 'dbf289abbd5611e7be45507b9dae4454', 'dbf958edbd5611e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '1', 'admin', 'admin', '2017-10-30 17:52:55', '2017-10-30 17:57:18');
INSERT INTO `flow_exec_identitylink` VALUES ('32af1f59bd5211e7be45507b9dae4454', '84', '8a3be65eb89911e783e5507b9dae4454', 'd306ef3fbd4a11e7be45507b9dae4454', 'd30b5063bd4a11e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '1', 'admin', 'admin', '2017-10-30 17:10:45', '2017-10-30 17:11:00');
INSERT INTO `flow_exec_identitylink` VALUES ('3d44185cbd5911e7be45507b9dae4454', '101', '8a3be65eb89911e783e5507b9dae4454', '3d381d7cbd5911e7be45507b9dae4454', '3d3bb0cdbd5911e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '1', 'admin', 'admin', '2017-10-30 18:01:09', '2017-10-30 18:01:21');
INSERT INTO `flow_exec_identitylink` VALUES ('40465290bd4811e7be45507b9dae4454', '79', '8a3be65eb89911e783e5507b9dae4454', '4027e8a1bd4811e7be45507b9dae4454', '402df2fbbd4811e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '0', 'admin', null, '2017-10-30 15:59:33', '2017-10-30 15:59:33');
INSERT INTO `flow_exec_identitylink` VALUES ('4475a95abd5911e7be45507b9dae4454', '102', '8a3be65eb89911e783e5507b9dae4454', '3d381d7cbd5911e7be45507b9dae4454', '3d3d0819bd5911e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '1', 'admin', 'admin', '2017-10-30 18:01:21', '2017-10-30 18:07:09');
INSERT INTO `flow_exec_identitylink` VALUES ('5f80b996c04011e7ab51507b9dae4454', '132', '59dd99f3bd2911e7be45507b9dae4454', '5f66889bc04011e7ab51507b9dae4454', '5f6d4de0c04011e7ab51507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '0', 'admin', null, '2017-11-03 10:40:37', '2017-11-03 10:40:37');
INSERT INTO `flow_exec_identitylink` VALUES ('6429dfc8bd5511e7be45507b9dae4454', '86', '8a3be65eb89911e783e5507b9dae4454', 'd86257a9bd5411e7be45507b9dae4454', 'd8677290bd5411e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '1', 'admin', 'admin', '2017-10-30 17:33:37', '2017-10-30 17:33:42');
INSERT INTO `flow_exec_identitylink` VALUES ('663f0334bd5b11e7be45507b9dae4454', '108', '8a3be65eb89911e783e5507b9dae4454', '66290378bd5b11e7be45507b9dae4454', '662badd7bd5b11e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '0', 'admin', null, '2017-10-30 18:16:37', '2017-10-30 18:16:37');
INSERT INTO `flow_exec_identitylink` VALUES ('6e4d7670bf9511e79515507b9dae4454', '128', '1f8e9ffeb86b11e783e5507b9dae4454', '6e379661bf9511e79515507b9dae4454', '6e3d3396bf9511e79515507b9dae4454', '89efa57992d911e780f9507b9dae4454', null, null, '1', 'admin', 'system', '2017-11-02 14:16:58', '2017-11-02 14:17:16');
INSERT INTO `flow_exec_identitylink` VALUES ('711382aabd4a11e7be45507b9dae4454', '81', '8a3be65eb89911e783e5507b9dae4454', '70f5de82bd4a11e7be45507b9dae4454', '71008467bd4a11e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '0', 'admin', null, '2017-10-30 16:15:14', '2017-10-30 16:15:14');
INSERT INTO `flow_exec_identitylink` VALUES ('71bbd7c6bf9511e79515507b9dae4454', '129', '12928861bf7811e79515507b9dae4454', '71b6db06bf9511e79515507b9dae4454', '71b87bb0bf9511e79515507b9dae4454', '89efa57992d911e780f9507b9dae4454', null, null, '0', 'admin', null, '2017-11-02 14:17:04', '2017-11-02 14:17:04');
INSERT INTO `flow_exec_identitylink` VALUES ('7311debcc04011e7ab51507b9dae4454', '133', '59dd99f3bd2911e7be45507b9dae4454', '73072a1ec04011e7ab51507b9dae4454', '73082ef8c04011e7ab51507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '0', 'admin', null, '2017-11-03 10:41:10', '2017-11-03 10:41:10');
INSERT INTO `flow_exec_identitylink` VALUES ('7402b22dbd5911e7be45507b9dae4454', '103', '9e40c480b54011e7a96c507b9dae4454', '73d2e991bd5911e7be45507b9dae4454', '73d4aad9bd5911e7be45507b9dae4454', '89efa57992d911e780f9507b9dae4454', null, null, '1', 'admin', 'system', '2017-10-30 18:02:36', '2017-10-30 18:04:54');
INSERT INTO `flow_exec_identitylink` VALUES ('81a042abc04011e7ab51507b9dae4454', '134', '59dd99f3bd2911e7be45507b9dae4454', '819462dbc04011e7ab51507b9dae4454', '81957d53c04011e7ab51507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '0', 'admin', null, '2017-11-03 10:41:34', '2017-11-03 10:41:34');
INSERT INTO `flow_exec_identitylink` VALUES ('913a1d15bd1111e7be45507b9dae4454', '60', '9e40c480b54011e7a96c507b9dae4454', '9127385ebd1111e7be45507b9dae4454', '912a45fdbd1111e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '1', 'admin', 'admin', '2017-10-30 09:28:01', '2017-10-30 09:29:41');
INSERT INTO `flow_exec_identitylink` VALUES ('93e83dd9bf6c11e79515507b9dae4454', '124', '8a3be65eb89911e783e5507b9dae4454', '93dce679bf6c11e79515507b9dae4454', '93e0a61cbf6c11e79515507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '1', 'admin', 'admin', '2017-11-02 09:24:36', '2017-11-02 09:27:22');
INSERT INTO `flow_exec_identitylink` VALUES ('97109c54bebd11e7b827507b9dae4454', '121', '9e40c480b54011e7a96c507b9dae4454', '9f33816abeb611e7b827507b9dae4454', '9f374594beb611e7b827507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '2', 'admin', 'admin', '2017-11-01 12:31:55', '2017-11-01 12:32:15');
INSERT INTO `flow_exec_identitylink` VALUES ('9ea95546bee611e7b827507b9dae4454', '122', '8a3be65eb89911e783e5507b9dae4454', '9e8c273ebee611e7b827507b9dae4454', '9e911902bee611e7b827507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '1', 'admin', 'admin', '2017-11-01 17:25:43', '2017-11-01 17:35:46');
INSERT INTO `flow_exec_identitylink` VALUES ('9f413ec9beb611e7b827507b9dae4454', '119', '9e40c480b54011e7a96c507b9dae4454', '9f33816abeb611e7b827507b9dae4454', '9f374594beb611e7b827507b9dae4454', '89efa57992d911e780f9507b9dae4454', null, null, '0', 'admin', 'system', '2017-11-01 11:42:03', '2017-11-01 12:13:17');
INSERT INTO `flow_exec_identitylink` VALUES ('a3b00180bd4911e7be45507b9dae4454', '80', '8a3be65eb89911e783e5507b9dae4454', 'a39214f2bd4911e7be45507b9dae4454', 'a39b7507bd4911e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '0', 'admin', null, '2017-10-30 16:09:29', '2017-10-30 16:09:29');
INSERT INTO `flow_exec_identitylink` VALUES ('a7296c8fbd1911e7be45507b9dae4454', '66', '9e40c480b54011e7a96c507b9dae4454', 'a6fddfd7bd1911e7be45507b9dae4454', 'a7026d02bd1911e7be45507b9dae4454', '', null, null, '0', 'admin', null, '2017-10-30 10:25:58', '2017-10-30 10:25:58');
INSERT INTO `flow_exec_identitylink` VALUES ('a8dcac7dbd1411e7be45507b9dae4454', '64', '9e40c480b54011e7a96c507b9dae4454', '9127385ebd1111e7be45507b9dae4454', '912fcf16bd1111e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '1', 'admin', 'admin', '2017-10-30 09:50:09', '2017-10-30 09:53:15');
INSERT INTO `flow_exec_identitylink` VALUES ('af759fccbd5511e7be45507b9dae4454', '89', '8a3be65eb89911e783e5507b9dae4454', 'af6b3bcdbd5511e7be45507b9dae4454', 'af6f4603bd5511e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '1', 'admin', 'admin', '2017-10-30 17:35:43', '2017-10-30 17:36:37');
INSERT INTO `flow_exec_identitylink` VALUES ('b48625dfbeb611e7b827507b9dae4454', '120', '9e40c480b54011e7a96c507b9dae4454', '9f33816abeb611e7b827507b9dae4454', '9f381125beb611e7b827507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '2', 'system', 'admin', '2017-11-01 11:42:38', '2017-11-01 11:59:55');
INSERT INTO `flow_exec_identitylink` VALUES ('b63e8ca3bd5811e7be45507b9dae4454', '99', '9e40c480b54011e7a96c507b9dae4454', 'dbf289abbd5611e7be45507b9dae4454', 'dc0fe0babd5611e7be45507b9dae4454', '89efa57992d911e780f9507b9dae4454', null, null, '1', 'admin', 'system', '2017-10-30 17:57:18', '2017-10-30 18:01:30');
INSERT INTO `flow_exec_identitylink` VALUES ('b640aa47bd5811e7be45507b9dae4454', '100', '9e40c480b54011e7a96c507b9dae4454', 'dbf289abbd5611e7be45507b9dae4454', 'dc0fe0babd5611e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '1', 'admin', 'admin', '2017-10-30 17:57:18', '2017-10-30 18:00:17');
INSERT INTO `flow_exec_identitylink` VALUES ('ba34d29bbd5511e7be45507b9dae4454', '90', '8a3be65eb89911e783e5507b9dae4454', 'af6b3bcdbd5511e7be45507b9dae4454', 'af703740bd5511e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '1', 'admin', 'admin', '2017-10-30 17:36:01', '2017-10-30 17:36:42');
INSERT INTO `flow_exec_identitylink` VALUES ('bc7b0a59bfb011e79515507b9dae4454', '130', '1f8e9ffeb86b11e783e5507b9dae4454', 'bc562c92bfb011e79515507b9dae4454', 'bc64283abfb011e79515507b9dae4454', '89efa57992d911e780f9507b9dae4454', null, null, '1', 'admin', 'system', '2017-11-02 17:32:26', '2017-11-02 17:48:40');
INSERT INTO `flow_exec_identitylink` VALUES ('bf1d9bd6bfb011e79515507b9dae4454', '131', '12928861bf7811e79515507b9dae4454', 'bf15a0d9bfb011e79515507b9dae4454', 'bf1a1503bfb011e79515507b9dae4454', '89efa57992d911e780f9507b9dae4454', null, null, '0', 'admin', null, '2017-11-02 17:32:30', '2017-11-02 17:32:30');
INSERT INTO `flow_exec_identitylink` VALUES ('c19efbc2bd5f11e7be45507b9dae4454', '109', '59dd99f3bd2911e7be45507b9dae4454', 'c17467d5bd5f11e7be45507b9dae4454', 'c17f9d1cbd5f11e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '0', 'admin', null, '2017-10-30 18:47:48', '2017-10-30 18:47:48');
INSERT INTO `flow_exec_identitylink` VALUES ('c5f7a7c4bd5911e7be45507b9dae4454', '104', '9e40c480b54011e7a96c507b9dae4454', '73d2e991bd5911e7be45507b9dae4454', '73d67a9cbd5911e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '1', 'system', 'admin', '2017-10-30 18:04:54', '2017-10-30 18:05:13');
INSERT INTO `flow_exec_identitylink` VALUES ('ca3dc0fec04811e7ab51507b9dae4454', '135', '8a3be65eb89911e783e5507b9dae4454', 'ca306762c04811e7ab51507b9dae4454', 'ca35e28ac04811e7ab51507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '1', 'admin', 'admin', '2017-11-03 11:40:58', '2017-11-03 14:20:32');
INSERT INTO `flow_exec_identitylink` VALUES ('cc3e059abd5711e7be45507b9dae4454', '96', '9e40c480b54011e7a96c507b9dae4454', 'dbf289abbd5611e7be45507b9dae4454', 'dbf8089cbd5611e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '1', 'system', 'admin', '2017-10-30 17:50:45', '2017-10-30 17:52:55');
INSERT INTO `flow_exec_identitylink` VALUES ('ccfc02f0bd4c11e7be45507b9dae4454', '83', '59dd99f3bd2911e7be45507b9dae4454', '024b911dbd3c11e7be45507b9dae4454', '0255020ebd3c11e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '0', 'admin', null, '2017-10-30 16:32:07', '2017-10-30 16:32:07');
INSERT INTO `flow_exec_identitylink` VALUES ('cd0314bbbd1111e7be45507b9dae4454', '61', '9e40c480b54011e7a96c507b9dae4454', '9127385ebd1111e7be45507b9dae4454', '912b86f8bd1111e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '1', 'admin', 'admin', '2017-10-30 09:29:41', '2017-10-30 09:29:54');
INSERT INTO `flow_exec_identitylink` VALUES ('d156453abd5911e7be45507b9dae4454', '105', '9e40c480b54011e7a96c507b9dae4454', '73d2e991bd5911e7be45507b9dae4454', '73d7f645bd5911e7be45507b9dae4454', '89efa57992d911e780f9507b9dae4454', null, null, '1', 'admin', 'system', '2017-10-30 18:05:13', '2017-10-30 18:05:27');
INSERT INTO `flow_exec_identitylink` VALUES ('d310389cbd4a11e7be45507b9dae4454', '82', '8a3be65eb89911e783e5507b9dae4454', 'd306ef3fbd4a11e7be45507b9dae4454', 'd30a2aebbd4a11e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '1', 'admin', 'admin', '2017-10-30 16:17:58', '2017-10-30 17:10:45');
INSERT INTO `flow_exec_identitylink` VALUES ('d47a4255bd1111e7be45507b9dae4454', '62', '9e40c480b54011e7a96c507b9dae4454', '9127385ebd1111e7be45507b9dae4454', '912d1f39bd1111e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '1', 'admin', 'admin', '2017-10-30 09:29:54', '2017-10-30 09:49:47');
INSERT INTO `flow_exec_identitylink` VALUES ('d86cdedabd5411e7be45507b9dae4454', '85', '8a3be65eb89911e783e5507b9dae4454', 'd86257a9bd5411e7be45507b9dae4454', 'd86632aabd5411e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '1', 'admin', 'admin', '2017-10-30 17:29:42', '2017-10-30 17:33:37');
INSERT INTO `flow_exec_identitylink` VALUES ('da20268bbd5911e7be45507b9dae4454', '106', '9e40c480b54011e7a96c507b9dae4454', '73d2e991bd5911e7be45507b9dae4454', '73d94963bd5911e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '1', 'system', 'admin', '2017-10-30 18:05:27', '2017-10-30 18:06:21');
INSERT INTO `flow_exec_identitylink` VALUES ('dc193b02bd5611e7be45507b9dae4454', '94', '9e40c480b54011e7a96c507b9dae4454', 'dbf289abbd5611e7be45507b9dae4454', 'dbf4c5b0bd5611e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '1', 'admin', 'admin', '2017-10-30 17:44:02', '2017-10-30 17:44:20');
INSERT INTO `flow_exec_identitylink` VALUES ('dc85e320bd1111e7be45507b9dae4454', '63', '9e40c480b54011e7a96c507b9dae4454', '9127385ebd1111e7be45507b9dae4454', '912e6782bd1111e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '1', 'admin', 'admin', '2017-10-30 09:30:07', '2017-10-30 09:50:09');
INSERT INTO `flow_exec_identitylink` VALUES ('de8db578bd5f11e7be45507b9dae4454', '110', '59dd99f3bd2911e7be45507b9dae4454', 'de78c1edbd5f11e7be45507b9dae4454', 'de7b6e2cbd5f11e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '0', 'admin', null, '2017-10-30 18:48:37', '2017-10-30 18:48:37');
INSERT INTO `flow_exec_identitylink` VALUES ('e3d36c92bd2511e7be45507b9dae4454', '72', '9e40c480b54011e7a96c507b9dae4454', 'e3c2200cbd2511e7be45507b9dae4454', 'e3c43172bd2511e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '1', 'admin', 'admin', '2017-10-30 11:53:29', '2017-10-30 11:53:47');
INSERT INTO `flow_exec_identitylink` VALUES ('e515be22bd1e11e7be45507b9dae4454', '67', '9e40c480b54011e7a96c507b9dae4454', 'e4fad48ebd1e11e7be45507b9dae4454', 'e5018dedbd1e11e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '1', 'admin', 'admin', '2017-10-30 11:03:25', '2017-10-30 11:04:09');
INSERT INTO `flow_exec_identitylink` VALUES ('e6f05530bd5611e7be45507b9dae4454', '95', '9e40c480b54011e7a96c507b9dae4454', 'dbf289abbd5611e7be45507b9dae4454', 'dbf65341bd5611e7be45507b9dae4454', '89efa57992d911e780f9507b9dae4454', null, null, '1', 'admin', 'system', '2017-10-30 17:44:20', '2017-10-30 17:50:45');
INSERT INTO `flow_exec_identitylink` VALUES ('e9dc3caebf6c11e79515507b9dae4454', '125', '8a3be65eb89911e783e5507b9dae4454', '93dce679bf6c11e79515507b9dae4454', '93e216e1bf6c11e79515507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '1', 'admin', 'admin', '2017-11-02 09:27:00', '2017-11-02 09:28:22');
INSERT INTO `flow_exec_identitylink` VALUES ('ee95a782bd2511e7be45507b9dae4454', '73', '9e40c480b54011e7a96c507b9dae4454', 'e3c2200cbd2511e7be45507b9dae4454', 'e3c55ff6bd2511e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '1', 'admin', 'admin', '2017-10-30 11:53:47', '2017-10-30 11:53:51');
INSERT INTO `flow_exec_identitylink` VALUES ('f0b82feabd2511e7be45507b9dae4454', '74', '9e40c480b54011e7a96c507b9dae4454', 'e3c2200cbd2511e7be45507b9dae4454', 'e3c7e095bd2511e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '1', 'admin', 'admin', '2017-10-30 11:53:51', '2017-10-30 11:53:56');
INSERT INTO `flow_exec_identitylink` VALUES ('f360c66abd2511e7be45507b9dae4454', '75', '9e40c480b54011e7a96c507b9dae4454', 'e3c2200cbd2511e7be45507b9dae4454', 'e3c8e73dbd2511e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '1', 'admin', 'admin', '2017-10-30 11:53:56', '2017-10-30 11:53:59');
INSERT INTO `flow_exec_identitylink` VALUES ('f5993554bd2511e7be45507b9dae4454', '76', '9e40c480b54011e7a96c507b9dae4454', 'e3c2200cbd2511e7be45507b9dae4454', 'e3ca9620bd2511e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '1', 'admin', 'admin', '2017-10-30 11:53:59', '2017-10-30 11:54:04');
INSERT INTO `flow_exec_identitylink` VALUES ('fa3634b1bd5911e7be45507b9dae4454', '107', '9e40c480b54011e7a96c507b9dae4454', '73d2e991bd5911e7be45507b9dae4454', '73daa08abd5911e7be45507b9dae4454', '89efa57992d911e780f9507b9dae4454', null, null, '1', 'admin', 'system', '2017-10-30 18:06:21', '2017-10-30 18:06:31');
INSERT INTO `flow_exec_identitylink` VALUES ('ff0f5b1ebd1e11e7be45507b9dae4454', '68', '9e40c480b54011e7a96c507b9dae4454', 'e4fad48ebd1e11e7be45507b9dae4454', 'e5026f9cbd1e11e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, null, '1', 'admin', 'admin', '2017-10-30 11:04:09', '2017-10-30 11:04:34');

-- ----------------------------
-- Table structure for flow_exec_line
-- ----------------------------
DROP TABLE IF EXISTS `flow_exec_line`;
CREATE TABLE `flow_exec_line` (
  `id` varchar(32) NOT NULL,
  `sort` bigint(20) NOT NULL AUTO_INCREMENT,
  `proc_def_id` varchar(32) DEFAULT NULL,
  `tl_line_id` varchar(32) DEFAULT NULL,
  `proc_inst_id` varchar(32) DEFAULT NULL,
  `line_name` varchar(100) DEFAULT NULL,
  `line_type` varchar(20) DEFAULT NULL,
  `line_code` varchar(50) DEFAULT NULL,
  `line_alt` tinyint(255) DEFAULT NULL,
  `mid_pos` decimal(8,2) DEFAULT NULL,
  `pre_node_id` varchar(32) DEFAULT NULL,
  `next_node_id` varchar(32) DEFAULT NULL,
  `status` smallint(6) DEFAULT NULL COMMENT '状态',
  `create_by` varchar(50) DEFAULT NULL,
  `update_by` varchar(50) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_exec_line_sort` (`sort`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=206 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of flow_exec_line
-- ----------------------------
INSERT INTO `flow_exec_line` VALUES ('025cc1bbbd3c11e7be45507b9dae4454', '95', '59dd99f3bd2911e7be45507b9dae4454', '0042216cbd2a11e7be45507b9dae4454', '024b911dbd3c11e7be45507b9dae4454', '', '', '', null, null, '024b911dbd3c11e7be45507b9dae4454', '02530986bd3c11e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 14:31:55', '2017-10-30 14:31:55');
INSERT INTO `flow_exec_line` VALUES ('025ee6c6bd3c11e7be45507b9dae4454', '96', '59dd99f3bd2911e7be45507b9dae4454', '004c5916bd2a11e7be45507b9dae4454', '024b911dbd3c11e7be45507b9dae4454', '', '', '', null, null, '02530986bd3c11e7be45507b9dae4454', '0255020ebd3c11e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 14:31:55', '2017-10-30 14:31:55');
INSERT INTO `flow_exec_line` VALUES ('0260e1e7bd3c11e7be45507b9dae4454', '97', '59dd99f3bd2911e7be45507b9dae4454', '00503f9ebd2a11e7be45507b9dae4454', '024b911dbd3c11e7be45507b9dae4454', '', '', '', null, null, '0255020ebd3c11e7be45507b9dae4454', '0256d0cebd3c11e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 14:31:55', '2017-10-30 14:31:55');
INSERT INTO `flow_exec_line` VALUES ('0262cdb5bd3c11e7be45507b9dae4454', '98', '59dd99f3bd2911e7be45507b9dae4454', '00525d94bd2a11e7be45507b9dae4454', '024b911dbd3c11e7be45507b9dae4454', '', '', '', null, null, '0256d0cebd3c11e7be45507b9dae4454', '025a7995bd3c11e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 14:31:55', '2017-10-30 14:31:55');
INSERT INTO `flow_exec_line` VALUES ('3d3eb28dbd5911e7be45507b9dae4454', '129', '8a3be65eb89911e783e5507b9dae4454', 'b9c71302bd2b11e7be45507b9dae4454', '3d381d7cbd5911e7be45507b9dae4454', '', '', '', null, null, '3d381d7cbd5911e7be45507b9dae4454', '3d3bb0cdbd5911e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 18:01:09', '2017-10-30 18:01:09');
INSERT INTO `flow_exec_line` VALUES ('3d3ffa9abd5911e7be45507b9dae4454', '130', '8a3be65eb89911e783e5507b9dae4454', 'b9c7dac1bd2b11e7be45507b9dae4454', '3d381d7cbd5911e7be45507b9dae4454', '', '', '', null, null, '3d3bb0cdbd5911e7be45507b9dae4454', '3d3d0819bd5911e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 18:01:09', '2017-10-30 18:01:09');
INSERT INTO `flow_exec_line` VALUES ('3d41979dbd5911e7be45507b9dae4454', '131', '8a3be65eb89911e783e5507b9dae4454', 'b9c874b8bd2b11e7be45507b9dae4454', '3d381d7cbd5911e7be45507b9dae4454', '', '', '', null, null, '3d3d0819bd5911e7be45507b9dae4454', '3d3a2529bd5911e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 18:01:09', '2017-10-30 18:01:09');
INSERT INTO `flow_exec_line` VALUES ('40421ba9bd4811e7be45507b9dae4454', '99', '8a3be65eb89911e783e5507b9dae4454', 'b9c71302bd2b11e7be45507b9dae4454', '4027e8a1bd4811e7be45507b9dae4454', '', '', '', null, null, '4027e8a1bd4811e7be45507b9dae4454', '402df2fbbd4811e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 15:59:33', '2017-10-30 15:59:33');
INSERT INTO `flow_exec_line` VALUES ('40435b9dbd4811e7be45507b9dae4454', '100', '8a3be65eb89911e783e5507b9dae4454', 'b9c7dac1bd2b11e7be45507b9dae4454', '4027e8a1bd4811e7be45507b9dae4454', '', '', '', null, null, '402df2fbbd4811e7be45507b9dae4454', '402fa09ebd4811e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 15:59:33', '2017-10-30 15:59:33');
INSERT INTO `flow_exec_line` VALUES ('4044b6d4bd4811e7be45507b9dae4454', '101', '8a3be65eb89911e783e5507b9dae4454', 'b9c874b8bd2b11e7be45507b9dae4454', '4027e8a1bd4811e7be45507b9dae4454', '', '', '', null, null, '402fa09ebd4811e7be45507b9dae4454', '402cc569bd4811e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 15:59:33', '2017-10-30 15:59:33');
INSERT INTO `flow_exec_line` VALUES ('5f765432c04011e7ab51507b9dae4454', '191', '59dd99f3bd2911e7be45507b9dae4454', '0042216cbd2a11e7be45507b9dae4454', '5f66889bc04011e7ab51507b9dae4454', '', '', '', null, null, '5f66889bc04011e7ab51507b9dae4454', '5f6d4de0c04011e7ab51507b9dae4454', '1', 'admin', null, '2017-11-03 10:40:37', '2017-11-03 10:40:37');
INSERT INTO `flow_exec_line` VALUES ('5f79cc15c04011e7ab51507b9dae4454', '192', '59dd99f3bd2911e7be45507b9dae4454', '004c5916bd2a11e7be45507b9dae4454', '5f66889bc04011e7ab51507b9dae4454', '', '', '', null, null, '5f6d4de0c04011e7ab51507b9dae4454', '5f70e393c04011e7ab51507b9dae4454', '1', 'admin', null, '2017-11-03 10:40:37', '2017-11-03 10:40:37');
INSERT INTO `flow_exec_line` VALUES ('5f7a82e7c04011e7ab51507b9dae4454', '193', '59dd99f3bd2911e7be45507b9dae4454', '00503f9ebd2a11e7be45507b9dae4454', '5f66889bc04011e7ab51507b9dae4454', '', '', '', null, null, '5f70e393c04011e7ab51507b9dae4454', '5f741243c04011e7ab51507b9dae4454', '1', 'admin', null, '2017-11-03 10:40:37', '2017-11-03 10:40:37');
INSERT INTO `flow_exec_line` VALUES ('5f7b630fc04011e7ab51507b9dae4454', '194', '59dd99f3bd2911e7be45507b9dae4454', '00525d94bd2a11e7be45507b9dae4454', '5f66889bc04011e7ab51507b9dae4454', '', '', '', null, null, '5f741243c04011e7ab51507b9dae4454', '5f750b3bc04011e7ab51507b9dae4454', '1', 'admin', null, '2017-11-03 10:40:37', '2017-11-03 10:40:37');
INSERT INTO `flow_exec_line` VALUES ('662e0447bd5b11e7be45507b9dae4454', '138', '8a3be65eb89911e783e5507b9dae4454', 'b9c71302bd2b11e7be45507b9dae4454', '66290378bd5b11e7be45507b9dae4454', '', '', '', null, null, '66290378bd5b11e7be45507b9dae4454', '662badd7bd5b11e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 18:16:37', '2017-10-30 18:16:37');
INSERT INTO `flow_exec_line` VALUES ('663137d8bd5b11e7be45507b9dae4454', '139', '8a3be65eb89911e783e5507b9dae4454', 'b9c7dac1bd2b11e7be45507b9dae4454', '66290378bd5b11e7be45507b9dae4454', '', '', '', null, null, '662badd7bd5b11e7be45507b9dae4454', '662cdf3bbd5b11e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 18:16:37', '2017-10-30 18:16:37');
INSERT INTO `flow_exec_line` VALUES ('663b7114bd5b11e7be45507b9dae4454', '140', '8a3be65eb89911e783e5507b9dae4454', 'b9c874b8bd2b11e7be45507b9dae4454', '66290378bd5b11e7be45507b9dae4454', '', '', '', null, null, '662cdf3bbd5b11e7be45507b9dae4454', '662a6a80bd5b11e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 18:16:37', '2017-10-30 18:16:37');
INSERT INTO `flow_exec_line` VALUES ('6e4a984abf9511e79515507b9dae4454', '183', '1f8e9ffeb86b11e783e5507b9dae4454', '0134b152bf7811e79515507b9dae4454', '6e379661bf9511e79515507b9dae4454', '', '', '', null, null, '6e379661bf9511e79515507b9dae4454', '6e3d3396bf9511e79515507b9dae4454', '1', 'admin', null, '2017-11-02 14:16:58', '2017-11-02 14:16:58');
INSERT INTO `flow_exec_line` VALUES ('6e4b7e87bf9511e79515507b9dae4454', '184', '1f8e9ffeb86b11e783e5507b9dae4454', '0137bfe2bf7811e79515507b9dae4454', '6e379661bf9511e79515507b9dae4454', '', '', '', null, null, '6e3d3396bf9511e79515507b9dae4454', '6e3c8990bf9511e79515507b9dae4454', '1', 'admin', null, '2017-11-02 14:16:58', '2017-11-02 14:16:58');
INSERT INTO `flow_exec_line` VALUES ('7109e0c1bd4a11e7be45507b9dae4454', '105', '8a3be65eb89911e783e5507b9dae4454', 'b9c71302bd2b11e7be45507b9dae4454', '70f5de82bd4a11e7be45507b9dae4454', '', '', '', null, null, '70f5de82bd4a11e7be45507b9dae4454', '71008467bd4a11e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 16:15:14', '2017-10-30 16:15:14');
INSERT INTO `flow_exec_line` VALUES ('710d199cbd4a11e7be45507b9dae4454', '106', '8a3be65eb89911e783e5507b9dae4454', 'b9c7dac1bd2b11e7be45507b9dae4454', '70f5de82bd4a11e7be45507b9dae4454', '', '', '', null, null, '71008467bd4a11e7be45507b9dae4454', '71073d6bbd4a11e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 16:15:14', '2017-10-30 16:15:14');
INSERT INTO `flow_exec_line` VALUES ('710f85d4bd4a11e7be45507b9dae4454', '107', '8a3be65eb89911e783e5507b9dae4454', 'b9c874b8bd2b11e7be45507b9dae4454', '70f5de82bd4a11e7be45507b9dae4454', '', '', '', null, null, '71073d6bbd4a11e7be45507b9dae4454', '70fd38c3bd4a11e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 16:15:14', '2017-10-30 16:15:14');
INSERT INTO `flow_exec_line` VALUES ('71b98209bf9511e79515507b9dae4454', '185', '12928861bf7811e79515507b9dae4454', '353fba74bf7811e79515507b9dae4454', '71b6db06bf9511e79515507b9dae4454', '', '', '', null, null, '71b6db06bf9511e79515507b9dae4454', '71b87bb0bf9511e79515507b9dae4454', '1', 'admin', null, '2017-11-02 14:17:04', '2017-11-02 14:17:04');
INSERT INTO `flow_exec_line` VALUES ('71ba7d56bf9511e79515507b9dae4454', '186', '12928861bf7811e79515507b9dae4454', '35404219bf7811e79515507b9dae4454', '71b6db06bf9511e79515507b9dae4454', '', '', '', null, null, '71b87bb0bf9511e79515507b9dae4454', '71b7a22bbf9511e79515507b9dae4454', '1', 'admin', null, '2017-11-02 14:17:04', '2017-11-02 14:17:04');
INSERT INTO `flow_exec_line` VALUES ('730b8638c04011e7ab51507b9dae4454', '195', '59dd99f3bd2911e7be45507b9dae4454', '0042216cbd2a11e7be45507b9dae4454', '73072a1ec04011e7ab51507b9dae4454', '', '', '', null, null, '73072a1ec04011e7ab51507b9dae4454', '73082ef8c04011e7ab51507b9dae4454', '1', 'admin', null, '2017-11-03 10:41:10', '2017-11-03 10:41:10');
INSERT INTO `flow_exec_line` VALUES ('730c4751c04011e7ab51507b9dae4454', '196', '59dd99f3bd2911e7be45507b9dae4454', '004c5916bd2a11e7be45507b9dae4454', '73072a1ec04011e7ab51507b9dae4454', '', '', '', null, null, '73082ef8c04011e7ab51507b9dae4454', '730910a2c04011e7ab51507b9dae4454', '1', 'admin', null, '2017-11-03 10:41:10', '2017-11-03 10:41:10');
INSERT INTO `flow_exec_line` VALUES ('730d002cc04011e7ab51507b9dae4454', '197', '59dd99f3bd2911e7be45507b9dae4454', '00503f9ebd2a11e7be45507b9dae4454', '73072a1ec04011e7ab51507b9dae4454', '', '', '', null, null, '730910a2c04011e7ab51507b9dae4454', '7309d5dfc04011e7ab51507b9dae4454', '1', 'admin', null, '2017-11-03 10:41:10', '2017-11-03 10:41:10');
INSERT INTO `flow_exec_line` VALUES ('73108a75c04011e7ab51507b9dae4454', '198', '59dd99f3bd2911e7be45507b9dae4454', '00525d94bd2a11e7be45507b9dae4454', '73072a1ec04011e7ab51507b9dae4454', '', '', '', null, null, '7309d5dfc04011e7ab51507b9dae4454', '730aa031c04011e7ab51507b9dae4454', '1', 'admin', null, '2017-11-03 10:41:10', '2017-11-03 10:41:10');
INSERT INTO `flow_exec_line` VALUES ('73ddfc49bd5911e7be45507b9dae4454', '132', '9e40c480b54011e7a96c507b9dae4454', 'dc8ac93ab95311e791be507b9dae4454', '73d2e991bd5911e7be45507b9dae4454', '', '', '', null, null, '73d2e991bd5911e7be45507b9dae4454', '73d4aad9bd5911e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 18:02:36', '2017-10-30 18:02:36');
INSERT INTO `flow_exec_line` VALUES ('73dfc1c8bd5911e7be45507b9dae4454', '133', '9e40c480b54011e7a96c507b9dae4454', 'dc8d0ff1b95311e791be507b9dae4454', '73d2e991bd5911e7be45507b9dae4454', '', '', '', null, null, '73d4aad9bd5911e7be45507b9dae4454', '73d67a9cbd5911e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 18:02:36', '2017-10-30 18:02:36');
INSERT INTO `flow_exec_line` VALUES ('73e1005abd5911e7be45507b9dae4454', '134', '9e40c480b54011e7a96c507b9dae4454', 'dc8dd903b95311e791be507b9dae4454', '73d2e991bd5911e7be45507b9dae4454', '', '', '', null, null, '73d67a9cbd5911e7be45507b9dae4454', '73d7f645bd5911e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 18:02:36', '2017-10-30 18:02:36');
INSERT INTO `flow_exec_line` VALUES ('73e239babd5911e7be45507b9dae4454', '135', '9e40c480b54011e7a96c507b9dae4454', 'dc8e71f7b95311e791be507b9dae4454', '73d2e991bd5911e7be45507b9dae4454', '', '', '', null, null, '73d7f645bd5911e7be45507b9dae4454', '73d94963bd5911e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 18:02:36', '2017-10-30 18:02:36');
INSERT INTO `flow_exec_line` VALUES ('73e3bc6cbd5911e7be45507b9dae4454', '136', '9e40c480b54011e7a96c507b9dae4454', 'dc8f047db95311e791be507b9dae4454', '73d2e991bd5911e7be45507b9dae4454', '', '', '', null, null, '73d94963bd5911e7be45507b9dae4454', '73daa08abd5911e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 18:02:36', '2017-10-30 18:02:36');
INSERT INTO `flow_exec_line` VALUES ('73ec7321bd5911e7be45507b9dae4454', '137', '9e40c480b54011e7a96c507b9dae4454', 'dc8f900bb95311e791be507b9dae4454', '73d2e991bd5911e7be45507b9dae4454', '', '', '', null, null, '73daa08abd5911e7be45507b9dae4454', '73dc431cbd5911e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 18:02:36', '2017-10-30 18:02:36');
INSERT INTO `flow_exec_line` VALUES ('819a3982c04011e7ab51507b9dae4454', '199', '59dd99f3bd2911e7be45507b9dae4454', '0042216cbd2a11e7be45507b9dae4454', '819462dbc04011e7ab51507b9dae4454', '', '', '', null, null, '819462dbc04011e7ab51507b9dae4454', '81957d53c04011e7ab51507b9dae4454', '1', 'admin', null, '2017-11-03 10:41:34', '2017-11-03 10:41:34');
INSERT INTO `flow_exec_line` VALUES ('819b5febc04011e7ab51507b9dae4454', '200', '59dd99f3bd2911e7be45507b9dae4454', '004c5916bd2a11e7be45507b9dae4454', '819462dbc04011e7ab51507b9dae4454', '', '', '', null, null, '81957d53c04011e7ab51507b9dae4454', '81972d5ec04011e7ab51507b9dae4454', '1', 'admin', null, '2017-11-03 10:41:34', '2017-11-03 10:41:34');
INSERT INTO `flow_exec_line` VALUES ('819cb395c04011e7ab51507b9dae4454', '201', '59dd99f3bd2911e7be45507b9dae4454', '00503f9ebd2a11e7be45507b9dae4454', '819462dbc04011e7ab51507b9dae4454', '', '', '', null, null, '81972d5ec04011e7ab51507b9dae4454', '81983e98c04011e7ab51507b9dae4454', '1', 'admin', null, '2017-11-03 10:41:34', '2017-11-03 10:41:34');
INSERT INTO `flow_exec_line` VALUES ('819e133ec04011e7ab51507b9dae4454', '202', '59dd99f3bd2911e7be45507b9dae4454', '00525d94bd2a11e7be45507b9dae4454', '819462dbc04011e7ab51507b9dae4454', '', '', '', null, null, '81983e98c04011e7ab51507b9dae4454', '81993115c04011e7ab51507b9dae4454', '1', 'admin', null, '2017-11-03 10:41:34', '2017-11-03 10:41:34');
INSERT INTO `flow_exec_line` VALUES ('91326b68bd1111e7be45507b9dae4454', '67', '9e40c480b54011e7a96c507b9dae4454', 'dc8ac93ab95311e791be507b9dae4454', '9127385ebd1111e7be45507b9dae4454', '', '', '', null, null, '9127385ebd1111e7be45507b9dae4454', '912a45fdbd1111e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 09:28:01', '2017-10-30 09:28:01');
INSERT INTO `flow_exec_line` VALUES ('91337cdbbd1111e7be45507b9dae4454', '68', '9e40c480b54011e7a96c507b9dae4454', 'dc8d0ff1b95311e791be507b9dae4454', '9127385ebd1111e7be45507b9dae4454', '', '', '', null, null, '912a45fdbd1111e7be45507b9dae4454', '912b86f8bd1111e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 09:28:01', '2017-10-30 09:28:01');
INSERT INTO `flow_exec_line` VALUES ('9134983fbd1111e7be45507b9dae4454', '69', '9e40c480b54011e7a96c507b9dae4454', 'dc8dd903b95311e791be507b9dae4454', '9127385ebd1111e7be45507b9dae4454', '', '', '', null, null, '912b86f8bd1111e7be45507b9dae4454', '912d1f39bd1111e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 09:28:01', '2017-10-30 09:28:01');
INSERT INTO `flow_exec_line` VALUES ('9135aa21bd1111e7be45507b9dae4454', '70', '9e40c480b54011e7a96c507b9dae4454', 'dc8e71f7b95311e791be507b9dae4454', '9127385ebd1111e7be45507b9dae4454', '', '', '', null, null, '912d1f39bd1111e7be45507b9dae4454', '912e6782bd1111e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 09:28:01', '2017-10-30 09:28:01');
INSERT INTO `flow_exec_line` VALUES ('913696d1bd1111e7be45507b9dae4454', '71', '9e40c480b54011e7a96c507b9dae4454', 'dc8f047db95311e791be507b9dae4454', '9127385ebd1111e7be45507b9dae4454', '', '', '', null, null, '912e6782bd1111e7be45507b9dae4454', '912fcf16bd1111e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 09:28:01', '2017-10-30 09:28:01');
INSERT INTO `flow_exec_line` VALUES ('91377b0abd1111e7be45507b9dae4454', '72', '9e40c480b54011e7a96c507b9dae4454', 'dc8f900bb95311e791be507b9dae4454', '9127385ebd1111e7be45507b9dae4454', '', '', '', null, null, '912fcf16bd1111e7be45507b9dae4454', '913106aebd1111e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 09:28:01', '2017-10-30 09:28:01');
INSERT INTO `flow_exec_line` VALUES ('93e37506bf6c11e79515507b9dae4454', '176', '8a3be65eb89911e783e5507b9dae4454', 'b9c71302bd2b11e7be45507b9dae4454', '93dce679bf6c11e79515507b9dae4454', '', '', '', null, null, '93dce679bf6c11e79515507b9dae4454', '93e0a61cbf6c11e79515507b9dae4454', '1', 'admin', null, '2017-11-02 09:24:36', '2017-11-02 09:24:36');
INSERT INTO `flow_exec_line` VALUES ('93e4ef3abf6c11e79515507b9dae4454', '177', '8a3be65eb89911e783e5507b9dae4454', 'b9c7dac1bd2b11e7be45507b9dae4454', '93dce679bf6c11e79515507b9dae4454', '', '', '', null, null, '93e0a61cbf6c11e79515507b9dae4454', '93e216e1bf6c11e79515507b9dae4454', '1', 'admin', null, '2017-11-02 09:24:36', '2017-11-02 09:24:36');
INSERT INTO `flow_exec_line` VALUES ('93e61427bf6c11e79515507b9dae4454', '178', '8a3be65eb89911e783e5507b9dae4454', 'b9c874b8bd2b11e7be45507b9dae4454', '93dce679bf6c11e79515507b9dae4454', '', '', '', null, null, '93e216e1bf6c11e79515507b9dae4454', '93ded10bbf6c11e79515507b9dae4454', '1', 'admin', null, '2017-11-02 09:24:36', '2017-11-02 09:24:36');
INSERT INTO `flow_exec_line` VALUES ('9ea1f59dbee611e7b827507b9dae4454', '173', '8a3be65eb89911e783e5507b9dae4454', 'b9c71302bd2b11e7be45507b9dae4454', '9e8c273ebee611e7b827507b9dae4454', '', '', '', null, null, '9e8c273ebee611e7b827507b9dae4454', '9e911902bee611e7b827507b9dae4454', '1', 'admin', null, '2017-11-01 17:25:43', '2017-11-01 17:25:43');
INSERT INTO `flow_exec_line` VALUES ('9ea3bc61bee611e7b827507b9dae4454', '174', '8a3be65eb89911e783e5507b9dae4454', 'b9c7dac1bd2b11e7be45507b9dae4454', '9e8c273ebee611e7b827507b9dae4454', '', '', '', null, null, '9e911902bee611e7b827507b9dae4454', '9e9fcfbbbee611e7b827507b9dae4454', '1', 'admin', null, '2017-11-01 17:25:43', '2017-11-01 17:25:43');
INSERT INTO `flow_exec_line` VALUES ('9ea5589cbee611e7b827507b9dae4454', '175', '8a3be65eb89911e783e5507b9dae4454', 'b9c874b8bd2b11e7be45507b9dae4454', '9e8c273ebee611e7b827507b9dae4454', '', '', '', null, null, '9e9fcfbbbee611e7b827507b9dae4454', '9e8f2628bee611e7b827507b9dae4454', '1', 'admin', null, '2017-11-01 17:25:43', '2017-11-01 17:25:43');
INSERT INTO `flow_exec_line` VALUES ('9f3bc7b6beb611e7b827507b9dae4454', '167', '9e40c480b54011e7a96c507b9dae4454', 'dc8ac93ab95311e791be507b9dae4454', '9f33816abeb611e7b827507b9dae4454', '', '', '', null, null, '9f33816abeb611e7b827507b9dae4454', '9f374594beb611e7b827507b9dae4454', '1', 'admin', null, '2017-11-01 11:42:02', '2017-11-01 11:42:02');
INSERT INTO `flow_exec_line` VALUES ('9f3cac86beb611e7b827507b9dae4454', '168', '9e40c480b54011e7a96c507b9dae4454', 'dc8d0ff1b95311e791be507b9dae4454', '9f33816abeb611e7b827507b9dae4454', '', '', '', null, null, '9f374594beb611e7b827507b9dae4454', '9f381125beb611e7b827507b9dae4454', '1', 'admin', null, '2017-11-01 11:42:03', '2017-11-01 11:42:03');
INSERT INTO `flow_exec_line` VALUES ('9f3d4569beb611e7b827507b9dae4454', '169', '9e40c480b54011e7a96c507b9dae4454', 'dc8dd903b95311e791be507b9dae4454', '9f33816abeb611e7b827507b9dae4454', '', '', '', null, null, '9f381125beb611e7b827507b9dae4454', '9f38d306beb611e7b827507b9dae4454', '1', 'admin', null, '2017-11-01 11:42:03', '2017-11-01 11:42:03');
INSERT INTO `flow_exec_line` VALUES ('9f3de331beb611e7b827507b9dae4454', '170', '9e40c480b54011e7a96c507b9dae4454', 'dc8e71f7b95311e791be507b9dae4454', '9f33816abeb611e7b827507b9dae4454', '', '', '', null, null, '9f38d306beb611e7b827507b9dae4454', '9f399332beb611e7b827507b9dae4454', '1', 'admin', null, '2017-11-01 11:42:03', '2017-11-01 11:42:03');
INSERT INTO `flow_exec_line` VALUES ('9f3e98fabeb611e7b827507b9dae4454', '171', '9e40c480b54011e7a96c507b9dae4454', 'dc8f047db95311e791be507b9dae4454', '9f33816abeb611e7b827507b9dae4454', '', '', '', null, null, '9f399332beb611e7b827507b9dae4454', '9f3a51e9beb611e7b827507b9dae4454', '1', 'admin', null, '2017-11-01 11:42:03', '2017-11-01 11:42:03');
INSERT INTO `flow_exec_line` VALUES ('9f3f5bdebeb611e7b827507b9dae4454', '172', '9e40c480b54011e7a96c507b9dae4454', 'dc8f900bb95311e791be507b9dae4454', '9f33816abeb611e7b827507b9dae4454', '', '', '', null, null, '9f3a51e9beb611e7b827507b9dae4454', '9f3b04ccbeb611e7b827507b9dae4454', '1', 'admin', null, '2017-11-01 11:42:03', '2017-11-01 11:42:03');
INSERT INTO `flow_exec_line` VALUES ('a3a54cdcbd4911e7be45507b9dae4454', '102', '8a3be65eb89911e783e5507b9dae4454', 'b9c71302bd2b11e7be45507b9dae4454', 'a39214f2bd4911e7be45507b9dae4454', '', '', '', null, null, 'a39214f2bd4911e7be45507b9dae4454', 'a39b7507bd4911e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 16:09:29', '2017-10-30 16:09:29');
INSERT INTO `flow_exec_line` VALUES ('a3a9131bbd4911e7be45507b9dae4454', '103', '8a3be65eb89911e783e5507b9dae4454', 'b9c7dac1bd2b11e7be45507b9dae4454', 'a39214f2bd4911e7be45507b9dae4454', '', '', '', null, null, 'a39b7507bd4911e7be45507b9dae4454', 'a3a2610dbd4911e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 16:09:29', '2017-10-30 16:09:29');
INSERT INTO `flow_exec_line` VALUES ('a3abc1c7bd4911e7be45507b9dae4454', '104', '8a3be65eb89911e783e5507b9dae4454', 'b9c874b8bd2b11e7be45507b9dae4454', 'a39214f2bd4911e7be45507b9dae4454', '', '', '', null, null, 'a3a2610dbd4911e7be45507b9dae4454', 'a39868e3bd4911e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 16:09:29', '2017-10-30 16:09:29');
INSERT INTO `flow_exec_line` VALUES ('a7179632bd1911e7be45507b9dae4454', '73', '9e40c480b54011e7a96c507b9dae4454', 'dc8ac93ab95311e791be507b9dae4454', 'a6fddfd7bd1911e7be45507b9dae4454', '', '', '', null, null, 'a6fddfd7bd1911e7be45507b9dae4454', 'a7026d02bd1911e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 10:25:58', '2017-10-30 10:25:58');
INSERT INTO `flow_exec_line` VALUES ('a71d33f1bd1911e7be45507b9dae4454', '74', '9e40c480b54011e7a96c507b9dae4454', 'dc8d0ff1b95311e791be507b9dae4454', 'a6fddfd7bd1911e7be45507b9dae4454', '', '', '', null, null, 'a7026d02bd1911e7be45507b9dae4454', 'a706712fbd1911e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 10:25:58', '2017-10-30 10:25:58');
INSERT INTO `flow_exec_line` VALUES ('a71f56b5bd1911e7be45507b9dae4454', '75', '9e40c480b54011e7a96c507b9dae4454', 'dc8dd903b95311e791be507b9dae4454', 'a6fddfd7bd1911e7be45507b9dae4454', '', '', '', null, null, 'a706712fbd1911e7be45507b9dae4454', 'a70a8767bd1911e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 10:25:58', '2017-10-30 10:25:58');
INSERT INTO `flow_exec_line` VALUES ('a7216b97bd1911e7be45507b9dae4454', '76', '9e40c480b54011e7a96c507b9dae4454', 'dc8e71f7b95311e791be507b9dae4454', 'a6fddfd7bd1911e7be45507b9dae4454', '', '', '', null, null, 'a70a8767bd1911e7be45507b9dae4454', 'a70c2a9bbd1911e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 10:25:58', '2017-10-30 10:25:58');
INSERT INTO `flow_exec_line` VALUES ('a723322abd1911e7be45507b9dae4454', '77', '9e40c480b54011e7a96c507b9dae4454', 'dc8f047db95311e791be507b9dae4454', 'a6fddfd7bd1911e7be45507b9dae4454', '', '', '', null, null, 'a70c2a9bbd1911e7be45507b9dae4454', 'a712a545bd1911e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 10:25:58', '2017-10-30 10:25:58');
INSERT INTO `flow_exec_line` VALUES ('a72654cdbd1911e7be45507b9dae4454', '78', '9e40c480b54011e7a96c507b9dae4454', 'dc8f900bb95311e791be507b9dae4454', 'a6fddfd7bd1911e7be45507b9dae4454', '', '', '', null, null, 'a712a545bd1911e7be45507b9dae4454', 'a715cc3dbd1911e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 10:25:58', '2017-10-30 10:25:58');
INSERT INTO `flow_exec_line` VALUES ('af715a10bd5511e7be45507b9dae4454', '120', '8a3be65eb89911e783e5507b9dae4454', 'b9c71302bd2b11e7be45507b9dae4454', 'af6b3bcdbd5511e7be45507b9dae4454', '', '', '', null, null, 'af6b3bcdbd5511e7be45507b9dae4454', 'af6f4603bd5511e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 17:35:43', '2017-10-30 17:35:43');
INSERT INTO `flow_exec_line` VALUES ('af727c3dbd5511e7be45507b9dae4454', '121', '8a3be65eb89911e783e5507b9dae4454', 'b9c7dac1bd2b11e7be45507b9dae4454', 'af6b3bcdbd5511e7be45507b9dae4454', '', '', '', null, null, 'af6f4603bd5511e7be45507b9dae4454', 'af703740bd5511e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 17:35:43', '2017-10-30 17:35:43');
INSERT INTO `flow_exec_line` VALUES ('af73c4cdbd5511e7be45507b9dae4454', '122', '8a3be65eb89911e783e5507b9dae4454', 'b9c874b8bd2b11e7be45507b9dae4454', 'af6b3bcdbd5511e7be45507b9dae4454', '', '', '', null, null, 'af703740bd5511e7be45507b9dae4454', 'af6e380abd5511e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 17:35:43', '2017-10-30 17:35:43');
INSERT INTO `flow_exec_line` VALUES ('bc788444bfb011e79515507b9dae4454', '187', '1f8e9ffeb86b11e783e5507b9dae4454', '0134b152bf7811e79515507b9dae4454', 'bc562c92bfb011e79515507b9dae4454', '', '', '', null, null, 'bc562c92bfb011e79515507b9dae4454', 'bc64283abfb011e79515507b9dae4454', '1', 'admin', null, '2017-11-02 17:32:26', '2017-11-02 17:32:26');
INSERT INTO `flow_exec_line` VALUES ('bc796abdbfb011e79515507b9dae4454', '188', '1f8e9ffeb86b11e783e5507b9dae4454', '0137bfe2bf7811e79515507b9dae4454', 'bc562c92bfb011e79515507b9dae4454', '', '', '', null, null, 'bc64283abfb011e79515507b9dae4454', 'bc5778e6bfb011e79515507b9dae4454', '1', 'admin', null, '2017-11-02 17:32:26', '2017-11-02 17:32:26');
INSERT INTO `flow_exec_line` VALUES ('bf1b078bbfb011e79515507b9dae4454', '189', '12928861bf7811e79515507b9dae4454', '353fba74bf7811e79515507b9dae4454', 'bf15a0d9bfb011e79515507b9dae4454', '', '', '', null, null, 'bf15a0d9bfb011e79515507b9dae4454', 'bf1a1503bfb011e79515507b9dae4454', '1', 'admin', null, '2017-11-02 17:32:30', '2017-11-02 17:32:30');
INSERT INTO `flow_exec_line` VALUES ('bf1bf54abfb011e79515507b9dae4454', '190', '12928861bf7811e79515507b9dae4454', '35404219bf7811e79515507b9dae4454', 'bf15a0d9bfb011e79515507b9dae4454', '', '', '', null, null, 'bf1a1503bfb011e79515507b9dae4454', 'bf191908bfb011e79515507b9dae4454', '1', 'admin', null, '2017-11-02 17:32:30', '2017-11-02 17:32:30');
INSERT INTO `flow_exec_line` VALUES ('c1889209bd5f11e7be45507b9dae4454', '141', '59dd99f3bd2911e7be45507b9dae4454', '0042216cbd2a11e7be45507b9dae4454', 'c17467d5bd5f11e7be45507b9dae4454', '', '', '', null, null, 'c17467d5bd5f11e7be45507b9dae4454', 'c17f9d1cbd5f11e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 18:47:48', '2017-10-30 18:47:48');
INSERT INTO `flow_exec_line` VALUES ('c18f1487bd5f11e7be45507b9dae4454', '142', '59dd99f3bd2911e7be45507b9dae4454', '004c5916bd2a11e7be45507b9dae4454', 'c17467d5bd5f11e7be45507b9dae4454', '', '', '', null, null, 'c17f9d1cbd5f11e7be45507b9dae4454', 'c18207c2bd5f11e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 18:47:48', '2017-10-30 18:47:48');
INSERT INTO `flow_exec_line` VALUES ('c1920696bd5f11e7be45507b9dae4454', '143', '59dd99f3bd2911e7be45507b9dae4454', '00503f9ebd2a11e7be45507b9dae4454', 'c17467d5bd5f11e7be45507b9dae4454', '', '', '', null, null, 'c18207c2bd5f11e7be45507b9dae4454', 'c1846ecabd5f11e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 18:47:48', '2017-10-30 18:47:48');
INSERT INTO `flow_exec_line` VALUES ('c19a32b3bd5f11e7be45507b9dae4454', '144', '59dd99f3bd2911e7be45507b9dae4454', '00525d94bd2a11e7be45507b9dae4454', 'c17467d5bd5f11e7be45507b9dae4454', '', '', '', null, null, 'c1846ecabd5f11e7be45507b9dae4454', 'c18677babd5f11e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 18:47:48', '2017-10-30 18:47:48');
INSERT INTO `flow_exec_line` VALUES ('ca38557fc04811e7ab51507b9dae4454', '203', '8a3be65eb89911e783e5507b9dae4454', 'b9c71302bd2b11e7be45507b9dae4454', 'ca306762c04811e7ab51507b9dae4454', '', '', '', null, null, 'ca306762c04811e7ab51507b9dae4454', 'ca35e28ac04811e7ab51507b9dae4454', '1', 'admin', null, '2017-11-03 11:40:58', '2017-11-03 11:40:58');
INSERT INTO `flow_exec_line` VALUES ('ca3b0752c04811e7ab51507b9dae4454', '204', '8a3be65eb89911e783e5507b9dae4454', 'b9c7dac1bd2b11e7be45507b9dae4454', 'ca306762c04811e7ab51507b9dae4454', '', '', '', null, null, 'ca35e28ac04811e7ab51507b9dae4454', 'ca374d59c04811e7ab51507b9dae4454', '1', 'admin', null, '2017-11-03 11:40:58', '2017-11-03 11:40:58');
INSERT INTO `flow_exec_line` VALUES ('ca3c1827c04811e7ab51507b9dae4454', '205', '8a3be65eb89911e783e5507b9dae4454', 'b9c874b8bd2b11e7be45507b9dae4454', 'ca306762c04811e7ab51507b9dae4454', '', '', '', null, null, 'ca374d59c04811e7ab51507b9dae4454', 'ca34a5e7c04811e7ab51507b9dae4454', '1', 'admin', null, '2017-11-03 11:40:58', '2017-11-03 11:40:58');
INSERT INTO `flow_exec_line` VALUES ('d30c6854bd4a11e7be45507b9dae4454', '108', '8a3be65eb89911e783e5507b9dae4454', 'b9c71302bd2b11e7be45507b9dae4454', 'd306ef3fbd4a11e7be45507b9dae4454', '', '', '', null, null, 'd306ef3fbd4a11e7be45507b9dae4454', 'd30a2aebbd4a11e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 16:17:58', '2017-10-30 16:17:58');
INSERT INTO `flow_exec_line` VALUES ('d30d8070bd4a11e7be45507b9dae4454', '109', '8a3be65eb89911e783e5507b9dae4454', 'b9c7dac1bd2b11e7be45507b9dae4454', 'd306ef3fbd4a11e7be45507b9dae4454', '', '', '', null, null, 'd30a2aebbd4a11e7be45507b9dae4454', 'd30b5063bd4a11e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 16:17:58', '2017-10-30 16:17:58');
INSERT INTO `flow_exec_line` VALUES ('d30e7e24bd4a11e7be45507b9dae4454', '110', '8a3be65eb89911e783e5507b9dae4454', 'b9c874b8bd2b11e7be45507b9dae4454', 'd306ef3fbd4a11e7be45507b9dae4454', '', '', '', null, null, 'd30b5063bd4a11e7be45507b9dae4454', 'd308f468bd4a11e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 16:17:58', '2017-10-30 16:17:58');
INSERT INTO `flow_exec_line` VALUES ('d868d415bd5411e7be45507b9dae4454', '111', '8a3be65eb89911e783e5507b9dae4454', 'b9c71302bd2b11e7be45507b9dae4454', 'd86257a9bd5411e7be45507b9dae4454', '', '', '', null, null, 'd86257a9bd5411e7be45507b9dae4454', 'd86632aabd5411e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 17:29:42', '2017-10-30 17:29:42');
INSERT INTO `flow_exec_line` VALUES ('d86a2226bd5411e7be45507b9dae4454', '112', '8a3be65eb89911e783e5507b9dae4454', 'b9c7dac1bd2b11e7be45507b9dae4454', 'd86257a9bd5411e7be45507b9dae4454', '', '', '', null, null, 'd86632aabd5411e7be45507b9dae4454', 'd8677290bd5411e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 17:29:42', '2017-10-30 17:29:42');
INSERT INTO `flow_exec_line` VALUES ('d86b301abd5411e7be45507b9dae4454', '113', '8a3be65eb89911e783e5507b9dae4454', 'b9c874b8bd2b11e7be45507b9dae4454', 'd86257a9bd5411e7be45507b9dae4454', '', '', '', null, null, 'd8677290bd5411e7be45507b9dae4454', 'd864eb59bd5411e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 17:29:42', '2017-10-30 17:29:42');
INSERT INTO `flow_exec_line` VALUES ('dc12394dbd5611e7be45507b9dae4454', '123', '9e40c480b54011e7a96c507b9dae4454', 'dc8ac93ab95311e791be507b9dae4454', 'dbf289abbd5611e7be45507b9dae4454', '', '', '', null, null, 'dbf289abbd5611e7be45507b9dae4454', 'dbf4c5b0bd5611e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 17:44:02', '2017-10-30 17:44:02');
INSERT INTO `flow_exec_line` VALUES ('dc134420bd5611e7be45507b9dae4454', '124', '9e40c480b54011e7a96c507b9dae4454', 'dc8d0ff1b95311e791be507b9dae4454', 'dbf289abbd5611e7be45507b9dae4454', '', '', '', null, null, 'dbf4c5b0bd5611e7be45507b9dae4454', 'dbf65341bd5611e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 17:44:02', '2017-10-30 17:44:02');
INSERT INTO `flow_exec_line` VALUES ('dc145199bd5611e7be45507b9dae4454', '125', '9e40c480b54011e7a96c507b9dae4454', 'dc8dd903b95311e791be507b9dae4454', 'dbf289abbd5611e7be45507b9dae4454', '', '', '', null, null, 'dbf65341bd5611e7be45507b9dae4454', 'dbf8089cbd5611e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 17:44:02', '2017-10-30 17:44:02');
INSERT INTO `flow_exec_line` VALUES ('dc153a76bd5611e7be45507b9dae4454', '126', '9e40c480b54011e7a96c507b9dae4454', 'dc8e71f7b95311e791be507b9dae4454', 'dbf289abbd5611e7be45507b9dae4454', '', '', '', null, null, 'dbf8089cbd5611e7be45507b9dae4454', 'dbf958edbd5611e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 17:44:02', '2017-10-30 17:44:02');
INSERT INTO `flow_exec_line` VALUES ('dc162f30bd5611e7be45507b9dae4454', '127', '9e40c480b54011e7a96c507b9dae4454', 'dc8f047db95311e791be507b9dae4454', 'dbf289abbd5611e7be45507b9dae4454', '', '', '', null, null, 'dbf958edbd5611e7be45507b9dae4454', 'dc0fe0babd5611e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 17:44:02', '2017-10-30 17:44:02');
INSERT INTO `flow_exec_line` VALUES ('dc170e4dbd5611e7be45507b9dae4454', '128', '9e40c480b54011e7a96c507b9dae4454', 'dc8f900bb95311e791be507b9dae4454', 'dbf289abbd5611e7be45507b9dae4454', '', '', '', null, null, 'dc0fe0babd5611e7be45507b9dae4454', 'dc111eefbd5611e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 17:44:02', '2017-10-30 17:44:02');
INSERT INTO `flow_exec_line` VALUES ('de845b25bd5f11e7be45507b9dae4454', '145', '59dd99f3bd2911e7be45507b9dae4454', '0042216cbd2a11e7be45507b9dae4454', 'de78c1edbd5f11e7be45507b9dae4454', '', '', '', null, null, 'de78c1edbd5f11e7be45507b9dae4454', 'de7b6e2cbd5f11e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 18:48:37', '2017-10-30 18:48:37');
INSERT INTO `flow_exec_line` VALUES ('de868d5dbd5f11e7be45507b9dae4454', '146', '59dd99f3bd2911e7be45507b9dae4454', '004c5916bd2a11e7be45507b9dae4454', 'de78c1edbd5f11e7be45507b9dae4454', '', '', '', null, null, 'de7b6e2cbd5f11e7be45507b9dae4454', 'de7d79b4bd5f11e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 18:48:37', '2017-10-30 18:48:37');
INSERT INTO `flow_exec_line` VALUES ('de88a570bd5f11e7be45507b9dae4454', '147', '59dd99f3bd2911e7be45507b9dae4454', '00503f9ebd2a11e7be45507b9dae4454', 'de78c1edbd5f11e7be45507b9dae4454', '', '', '', null, null, 'de7d79b4bd5f11e7be45507b9dae4454', 'de806fbabd5f11e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 18:48:37', '2017-10-30 18:48:37');
INSERT INTO `flow_exec_line` VALUES ('de8a7cb4bd5f11e7be45507b9dae4454', '148', '59dd99f3bd2911e7be45507b9dae4454', '00525d94bd2a11e7be45507b9dae4454', 'de78c1edbd5f11e7be45507b9dae4454', '', '', '', null, null, 'de806fbabd5f11e7be45507b9dae4454', 'de8275cabd5f11e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 18:48:37', '2017-10-30 18:48:37');
INSERT INTO `flow_exec_line` VALUES ('e3cc80d6bd2511e7be45507b9dae4454', '85', '9e40c480b54011e7a96c507b9dae4454', 'dc8ac93ab95311e791be507b9dae4454', 'e3c2200cbd2511e7be45507b9dae4454', '', '', '', null, null, 'e3c2200cbd2511e7be45507b9dae4454', 'e3c43172bd2511e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 11:53:29', '2017-10-30 11:53:29');
INSERT INTO `flow_exec_line` VALUES ('e3cd7424bd2511e7be45507b9dae4454', '86', '9e40c480b54011e7a96c507b9dae4454', 'dc8d0ff1b95311e791be507b9dae4454', 'e3c2200cbd2511e7be45507b9dae4454', '', '', '', null, null, 'e3c43172bd2511e7be45507b9dae4454', 'e3c55ff6bd2511e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 11:53:29', '2017-10-30 11:53:29');
INSERT INTO `flow_exec_line` VALUES ('e3ce452cbd2511e7be45507b9dae4454', '87', '9e40c480b54011e7a96c507b9dae4454', 'dc8dd903b95311e791be507b9dae4454', 'e3c2200cbd2511e7be45507b9dae4454', '', '', '', null, null, 'e3c55ff6bd2511e7be45507b9dae4454', 'e3c7e095bd2511e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 11:53:29', '2017-10-30 11:53:29');
INSERT INTO `flow_exec_line` VALUES ('e3cf3ec1bd2511e7be45507b9dae4454', '88', '9e40c480b54011e7a96c507b9dae4454', 'dc8e71f7b95311e791be507b9dae4454', 'e3c2200cbd2511e7be45507b9dae4454', '', '', '', null, null, 'e3c7e095bd2511e7be45507b9dae4454', 'e3c8e73dbd2511e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 11:53:29', '2017-10-30 11:53:29');
INSERT INTO `flow_exec_line` VALUES ('e3d15eecbd2511e7be45507b9dae4454', '89', '9e40c480b54011e7a96c507b9dae4454', 'dc8f047db95311e791be507b9dae4454', 'e3c2200cbd2511e7be45507b9dae4454', '', '', '', null, null, 'e3c8e73dbd2511e7be45507b9dae4454', 'e3ca9620bd2511e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 11:53:29', '2017-10-30 11:53:29');
INSERT INTO `flow_exec_line` VALUES ('e3d21e95bd2511e7be45507b9dae4454', '90', '9e40c480b54011e7a96c507b9dae4454', 'dc8f900bb95311e791be507b9dae4454', 'e3c2200cbd2511e7be45507b9dae4454', '', '', '', null, null, 'e3ca9620bd2511e7be45507b9dae4454', 'e3cb9680bd2511e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 11:53:29', '2017-10-30 11:53:29');
INSERT INTO `flow_exec_line` VALUES ('e50f8159bd1e11e7be45507b9dae4454', '79', '9e40c480b54011e7a96c507b9dae4454', 'dc8ac93ab95311e791be507b9dae4454', 'e4fad48ebd1e11e7be45507b9dae4454', '', '', '', null, null, 'e4fad48ebd1e11e7be45507b9dae4454', 'e5018dedbd1e11e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 11:03:25', '2017-10-30 11:03:25');
INSERT INTO `flow_exec_line` VALUES ('e51046aabd1e11e7be45507b9dae4454', '80', '9e40c480b54011e7a96c507b9dae4454', 'dc8d0ff1b95311e791be507b9dae4454', 'e4fad48ebd1e11e7be45507b9dae4454', '', '', '', null, null, 'e5018dedbd1e11e7be45507b9dae4454', 'e5026f9cbd1e11e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 11:03:25', '2017-10-30 11:03:25');
INSERT INTO `flow_exec_line` VALUES ('e510e37bbd1e11e7be45507b9dae4454', '81', '9e40c480b54011e7a96c507b9dae4454', 'dc8dd903b95311e791be507b9dae4454', 'e4fad48ebd1e11e7be45507b9dae4454', '', '', '', null, null, 'e5026f9cbd1e11e7be45507b9dae4454', 'e509ce13bd1e11e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 11:03:25', '2017-10-30 11:03:25');
INSERT INTO `flow_exec_line` VALUES ('e511d1dfbd1e11e7be45507b9dae4454', '82', '9e40c480b54011e7a96c507b9dae4454', 'dc8e71f7b95311e791be507b9dae4454', 'e4fad48ebd1e11e7be45507b9dae4454', '', '', '', null, null, 'e509ce13bd1e11e7be45507b9dae4454', 'e50b4d5abd1e11e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 11:03:25', '2017-10-30 11:03:25');
INSERT INTO `flow_exec_line` VALUES ('e513d2b9bd1e11e7be45507b9dae4454', '83', '9e40c480b54011e7a96c507b9dae4454', 'dc8f047db95311e791be507b9dae4454', 'e4fad48ebd1e11e7be45507b9dae4454', '', '', '', null, null, 'e50b4d5abd1e11e7be45507b9dae4454', 'e50dbaddbd1e11e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 11:03:25', '2017-10-30 11:03:25');
INSERT INTO `flow_exec_line` VALUES ('e514a3ecbd1e11e7be45507b9dae4454', '84', '9e40c480b54011e7a96c507b9dae4454', 'dc8f900bb95311e791be507b9dae4454', 'e4fad48ebd1e11e7be45507b9dae4454', '', '', '', null, null, 'e50dbaddbd1e11e7be45507b9dae4454', 'e50e9e45bd1e11e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 11:03:25', '2017-10-30 11:03:25');

-- ----------------------------
-- Table structure for flow_exec_node
-- ----------------------------
DROP TABLE IF EXISTS `flow_exec_node`;
CREATE TABLE `flow_exec_node` (
  `id` varchar(32) NOT NULL,
  `sort` bigint(20) NOT NULL AUTO_INCREMENT,
  `proc_def_id` varchar(32) DEFAULT NULL,
  `tl_node_id` varchar(32) DEFAULT NULL,
  `data_id` varchar(32) DEFAULT NULL,
  `data_type` varchar(30) DEFAULT NULL,
  `proc_inst_id` varchar(32) DEFAULT NULL,
  `progress_text` varchar(200) DEFAULT NULL,
  `node_name` varchar(100) DEFAULT NULL,
  `node_code` varchar(50) DEFAULT NULL,
  `node_type` varchar(20) DEFAULT NULL,
  `left_pos` decimal(8,2) DEFAULT NULL,
  `top_pos` decimal(8,2) DEFAULT NULL,
  `width` varchar(20) DEFAULT NULL,
  `height` varchar(255) DEFAULT NULL,
  `sub_def_id` varchar(32) DEFAULT NULL,
  `proc_type` varchar(20) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `requirement` varchar(300) DEFAULT NULL,
  `note` varchar(300) DEFAULT NULL,
  `limit_day` int(11) DEFAULT NULL,
  `duty_depart_id` varchar(32) DEFAULT NULL,
  `duty_user_id` varchar(32) DEFAULT NULL,
  `allot_strategy` smallint(6) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `status` smallint(6) DEFAULT NULL COMMENT '状态',
  `check_status` smallint(6) DEFAULT NULL COMMENT '状态',
  `flow_status` smallint(6) DEFAULT NULL COMMENT '状态',
  `flag` smallint(6) DEFAULT NULL,
  `create_by` varchar(50) DEFAULT NULL,
  `update_by` varchar(50) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_exec_node_sort` (`sort`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=262 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of flow_exec_node
-- ----------------------------
INSERT INTO `flow_exec_node` VALUES ('024b911dbd3c11e7be45507b9dae4454', '111', '59dd99f3bd2911e7be45507b9dae4454', '000d2d76bd2a11e7be45507b9dae4454', '023f5a39bd3c11e7be45507b9dae4454', 'run_waste_transfer', '024b911dbd3c11e7be45507b9dae4454', '计价部门', 'node_1', 'flowPanel_node_1', 'start', '111.00', '82.00', '130', '55', null, null, '申报', '', null, '1', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 14:31:55', '2017-10-30 16:32:07');
INSERT INTO `flow_exec_node` VALUES ('02530986bd3c11e7be45507b9dae4454', '112', '59dd99f3bd2911e7be45507b9dae4454', '001d25cebd2a11e7be45507b9dae4454', '023f5a39bd3c11e7be45507b9dae4454', 'run_waste_transfer', '024b911dbd3c11e7be45507b9dae4454', null, 'node_3', 'flowPanel_node_3', 'node', '342.00', '80.00', '130', '55', null, null, '校对部门', '', null, '2', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 14:31:55', '2017-10-30 16:32:07');
INSERT INTO `flow_exec_node` VALUES ('0255020ebd3c11e7be45507b9dae4454', '113', '59dd99f3bd2911e7be45507b9dae4454', '002a050cbd2a11e7be45507b9dae4454', '023f5a39bd3c11e7be45507b9dae4454', 'run_waste_transfer', '024b911dbd3c11e7be45507b9dae4454', null, 'node_4', 'flowPanel_node_4', 'node', '572.00', '91.00', '130', '55', null, null, '计价部门', '', null, '3', null, null, null, null, '0', null, '1', '1', 'admin', null, '2017-10-30 14:31:55', '2017-10-30 16:32:07');
INSERT INTO `flow_exec_node` VALUES ('0256d0cebd3c11e7be45507b9dae4454', '114', '59dd99f3bd2911e7be45507b9dae4454', '0031d71cbd2a11e7be45507b9dae4454', '023f5a39bd3c11e7be45507b9dae4454', 'run_waste_transfer', '024b911dbd3c11e7be45507b9dae4454', null, 'node_5', 'flowPanel_node_5', 'node', '808.00', '99.00', '130', '55', null, null, '采购部门', '', null, '1', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-10-30 14:31:55', '2017-10-30 14:31:55');
INSERT INTO `flow_exec_node` VALUES ('025a7995bd3c11e7be45507b9dae4454', '115', '59dd99f3bd2911e7be45507b9dae4454', '00387985bd2a11e7be45507b9dae4454', '023f5a39bd3c11e7be45507b9dae4454', 'run_waste_transfer', '024b911dbd3c11e7be45507b9dae4454', null, 'node_7', 'flowPanel_node_7', 'end', '824.00', '211.00', '130', '55', null, null, '注销部门', '', null, '4', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-10-30 14:31:55', '2017-10-30 14:31:55');
INSERT INTO `flow_exec_node` VALUES ('080cc0c3beef11e7b827507b9dae4454', '213', '8a3be65eb89911e783e5507b9dae4454', 'b9c12bf1bd2b11e7be45507b9dae4454', '080881edbeef11e7b827507b9dae4454', 'run_take_monitor', '080cc0c3beef11e7b827507b9dae4454', '部门负责人意见', 'node_1', 'flowPanel_node_1', 'start', '168.00', '98.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-11-01 18:25:56', '2017-11-01 18:25:56');
INSERT INTO `flow_exec_node` VALUES ('0816ef70beef11e7b827507b9dae4454', '214', '8a3be65eb89911e783e5507b9dae4454', 'b9c270a9bd2b11e7be45507b9dae4454', '080881edbeef11e7b827507b9dae4454', 'run_take_monitor', '080cc0c3beef11e7b827507b9dae4454', null, 'node_2', 'flowPanel_node_2', 'end', '854.00', '110.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-11-01 18:25:56', '2017-11-01 18:25:56');
INSERT INTO `flow_exec_node` VALUES ('081815dbbeef11e7b827507b9dae4454', '215', '8a3be65eb89911e783e5507b9dae4454', 'b9c547d9bd2b11e7be45507b9dae4454', '080881edbeef11e7b827507b9dae4454', 'run_take_monitor', '080cc0c3beef11e7b827507b9dae4454', null, 'node_3', 'flowPanel_node_3', 'node', '393.00', '112.00', '130', '55', null, null, '部门负责人意见', '', null, '0', null, null, null, null, '0', null, '1', '1', 'admin', null, '2017-11-01 18:25:56', '2017-11-01 18:25:56');
INSERT INTO `flow_exec_node` VALUES ('081948b7beef11e7b827507b9dae4454', '216', '8a3be65eb89911e783e5507b9dae4454', 'b9c65c12bd2b11e7be45507b9dae4454', '080881edbeef11e7b827507b9dae4454', 'run_take_monitor', '080cc0c3beef11e7b827507b9dae4454', null, 'node_4', 'flowPanel_node_4', 'node', '634.00', '110.00', '130', '55', null, null, '分管领导意见', '', null, '0', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-11-01 18:25:56', '2017-11-01 18:25:56');
INSERT INTO `flow_exec_node` VALUES ('21ae7eaebddf11e797cd507b9dae4454', '179', '8a3be65eb89911e783e5507b9dae4454', 'b9c12bf1bd2b11e7be45507b9dae4454', 'a8c0936ebdde11e797cd507b9dae4454', 'run_take_monitor', '21ae7eaebddf11e797cd507b9dae4454', '分管领导意见', 'node_1', 'flowPanel_node_1', 'start', '168.00', '98.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, null, '1', null, '2', '1', 'admin', null, '2017-10-31 09:59:35', '2017-10-31 10:04:13');
INSERT INTO `flow_exec_node` VALUES ('21b0790cbddf11e797cd507b9dae4454', '180', '8a3be65eb89911e783e5507b9dae4454', 'b9c270a9bd2b11e7be45507b9dae4454', 'a8c0936ebdde11e797cd507b9dae4454', 'run_take_monitor', '21ae7eaebddf11e797cd507b9dae4454', null, 'node_2', 'flowPanel_node_2', 'end', '854.00', '110.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, null, '0', null, '1', '1', 'admin', null, '2017-10-31 09:59:35', '2017-10-31 10:04:13');
INSERT INTO `flow_exec_node` VALUES ('21b23d97bddf11e797cd507b9dae4454', '181', '8a3be65eb89911e783e5507b9dae4454', 'b9c547d9bd2b11e7be45507b9dae4454', 'a8c0936ebdde11e797cd507b9dae4454', 'run_take_monitor', '21ae7eaebddf11e797cd507b9dae4454', null, 'node_3', 'flowPanel_node_3', 'node', '393.00', '112.00', '130', '55', null, null, '部门负责人意见', '', null, '0', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-31 09:59:35', '2017-10-31 10:00:25');
INSERT INTO `flow_exec_node` VALUES ('21b3cc92bddf11e797cd507b9dae4454', '182', '8a3be65eb89911e783e5507b9dae4454', 'b9c65c12bd2b11e7be45507b9dae4454', 'a8c0936ebdde11e797cd507b9dae4454', 'run_take_monitor', '21ae7eaebddf11e797cd507b9dae4454', null, 'node_4', 'flowPanel_node_4', 'node', '634.00', '110.00', '130', '55', null, null, '分管领导意见', '', null, '0', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-31 09:59:35', '2017-10-31 10:04:13');
INSERT INTO `flow_exec_node` VALUES ('224b86ebbeef11e7b827507b9dae4454', '217', '8a3be65eb89911e783e5507b9dae4454', 'b9c12bf1bd2b11e7be45507b9dae4454', '2247aebebeef11e7b827507b9dae4454', 'run_take_monitor', '224b86ebbeef11e7b827507b9dae4454', '部门负责人意见', 'node_1', 'flowPanel_node_1', 'start', '168.00', '98.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-11-01 18:26:40', '2017-11-01 18:26:40');
INSERT INTO `flow_exec_node` VALUES ('224cc576beef11e7b827507b9dae4454', '218', '8a3be65eb89911e783e5507b9dae4454', 'b9c270a9bd2b11e7be45507b9dae4454', '2247aebebeef11e7b827507b9dae4454', 'run_take_monitor', '224b86ebbeef11e7b827507b9dae4454', null, 'node_2', 'flowPanel_node_2', 'end', '854.00', '110.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-11-01 18:26:40', '2017-11-01 18:26:40');
INSERT INTO `flow_exec_node` VALUES ('224e0244beef11e7b827507b9dae4454', '219', '8a3be65eb89911e783e5507b9dae4454', 'b9c547d9bd2b11e7be45507b9dae4454', '2247aebebeef11e7b827507b9dae4454', 'run_take_monitor', '224b86ebbeef11e7b827507b9dae4454', null, 'node_3', 'flowPanel_node_3', 'node', '393.00', '112.00', '130', '55', null, null, '部门负责人意见', '', null, '0', null, null, null, null, '0', null, '1', '1', 'admin', null, '2017-11-01 18:26:40', '2017-11-01 18:26:40');
INSERT INTO `flow_exec_node` VALUES ('224f3d21beef11e7b827507b9dae4454', '220', '8a3be65eb89911e783e5507b9dae4454', 'b9c65c12bd2b11e7be45507b9dae4454', '2247aebebeef11e7b827507b9dae4454', 'run_take_monitor', '224b86ebbeef11e7b827507b9dae4454', null, 'node_4', 'flowPanel_node_4', 'node', '634.00', '110.00', '130', '55', null, null, '分管领导意见', '', null, '0', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-11-01 18:26:40', '2017-11-01 18:26:40');
INSERT INTO `flow_exec_node` VALUES ('25ed0a00be0d11e797cd507b9dae4454', '191', '8a3be65eb89911e783e5507b9dae4454', 'b9c12bf1bd2b11e7be45507b9dae4454', 'e96b160cbe0711e797cd507b9dae4454', 'run_take_monitor', '25ed0a00be0d11e797cd507b9dae4454', '部门负责人意见', 'node_1', 'flowPanel_node_1', 'start', '168.00', '98.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, null, '0', null, '2', '1', 'bgs', null, '2017-10-31 15:28:59', '2017-10-31 15:28:59');
INSERT INTO `flow_exec_node` VALUES ('25eed4c2be0d11e797cd507b9dae4454', '192', '8a3be65eb89911e783e5507b9dae4454', 'b9c270a9bd2b11e7be45507b9dae4454', 'e96b160cbe0711e797cd507b9dae4454', 'run_take_monitor', '25ed0a00be0d11e797cd507b9dae4454', null, 'node_2', 'flowPanel_node_2', 'end', '854.00', '110.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, null, '0', null, '0', '1', 'bgs', null, '2017-10-31 15:28:59', '2017-10-31 15:28:59');
INSERT INTO `flow_exec_node` VALUES ('25efe3aebe0d11e797cd507b9dae4454', '193', '8a3be65eb89911e783e5507b9dae4454', 'b9c547d9bd2b11e7be45507b9dae4454', 'e96b160cbe0711e797cd507b9dae4454', 'run_take_monitor', '25ed0a00be0d11e797cd507b9dae4454', null, 'node_3', 'flowPanel_node_3', 'node', '393.00', '112.00', '130', '55', null, null, '部门负责人意见', '', null, '0', null, null, null, null, '0', null, '1', '1', 'bgs', null, '2017-10-31 15:28:59', '2017-10-31 15:28:59');
INSERT INTO `flow_exec_node` VALUES ('25f106f4be0d11e797cd507b9dae4454', '194', '8a3be65eb89911e783e5507b9dae4454', 'b9c65c12bd2b11e7be45507b9dae4454', 'e96b160cbe0711e797cd507b9dae4454', 'run_take_monitor', '25ed0a00be0d11e797cd507b9dae4454', null, 'node_4', 'flowPanel_node_4', 'node', '634.00', '110.00', '130', '55', null, null, '分管领导意见', '', null, '0', null, null, null, null, '0', null, '0', '1', 'bgs', null, '2017-10-31 15:28:59', '2017-10-31 15:28:59');
INSERT INTO `flow_exec_node` VALUES ('30f08e7ebea011e7b827507b9dae4454', '195', '9e40c480b54011e7a96c507b9dae4454', 'dc823a5ab95311e791be507b9dae4454', '30eb3112bea011e7b827507b9dae4454', 'run_abnormal_receipts', '30f08e7ebea011e7b827507b9dae4454', '收费站意见', 'node_9', 'flowPanel_node_9', 'start', '195.00', '53.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-11-01 09:01:28', '2017-11-01 09:04:06');
INSERT INTO `flow_exec_node` VALUES ('30f26037bea011e7b827507b9dae4454', '196', '9e40c480b54011e7a96c507b9dae4454', 'dc830dcbb95311e791be507b9dae4454', '30eb3112bea011e7b827507b9dae4454', 'run_abnormal_receipts', '30f08e7ebea011e7b827507b9dae4454', null, 'node_10', 'flowPanel_node_10', 'node', '375.00', '99.00', '128', '53', null, null, '收费站意见', '', null, '2', null, null, null, null, '0', null, '1', '1', 'admin', null, '2017-11-01 09:01:28', '2017-11-01 09:04:06');
INSERT INTO `flow_exec_node` VALUES ('30f3650fbea011e7b827507b9dae4454', '197', '9e40c480b54011e7a96c507b9dae4454', 'dc84e5f9b95311e791be507b9dae4454', '30eb3112bea011e7b827507b9dae4454', 'run_abnormal_receipts', '30f08e7ebea011e7b827507b9dae4454', null, 'node_11', 'flowPanel_node_11', 'node', '385.00', '219.00', '128', '53', null, null, '稽查意见', '', null, '2', null, null, null, null, '0', null, '3', '1', 'admin', null, '2017-11-01 09:01:28', '2017-11-01 09:04:06');
INSERT INTO `flow_exec_node` VALUES ('30f4827ebea011e7b827507b9dae4454', '198', '9e40c480b54011e7a96c507b9dae4454', 'dc865c63b95311e791be507b9dae4454', '30eb3112bea011e7b827507b9dae4454', 'run_abnormal_receipts', '30f08e7ebea011e7b827507b9dae4454', null, 'node_12', 'flowPanel_node_12', 'node', '389.00', '316.00', '128', '53', null, null, '营运部意见', '', null, '2', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-11-01 09:01:28', '2017-11-01 09:01:28');
INSERT INTO `flow_exec_node` VALUES ('30f5a7c0bea011e7b827507b9dae4454', '199', '9e40c480b54011e7a96c507b9dae4454', 'dc87b6d0b95311e791be507b9dae4454', '30eb3112bea011e7b827507b9dae4454', 'run_abnormal_receipts', '30f08e7ebea011e7b827507b9dae4454', null, 'node_13', 'flowPanel_node_13', 'node', '379.00', '434.00', '128', '53', null, null, '相关部门意见', '', null, '2', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-11-01 09:01:28', '2017-11-01 09:01:28');
INSERT INTO `flow_exec_node` VALUES ('30f6e969bea011e7b827507b9dae4454', '200', '9e40c480b54011e7a96c507b9dae4454', 'dc88ff8cb95311e791be507b9dae4454', '30eb3112bea011e7b827507b9dae4454', 'run_abnormal_receipts', '30f08e7ebea011e7b827507b9dae4454', null, 'node_14', 'flowPanel_node_14', 'node', '384.00', '527.00', '128', '53', null, null, '领导批示', '', null, '2', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-11-01 09:01:28', '2017-11-01 09:01:28');
INSERT INTO `flow_exec_node` VALUES ('30f7fb29bea011e7b827507b9dae4454', '201', '9e40c480b54011e7a96c507b9dae4454', 'dc8a2d04b95311e791be507b9dae4454', '30eb3112bea011e7b827507b9dae4454', 'run_abnormal_receipts', '30f08e7ebea011e7b827507b9dae4454', null, 'node_20', 'flowPanel_node_20', 'end', '675.00', '532.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-11-01 09:01:28', '2017-11-01 09:01:28');
INSERT INTO `flow_exec_node` VALUES ('3899f870bde411e797cd507b9dae4454', '183', '8a3be65eb89911e783e5507b9dae4454', 'b9c12bf1bd2b11e7be45507b9dae4454', '3895f6dfbde411e797cd507b9dae4454', 'run_take_monitor', '3899f870bde411e797cd507b9dae4454', '分管领导意见', 'node_1', 'flowPanel_node_1', 'start', '168.00', '98.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-31 10:36:01', '2017-10-31 10:36:27');
INSERT INTO `flow_exec_node` VALUES ('389c8809bde411e797cd507b9dae4454', '184', '8a3be65eb89911e783e5507b9dae4454', 'b9c270a9bd2b11e7be45507b9dae4454', '3895f6dfbde411e797cd507b9dae4454', 'run_take_monitor', '3899f870bde411e797cd507b9dae4454', null, 'node_2', 'flowPanel_node_2', 'end', '854.00', '110.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-10-31 10:36:01', '2017-10-31 10:36:01');
INSERT INTO `flow_exec_node` VALUES ('389dcb7fbde411e797cd507b9dae4454', '185', '8a3be65eb89911e783e5507b9dae4454', 'b9c547d9bd2b11e7be45507b9dae4454', '3895f6dfbde411e797cd507b9dae4454', 'run_take_monitor', '3899f870bde411e797cd507b9dae4454', null, 'node_3', 'flowPanel_node_3', 'node', '393.00', '112.00', '130', '55', null, null, '部门负责人意见', '', null, '0', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-31 10:36:01', '2017-10-31 10:36:27');
INSERT INTO `flow_exec_node` VALUES ('389f16d4bde411e797cd507b9dae4454', '186', '8a3be65eb89911e783e5507b9dae4454', 'b9c65c12bd2b11e7be45507b9dae4454', '3895f6dfbde411e797cd507b9dae4454', 'run_take_monitor', '3899f870bde411e797cd507b9dae4454', null, 'node_4', 'flowPanel_node_4', 'node', '634.00', '110.00', '130', '55', null, null, '分管领导意见', '', null, '0', null, null, null, null, '0', null, '1', '1', 'admin', null, '2017-10-31 10:36:01', '2017-10-31 10:36:27');
INSERT INTO `flow_exec_node` VALUES ('3d381d7cbd5911e7be45507b9dae4454', '154', '8a3be65eb89911e783e5507b9dae4454', 'b9c12bf1bd2b11e7be45507b9dae4454', '3d31b37bbd5911e7be45507b9dae4454', 'run_take_monitor', '3d381d7cbd5911e7be45507b9dae4454', '分管领导意见', 'node_1', 'flowPanel_node_1', 'start', '168.00', '98.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, null, '1', null, '2', '1', 'admin', null, '2017-10-30 18:01:09', '2017-10-30 18:07:09');
INSERT INTO `flow_exec_node` VALUES ('3d3a2529bd5911e7be45507b9dae4454', '155', '8a3be65eb89911e783e5507b9dae4454', 'b9c270a9bd2b11e7be45507b9dae4454', '3d31b37bbd5911e7be45507b9dae4454', 'run_take_monitor', '3d381d7cbd5911e7be45507b9dae4454', null, 'node_2', 'flowPanel_node_2', 'end', '854.00', '110.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, null, '0', null, '1', '1', 'admin', null, '2017-10-30 18:01:09', '2017-10-30 18:07:09');
INSERT INTO `flow_exec_node` VALUES ('3d3bb0cdbd5911e7be45507b9dae4454', '156', '8a3be65eb89911e783e5507b9dae4454', 'b9c547d9bd2b11e7be45507b9dae4454', '3d31b37bbd5911e7be45507b9dae4454', 'run_take_monitor', '3d381d7cbd5911e7be45507b9dae4454', null, 'node_3', 'flowPanel_node_3', 'node', '393.00', '112.00', '130', '55', null, null, '部门负责人意见', '', null, '0', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 18:01:09', '2017-10-30 18:01:21');
INSERT INTO `flow_exec_node` VALUES ('3d3d0819bd5911e7be45507b9dae4454', '157', '8a3be65eb89911e783e5507b9dae4454', 'b9c65c12bd2b11e7be45507b9dae4454', '3d31b37bbd5911e7be45507b9dae4454', 'run_take_monitor', '3d381d7cbd5911e7be45507b9dae4454', null, 'node_4', 'flowPanel_node_4', 'node', '634.00', '110.00', '130', '55', null, null, '分管领导意见', '', null, '0', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 18:01:09', '2017-10-30 18:07:09');
INSERT INTO `flow_exec_node` VALUES ('4027e8a1bd4811e7be45507b9dae4454', '116', '8a3be65eb89911e783e5507b9dae4454', 'b9c12bf1bd2b11e7be45507b9dae4454', 'f483de6fbd2711e7be45507b9dae4454', 'run_take_monitor', '4027e8a1bd4811e7be45507b9dae4454', null, 'node_1', 'flowPanel_node_1', 'start', '168.00', '98.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 15:59:33', '2017-10-30 15:59:33');
INSERT INTO `flow_exec_node` VALUES ('402cc569bd4811e7be45507b9dae4454', '117', '8a3be65eb89911e783e5507b9dae4454', 'b9c270a9bd2b11e7be45507b9dae4454', 'f483de6fbd2711e7be45507b9dae4454', 'run_take_monitor', '4027e8a1bd4811e7be45507b9dae4454', null, 'node_2', 'flowPanel_node_2', 'end', '854.00', '110.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-10-30 15:59:33', '2017-10-30 15:59:33');
INSERT INTO `flow_exec_node` VALUES ('402df2fbbd4811e7be45507b9dae4454', '118', '8a3be65eb89911e783e5507b9dae4454', 'b9c547d9bd2b11e7be45507b9dae4454', 'f483de6fbd2711e7be45507b9dae4454', 'run_take_monitor', '4027e8a1bd4811e7be45507b9dae4454', null, 'node_3', 'flowPanel_node_3', 'node', '393.00', '112.00', '130', '55', null, null, '部门负责人意见', '', null, '0', null, null, null, null, '0', null, '1', '1', 'admin', null, '2017-10-30 15:59:33', '2017-10-30 15:59:33');
INSERT INTO `flow_exec_node` VALUES ('402fa09ebd4811e7be45507b9dae4454', '119', '8a3be65eb89911e783e5507b9dae4454', 'b9c65c12bd2b11e7be45507b9dae4454', 'f483de6fbd2711e7be45507b9dae4454', 'run_take_monitor', '4027e8a1bd4811e7be45507b9dae4454', null, 'node_4', 'flowPanel_node_4', 'node', '634.00', '110.00', '130', '55', null, null, '分管领导意见', '', null, '0', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-10-30 15:59:33', '2017-10-30 15:59:33');
INSERT INTO `flow_exec_node` VALUES ('5f66889bc04011e7ab51507b9dae4454', '243', '59dd99f3bd2911e7be45507b9dae4454', '000d2d76bd2a11e7be45507b9dae4454', '5f5f2e52c04011e7ab51507b9dae4454', 'run_waste_transfer', '5f66889bc04011e7ab51507b9dae4454', '校对部门', 'node_1', 'flowPanel_node_1', 'start', '111.00', '82.00', '130', '55', null, null, '申报', '', null, '1', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-11-03 10:40:37', '2017-11-03 10:40:37');
INSERT INTO `flow_exec_node` VALUES ('5f6d4de0c04011e7ab51507b9dae4454', '244', '59dd99f3bd2911e7be45507b9dae4454', '001d25cebd2a11e7be45507b9dae4454', '5f5f2e52c04011e7ab51507b9dae4454', 'run_waste_transfer', '5f66889bc04011e7ab51507b9dae4454', null, 'node_3', 'flowPanel_node_3', 'node', '342.00', '80.00', '130', '55', null, null, '校对部门', '', null, '2', null, null, null, null, '0', null, '1', '1', 'admin', null, '2017-11-03 10:40:37', '2017-11-03 10:40:37');
INSERT INTO `flow_exec_node` VALUES ('5f70e393c04011e7ab51507b9dae4454', '245', '59dd99f3bd2911e7be45507b9dae4454', '002a050cbd2a11e7be45507b9dae4454', '5f5f2e52c04011e7ab51507b9dae4454', 'run_waste_transfer', '5f66889bc04011e7ab51507b9dae4454', null, 'node_4', 'flowPanel_node_4', 'node', '572.00', '91.00', '130', '55', null, null, '计价部门', '', null, '3', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-11-03 10:40:37', '2017-11-03 10:40:37');
INSERT INTO `flow_exec_node` VALUES ('5f741243c04011e7ab51507b9dae4454', '246', '59dd99f3bd2911e7be45507b9dae4454', '0031d71cbd2a11e7be45507b9dae4454', '5f5f2e52c04011e7ab51507b9dae4454', 'run_waste_transfer', '5f66889bc04011e7ab51507b9dae4454', null, 'node_5', 'flowPanel_node_5', 'node', '808.00', '99.00', '130', '55', null, null, '采购部门', '', null, '1', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-11-03 10:40:37', '2017-11-03 10:40:37');
INSERT INTO `flow_exec_node` VALUES ('5f750b3bc04011e7ab51507b9dae4454', '247', '59dd99f3bd2911e7be45507b9dae4454', '00387985bd2a11e7be45507b9dae4454', '5f5f2e52c04011e7ab51507b9dae4454', 'run_waste_transfer', '5f66889bc04011e7ab51507b9dae4454', null, 'node_7', 'flowPanel_node_7', 'end', '824.00', '211.00', '130', '55', null, null, '注销部门', '', null, '4', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-11-03 10:40:37', '2017-11-03 10:40:37');
INSERT INTO `flow_exec_node` VALUES ('66290378bd5b11e7be45507b9dae4454', '165', '8a3be65eb89911e783e5507b9dae4454', 'b9c12bf1bd2b11e7be45507b9dae4454', 'a27371f1bd5a11e7be45507b9dae4454', 'run_take_monitor', '66290378bd5b11e7be45507b9dae4454', '部门负责人意见', 'node_1', 'flowPanel_node_1', 'start', '168.00', '98.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 18:16:37', '2017-10-30 18:16:37');
INSERT INTO `flow_exec_node` VALUES ('662a6a80bd5b11e7be45507b9dae4454', '166', '8a3be65eb89911e783e5507b9dae4454', 'b9c270a9bd2b11e7be45507b9dae4454', 'a27371f1bd5a11e7be45507b9dae4454', 'run_take_monitor', '66290378bd5b11e7be45507b9dae4454', null, 'node_2', 'flowPanel_node_2', 'end', '854.00', '110.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-10-30 18:16:37', '2017-10-30 18:16:37');
INSERT INTO `flow_exec_node` VALUES ('662badd7bd5b11e7be45507b9dae4454', '167', '8a3be65eb89911e783e5507b9dae4454', 'b9c547d9bd2b11e7be45507b9dae4454', 'a27371f1bd5a11e7be45507b9dae4454', 'run_take_monitor', '66290378bd5b11e7be45507b9dae4454', null, 'node_3', 'flowPanel_node_3', 'node', '393.00', '112.00', '130', '55', null, null, '部门负责人意见', '', null, '0', null, null, null, null, '0', null, '1', '1', 'admin', null, '2017-10-30 18:16:37', '2017-10-30 18:16:37');
INSERT INTO `flow_exec_node` VALUES ('662cdf3bbd5b11e7be45507b9dae4454', '168', '8a3be65eb89911e783e5507b9dae4454', 'b9c65c12bd2b11e7be45507b9dae4454', 'a27371f1bd5a11e7be45507b9dae4454', 'run_take_monitor', '66290378bd5b11e7be45507b9dae4454', null, 'node_4', 'flowPanel_node_4', 'node', '634.00', '110.00', '130', '55', null, null, '分管领导意见', '', null, '0', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-10-30 18:16:37', '2017-10-30 18:16:37');
INSERT INTO `flow_exec_node` VALUES ('6e379661bf9511e79515507b9dae4454', '231', '1f8e9ffeb86b11e783e5507b9dae4454', '01300577bf7811e79515507b9dae4454', '47d61872bf9511e79515507b9dae4454', 'run_staff_performance_1', '6e379661bf9511e79515507b9dae4454', '领导意见', 'node_1', 'flowPanel_node_1', 'start', '202.00', '128.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, null, '1', null, '2', '1', 'admin', null, '2017-11-02 14:16:58', '2017-11-02 14:17:16');
INSERT INTO `flow_exec_node` VALUES ('6e3c8990bf9511e79515507b9dae4454', '232', '1f8e9ffeb86b11e783e5507b9dae4454', '01315b51bf7811e79515507b9dae4454', '47d61872bf9511e79515507b9dae4454', 'run_staff_performance_1', '6e379661bf9511e79515507b9dae4454', null, 'node_2', 'flowPanel_node_2', 'end', '734.00', '133.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, null, '0', null, '1', '1', 'admin', null, '2017-11-02 14:16:58', '2017-11-02 14:17:16');
INSERT INTO `flow_exec_node` VALUES ('6e3d3396bf9511e79515507b9dae4454', '233', '1f8e9ffeb86b11e783e5507b9dae4454', '01325768bf7811e79515507b9dae4454', '47d61872bf9511e79515507b9dae4454', 'run_staff_performance_1', '6e379661bf9511e79515507b9dae4454', null, 'node_3', 'flowPanel_node_3', 'node', '470.00', '132.00', '130', '55', null, null, '领导意见', '', null, '0', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-11-02 14:16:58', '2017-11-02 14:17:16');
INSERT INTO `flow_exec_node` VALUES ('70f5de82bd4a11e7be45507b9dae4454', '124', '8a3be65eb89911e783e5507b9dae4454', 'b9c12bf1bd2b11e7be45507b9dae4454', '67a1ebb3bd4a11e7be45507b9dae4454', 'run_take_monitor', '70f5de82bd4a11e7be45507b9dae4454', null, 'node_1', 'flowPanel_node_1', 'start', '168.00', '98.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 16:15:13', '2017-10-30 16:15:13');
INSERT INTO `flow_exec_node` VALUES ('70fd38c3bd4a11e7be45507b9dae4454', '125', '8a3be65eb89911e783e5507b9dae4454', 'b9c270a9bd2b11e7be45507b9dae4454', '67a1ebb3bd4a11e7be45507b9dae4454', 'run_take_monitor', '70f5de82bd4a11e7be45507b9dae4454', null, 'node_2', 'flowPanel_node_2', 'end', '854.00', '110.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-10-30 16:15:13', '2017-10-30 16:15:13');
INSERT INTO `flow_exec_node` VALUES ('71008467bd4a11e7be45507b9dae4454', '126', '8a3be65eb89911e783e5507b9dae4454', 'b9c547d9bd2b11e7be45507b9dae4454', '67a1ebb3bd4a11e7be45507b9dae4454', 'run_take_monitor', '70f5de82bd4a11e7be45507b9dae4454', null, 'node_3', 'flowPanel_node_3', 'node', '393.00', '112.00', '130', '55', null, null, '部门负责人意见', '', null, '0', null, null, null, null, '0', null, '1', '1', 'admin', null, '2017-10-30 16:15:13', '2017-10-30 16:15:14');
INSERT INTO `flow_exec_node` VALUES ('71073d6bbd4a11e7be45507b9dae4454', '127', '8a3be65eb89911e783e5507b9dae4454', 'b9c65c12bd2b11e7be45507b9dae4454', '67a1ebb3bd4a11e7be45507b9dae4454', 'run_take_monitor', '70f5de82bd4a11e7be45507b9dae4454', null, 'node_4', 'flowPanel_node_4', 'node', '634.00', '110.00', '130', '55', null, null, '分管领导意见', '', null, '0', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-10-30 16:15:13', '2017-10-30 16:15:13');
INSERT INTO `flow_exec_node` VALUES ('71b6db06bf9511e79515507b9dae4454', '234', '12928861bf7811e79515507b9dae4454', '353bd697bf7811e79515507b9dae4454', '47d61872bf9511e79515507b9dae4454', 'run_staff_performance_2', '71b6db06bf9511e79515507b9dae4454', '人事部意见', 'node_1', 'flowPanel_node_1', 'start', '179.00', '130.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-11-02 14:17:04', '2017-11-02 14:17:04');
INSERT INTO `flow_exec_node` VALUES ('71b7a22bbf9511e79515507b9dae4454', '235', '12928861bf7811e79515507b9dae4454', '353e7b30bf7811e79515507b9dae4454', '47d61872bf9511e79515507b9dae4454', 'run_staff_performance_2', '71b6db06bf9511e79515507b9dae4454', null, 'node_2', 'flowPanel_node_2', 'end', '665.00', '140.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-11-02 14:17:04', '2017-11-02 14:17:04');
INSERT INTO `flow_exec_node` VALUES ('71b87bb0bf9511e79515507b9dae4454', '236', '12928861bf7811e79515507b9dae4454', '353f24f1bf7811e79515507b9dae4454', '47d61872bf9511e79515507b9dae4454', 'run_staff_performance_2', '71b6db06bf9511e79515507b9dae4454', null, 'node_3', 'flowPanel_node_3', 'node', '416.00', '138.00', '130', '55', null, null, '人事部意见', '', null, '0', null, null, null, null, '0', null, '1', '1', 'admin', null, '2017-11-02 14:17:04', '2017-11-02 14:17:04');
INSERT INTO `flow_exec_node` VALUES ('73072a1ec04011e7ab51507b9dae4454', '248', '59dd99f3bd2911e7be45507b9dae4454', '000d2d76bd2a11e7be45507b9dae4454', '73034c8bc04011e7ab51507b9dae4454', 'run_waste_transfer', '73072a1ec04011e7ab51507b9dae4454', '校对部门', 'node_1', 'flowPanel_node_1', 'start', '111.00', '82.00', '130', '55', null, null, '申报', '', null, '1', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-11-03 10:41:10', '2017-11-03 10:41:10');
INSERT INTO `flow_exec_node` VALUES ('73082ef8c04011e7ab51507b9dae4454', '249', '59dd99f3bd2911e7be45507b9dae4454', '001d25cebd2a11e7be45507b9dae4454', '73034c8bc04011e7ab51507b9dae4454', 'run_waste_transfer', '73072a1ec04011e7ab51507b9dae4454', null, 'node_3', 'flowPanel_node_3', 'node', '342.00', '80.00', '130', '55', null, null, '校对部门', '', null, '2', null, null, null, null, '0', null, '1', '1', 'admin', null, '2017-11-03 10:41:10', '2017-11-03 10:41:10');
INSERT INTO `flow_exec_node` VALUES ('730910a2c04011e7ab51507b9dae4454', '250', '59dd99f3bd2911e7be45507b9dae4454', '002a050cbd2a11e7be45507b9dae4454', '73034c8bc04011e7ab51507b9dae4454', 'run_waste_transfer', '73072a1ec04011e7ab51507b9dae4454', null, 'node_4', 'flowPanel_node_4', 'node', '572.00', '91.00', '130', '55', null, null, '计价部门', '', null, '3', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-11-03 10:41:10', '2017-11-03 10:41:10');
INSERT INTO `flow_exec_node` VALUES ('7309d5dfc04011e7ab51507b9dae4454', '251', '59dd99f3bd2911e7be45507b9dae4454', '0031d71cbd2a11e7be45507b9dae4454', '73034c8bc04011e7ab51507b9dae4454', 'run_waste_transfer', '73072a1ec04011e7ab51507b9dae4454', null, 'node_5', 'flowPanel_node_5', 'node', '808.00', '99.00', '130', '55', null, null, '采购部门', '', null, '1', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-11-03 10:41:10', '2017-11-03 10:41:10');
INSERT INTO `flow_exec_node` VALUES ('730aa031c04011e7ab51507b9dae4454', '252', '59dd99f3bd2911e7be45507b9dae4454', '00387985bd2a11e7be45507b9dae4454', '73034c8bc04011e7ab51507b9dae4454', 'run_waste_transfer', '73072a1ec04011e7ab51507b9dae4454', null, 'node_7', 'flowPanel_node_7', 'end', '824.00', '211.00', '130', '55', null, null, '注销部门', '', null, '4', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-11-03 10:41:10', '2017-11-03 10:41:10');
INSERT INTO `flow_exec_node` VALUES ('73d2e991bd5911e7be45507b9dae4454', '158', '9e40c480b54011e7a96c507b9dae4454', 'dc823a5ab95311e791be507b9dae4454', '73cdbb65bd5911e7be45507b9dae4454', 'run_abnormal_receipts', '73d2e991bd5911e7be45507b9dae4454', '领导批示', 'node_9', 'flowPanel_node_9', 'start', '195.00', '53.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, null, '1', null, '2', '1', 'admin', null, '2017-10-30 18:02:36', '2017-10-30 18:06:31');
INSERT INTO `flow_exec_node` VALUES ('73d4aad9bd5911e7be45507b9dae4454', '159', '9e40c480b54011e7a96c507b9dae4454', 'dc830dcbb95311e791be507b9dae4454', '73cdbb65bd5911e7be45507b9dae4454', 'run_abnormal_receipts', '73d2e991bd5911e7be45507b9dae4454', null, 'node_10', 'flowPanel_node_10', 'node', '375.00', '99.00', '128', '53', null, null, '收费站意见', '', null, '2', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 18:02:36', '2017-10-30 18:04:54');
INSERT INTO `flow_exec_node` VALUES ('73d67a9cbd5911e7be45507b9dae4454', '160', '9e40c480b54011e7a96c507b9dae4454', 'dc84e5f9b95311e791be507b9dae4454', '73cdbb65bd5911e7be45507b9dae4454', 'run_abnormal_receipts', '73d2e991bd5911e7be45507b9dae4454', null, 'node_11', 'flowPanel_node_11', 'node', '385.00', '219.00', '128', '53', null, null, '稽查意见', '', null, '2', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 18:02:36', '2017-10-30 18:05:13');
INSERT INTO `flow_exec_node` VALUES ('73d7f645bd5911e7be45507b9dae4454', '161', '9e40c480b54011e7a96c507b9dae4454', 'dc865c63b95311e791be507b9dae4454', '73cdbb65bd5911e7be45507b9dae4454', 'run_abnormal_receipts', '73d2e991bd5911e7be45507b9dae4454', null, 'node_12', 'flowPanel_node_12', 'node', '389.00', '316.00', '128', '53', null, null, '营运部意见', '', null, '2', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 18:02:36', '2017-10-30 18:05:27');
INSERT INTO `flow_exec_node` VALUES ('73d94963bd5911e7be45507b9dae4454', '162', '9e40c480b54011e7a96c507b9dae4454', 'dc87b6d0b95311e791be507b9dae4454', '73cdbb65bd5911e7be45507b9dae4454', 'run_abnormal_receipts', '73d2e991bd5911e7be45507b9dae4454', null, 'node_13', 'flowPanel_node_13', 'node', '379.00', '434.00', '128', '53', null, null, '相关部门意见', '', null, '2', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 18:02:36', '2017-10-30 18:06:21');
INSERT INTO `flow_exec_node` VALUES ('73daa08abd5911e7be45507b9dae4454', '163', '9e40c480b54011e7a96c507b9dae4454', 'dc88ff8cb95311e791be507b9dae4454', '73cdbb65bd5911e7be45507b9dae4454', 'run_abnormal_receipts', '73d2e991bd5911e7be45507b9dae4454', null, 'node_14', 'flowPanel_node_14', 'node', '384.00', '527.00', '128', '53', null, null, '领导批示', '', null, '2', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 18:02:36', '2017-10-30 18:06:31');
INSERT INTO `flow_exec_node` VALUES ('73dc431cbd5911e7be45507b9dae4454', '164', '9e40c480b54011e7a96c507b9dae4454', 'dc8a2d04b95311e791be507b9dae4454', '73cdbb65bd5911e7be45507b9dae4454', 'run_abnormal_receipts', '73d2e991bd5911e7be45507b9dae4454', null, 'node_20', 'flowPanel_node_20', 'end', '675.00', '532.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, null, '0', null, '1', '1', 'admin', null, '2017-10-30 18:02:36', '2017-10-30 18:06:31');
INSERT INTO `flow_exec_node` VALUES ('7b4a67b6bf9411e79515507b9dae4454', '228', '1f8e9ffeb86b11e783e5507b9dae4454', '01300577bf7811e79515507b9dae4454', 'cfba7eabbef711e7b827507b9dae4454', 'run_staff_performance_1', '7b4a67b6bf9411e79515507b9dae4454', '领导意见', 'node_1', 'flowPanel_node_1', 'start', '202.00', '128.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-11-02 14:10:11', '2017-11-02 14:10:11');
INSERT INTO `flow_exec_node` VALUES ('7b4f1303bf9411e79515507b9dae4454', '229', '1f8e9ffeb86b11e783e5507b9dae4454', '01315b51bf7811e79515507b9dae4454', 'cfba7eabbef711e7b827507b9dae4454', 'run_staff_performance_1', '7b4a67b6bf9411e79515507b9dae4454', null, 'node_2', 'flowPanel_node_2', 'end', '734.00', '133.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-11-02 14:10:11', '2017-11-02 14:10:11');
INSERT INTO `flow_exec_node` VALUES ('7b510a11bf9411e79515507b9dae4454', '230', '1f8e9ffeb86b11e783e5507b9dae4454', '01325768bf7811e79515507b9dae4454', 'cfba7eabbef711e7b827507b9dae4454', 'run_staff_performance_1', '7b4a67b6bf9411e79515507b9dae4454', null, 'node_3', 'flowPanel_node_3', 'node', '470.00', '132.00', '130', '55', null, null, '领导意见', '', null, '0', null, null, null, null, '0', null, '1', '1', 'admin', null, '2017-11-02 14:10:11', '2017-11-02 14:10:11');
INSERT INTO `flow_exec_node` VALUES ('819462dbc04011e7ab51507b9dae4454', '253', '59dd99f3bd2911e7be45507b9dae4454', '000d2d76bd2a11e7be45507b9dae4454', '818cddafc04011e7ab51507b9dae4454', 'run_waste_transfer', '819462dbc04011e7ab51507b9dae4454', '校对部门', 'node_1', 'flowPanel_node_1', 'start', '111.00', '82.00', '130', '55', null, null, '申报', '', null, '1', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-11-03 10:41:34', '2017-11-03 10:41:34');
INSERT INTO `flow_exec_node` VALUES ('81957d53c04011e7ab51507b9dae4454', '254', '59dd99f3bd2911e7be45507b9dae4454', '001d25cebd2a11e7be45507b9dae4454', '818cddafc04011e7ab51507b9dae4454', 'run_waste_transfer', '819462dbc04011e7ab51507b9dae4454', null, 'node_3', 'flowPanel_node_3', 'node', '342.00', '80.00', '130', '55', null, null, '校对部门', '', null, '2', null, null, null, null, '0', null, '1', '1', 'admin', null, '2017-11-03 10:41:34', '2017-11-03 10:41:34');
INSERT INTO `flow_exec_node` VALUES ('81972d5ec04011e7ab51507b9dae4454', '255', '59dd99f3bd2911e7be45507b9dae4454', '002a050cbd2a11e7be45507b9dae4454', '818cddafc04011e7ab51507b9dae4454', 'run_waste_transfer', '819462dbc04011e7ab51507b9dae4454', null, 'node_4', 'flowPanel_node_4', 'node', '572.00', '91.00', '130', '55', null, null, '计价部门', '', null, '3', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-11-03 10:41:34', '2017-11-03 10:41:34');
INSERT INTO `flow_exec_node` VALUES ('81983e98c04011e7ab51507b9dae4454', '256', '59dd99f3bd2911e7be45507b9dae4454', '0031d71cbd2a11e7be45507b9dae4454', '818cddafc04011e7ab51507b9dae4454', 'run_waste_transfer', '819462dbc04011e7ab51507b9dae4454', null, 'node_5', 'flowPanel_node_5', 'node', '808.00', '99.00', '130', '55', null, null, '采购部门', '', null, '1', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-11-03 10:41:34', '2017-11-03 10:41:34');
INSERT INTO `flow_exec_node` VALUES ('81993115c04011e7ab51507b9dae4454', '257', '59dd99f3bd2911e7be45507b9dae4454', '00387985bd2a11e7be45507b9dae4454', '818cddafc04011e7ab51507b9dae4454', 'run_waste_transfer', '819462dbc04011e7ab51507b9dae4454', null, 'node_7', 'flowPanel_node_7', 'end', '824.00', '211.00', '130', '55', null, null, '注销部门', '', null, '4', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-11-03 10:41:34', '2017-11-03 10:41:34');
INSERT INTO `flow_exec_node` VALUES ('84a24518bafe11e7a2d8507b9dae4454', '64', '9e40c480b54011e7a96c507b9dae4454', 'dc823a5ab95311e791be507b9dae4454', '849cb464bafe11e7a2d8507b9dae4454', 'run_abnormal_receipts', '84a24518bafe11e7a2d8507b9dae4454', '营运部意见', 'node_9', 'flowPanel_node_9', 'start', '195.00', '53.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-27 18:06:37', '2017-10-27 18:12:28');
INSERT INTO `flow_exec_node` VALUES ('84a537a0bafe11e7a2d8507b9dae4454', '65', '9e40c480b54011e7a96c507b9dae4454', 'dc830dcbb95311e791be507b9dae4454', '849cb464bafe11e7a2d8507b9dae4454', 'run_abnormal_receipts', '84a24518bafe11e7a2d8507b9dae4454', null, 'node_10', 'flowPanel_node_10', 'node', '375.00', '99.00', '128', '53', null, null, '收费站意见', '', null, '2', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-27 18:06:37', '2017-10-27 18:12:20');
INSERT INTO `flow_exec_node` VALUES ('84a67a41bafe11e7a2d8507b9dae4454', '66', '9e40c480b54011e7a96c507b9dae4454', 'dc84e5f9b95311e791be507b9dae4454', '849cb464bafe11e7a2d8507b9dae4454', 'run_abnormal_receipts', '84a24518bafe11e7a2d8507b9dae4454', null, 'node_11', 'flowPanel_node_11', 'node', '385.00', '219.00', '128', '53', null, null, '稽查意见', '', null, '2', null, null, null, null, '0', null, '1', '1', 'admin', null, '2017-10-27 18:06:37', '2017-10-27 18:12:36');
INSERT INTO `flow_exec_node` VALUES ('84a78f9abafe11e7a2d8507b9dae4454', '67', '9e40c480b54011e7a96c507b9dae4454', 'dc865c63b95311e791be507b9dae4454', '849cb464bafe11e7a2d8507b9dae4454', 'run_abnormal_receipts', '84a24518bafe11e7a2d8507b9dae4454', null, 'node_12', 'flowPanel_node_12', 'node', '389.00', '316.00', '128', '53', null, null, '营运部意见', '', null, '2', null, null, null, null, '0', null, '3', '1', 'admin', null, '2017-10-27 18:06:37', '2017-10-27 18:12:36');
INSERT INTO `flow_exec_node` VALUES ('84a86bdabafe11e7a2d8507b9dae4454', '68', '9e40c480b54011e7a96c507b9dae4454', 'dc87b6d0b95311e791be507b9dae4454', '849cb464bafe11e7a2d8507b9dae4454', 'run_abnormal_receipts', '84a24518bafe11e7a2d8507b9dae4454', null, 'node_13', 'flowPanel_node_13', 'node', '379.00', '434.00', '128', '53', null, null, '相关部门意见', '', null, '2', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-10-27 18:06:37', '2017-10-27 18:06:37');
INSERT INTO `flow_exec_node` VALUES ('84a9d545bafe11e7a2d8507b9dae4454', '69', '9e40c480b54011e7a96c507b9dae4454', 'dc88ff8cb95311e791be507b9dae4454', '849cb464bafe11e7a2d8507b9dae4454', 'run_abnormal_receipts', '84a24518bafe11e7a2d8507b9dae4454', null, 'node_14', 'flowPanel_node_14', 'node', '384.00', '527.00', '128', '53', null, null, '领导批示', '', null, '2', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-10-27 18:06:37', '2017-10-27 18:06:37');
INSERT INTO `flow_exec_node` VALUES ('84aac407bafe11e7a2d8507b9dae4454', '70', '9e40c480b54011e7a96c507b9dae4454', 'dc8a2d04b95311e791be507b9dae4454', '849cb464bafe11e7a2d8507b9dae4454', 'run_abnormal_receipts', '84a24518bafe11e7a2d8507b9dae4454', null, 'node_20', 'flowPanel_node_20', 'end', '675.00', '532.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-10-27 18:06:37', '2017-10-27 18:06:37');
INSERT INTO `flow_exec_node` VALUES ('9127385ebd1111e7be45507b9dae4454', '78', '9e40c480b54011e7a96c507b9dae4454', 'dc823a5ab95311e791be507b9dae4454', '91224717bd1111e7be45507b9dae4454', 'run_abnormal_receipts', '9127385ebd1111e7be45507b9dae4454', '结束', 'node_9', 'flowPanel_node_9', 'start', '195.00', '53.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 09:28:01', '2017-10-30 09:53:15');
INSERT INTO `flow_exec_node` VALUES ('912a45fdbd1111e7be45507b9dae4454', '79', '9e40c480b54011e7a96c507b9dae4454', 'dc830dcbb95311e791be507b9dae4454', '91224717bd1111e7be45507b9dae4454', 'run_abnormal_receipts', '9127385ebd1111e7be45507b9dae4454', null, 'node_10', 'flowPanel_node_10', 'node', '375.00', '99.00', '128', '53', null, null, '收费站意见', '', null, '2', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 09:28:01', '2017-10-30 09:29:41');
INSERT INTO `flow_exec_node` VALUES ('912b86f8bd1111e7be45507b9dae4454', '80', '9e40c480b54011e7a96c507b9dae4454', 'dc84e5f9b95311e791be507b9dae4454', '91224717bd1111e7be45507b9dae4454', 'run_abnormal_receipts', '9127385ebd1111e7be45507b9dae4454', null, 'node_11', 'flowPanel_node_11', 'node', '385.00', '219.00', '128', '53', null, null, '稽查意见', '', null, '2', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 09:28:01', '2017-10-30 09:29:54');
INSERT INTO `flow_exec_node` VALUES ('912d1f39bd1111e7be45507b9dae4454', '81', '9e40c480b54011e7a96c507b9dae4454', 'dc865c63b95311e791be507b9dae4454', '91224717bd1111e7be45507b9dae4454', 'run_abnormal_receipts', '9127385ebd1111e7be45507b9dae4454', null, 'node_12', 'flowPanel_node_12', 'node', '389.00', '316.00', '128', '53', null, null, '营运部意见', '', null, '2', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 09:28:01', '2017-10-30 09:49:47');
INSERT INTO `flow_exec_node` VALUES ('912e6782bd1111e7be45507b9dae4454', '82', '9e40c480b54011e7a96c507b9dae4454', 'dc87b6d0b95311e791be507b9dae4454', '91224717bd1111e7be45507b9dae4454', 'run_abnormal_receipts', '9127385ebd1111e7be45507b9dae4454', null, 'node_13', 'flowPanel_node_13', 'node', '379.00', '434.00', '128', '53', null, null, '相关部门意见', '', null, '2', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 09:28:01', '2017-10-30 09:50:09');
INSERT INTO `flow_exec_node` VALUES ('912fcf16bd1111e7be45507b9dae4454', '83', '9e40c480b54011e7a96c507b9dae4454', 'dc88ff8cb95311e791be507b9dae4454', '91224717bd1111e7be45507b9dae4454', 'run_abnormal_receipts', '9127385ebd1111e7be45507b9dae4454', null, 'node_14', 'flowPanel_node_14', 'node', '384.00', '527.00', '128', '53', null, null, '领导批示', '', null, '2', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 09:28:01', '2017-10-30 09:53:15');
INSERT INTO `flow_exec_node` VALUES ('913106aebd1111e7be45507b9dae4454', '84', '9e40c480b54011e7a96c507b9dae4454', 'dc8a2d04b95311e791be507b9dae4454', '91224717bd1111e7be45507b9dae4454', 'run_abnormal_receipts', '9127385ebd1111e7be45507b9dae4454', null, 'node_20', 'flowPanel_node_20', 'end', '675.00', '532.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, null, '0', null, '1', '1', 'admin', null, '2017-10-30 09:28:01', '2017-10-30 09:53:15');
INSERT INTO `flow_exec_node` VALUES ('93dce679bf6c11e79515507b9dae4454', '221', '8a3be65eb89911e783e5507b9dae4454', 'b9c12bf1bd2b11e7be45507b9dae4454', '8fc21808bf6c11e79515507b9dae4454', 'run_take_monitor', '93dce679bf6c11e79515507b9dae4454', '分管领导意见', 'node_1', 'flowPanel_node_1', 'start', '168.00', '98.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, null, '1', null, '2', '1', 'admin', null, '2017-11-02 09:24:36', '2017-11-02 09:28:22');
INSERT INTO `flow_exec_node` VALUES ('93ded10bbf6c11e79515507b9dae4454', '222', '8a3be65eb89911e783e5507b9dae4454', 'b9c270a9bd2b11e7be45507b9dae4454', '8fc21808bf6c11e79515507b9dae4454', 'run_take_monitor', '93dce679bf6c11e79515507b9dae4454', null, 'node_2', 'flowPanel_node_2', 'end', '854.00', '110.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, null, '0', null, '1', '1', 'admin', null, '2017-11-02 09:24:36', '2017-11-02 09:28:22');
INSERT INTO `flow_exec_node` VALUES ('93e0a61cbf6c11e79515507b9dae4454', '223', '8a3be65eb89911e783e5507b9dae4454', 'b9c547d9bd2b11e7be45507b9dae4454', '8fc21808bf6c11e79515507b9dae4454', 'run_take_monitor', '93dce679bf6c11e79515507b9dae4454', null, 'node_3', 'flowPanel_node_3', 'node', '393.00', '112.00', '130', '55', null, null, '部门负责人意见', '', null, '0', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-11-02 09:24:36', '2017-11-02 09:27:22');
INSERT INTO `flow_exec_node` VALUES ('93e216e1bf6c11e79515507b9dae4454', '224', '8a3be65eb89911e783e5507b9dae4454', 'b9c65c12bd2b11e7be45507b9dae4454', '8fc21808bf6c11e79515507b9dae4454', 'run_take_monitor', '93dce679bf6c11e79515507b9dae4454', null, 'node_4', 'flowPanel_node_4', 'node', '634.00', '110.00', '130', '55', null, null, '分管领导意见', '', null, '0', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-11-02 09:24:36', '2017-11-02 09:28:22');
INSERT INTO `flow_exec_node` VALUES ('9e8c273ebee611e7b827507b9dae4454', '209', '8a3be65eb89911e783e5507b9dae4454', 'b9c12bf1bd2b11e7be45507b9dae4454', '20e14a07bee611e7b827507b9dae4454', 'run_take_monitor', '9e8c273ebee611e7b827507b9dae4454', '分管领导意见', 'node_1', 'flowPanel_node_1', 'start', '168.00', '98.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, null, '1', null, '2', '1', 'admin', null, '2017-11-01 17:25:43', '2017-11-01 17:35:58');
INSERT INTO `flow_exec_node` VALUES ('9e8f2628bee611e7b827507b9dae4454', '210', '8a3be65eb89911e783e5507b9dae4454', 'b9c270a9bd2b11e7be45507b9dae4454', '20e14a07bee611e7b827507b9dae4454', 'run_take_monitor', '9e8c273ebee611e7b827507b9dae4454', null, 'node_2', 'flowPanel_node_2', 'end', '854.00', '110.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, null, '0', null, '1', '1', 'admin', null, '2017-11-01 17:25:43', '2017-11-01 17:35:58');
INSERT INTO `flow_exec_node` VALUES ('9e911902bee611e7b827507b9dae4454', '211', '8a3be65eb89911e783e5507b9dae4454', 'b9c547d9bd2b11e7be45507b9dae4454', '20e14a07bee611e7b827507b9dae4454', 'run_take_monitor', '9e8c273ebee611e7b827507b9dae4454', null, 'node_3', 'flowPanel_node_3', 'node', '393.00', '112.00', '130', '55', null, null, '部门负责人意见', '', null, '0', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-11-01 17:25:43', '2017-11-01 17:35:46');
INSERT INTO `flow_exec_node` VALUES ('9e9fcfbbbee611e7b827507b9dae4454', '212', '8a3be65eb89911e783e5507b9dae4454', 'b9c65c12bd2b11e7be45507b9dae4454', '20e14a07bee611e7b827507b9dae4454', 'run_take_monitor', '9e8c273ebee611e7b827507b9dae4454', null, 'node_4', 'flowPanel_node_4', 'node', '634.00', '110.00', '130', '55', null, null, '分管领导意见', '', null, '0', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-11-01 17:25:43', '2017-11-01 17:35:58');
INSERT INTO `flow_exec_node` VALUES ('9f33816abeb611e7b827507b9dae4454', '202', '9e40c480b54011e7a96c507b9dae4454', 'dc823a5ab95311e791be507b9dae4454', '9f2ba707beb611e7b827507b9dae4454', 'run_abnormal_receipts', '9f33816abeb611e7b827507b9dae4454', '登记', 'node_9', 'flowPanel_node_9', 'start', '195.00', '53.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, null, '2', null, '1', '1', 'admin', null, '2017-11-01 11:42:02', '2017-11-01 12:32:15');
INSERT INTO `flow_exec_node` VALUES ('9f374594beb611e7b827507b9dae4454', '203', '9e40c480b54011e7a96c507b9dae4454', 'dc830dcbb95311e791be507b9dae4454', '9f2ba707beb611e7b827507b9dae4454', 'run_abnormal_receipts', '9f33816abeb611e7b827507b9dae4454', null, 'node_10', 'flowPanel_node_10', 'node', '375.00', '99.00', '128', '53', null, null, '收费站意见', '', null, '2', null, null, null, null, '0', null, '3', '1', 'admin', null, '2017-11-01 11:42:02', '2017-11-01 12:32:15');
INSERT INTO `flow_exec_node` VALUES ('9f381125beb611e7b827507b9dae4454', '204', '9e40c480b54011e7a96c507b9dae4454', 'dc84e5f9b95311e791be507b9dae4454', '9f2ba707beb611e7b827507b9dae4454', 'run_abnormal_receipts', '9f33816abeb611e7b827507b9dae4454', null, 'node_11', 'flowPanel_node_11', 'node', '385.00', '219.00', '128', '53', null, null, '稽查意见', '', null, '2', null, null, null, null, '0', null, '3', '1', 'admin', null, '2017-11-01 11:42:02', '2017-11-01 11:59:55');
INSERT INTO `flow_exec_node` VALUES ('9f38d306beb611e7b827507b9dae4454', '205', '9e40c480b54011e7a96c507b9dae4454', 'dc865c63b95311e791be507b9dae4454', '9f2ba707beb611e7b827507b9dae4454', 'run_abnormal_receipts', '9f33816abeb611e7b827507b9dae4454', null, 'node_12', 'flowPanel_node_12', 'node', '389.00', '316.00', '128', '53', null, null, '营运部意见', '', null, '2', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-11-01 11:42:02', '2017-11-01 11:42:02');
INSERT INTO `flow_exec_node` VALUES ('9f399332beb611e7b827507b9dae4454', '206', '9e40c480b54011e7a96c507b9dae4454', 'dc87b6d0b95311e791be507b9dae4454', '9f2ba707beb611e7b827507b9dae4454', 'run_abnormal_receipts', '9f33816abeb611e7b827507b9dae4454', null, 'node_13', 'flowPanel_node_13', 'node', '379.00', '434.00', '128', '53', null, null, '相关部门意见', '', null, '2', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-11-01 11:42:02', '2017-11-01 11:42:02');
INSERT INTO `flow_exec_node` VALUES ('9f3a51e9beb611e7b827507b9dae4454', '207', '9e40c480b54011e7a96c507b9dae4454', 'dc88ff8cb95311e791be507b9dae4454', '9f2ba707beb611e7b827507b9dae4454', 'run_abnormal_receipts', '9f33816abeb611e7b827507b9dae4454', null, 'node_14', 'flowPanel_node_14', 'node', '384.00', '527.00', '128', '53', null, null, '领导批示', '', null, '2', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-11-01 11:42:02', '2017-11-01 11:42:02');
INSERT INTO `flow_exec_node` VALUES ('9f3b04ccbeb611e7b827507b9dae4454', '208', '9e40c480b54011e7a96c507b9dae4454', 'dc8a2d04b95311e791be507b9dae4454', '9f2ba707beb611e7b827507b9dae4454', 'run_abnormal_receipts', '9f33816abeb611e7b827507b9dae4454', null, 'node_20', 'flowPanel_node_20', 'end', '675.00', '532.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-11-01 11:42:02', '2017-11-01 11:42:02');
INSERT INTO `flow_exec_node` VALUES ('a39214f2bd4911e7be45507b9dae4454', '120', '8a3be65eb89911e783e5507b9dae4454', 'b9c12bf1bd2b11e7be45507b9dae4454', '9f9fcd94bd4911e7be45507b9dae4454', 'run_take_monitor', 'a39214f2bd4911e7be45507b9dae4454', null, 'node_1', 'flowPanel_node_1', 'start', '168.00', '98.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 16:09:29', '2017-10-30 16:09:29');
INSERT INTO `flow_exec_node` VALUES ('a39868e3bd4911e7be45507b9dae4454', '121', '8a3be65eb89911e783e5507b9dae4454', 'b9c270a9bd2b11e7be45507b9dae4454', '9f9fcd94bd4911e7be45507b9dae4454', 'run_take_monitor', 'a39214f2bd4911e7be45507b9dae4454', null, 'node_2', 'flowPanel_node_2', 'end', '854.00', '110.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-10-30 16:09:29', '2017-10-30 16:09:29');
INSERT INTO `flow_exec_node` VALUES ('a39b7507bd4911e7be45507b9dae4454', '122', '8a3be65eb89911e783e5507b9dae4454', 'b9c547d9bd2b11e7be45507b9dae4454', '9f9fcd94bd4911e7be45507b9dae4454', 'run_take_monitor', 'a39214f2bd4911e7be45507b9dae4454', null, 'node_3', 'flowPanel_node_3', 'node', '393.00', '112.00', '130', '55', null, null, '部门负责人意见', '', null, '0', null, null, null, null, '0', null, '1', '1', 'admin', null, '2017-10-30 16:09:29', '2017-10-30 16:09:29');
INSERT INTO `flow_exec_node` VALUES ('a3a2610dbd4911e7be45507b9dae4454', '123', '8a3be65eb89911e783e5507b9dae4454', 'b9c65c12bd2b11e7be45507b9dae4454', '9f9fcd94bd4911e7be45507b9dae4454', 'run_take_monitor', 'a39214f2bd4911e7be45507b9dae4454', null, 'node_4', 'flowPanel_node_4', 'node', '634.00', '110.00', '130', '55', null, null, '分管领导意见', '', null, '0', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-10-30 16:09:29', '2017-10-30 16:09:29');
INSERT INTO `flow_exec_node` VALUES ('a6fddfd7bd1911e7be45507b9dae4454', '85', '9e40c480b54011e7a96c507b9dae4454', 'dc823a5ab95311e791be507b9dae4454', 'a6f0507fbd1911e7be45507b9dae4454', 'run_abnormal_receipts', 'a6fddfd7bd1911e7be45507b9dae4454', null, 'node_9', 'flowPanel_node_9', 'start', '195.00', '53.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 10:25:58', '2017-10-30 10:25:58');
INSERT INTO `flow_exec_node` VALUES ('a7026d02bd1911e7be45507b9dae4454', '86', '9e40c480b54011e7a96c507b9dae4454', 'dc830dcbb95311e791be507b9dae4454', 'a6f0507fbd1911e7be45507b9dae4454', 'run_abnormal_receipts', 'a6fddfd7bd1911e7be45507b9dae4454', null, 'node_10', 'flowPanel_node_10', 'node', '375.00', '99.00', '128', '53', null, null, '收费站意见', '', null, '2', null, null, null, null, '0', null, '1', '1', 'admin', null, '2017-10-30 10:25:58', '2017-10-30 10:25:58');
INSERT INTO `flow_exec_node` VALUES ('a706712fbd1911e7be45507b9dae4454', '87', '9e40c480b54011e7a96c507b9dae4454', 'dc84e5f9b95311e791be507b9dae4454', 'a6f0507fbd1911e7be45507b9dae4454', 'run_abnormal_receipts', 'a6fddfd7bd1911e7be45507b9dae4454', null, 'node_11', 'flowPanel_node_11', 'node', '385.00', '219.00', '128', '53', null, null, '稽查意见', '', null, '2', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-10-30 10:25:58', '2017-10-30 10:25:58');
INSERT INTO `flow_exec_node` VALUES ('a70a8767bd1911e7be45507b9dae4454', '88', '9e40c480b54011e7a96c507b9dae4454', 'dc865c63b95311e791be507b9dae4454', 'a6f0507fbd1911e7be45507b9dae4454', 'run_abnormal_receipts', 'a6fddfd7bd1911e7be45507b9dae4454', null, 'node_12', 'flowPanel_node_12', 'node', '389.00', '316.00', '128', '53', null, null, '营运部意见', '', null, '2', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-10-30 10:25:58', '2017-10-30 10:25:58');
INSERT INTO `flow_exec_node` VALUES ('a70c2a9bbd1911e7be45507b9dae4454', '89', '9e40c480b54011e7a96c507b9dae4454', 'dc87b6d0b95311e791be507b9dae4454', 'a6f0507fbd1911e7be45507b9dae4454', 'run_abnormal_receipts', 'a6fddfd7bd1911e7be45507b9dae4454', null, 'node_13', 'flowPanel_node_13', 'node', '379.00', '434.00', '128', '53', null, null, '相关部门意见', '', null, '2', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-10-30 10:25:58', '2017-10-30 10:25:58');
INSERT INTO `flow_exec_node` VALUES ('a712a545bd1911e7be45507b9dae4454', '90', '9e40c480b54011e7a96c507b9dae4454', 'dc88ff8cb95311e791be507b9dae4454', 'a6f0507fbd1911e7be45507b9dae4454', 'run_abnormal_receipts', 'a6fddfd7bd1911e7be45507b9dae4454', null, 'node_14', 'flowPanel_node_14', 'node', '384.00', '527.00', '128', '53', null, null, '领导批示', '', null, '2', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-10-30 10:25:58', '2017-10-30 10:25:58');
INSERT INTO `flow_exec_node` VALUES ('a715cc3dbd1911e7be45507b9dae4454', '91', '9e40c480b54011e7a96c507b9dae4454', 'dc8a2d04b95311e791be507b9dae4454', 'a6f0507fbd1911e7be45507b9dae4454', 'run_abnormal_receipts', 'a6fddfd7bd1911e7be45507b9dae4454', null, 'node_20', 'flowPanel_node_20', 'end', '675.00', '532.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-10-30 10:25:58', '2017-10-30 10:25:58');
INSERT INTO `flow_exec_node` VALUES ('aa12ff37bd5511e7be45507b9dae4454', '136', '9e40c480b54011e7a96c507b9dae4454', 'dc823a5ab95311e791be507b9dae4454', '6d271736bd5511e7be45507b9dae4454', 'run_abnormal_receipts', 'aa12ff37bd5511e7be45507b9dae4454', '营运部意见', 'node_9', 'flowPanel_node_9', 'start', '195.00', '53.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 17:35:29', '2017-10-30 17:38:58');
INSERT INTO `flow_exec_node` VALUES ('aa158766bd5511e7be45507b9dae4454', '137', '9e40c480b54011e7a96c507b9dae4454', 'dc830dcbb95311e791be507b9dae4454', '6d271736bd5511e7be45507b9dae4454', 'run_abnormal_receipts', 'aa12ff37bd5511e7be45507b9dae4454', null, 'node_10', 'flowPanel_node_10', 'node', '375.00', '99.00', '128', '53', null, null, '收费站意见', '', null, '2', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 17:35:29', '2017-10-30 17:37:16');
INSERT INTO `flow_exec_node` VALUES ('aa17252bbd5511e7be45507b9dae4454', '138', '9e40c480b54011e7a96c507b9dae4454', 'dc84e5f9b95311e791be507b9dae4454', '6d271736bd5511e7be45507b9dae4454', 'run_abnormal_receipts', 'aa12ff37bd5511e7be45507b9dae4454', null, 'node_11', 'flowPanel_node_11', 'node', '385.00', '219.00', '128', '53', null, null, '稽查意见', '', null, '2', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 17:35:29', '2017-10-30 17:38:48');
INSERT INTO `flow_exec_node` VALUES ('aa189b2ebd5511e7be45507b9dae4454', '139', '9e40c480b54011e7a96c507b9dae4454', 'dc865c63b95311e791be507b9dae4454', '6d271736bd5511e7be45507b9dae4454', 'run_abnormal_receipts', 'aa12ff37bd5511e7be45507b9dae4454', null, 'node_12', 'flowPanel_node_12', 'node', '389.00', '316.00', '128', '53', null, null, '营运部意见', '', null, '2', null, null, null, null, '0', null, '1', '1', 'admin', null, '2017-10-30 17:35:29', '2017-10-30 17:38:48');
INSERT INTO `flow_exec_node` VALUES ('aa1a1bafbd5511e7be45507b9dae4454', '140', '9e40c480b54011e7a96c507b9dae4454', 'dc87b6d0b95311e791be507b9dae4454', '6d271736bd5511e7be45507b9dae4454', 'run_abnormal_receipts', 'aa12ff37bd5511e7be45507b9dae4454', null, 'node_13', 'flowPanel_node_13', 'node', '379.00', '434.00', '128', '53', null, null, '相关部门意见', '', null, '2', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-10-30 17:35:29', '2017-10-30 17:35:29');
INSERT INTO `flow_exec_node` VALUES ('aa1b6a59bd5511e7be45507b9dae4454', '141', '9e40c480b54011e7a96c507b9dae4454', 'dc88ff8cb95311e791be507b9dae4454', '6d271736bd5511e7be45507b9dae4454', 'run_abnormal_receipts', 'aa12ff37bd5511e7be45507b9dae4454', null, 'node_14', 'flowPanel_node_14', 'node', '384.00', '527.00', '128', '53', null, null, '领导批示', '', null, '2', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-10-30 17:35:29', '2017-10-30 17:35:29');
INSERT INTO `flow_exec_node` VALUES ('aa1cdda8bd5511e7be45507b9dae4454', '142', '9e40c480b54011e7a96c507b9dae4454', 'dc8a2d04b95311e791be507b9dae4454', '6d271736bd5511e7be45507b9dae4454', 'run_abnormal_receipts', 'aa12ff37bd5511e7be45507b9dae4454', null, 'node_20', 'flowPanel_node_20', 'end', '675.00', '532.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-10-30 17:35:29', '2017-10-30 17:35:29');
INSERT INTO `flow_exec_node` VALUES ('af6b3bcdbd5511e7be45507b9dae4454', '143', '8a3be65eb89911e783e5507b9dae4454', 'b9c12bf1bd2b11e7be45507b9dae4454', 'c1bfc48cbd5411e7be45507b9dae4454', 'run_take_monitor', 'af6b3bcdbd5511e7be45507b9dae4454', '分管领导意见', 'node_1', 'flowPanel_node_1', 'start', '168.00', '98.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, null, '1', null, '2', '1', 'admin', null, '2017-10-30 17:35:43', '2017-10-30 17:36:42');
INSERT INTO `flow_exec_node` VALUES ('af6e380abd5511e7be45507b9dae4454', '144', '8a3be65eb89911e783e5507b9dae4454', 'b9c270a9bd2b11e7be45507b9dae4454', 'c1bfc48cbd5411e7be45507b9dae4454', 'run_take_monitor', 'af6b3bcdbd5511e7be45507b9dae4454', null, 'node_2', 'flowPanel_node_2', 'end', '854.00', '110.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, null, '0', null, '1', '1', 'admin', null, '2017-10-30 17:35:43', '2017-10-30 17:36:42');
INSERT INTO `flow_exec_node` VALUES ('af6f4603bd5511e7be45507b9dae4454', '145', '8a3be65eb89911e783e5507b9dae4454', 'b9c547d9bd2b11e7be45507b9dae4454', 'c1bfc48cbd5411e7be45507b9dae4454', 'run_take_monitor', 'af6b3bcdbd5511e7be45507b9dae4454', null, 'node_3', 'flowPanel_node_3', 'node', '393.00', '112.00', '130', '55', null, null, '部门负责人意见', '', null, '0', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 17:35:43', '2017-10-30 17:36:37');
INSERT INTO `flow_exec_node` VALUES ('af703740bd5511e7be45507b9dae4454', '146', '8a3be65eb89911e783e5507b9dae4454', 'b9c65c12bd2b11e7be45507b9dae4454', 'c1bfc48cbd5411e7be45507b9dae4454', 'run_take_monitor', 'af6b3bcdbd5511e7be45507b9dae4454', null, 'node_4', 'flowPanel_node_4', 'node', '634.00', '110.00', '130', '55', null, null, '分管领导意见', '', null, '0', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 17:35:43', '2017-10-30 17:36:42');
INSERT INTO `flow_exec_node` VALUES ('b5cf2226bd1011e7be45507b9dae4454', '71', '9e40c480b54011e7a96c507b9dae4454', 'dc823a5ab95311e791be507b9dae4454', 'b5c1c535bd1011e7be45507b9dae4454', 'run_abnormal_receipts', 'b5cf2226bd1011e7be45507b9dae4454', null, 'node_9', 'flowPanel_node_9', 'start', '195.00', '53.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 09:21:57', '2017-10-30 09:21:57');
INSERT INTO `flow_exec_node` VALUES ('b5d33aa1bd1011e7be45507b9dae4454', '72', '9e40c480b54011e7a96c507b9dae4454', 'dc830dcbb95311e791be507b9dae4454', 'b5c1c535bd1011e7be45507b9dae4454', 'run_abnormal_receipts', 'b5cf2226bd1011e7be45507b9dae4454', null, 'node_10', 'flowPanel_node_10', 'node', '375.00', '99.00', '128', '53', null, null, '收费站意见', '', null, '2', null, null, null, null, '0', null, '1', '1', 'admin', null, '2017-10-30 09:21:57', '2017-10-30 09:21:57');
INSERT INTO `flow_exec_node` VALUES ('b5dbae28bd1011e7be45507b9dae4454', '73', '9e40c480b54011e7a96c507b9dae4454', 'dc84e5f9b95311e791be507b9dae4454', 'b5c1c535bd1011e7be45507b9dae4454', 'run_abnormal_receipts', 'b5cf2226bd1011e7be45507b9dae4454', null, 'node_11', 'flowPanel_node_11', 'node', '385.00', '219.00', '128', '53', null, null, '稽查意见', '', null, '2', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-10-30 09:21:57', '2017-10-30 09:21:57');
INSERT INTO `flow_exec_node` VALUES ('b5f147abbd1011e7be45507b9dae4454', '74', '9e40c480b54011e7a96c507b9dae4454', 'dc865c63b95311e791be507b9dae4454', 'b5c1c535bd1011e7be45507b9dae4454', 'run_abnormal_receipts', 'b5cf2226bd1011e7be45507b9dae4454', null, 'node_12', 'flowPanel_node_12', 'node', '389.00', '316.00', '128', '53', null, null, '营运部意见', '', null, '2', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-10-30 09:21:57', '2017-10-30 09:21:57');
INSERT INTO `flow_exec_node` VALUES ('b5f2d701bd1011e7be45507b9dae4454', '75', '9e40c480b54011e7a96c507b9dae4454', 'dc87b6d0b95311e791be507b9dae4454', 'b5c1c535bd1011e7be45507b9dae4454', 'run_abnormal_receipts', 'b5cf2226bd1011e7be45507b9dae4454', null, 'node_13', 'flowPanel_node_13', 'node', '379.00', '434.00', '128', '53', null, null, '相关部门意见', '', null, '2', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-10-30 09:21:57', '2017-10-30 09:21:57');
INSERT INTO `flow_exec_node` VALUES ('b5f46571bd1011e7be45507b9dae4454', '76', '9e40c480b54011e7a96c507b9dae4454', 'dc88ff8cb95311e791be507b9dae4454', 'b5c1c535bd1011e7be45507b9dae4454', 'run_abnormal_receipts', 'b5cf2226bd1011e7be45507b9dae4454', null, 'node_14', 'flowPanel_node_14', 'node', '384.00', '527.00', '128', '53', null, null, '领导批示', '', null, '2', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-10-30 09:21:57', '2017-10-30 09:21:57');
INSERT INTO `flow_exec_node` VALUES ('b5f67643bd1011e7be45507b9dae4454', '77', '9e40c480b54011e7a96c507b9dae4454', 'dc8a2d04b95311e791be507b9dae4454', 'b5c1c535bd1011e7be45507b9dae4454', 'run_abnormal_receipts', 'b5cf2226bd1011e7be45507b9dae4454', null, 'node_20', 'flowPanel_node_20', 'end', '675.00', '532.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-10-30 09:21:57', '2017-10-30 09:21:57');
INSERT INTO `flow_exec_node` VALUES ('bc562c92bfb011e79515507b9dae4454', '237', '1f8e9ffeb86b11e783e5507b9dae4454', '01300577bf7811e79515507b9dae4454', '4d332310bfae11e79515507b9dae4454', 'run_staff_performance_1', 'bc562c92bfb011e79515507b9dae4454', '结束', 'node_1', 'flowPanel_node_1', 'start', '202.00', '128.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, null, '1', null, '1', '1', 'admin', null, '2017-11-02 17:32:26', '2017-11-02 17:48:40');
INSERT INTO `flow_exec_node` VALUES ('bc5778e6bfb011e79515507b9dae4454', '238', '1f8e9ffeb86b11e783e5507b9dae4454', '01315b51bf7811e79515507b9dae4454', '4d332310bfae11e79515507b9dae4454', 'run_staff_performance_1', 'bc562c92bfb011e79515507b9dae4454', null, 'node_2', 'flowPanel_node_2', 'end', '734.00', '133.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, null, '0', null, '1', '1', 'admin', null, '2017-11-02 17:32:26', '2017-11-02 17:48:40');
INSERT INTO `flow_exec_node` VALUES ('bc64283abfb011e79515507b9dae4454', '239', '1f8e9ffeb86b11e783e5507b9dae4454', '01325768bf7811e79515507b9dae4454', '4d332310bfae11e79515507b9dae4454', 'run_staff_performance_1', 'bc562c92bfb011e79515507b9dae4454', null, 'node_3', 'flowPanel_node_3', 'node', '470.00', '132.00', '130', '55', null, null, '领导意见', '', null, '0', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-11-02 17:32:26', '2017-11-02 17:48:40');
INSERT INTO `flow_exec_node` VALUES ('bf15a0d9bfb011e79515507b9dae4454', '240', '12928861bf7811e79515507b9dae4454', '353bd697bf7811e79515507b9dae4454', '4d332310bfae11e79515507b9dae4454', 'run_staff_performance_2', 'bf15a0d9bfb011e79515507b9dae4454', '人事部意见', 'node_1', 'flowPanel_node_1', 'start', '179.00', '130.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-11-02 17:32:30', '2017-11-02 17:32:30');
INSERT INTO `flow_exec_node` VALUES ('bf191908bfb011e79515507b9dae4454', '241', '12928861bf7811e79515507b9dae4454', '353e7b30bf7811e79515507b9dae4454', '4d332310bfae11e79515507b9dae4454', 'run_staff_performance_2', 'bf15a0d9bfb011e79515507b9dae4454', null, 'node_2', 'flowPanel_node_2', 'end', '665.00', '140.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-11-02 17:32:30', '2017-11-02 17:32:30');
INSERT INTO `flow_exec_node` VALUES ('bf1a1503bfb011e79515507b9dae4454', '242', '12928861bf7811e79515507b9dae4454', '353f24f1bf7811e79515507b9dae4454', '4d332310bfae11e79515507b9dae4454', 'run_staff_performance_2', 'bf15a0d9bfb011e79515507b9dae4454', null, 'node_3', 'flowPanel_node_3', 'node', '416.00', '138.00', '130', '55', null, null, '人事部意见', '', null, '0', null, null, null, null, '0', null, '1', '1', 'admin', null, '2017-11-02 17:32:30', '2017-11-02 17:32:30');
INSERT INTO `flow_exec_node` VALUES ('c08c0573be0711e797cd507b9dae4454', '187', '8a3be65eb89911e783e5507b9dae4454', 'b9c12bf1bd2b11e7be45507b9dae4454', 'c086268abe0711e797cd507b9dae4454', 'run_take_monitor', 'c08c0573be0711e797cd507b9dae4454', '部门负责人意见', 'node_1', 'flowPanel_node_1', 'start', '168.00', '98.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, null, '0', null, '2', '1', 'bgs', null, '2017-10-31 14:50:21', '2017-10-31 14:50:21');
INSERT INTO `flow_exec_node` VALUES ('c08d792abe0711e797cd507b9dae4454', '188', '8a3be65eb89911e783e5507b9dae4454', 'b9c270a9bd2b11e7be45507b9dae4454', 'c086268abe0711e797cd507b9dae4454', 'run_take_monitor', 'c08c0573be0711e797cd507b9dae4454', null, 'node_2', 'flowPanel_node_2', 'end', '854.00', '110.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, null, '0', null, '0', '1', 'bgs', null, '2017-10-31 14:50:21', '2017-10-31 14:50:21');
INSERT INTO `flow_exec_node` VALUES ('c092f32abe0711e797cd507b9dae4454', '189', '8a3be65eb89911e783e5507b9dae4454', 'b9c547d9bd2b11e7be45507b9dae4454', 'c086268abe0711e797cd507b9dae4454', 'run_take_monitor', 'c08c0573be0711e797cd507b9dae4454', null, 'node_3', 'flowPanel_node_3', 'node', '393.00', '112.00', '130', '55', null, null, '部门负责人意见', '', null, '0', null, null, null, null, '0', null, '1', '1', 'bgs', null, '2017-10-31 14:50:21', '2017-10-31 14:50:22');
INSERT INTO `flow_exec_node` VALUES ('c0946d76be0711e797cd507b9dae4454', '190', '8a3be65eb89911e783e5507b9dae4454', 'b9c65c12bd2b11e7be45507b9dae4454', 'c086268abe0711e797cd507b9dae4454', 'run_take_monitor', 'c08c0573be0711e797cd507b9dae4454', null, 'node_4', 'flowPanel_node_4', 'node', '634.00', '110.00', '130', '55', null, null, '分管领导意见', '', null, '0', null, null, null, null, '0', null, '0', '1', 'bgs', null, '2017-10-31 14:50:21', '2017-10-31 14:50:21');
INSERT INTO `flow_exec_node` VALUES ('c17467d5bd5f11e7be45507b9dae4454', '169', '59dd99f3bd2911e7be45507b9dae4454', '000d2d76bd2a11e7be45507b9dae4454', '9222400bbd5a11e7be45507b9dae4454', 'run_waste_transfer', 'c17467d5bd5f11e7be45507b9dae4454', '校对部门', 'node_1', 'flowPanel_node_1', 'start', '111.00', '82.00', '130', '55', null, null, '申报', '', null, '1', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 18:47:48', '2017-10-30 18:47:48');
INSERT INTO `flow_exec_node` VALUES ('c17f9d1cbd5f11e7be45507b9dae4454', '170', '59dd99f3bd2911e7be45507b9dae4454', '001d25cebd2a11e7be45507b9dae4454', '9222400bbd5a11e7be45507b9dae4454', 'run_waste_transfer', 'c17467d5bd5f11e7be45507b9dae4454', null, 'node_3', 'flowPanel_node_3', 'node', '342.00', '80.00', '130', '55', null, null, '校对部门', '', null, '2', null, null, null, null, '0', null, '1', '1', 'admin', null, '2017-10-30 18:47:48', '2017-10-30 18:47:48');
INSERT INTO `flow_exec_node` VALUES ('c18207c2bd5f11e7be45507b9dae4454', '171', '59dd99f3bd2911e7be45507b9dae4454', '002a050cbd2a11e7be45507b9dae4454', '9222400bbd5a11e7be45507b9dae4454', 'run_waste_transfer', 'c17467d5bd5f11e7be45507b9dae4454', null, 'node_4', 'flowPanel_node_4', 'node', '572.00', '91.00', '130', '55', null, null, '计价部门', '', null, '3', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-10-30 18:47:48', '2017-10-30 18:47:48');
INSERT INTO `flow_exec_node` VALUES ('c1846ecabd5f11e7be45507b9dae4454', '172', '59dd99f3bd2911e7be45507b9dae4454', '0031d71cbd2a11e7be45507b9dae4454', '9222400bbd5a11e7be45507b9dae4454', 'run_waste_transfer', 'c17467d5bd5f11e7be45507b9dae4454', null, 'node_5', 'flowPanel_node_5', 'node', '808.00', '99.00', '130', '55', null, null, '采购部门', '', null, '1', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-10-30 18:47:48', '2017-10-30 18:47:48');
INSERT INTO `flow_exec_node` VALUES ('c18677babd5f11e7be45507b9dae4454', '173', '59dd99f3bd2911e7be45507b9dae4454', '00387985bd2a11e7be45507b9dae4454', '9222400bbd5a11e7be45507b9dae4454', 'run_waste_transfer', 'c17467d5bd5f11e7be45507b9dae4454', null, 'node_7', 'flowPanel_node_7', 'end', '824.00', '211.00', '130', '55', null, null, '注销部门', '', null, '4', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-10-30 18:47:48', '2017-10-30 18:47:48');
INSERT INTO `flow_exec_node` VALUES ('ca306762c04811e7ab51507b9dae4454', '258', '8a3be65eb89911e783e5507b9dae4454', 'b9c12bf1bd2b11e7be45507b9dae4454', '102c92a7c04611e7ab51507b9dae4454', 'run_take_monitor', 'ca306762c04811e7ab51507b9dae4454', '分管领导意见', 'node_1', 'flowPanel_node_1', 'start', '168.00', '98.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-11-03 11:40:58', '2017-11-03 14:20:32');
INSERT INTO `flow_exec_node` VALUES ('ca34a5e7c04811e7ab51507b9dae4454', '259', '8a3be65eb89911e783e5507b9dae4454', 'b9c270a9bd2b11e7be45507b9dae4454', '102c92a7c04611e7ab51507b9dae4454', 'run_take_monitor', 'ca306762c04811e7ab51507b9dae4454', null, 'node_2', 'flowPanel_node_2', 'end', '854.00', '110.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-11-03 11:40:58', '2017-11-03 11:40:58');
INSERT INTO `flow_exec_node` VALUES ('ca35e28ac04811e7ab51507b9dae4454', '260', '8a3be65eb89911e783e5507b9dae4454', 'b9c547d9bd2b11e7be45507b9dae4454', '102c92a7c04611e7ab51507b9dae4454', 'run_take_monitor', 'ca306762c04811e7ab51507b9dae4454', null, 'node_3', 'flowPanel_node_3', 'node', '393.00', '112.00', '130', '55', null, null, '部门负责人意见', '', null, '0', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-11-03 11:40:58', '2017-11-03 14:20:32');
INSERT INTO `flow_exec_node` VALUES ('ca374d59c04811e7ab51507b9dae4454', '261', '8a3be65eb89911e783e5507b9dae4454', 'b9c65c12bd2b11e7be45507b9dae4454', '102c92a7c04611e7ab51507b9dae4454', 'run_take_monitor', 'ca306762c04811e7ab51507b9dae4454', null, 'node_4', 'flowPanel_node_4', 'node', '634.00', '110.00', '130', '55', null, null, '分管领导意见', '', null, '0', null, null, null, null, '0', null, '1', '1', 'admin', null, '2017-11-03 11:40:58', '2017-11-03 14:20:32');
INSERT INTO `flow_exec_node` VALUES ('cfb87cfabf7911e79515507b9dae4454', '225', '1f8e9ffeb86b11e783e5507b9dae4454', '01300577bf7811e79515507b9dae4454', 'cfba7eabbef711e7b827507b9dae4454', 'run_staff_performance_1', 'cfb87cfabf7911e79515507b9dae4454', '领导意见', 'node_1', 'flowPanel_node_1', 'start', '202.00', '128.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-11-02 10:59:16', '2017-11-02 10:59:16');
INSERT INTO `flow_exec_node` VALUES ('cfb99636bf7911e79515507b9dae4454', '226', '1f8e9ffeb86b11e783e5507b9dae4454', '01315b51bf7811e79515507b9dae4454', 'cfba7eabbef711e7b827507b9dae4454', 'run_staff_performance_1', 'cfb87cfabf7911e79515507b9dae4454', null, 'node_2', 'flowPanel_node_2', 'end', '734.00', '133.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-11-02 10:59:16', '2017-11-02 10:59:16');
INSERT INTO `flow_exec_node` VALUES ('cfba7310bf7911e79515507b9dae4454', '227', '1f8e9ffeb86b11e783e5507b9dae4454', '01325768bf7811e79515507b9dae4454', 'cfba7eabbef711e7b827507b9dae4454', 'run_staff_performance_1', 'cfb87cfabf7911e79515507b9dae4454', null, 'node_3', 'flowPanel_node_3', 'node', '470.00', '132.00', '130', '55', null, null, '领导意见', '', null, '0', null, null, null, null, '0', null, '1', '1', 'admin', null, '2017-11-02 10:59:16', '2017-11-02 10:59:16');
INSERT INTO `flow_exec_node` VALUES ('d306ef3fbd4a11e7be45507b9dae4454', '128', '8a3be65eb89911e783e5507b9dae4454', 'b9c12bf1bd2b11e7be45507b9dae4454', null, 'run_take_monitor', 'd306ef3fbd4a11e7be45507b9dae4454', '分管领导意见', 'node_1', 'flowPanel_node_1', 'start', '168.00', '98.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, null, '1', null, '2', '1', 'admin', null, '2017-10-30 16:17:58', '2017-10-30 17:11:00');
INSERT INTO `flow_exec_node` VALUES ('d308f468bd4a11e7be45507b9dae4454', '129', '8a3be65eb89911e783e5507b9dae4454', 'b9c270a9bd2b11e7be45507b9dae4454', null, 'run_take_monitor', 'd306ef3fbd4a11e7be45507b9dae4454', null, 'node_2', 'flowPanel_node_2', 'end', '854.00', '110.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, null, '0', null, '1', '1', 'admin', null, '2017-10-30 16:17:58', '2017-10-30 17:11:00');
INSERT INTO `flow_exec_node` VALUES ('d30a2aebbd4a11e7be45507b9dae4454', '130', '8a3be65eb89911e783e5507b9dae4454', 'b9c547d9bd2b11e7be45507b9dae4454', null, 'run_take_monitor', 'd306ef3fbd4a11e7be45507b9dae4454', null, 'node_3', 'flowPanel_node_3', 'node', '393.00', '112.00', '130', '55', null, null, '部门负责人意见', '', null, '0', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 16:17:58', '2017-10-30 17:10:45');
INSERT INTO `flow_exec_node` VALUES ('d30b5063bd4a11e7be45507b9dae4454', '131', '8a3be65eb89911e783e5507b9dae4454', 'b9c65c12bd2b11e7be45507b9dae4454', null, 'run_take_monitor', 'd306ef3fbd4a11e7be45507b9dae4454', null, 'node_4', 'flowPanel_node_4', 'node', '634.00', '110.00', '130', '55', null, null, '分管领导意见', '', null, '0', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 16:17:58', '2017-10-30 17:11:00');
INSERT INTO `flow_exec_node` VALUES ('d86257a9bd5411e7be45507b9dae4454', '132', '8a3be65eb89911e783e5507b9dae4454', 'b9c12bf1bd2b11e7be45507b9dae4454', 'd85b5d93bd5411e7be45507b9dae4454', 'run_take_monitor', 'd86257a9bd5411e7be45507b9dae4454', '分管领导意见', 'node_1', 'flowPanel_node_1', 'start', '168.00', '98.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, null, '1', null, '2', '1', 'admin', null, '2017-10-30 17:29:42', '2017-10-30 17:33:42');
INSERT INTO `flow_exec_node` VALUES ('d864eb59bd5411e7be45507b9dae4454', '133', '8a3be65eb89911e783e5507b9dae4454', 'b9c270a9bd2b11e7be45507b9dae4454', 'd85b5d93bd5411e7be45507b9dae4454', 'run_take_monitor', 'd86257a9bd5411e7be45507b9dae4454', null, 'node_2', 'flowPanel_node_2', 'end', '854.00', '110.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, null, '0', null, '1', '1', 'admin', null, '2017-10-30 17:29:42', '2017-10-30 17:33:42');
INSERT INTO `flow_exec_node` VALUES ('d86632aabd5411e7be45507b9dae4454', '134', '8a3be65eb89911e783e5507b9dae4454', 'b9c547d9bd2b11e7be45507b9dae4454', 'd85b5d93bd5411e7be45507b9dae4454', 'run_take_monitor', 'd86257a9bd5411e7be45507b9dae4454', null, 'node_3', 'flowPanel_node_3', 'node', '393.00', '112.00', '130', '55', null, null, '部门负责人意见', '', null, '0', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 17:29:42', '2017-10-30 17:33:37');
INSERT INTO `flow_exec_node` VALUES ('d8677290bd5411e7be45507b9dae4454', '135', '8a3be65eb89911e783e5507b9dae4454', 'b9c65c12bd2b11e7be45507b9dae4454', 'd85b5d93bd5411e7be45507b9dae4454', 'run_take_monitor', 'd86257a9bd5411e7be45507b9dae4454', null, 'node_4', 'flowPanel_node_4', 'node', '634.00', '110.00', '130', '55', null, null, '分管领导意见', '', null, '0', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 17:29:42', '2017-10-30 17:33:42');
INSERT INTO `flow_exec_node` VALUES ('dbf289abbd5611e7be45507b9dae4454', '147', '9e40c480b54011e7a96c507b9dae4454', 'dc823a5ab95311e791be507b9dae4454', 'dbed10d7bd5611e7be45507b9dae4454', 'run_abnormal_receipts', 'dbf289abbd5611e7be45507b9dae4454', '领导批示', 'node_9', 'flowPanel_node_9', 'start', '195.00', '53.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, null, '1', null, '2', '1', 'admin', null, '2017-10-30 17:44:02', '2017-10-30 18:01:30');
INSERT INTO `flow_exec_node` VALUES ('dbf4c5b0bd5611e7be45507b9dae4454', '148', '9e40c480b54011e7a96c507b9dae4454', 'dc830dcbb95311e791be507b9dae4454', 'dbed10d7bd5611e7be45507b9dae4454', 'run_abnormal_receipts', 'dbf289abbd5611e7be45507b9dae4454', null, 'node_10', 'flowPanel_node_10', 'node', '375.00', '99.00', '128', '53', null, null, '收费站意见', '', null, '2', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 17:44:02', '2017-10-30 17:44:20');
INSERT INTO `flow_exec_node` VALUES ('dbf65341bd5611e7be45507b9dae4454', '149', '9e40c480b54011e7a96c507b9dae4454', 'dc84e5f9b95311e791be507b9dae4454', 'dbed10d7bd5611e7be45507b9dae4454', 'run_abnormal_receipts', 'dbf289abbd5611e7be45507b9dae4454', null, 'node_11', 'flowPanel_node_11', 'node', '385.00', '219.00', '128', '53', null, null, '稽查意见', '', null, '2', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 17:44:02', '2017-10-30 17:50:45');
INSERT INTO `flow_exec_node` VALUES ('dbf8089cbd5611e7be45507b9dae4454', '150', '9e40c480b54011e7a96c507b9dae4454', 'dc865c63b95311e791be507b9dae4454', 'dbed10d7bd5611e7be45507b9dae4454', 'run_abnormal_receipts', 'dbf289abbd5611e7be45507b9dae4454', null, 'node_12', 'flowPanel_node_12', 'node', '389.00', '316.00', '128', '53', null, null, '营运部意见', '', null, '2', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 17:44:02', '2017-10-30 17:52:55');
INSERT INTO `flow_exec_node` VALUES ('dbf958edbd5611e7be45507b9dae4454', '151', '9e40c480b54011e7a96c507b9dae4454', 'dc87b6d0b95311e791be507b9dae4454', 'dbed10d7bd5611e7be45507b9dae4454', 'run_abnormal_receipts', 'dbf289abbd5611e7be45507b9dae4454', null, 'node_13', 'flowPanel_node_13', 'node', '379.00', '434.00', '128', '53', null, null, '相关部门意见', '', null, '2', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 17:44:02', '2017-10-30 17:57:18');
INSERT INTO `flow_exec_node` VALUES ('dc0fe0babd5611e7be45507b9dae4454', '152', '9e40c480b54011e7a96c507b9dae4454', 'dc88ff8cb95311e791be507b9dae4454', 'dbed10d7bd5611e7be45507b9dae4454', 'run_abnormal_receipts', 'dbf289abbd5611e7be45507b9dae4454', null, 'node_14', 'flowPanel_node_14', 'node', '384.00', '527.00', '128', '53', null, null, '领导批示', '', null, '2', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 17:44:02', '2017-10-30 18:01:30');
INSERT INTO `flow_exec_node` VALUES ('dc111eefbd5611e7be45507b9dae4454', '153', '9e40c480b54011e7a96c507b9dae4454', 'dc8a2d04b95311e791be507b9dae4454', 'dbed10d7bd5611e7be45507b9dae4454', 'run_abnormal_receipts', 'dbf289abbd5611e7be45507b9dae4454', null, 'node_20', 'flowPanel_node_20', 'end', '675.00', '532.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, null, '0', null, '1', '1', 'admin', null, '2017-10-30 17:44:02', '2017-10-30 18:01:30');
INSERT INTO `flow_exec_node` VALUES ('de78c1edbd5f11e7be45507b9dae4454', '174', '59dd99f3bd2911e7be45507b9dae4454', '000d2d76bd2a11e7be45507b9dae4454', 'afd04f50bd2811e7be45507b9dae4454', 'run_waste_transfer', 'de78c1edbd5f11e7be45507b9dae4454', '校对部门', 'node_1', 'flowPanel_node_1', 'start', '111.00', '82.00', '130', '55', null, null, '申报', '', null, '1', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 18:48:37', '2017-10-30 18:48:37');
INSERT INTO `flow_exec_node` VALUES ('de7b6e2cbd5f11e7be45507b9dae4454', '175', '59dd99f3bd2911e7be45507b9dae4454', '001d25cebd2a11e7be45507b9dae4454', 'afd04f50bd2811e7be45507b9dae4454', 'run_waste_transfer', 'de78c1edbd5f11e7be45507b9dae4454', null, 'node_3', 'flowPanel_node_3', 'node', '342.00', '80.00', '130', '55', null, null, '校对部门', '', null, '2', null, null, null, null, '0', null, '1', '1', 'admin', null, '2017-10-30 18:48:37', '2017-10-30 18:48:37');
INSERT INTO `flow_exec_node` VALUES ('de7d79b4bd5f11e7be45507b9dae4454', '176', '59dd99f3bd2911e7be45507b9dae4454', '002a050cbd2a11e7be45507b9dae4454', 'afd04f50bd2811e7be45507b9dae4454', 'run_waste_transfer', 'de78c1edbd5f11e7be45507b9dae4454', null, 'node_4', 'flowPanel_node_4', 'node', '572.00', '91.00', '130', '55', null, null, '计价部门', '', null, '3', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-10-30 18:48:37', '2017-10-30 18:48:37');
INSERT INTO `flow_exec_node` VALUES ('de806fbabd5f11e7be45507b9dae4454', '177', '59dd99f3bd2911e7be45507b9dae4454', '0031d71cbd2a11e7be45507b9dae4454', 'afd04f50bd2811e7be45507b9dae4454', 'run_waste_transfer', 'de78c1edbd5f11e7be45507b9dae4454', null, 'node_5', 'flowPanel_node_5', 'node', '808.00', '99.00', '130', '55', null, null, '采购部门', '', null, '1', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-10-30 18:48:37', '2017-10-30 18:48:37');
INSERT INTO `flow_exec_node` VALUES ('de8275cabd5f11e7be45507b9dae4454', '178', '59dd99f3bd2911e7be45507b9dae4454', '00387985bd2a11e7be45507b9dae4454', 'afd04f50bd2811e7be45507b9dae4454', 'run_waste_transfer', 'de78c1edbd5f11e7be45507b9dae4454', null, 'node_7', 'flowPanel_node_7', 'end', '824.00', '211.00', '130', '55', null, null, '注销部门', '', null, '4', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-10-30 18:48:37', '2017-10-30 18:48:37');
INSERT INTO `flow_exec_node` VALUES ('e3c2200cbd2511e7be45507b9dae4454', '99', '9e40c480b54011e7a96c507b9dae4454', 'dc823a5ab95311e791be507b9dae4454', 'e3be3b96bd2511e7be45507b9dae4454', 'run_abnormal_receipts', 'e3c2200cbd2511e7be45507b9dae4454', '领导批示', 'node_9', 'flowPanel_node_9', 'start', '195.00', '53.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, null, '1', null, '2', '1', 'admin', null, '2017-10-30 11:53:29', '2017-10-30 11:54:04');
INSERT INTO `flow_exec_node` VALUES ('e3c43172bd2511e7be45507b9dae4454', '100', '9e40c480b54011e7a96c507b9dae4454', 'dc830dcbb95311e791be507b9dae4454', 'e3be3b96bd2511e7be45507b9dae4454', 'run_abnormal_receipts', 'e3c2200cbd2511e7be45507b9dae4454', null, 'node_10', 'flowPanel_node_10', 'node', '375.00', '99.00', '128', '53', null, null, '收费站意见', '', null, '2', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 11:53:29', '2017-10-30 11:53:47');
INSERT INTO `flow_exec_node` VALUES ('e3c55ff6bd2511e7be45507b9dae4454', '101', '9e40c480b54011e7a96c507b9dae4454', 'dc84e5f9b95311e791be507b9dae4454', 'e3be3b96bd2511e7be45507b9dae4454', 'run_abnormal_receipts', 'e3c2200cbd2511e7be45507b9dae4454', null, 'node_11', 'flowPanel_node_11', 'node', '385.00', '219.00', '128', '53', null, null, '稽查意见', '', null, '2', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 11:53:29', '2017-10-30 11:53:51');
INSERT INTO `flow_exec_node` VALUES ('e3c7e095bd2511e7be45507b9dae4454', '102', '9e40c480b54011e7a96c507b9dae4454', 'dc865c63b95311e791be507b9dae4454', 'e3be3b96bd2511e7be45507b9dae4454', 'run_abnormal_receipts', 'e3c2200cbd2511e7be45507b9dae4454', null, 'node_12', 'flowPanel_node_12', 'node', '389.00', '316.00', '128', '53', null, null, '营运部意见', '', null, '2', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 11:53:29', '2017-10-30 11:53:56');
INSERT INTO `flow_exec_node` VALUES ('e3c8e73dbd2511e7be45507b9dae4454', '103', '9e40c480b54011e7a96c507b9dae4454', 'dc87b6d0b95311e791be507b9dae4454', 'e3be3b96bd2511e7be45507b9dae4454', 'run_abnormal_receipts', 'e3c2200cbd2511e7be45507b9dae4454', null, 'node_13', 'flowPanel_node_13', 'node', '379.00', '434.00', '128', '53', null, null, '相关部门意见', '', null, '2', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 11:53:29', '2017-10-30 11:53:59');
INSERT INTO `flow_exec_node` VALUES ('e3ca9620bd2511e7be45507b9dae4454', '104', '9e40c480b54011e7a96c507b9dae4454', 'dc88ff8cb95311e791be507b9dae4454', 'e3be3b96bd2511e7be45507b9dae4454', 'run_abnormal_receipts', 'e3c2200cbd2511e7be45507b9dae4454', null, 'node_14', 'flowPanel_node_14', 'node', '384.00', '527.00', '128', '53', null, null, '领导批示', '', null, '2', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 11:53:29', '2017-10-30 11:54:04');
INSERT INTO `flow_exec_node` VALUES ('e3cb9680bd2511e7be45507b9dae4454', '105', '9e40c480b54011e7a96c507b9dae4454', 'dc8a2d04b95311e791be507b9dae4454', 'e3be3b96bd2511e7be45507b9dae4454', 'run_abnormal_receipts', 'e3c2200cbd2511e7be45507b9dae4454', null, 'node_20', 'flowPanel_node_20', 'end', '675.00', '532.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-10-30 11:53:29', '2017-10-30 11:53:29');
INSERT INTO `flow_exec_node` VALUES ('e4fad48ebd1e11e7be45507b9dae4454', '92', '9e40c480b54011e7a96c507b9dae4454', 'dc823a5ab95311e791be507b9dae4454', 'e4f69231bd1e11e7be45507b9dae4454', 'run_abnormal_receipts', 'e4fad48ebd1e11e7be45507b9dae4454', '领导批示', 'node_9', 'flowPanel_node_9', 'start', '195.00', '53.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, null, '1', null, '2', '1', 'admin', null, '2017-10-30 11:03:25', '2017-10-30 11:47:04');
INSERT INTO `flow_exec_node` VALUES ('e5018dedbd1e11e7be45507b9dae4454', '93', '9e40c480b54011e7a96c507b9dae4454', 'dc830dcbb95311e791be507b9dae4454', 'e4f69231bd1e11e7be45507b9dae4454', 'run_abnormal_receipts', 'e4fad48ebd1e11e7be45507b9dae4454', null, 'node_10', 'flowPanel_node_10', 'node', '375.00', '99.00', '128', '53', null, null, '收费站意见', '', null, '2', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 11:03:25', '2017-10-30 11:04:09');
INSERT INTO `flow_exec_node` VALUES ('e5026f9cbd1e11e7be45507b9dae4454', '94', '9e40c480b54011e7a96c507b9dae4454', 'dc84e5f9b95311e791be507b9dae4454', 'e4f69231bd1e11e7be45507b9dae4454', 'run_abnormal_receipts', 'e4fad48ebd1e11e7be45507b9dae4454', null, 'node_11', 'flowPanel_node_11', 'node', '385.00', '219.00', '128', '53', null, null, '稽查意见', '', null, '2', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 11:03:25', '2017-10-30 11:04:34');
INSERT INTO `flow_exec_node` VALUES ('e509ce13bd1e11e7be45507b9dae4454', '95', '9e40c480b54011e7a96c507b9dae4454', 'dc865c63b95311e791be507b9dae4454', 'e4f69231bd1e11e7be45507b9dae4454', 'run_abnormal_receipts', 'e4fad48ebd1e11e7be45507b9dae4454', null, 'node_12', 'flowPanel_node_12', 'node', '389.00', '316.00', '128', '53', null, null, '营运部意见', '', null, '2', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 11:03:25', '2017-10-30 11:04:38');
INSERT INTO `flow_exec_node` VALUES ('e50b4d5abd1e11e7be45507b9dae4454', '96', '9e40c480b54011e7a96c507b9dae4454', 'dc87b6d0b95311e791be507b9dae4454', 'e4f69231bd1e11e7be45507b9dae4454', 'run_abnormal_receipts', 'e4fad48ebd1e11e7be45507b9dae4454', null, 'node_13', 'flowPanel_node_13', 'node', '379.00', '434.00', '128', '53', null, null, '相关部门意见', '', null, '2', null, null, null, null, '0', null, '2', '1', 'admin', null, '2017-10-30 11:03:25', '2017-10-30 11:04:45');
INSERT INTO `flow_exec_node` VALUES ('e50dbaddbd1e11e7be45507b9dae4454', '97', '9e40c480b54011e7a96c507b9dae4454', 'dc88ff8cb95311e791be507b9dae4454', 'e4f69231bd1e11e7be45507b9dae4454', 'run_abnormal_receipts', 'e4fad48ebd1e11e7be45507b9dae4454', null, 'node_14', 'flowPanel_node_14', 'node', '384.00', '527.00', '128', '53', null, null, '领导批示', '', null, '2', null, null, null, null, '0', null, '1', '1', 'admin', null, '2017-10-30 11:03:25', '2017-10-30 11:04:45');
INSERT INTO `flow_exec_node` VALUES ('e50e9e45bd1e11e7be45507b9dae4454', '98', '9e40c480b54011e7a96c507b9dae4454', 'dc8a2d04b95311e791be507b9dae4454', 'e4f69231bd1e11e7be45507b9dae4454', 'run_abnormal_receipts', 'e4fad48ebd1e11e7be45507b9dae4454', null, 'node_20', 'flowPanel_node_20', 'end', '675.00', '532.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, null, '0', null, '0', '1', 'admin', null, '2017-10-30 11:03:25', '2017-10-30 11:03:25');

-- ----------------------------
-- Table structure for flow_proc_def
-- ----------------------------
DROP TABLE IF EXISTS `flow_proc_def`;
CREATE TABLE `flow_proc_def` (
  `id` varchar(32) NOT NULL,
  `sort` bigint(20) NOT NULL AUTO_INCREMENT,
  `process_code` varchar(100) DEFAULT NULL,
  `process_name` varchar(100) DEFAULT NULL,
  `description` varchar(300) DEFAULT NULL,
  `numb_template` varchar(100) DEFAULT NULL,
  `curr_year` varchar(10) DEFAULT NULL,
  `curr_sn` int(11) DEFAULT NULL,
  `status` smallint(6) DEFAULT NULL COMMENT '状态',
  `flag` smallint(6) DEFAULT NULL,
  `create_by` varchar(50) DEFAULT NULL,
  `update_by` varchar(50) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_def_sort` (`sort`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of flow_proc_def
-- ----------------------------
INSERT INTO `flow_proc_def` VALUES ('12928861bf7811e79515507b9dae4454', '11', 'run_staff_performance_2', '绩效管理送人事部', '', '', '2017', '0', '1', null, 'admin', null, '2017-11-02 10:46:49', '2017-11-02 10:46:49');
INSERT INTO `flow_proc_def` VALUES ('1f8e9ffeb86b11e783e5507b9dae4454', '4', 'run_staff_performance_1', '绩效管理送部门领导', '', '', '2017', '0', '1', null, 'admin', 'admin', '2017-10-24 11:26:30', '2017-11-02 10:47:05');
INSERT INTO `flow_proc_def` VALUES ('59dd99f3bd2911e7be45507b9dae4454', '10', 'run_waste_transfer', 'run_waste_transfer', '1', '1234', '2017', '0', '1', null, 'admin', 'admin', '2017-10-30 12:18:20', '2017-11-03 16:20:15');
INSERT INTO `flow_proc_def` VALUES ('8a3be65eb89911e783e5507b9dae4454', '9', 'run_take_monitor', '调取监控审批', '', '[${year}]CH-YY-05-${sn}', '2017', '0', '1', null, 'admin', 'admin', '2017-10-24 16:58:47', '2017-11-02 17:06:03');
INSERT INTO `flow_proc_def` VALUES ('9e40c480b54011e7a96c507b9dae4454', '1', 'run_abnormal_receipts', 'run_abnormal_receipts', '收费异常登记流程', '[${year}]YY-13-${sn}', '2017', '3', '1', null, 'admin', 'admin', '2017-10-20 10:44:34', '2017-11-06 10:04:34');

-- ----------------------------
-- Table structure for flow_proc_identitylink
-- ----------------------------
DROP TABLE IF EXISTS `flow_proc_identitylink`;
CREATE TABLE `flow_proc_identitylink` (
  `id` varchar(32) NOT NULL,
  `sort` bigint(20) NOT NULL AUTO_INCREMENT,
  `proc_def_id` varchar(32) DEFAULT NULL,
  `node_id` varchar(32) DEFAULT NULL,
  `user_id` varchar(32) DEFAULT NULL,
  `depart_id` varchar(32) DEFAULT NULL,
  `type` smallint(6) DEFAULT NULL,
  `status` smallint(6) DEFAULT NULL COMMENT '状态',
  `create_by` varchar(50) DEFAULT NULL,
  `update_by` varchar(50) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_proc_idlink_sort` (`sort`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of flow_proc_identitylink
-- ----------------------------
INSERT INTO `flow_proc_identitylink` VALUES ('001463afbd2a11e7be45507b9dae4454', '23', '59dd99f3bd2911e7be45507b9dae4454', '000d2d76bd2a11e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, '1', '1', 'admin', null, '2017-10-30 12:22:59', '2017-10-30 12:22:59');
INSERT INTO `flow_proc_identitylink` VALUES ('00285592bd2a11e7be45507b9dae4454', '24', '59dd99f3bd2911e7be45507b9dae4454', '001d25cebd2a11e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, '1', '1', 'admin', null, '2017-10-30 12:22:59', '2017-10-30 12:22:59');
INSERT INTO `flow_proc_identitylink` VALUES ('002ed57ebd2a11e7be45507b9dae4454', '25', '59dd99f3bd2911e7be45507b9dae4454', '002a050cbd2a11e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, '1', '1', 'admin', null, '2017-10-30 12:22:59', '2017-10-30 12:22:59');
INSERT INTO `flow_proc_identitylink` VALUES ('00350befbd2a11e7be45507b9dae4454', '26', '59dd99f3bd2911e7be45507b9dae4454', '0031d71cbd2a11e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, '1', '1', 'admin', null, '2017-10-30 12:22:59', '2017-10-30 12:22:59');
INSERT INTO `flow_proc_identitylink` VALUES ('003b8ab7bd2a11e7be45507b9dae4454', '27', '59dd99f3bd2911e7be45507b9dae4454', '00387985bd2a11e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, '1', '1', 'admin', null, '2017-10-30 12:23:00', '2017-10-30 12:23:00');
INSERT INTO `flow_proc_identitylink` VALUES ('c707ec4cbabb11e7a2d8507b9dae4454', '18', '9e40c480b54011e7a96c507b9dae4454', 'dc830dcbb95311e791be507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, '1', '1', 'admin', null, '2017-10-27 10:08:52', '2017-10-27 10:08:52');
INSERT INTO `flow_proc_identitylink` VALUES ('c709dc61babb11e7a2d8507b9dae4454', '19', '9e40c480b54011e7a96c507b9dae4454', 'dc84e5f9b95311e791be507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, '1', '1', 'admin', null, '2017-10-27 10:08:52', '2017-10-27 10:08:52');
INSERT INTO `flow_proc_identitylink` VALUES ('c70badb3babb11e7a2d8507b9dae4454', '20', '9e40c480b54011e7a96c507b9dae4454', 'dc865c63b95311e791be507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, '1', '1', 'admin', null, '2017-10-27 10:08:52', '2017-10-27 10:08:52');
INSERT INTO `flow_proc_identitylink` VALUES ('c70d6701babb11e7a2d8507b9dae4454', '21', '9e40c480b54011e7a96c507b9dae4454', 'dc87b6d0b95311e791be507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, '1', '1', 'admin', null, '2017-10-27 10:08:52', '2017-10-27 10:08:52');
INSERT INTO `flow_proc_identitylink` VALUES ('c710e22ebabb11e7a2d8507b9dae4454', '22', '9e40c480b54011e7a96c507b9dae4454', 'dc88ff8cb95311e791be507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, '1', '1', 'admin', null, '2017-10-27 10:08:52', '2017-10-27 10:08:52');

-- ----------------------------
-- Table structure for flow_proc_line
-- ----------------------------
DROP TABLE IF EXISTS `flow_proc_line`;
CREATE TABLE `flow_proc_line` (
  `id` varchar(32) NOT NULL,
  `sort` bigint(20) NOT NULL AUTO_INCREMENT,
  `proc_def_id` varchar(32) DEFAULT NULL,
  `line_name` varchar(100) DEFAULT NULL,
  `line_type` varchar(20) DEFAULT NULL,
  `line_code` varchar(50) DEFAULT NULL,
  `line_alt` tinyint(255) DEFAULT NULL,
  `mid_pos` decimal(8,2) DEFAULT NULL,
  `pre_node_id` varchar(32) DEFAULT NULL,
  `next_node_id` varchar(32) DEFAULT NULL,
  `status` smallint(6) DEFAULT NULL COMMENT '状态',
  `create_by` varchar(50) DEFAULT NULL,
  `update_by` varchar(50) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_proc_line_sort` (`sort`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of flow_proc_line
-- ----------------------------
INSERT INTO `flow_proc_line` VALUES ('0042216cbd2a11e7be45507b9dae4454', '11', '59dd99f3bd2911e7be45507b9dae4454', '', '', '', null, null, '000d2d76bd2a11e7be45507b9dae4454', '001d25cebd2a11e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 12:23:00', '2017-10-30 12:23:00');
INSERT INTO `flow_proc_line` VALUES ('004c5916bd2a11e7be45507b9dae4454', '12', '59dd99f3bd2911e7be45507b9dae4454', '', '', '', null, null, '001d25cebd2a11e7be45507b9dae4454', '002a050cbd2a11e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 12:23:00', '2017-10-30 12:23:00');
INSERT INTO `flow_proc_line` VALUES ('00503f9ebd2a11e7be45507b9dae4454', '13', '59dd99f3bd2911e7be45507b9dae4454', '', '', '', null, null, '002a050cbd2a11e7be45507b9dae4454', '0031d71cbd2a11e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 12:23:00', '2017-10-30 12:23:00');
INSERT INTO `flow_proc_line` VALUES ('00525d94bd2a11e7be45507b9dae4454', '14', '59dd99f3bd2911e7be45507b9dae4454', '', '', '', null, null, '0031d71cbd2a11e7be45507b9dae4454', '00387985bd2a11e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 12:23:00', '2017-10-30 12:23:00');
INSERT INTO `flow_proc_line` VALUES ('0134b152bf7811e79515507b9dae4454', '18', '1f8e9ffeb86b11e783e5507b9dae4454', '', '', '', null, null, '01300577bf7811e79515507b9dae4454', '01325768bf7811e79515507b9dae4454', '1', 'admin', null, '2017-11-02 10:46:20', '2017-11-02 10:46:20');
INSERT INTO `flow_proc_line` VALUES ('0137bfe2bf7811e79515507b9dae4454', '19', '1f8e9ffeb86b11e783e5507b9dae4454', '', '', '', null, null, '01325768bf7811e79515507b9dae4454', '01315b51bf7811e79515507b9dae4454', '1', 'admin', null, '2017-11-02 10:46:20', '2017-11-02 10:46:20');
INSERT INTO `flow_proc_line` VALUES ('353fba74bf7811e79515507b9dae4454', '20', '12928861bf7811e79515507b9dae4454', '', '', '', null, null, '353bd697bf7811e79515507b9dae4454', '353f24f1bf7811e79515507b9dae4454', '1', 'admin', null, '2017-11-02 10:47:47', '2017-11-02 10:47:47');
INSERT INTO `flow_proc_line` VALUES ('35404219bf7811e79515507b9dae4454', '21', '12928861bf7811e79515507b9dae4454', '', '', '', null, null, '353f24f1bf7811e79515507b9dae4454', '353e7b30bf7811e79515507b9dae4454', '1', 'admin', null, '2017-11-02 10:47:47', '2017-11-02 10:47:47');
INSERT INTO `flow_proc_line` VALUES ('b9c71302bd2b11e7be45507b9dae4454', '15', '8a3be65eb89911e783e5507b9dae4454', '', '', '', null, null, 'b9c12bf1bd2b11e7be45507b9dae4454', 'b9c547d9bd2b11e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 12:35:16', '2017-10-30 12:35:16');
INSERT INTO `flow_proc_line` VALUES ('b9c7dac1bd2b11e7be45507b9dae4454', '16', '8a3be65eb89911e783e5507b9dae4454', '', '', '', null, null, 'b9c547d9bd2b11e7be45507b9dae4454', 'b9c65c12bd2b11e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 12:35:16', '2017-10-30 12:35:16');
INSERT INTO `flow_proc_line` VALUES ('b9c874b8bd2b11e7be45507b9dae4454', '17', '8a3be65eb89911e783e5507b9dae4454', '', '', '', null, null, 'b9c65c12bd2b11e7be45507b9dae4454', 'b9c270a9bd2b11e7be45507b9dae4454', '1', 'admin', null, '2017-10-30 12:35:16', '2017-10-30 12:35:16');
INSERT INTO `flow_proc_line` VALUES ('dc8ac93ab95311e791be507b9dae4454', '5', '9e40c480b54011e7a96c507b9dae4454', '', '', '', null, null, 'dc823a5ab95311e791be507b9dae4454', 'dc830dcbb95311e791be507b9dae4454', '1', 'admin', null, '2017-10-25 15:12:30', '2017-10-25 15:12:30');
INSERT INTO `flow_proc_line` VALUES ('dc8d0ff1b95311e791be507b9dae4454', '6', '9e40c480b54011e7a96c507b9dae4454', '', '', '', null, null, 'dc830dcbb95311e791be507b9dae4454', 'dc84e5f9b95311e791be507b9dae4454', '1', 'admin', null, '2017-10-25 15:12:30', '2017-10-25 15:12:30');
INSERT INTO `flow_proc_line` VALUES ('dc8dd903b95311e791be507b9dae4454', '7', '9e40c480b54011e7a96c507b9dae4454', '', '', '', null, null, 'dc84e5f9b95311e791be507b9dae4454', 'dc865c63b95311e791be507b9dae4454', '1', 'admin', null, '2017-10-25 15:12:30', '2017-10-25 15:12:30');
INSERT INTO `flow_proc_line` VALUES ('dc8e71f7b95311e791be507b9dae4454', '8', '9e40c480b54011e7a96c507b9dae4454', '', '', '', null, null, 'dc865c63b95311e791be507b9dae4454', 'dc87b6d0b95311e791be507b9dae4454', '1', 'admin', null, '2017-10-25 15:12:30', '2017-10-25 15:12:30');
INSERT INTO `flow_proc_line` VALUES ('dc8f047db95311e791be507b9dae4454', '9', '9e40c480b54011e7a96c507b9dae4454', '', '', '', null, null, 'dc87b6d0b95311e791be507b9dae4454', 'dc88ff8cb95311e791be507b9dae4454', '1', 'admin', null, '2017-10-25 15:12:30', '2017-10-25 15:12:30');
INSERT INTO `flow_proc_line` VALUES ('dc8f900bb95311e791be507b9dae4454', '10', '9e40c480b54011e7a96c507b9dae4454', '', '', '', null, null, 'dc88ff8cb95311e791be507b9dae4454', 'dc8a2d04b95311e791be507b9dae4454', '1', 'admin', null, '2017-10-25 15:12:30', '2017-10-25 15:12:30');

-- ----------------------------
-- Table structure for flow_proc_node
-- ----------------------------
DROP TABLE IF EXISTS `flow_proc_node`;
CREATE TABLE `flow_proc_node` (
  `id` varchar(32) NOT NULL,
  `sort` bigint(20) NOT NULL AUTO_INCREMENT,
  `proc_def_id` varchar(32) DEFAULT NULL,
  `node_name` varchar(100) DEFAULT NULL,
  `node_code` varchar(50) DEFAULT NULL,
  `node_type` varchar(20) DEFAULT NULL,
  `left_pos` decimal(8,2) DEFAULT NULL,
  `top_pos` decimal(8,2) DEFAULT NULL,
  `width` varchar(20) DEFAULT NULL,
  `height` varchar(255) DEFAULT NULL,
  `sub_def_id` varchar(32) DEFAULT NULL,
  `proc_type` varchar(20) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `requirement` varchar(300) DEFAULT NULL,
  `note` varchar(300) DEFAULT NULL,
  `limit_day` int(11) DEFAULT NULL,
  `duty_depart_id` varchar(32) DEFAULT NULL,
  `duty_user_id` varchar(32) DEFAULT NULL,
  `allot_strategy` smallint(6) DEFAULT NULL,
  `status` smallint(6) DEFAULT NULL COMMENT '状态',
  `create_by` varchar(50) DEFAULT NULL,
  `update_by` varchar(50) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_proc_node_sort` (`sort`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of flow_proc_node
-- ----------------------------
INSERT INTO `flow_proc_node` VALUES ('000d2d76bd2a11e7be45507b9dae4454', '31', '59dd99f3bd2911e7be45507b9dae4454', 'node_1', 'flowPanel_node_1', 'start', '111.00', '82.00', '130', '55', null, null, '申报', '', null, '1', null, null, null, '1', 'admin', 'admin', '2017-10-30 12:22:59', '2017-10-31 12:29:24');
INSERT INTO `flow_proc_node` VALUES ('001d25cebd2a11e7be45507b9dae4454', '32', '59dd99f3bd2911e7be45507b9dae4454', 'node_3', 'flowPanel_node_3', 'node', '342.00', '80.00', '130', '55', null, null, '校对部门', '', null, '2', null, null, null, '1', 'admin', 'admin', '2017-10-30 12:22:59', '2017-10-31 12:29:24');
INSERT INTO `flow_proc_node` VALUES ('002a050cbd2a11e7be45507b9dae4454', '33', '59dd99f3bd2911e7be45507b9dae4454', 'node_4', 'flowPanel_node_4', 'node', '572.00', '91.00', '130', '55', null, null, '计价部门', '', null, '3', null, null, null, '1', 'admin', 'admin', '2017-10-30 12:22:59', '2017-10-31 12:29:24');
INSERT INTO `flow_proc_node` VALUES ('0031d71cbd2a11e7be45507b9dae4454', '34', '59dd99f3bd2911e7be45507b9dae4454', 'node_5', 'flowPanel_node_5', 'node', '808.00', '99.00', '130', '55', null, null, '采购部门', '', null, '1', null, null, null, '1', 'admin', 'admin', '2017-10-30 12:22:59', '2017-10-31 12:29:24');
INSERT INTO `flow_proc_node` VALUES ('00387985bd2a11e7be45507b9dae4454', '35', '59dd99f3bd2911e7be45507b9dae4454', 'node_7', 'flowPanel_node_7', 'end', '824.00', '211.00', '130', '55', null, null, '注销部门', '', null, '4', null, null, null, '1', 'admin', 'admin', '2017-10-30 12:23:00', '2017-10-31 12:29:24');
INSERT INTO `flow_proc_node` VALUES ('01300577bf7811e79515507b9dae4454', '40', '1f8e9ffeb86b11e783e5507b9dae4454', 'node_1', 'flowPanel_node_1', 'start', '202.00', '128.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, '1', 'admin', null, '2017-11-02 10:46:20', '2017-11-02 10:46:20');
INSERT INTO `flow_proc_node` VALUES ('01315b51bf7811e79515507b9dae4454', '41', '1f8e9ffeb86b11e783e5507b9dae4454', 'node_2', 'flowPanel_node_2', 'end', '734.00', '133.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, '1', 'admin', null, '2017-11-02 10:46:20', '2017-11-02 10:46:20');
INSERT INTO `flow_proc_node` VALUES ('01325768bf7811e79515507b9dae4454', '42', '1f8e9ffeb86b11e783e5507b9dae4454', 'node_3', 'flowPanel_node_3', 'node', '470.00', '132.00', '130', '55', null, null, '领导意见', '', null, '0', null, null, null, '1', 'admin', null, '2017-11-02 10:46:20', '2017-11-02 10:46:20');
INSERT INTO `flow_proc_node` VALUES ('353bd697bf7811e79515507b9dae4454', '43', '12928861bf7811e79515507b9dae4454', 'node_1', 'flowPanel_node_1', 'start', '179.00', '130.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, '1', 'admin', null, '2017-11-02 10:47:47', '2017-11-02 10:47:47');
INSERT INTO `flow_proc_node` VALUES ('353e7b30bf7811e79515507b9dae4454', '44', '12928861bf7811e79515507b9dae4454', 'node_2', 'flowPanel_node_2', 'end', '665.00', '140.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, '1', 'admin', null, '2017-11-02 10:47:47', '2017-11-02 10:47:47');
INSERT INTO `flow_proc_node` VALUES ('353f24f1bf7811e79515507b9dae4454', '45', '12928861bf7811e79515507b9dae4454', 'node_3', 'flowPanel_node_3', 'node', '416.00', '138.00', '130', '55', null, null, '人事部意见', '', null, '0', null, null, null, '1', 'admin', null, '2017-11-02 10:47:47', '2017-11-02 10:47:47');
INSERT INTO `flow_proc_node` VALUES ('b9c12bf1bd2b11e7be45507b9dae4454', '36', '8a3be65eb89911e783e5507b9dae4454', 'node_1', 'flowPanel_node_1', 'start', '168.00', '98.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, '1', 'admin', 'admin', '2017-10-30 12:35:16', '2017-10-31 12:29:32');
INSERT INTO `flow_proc_node` VALUES ('b9c270a9bd2b11e7be45507b9dae4454', '37', '8a3be65eb89911e783e5507b9dae4454', 'node_2', 'flowPanel_node_2', 'end', '854.00', '110.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, '1', 'admin', 'admin', '2017-10-30 12:35:16', '2017-10-31 12:29:32');
INSERT INTO `flow_proc_node` VALUES ('b9c547d9bd2b11e7be45507b9dae4454', '38', '8a3be65eb89911e783e5507b9dae4454', 'node_3', 'flowPanel_node_3', 'node', '393.00', '112.00', '130', '55', null, null, '部门负责人意见', '', null, '0', null, null, null, '1', 'admin', 'admin', '2017-10-30 12:35:16', '2017-10-31 12:29:32');
INSERT INTO `flow_proc_node` VALUES ('b9c65c12bd2b11e7be45507b9dae4454', '39', '8a3be65eb89911e783e5507b9dae4454', 'node_4', 'flowPanel_node_4', 'node', '634.00', '110.00', '130', '55', null, null, '分管领导意见', '', null, '0', null, null, null, '1', 'admin', 'admin', '2017-10-30 12:35:16', '2017-10-31 12:29:32');
INSERT INTO `flow_proc_node` VALUES ('dc823a5ab95311e791be507b9dae4454', '24', '9e40c480b54011e7a96c507b9dae4454', 'node_9', 'flowPanel_node_9', 'start', '195.00', '53.00', '130', '55', null, null, '登记', '', null, '0', null, null, null, '1', 'admin', 'admin', '2017-10-25 15:12:30', '2017-10-27 10:08:52');
INSERT INTO `flow_proc_node` VALUES ('dc830dcbb95311e791be507b9dae4454', '25', '9e40c480b54011e7a96c507b9dae4454', 'node_10', 'flowPanel_node_10', 'node', '375.00', '99.00', '128', '53', null, null, '收费站意见', '', null, '2', null, null, null, '1', 'admin', 'admin', '2017-10-25 15:12:30', '2017-10-27 10:08:52');
INSERT INTO `flow_proc_node` VALUES ('dc84e5f9b95311e791be507b9dae4454', '26', '9e40c480b54011e7a96c507b9dae4454', 'node_11', 'flowPanel_node_11', 'node', '385.00', '219.00', '128', '53', null, null, '稽查意见', '', null, '2', null, null, null, '1', 'admin', 'admin', '2017-10-25 15:12:30', '2017-10-27 10:08:52');
INSERT INTO `flow_proc_node` VALUES ('dc865c63b95311e791be507b9dae4454', '27', '9e40c480b54011e7a96c507b9dae4454', 'node_12', 'flowPanel_node_12', 'node', '389.00', '316.00', '128', '53', null, null, '营运部意见', '', null, '2', null, null, null, '1', 'admin', 'admin', '2017-10-25 15:12:30', '2017-10-27 10:08:52');
INSERT INTO `flow_proc_node` VALUES ('dc87b6d0b95311e791be507b9dae4454', '28', '9e40c480b54011e7a96c507b9dae4454', 'node_13', 'flowPanel_node_13', 'node', '379.00', '434.00', '128', '53', null, null, '相关部门意见', '', null, '2', null, null, null, '1', 'admin', 'admin', '2017-10-25 15:12:30', '2017-10-27 10:08:52');
INSERT INTO `flow_proc_node` VALUES ('dc88ff8cb95311e791be507b9dae4454', '29', '9e40c480b54011e7a96c507b9dae4454', 'node_14', 'flowPanel_node_14', 'node', '384.00', '527.00', '128', '53', null, null, '领导批示', '', null, '2', null, null, null, '1', 'admin', 'admin', '2017-10-25 15:12:30', '2017-10-27 10:08:52');
INSERT INTO `flow_proc_node` VALUES ('dc8a2d04b95311e791be507b9dae4454', '30', '9e40c480b54011e7a96c507b9dae4454', 'node_20', 'flowPanel_node_20', 'end', '675.00', '532.00', '130', '55', null, null, '结束', '', null, '0', null, null, null, '1', 'admin', 'admin', '2017-10-25 15:12:30', '2017-10-27 10:08:52');

-- ----------------------------
-- Table structure for m_base_file
-- ----------------------------
DROP TABLE IF EXISTS `m_base_file`;
CREATE TABLE `m_base_file` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `file_name` varchar(255) NOT NULL,
  `pattern` varchar(255) NOT NULL,
  `big_pattern` varchar(255) DEFAULT NULL,
  `content_type` varchar(100) DEFAULT NULL,
  `create_by` varchar(50) DEFAULT NULL,
  `file_kind` smallint(6) NOT NULL,
  `file_size` varchar(30) DEFAULT NULL,
  `file_type` varchar(10) NOT NULL,
  `length` bigint(20) NOT NULL,
  `md5_code` varchar(32) DEFAULT NULL,
  `real_name` varchar(80) DEFAULT NULL,
  `save_path` varchar(255) NOT NULL,
  `transfer_path` varchar(255) DEFAULT NULL,
  `zone_path_id` bigint(20) NOT NULL,
  `turn_status` smallint(6) DEFAULT NULL,
  `main_id` bigint(20) DEFAULT NULL,
  `status` smallint(6) NOT NULL DEFAULT '0',
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of m_base_file
-- ----------------------------
INSERT INTO `m_base_file` VALUES ('1', '9812955_195532282173_2.jpg', '2017\\09-06\\2e10f77b-afaf-4ebb-ab7a-15accd1298bc.jpg', '2017\\09-06\\2e10f77b-afaf-4ebb-ab7a-15accd1298bc.jpg', 'image/jpeg', 'admin', '1', '97.88KB', 'jpg', '100230', '5516DDFAFEEE7EDD57A90D88F5B22852', '6fc232bde2a543a096d9f129ddec04ca.jpg', '2017\\09-06\\6fc232bde2a543a096d9f129ddec04ca.jpg', null, '1', '2', null, '1', '2017-09-06 12:26:16', '2017-09-06 12:26:16');
INSERT INTO `m_base_file` VALUES ('2', 'u=659165267,1439470182&fm=21&gp=0.jpg', '2017\\09-06\\b2471e79-faa3-4d08-8d5c-471ebfb16113.jpg', '2017\\09-06\\b2471e79-faa3-4d08-8d5c-471ebfb16113.jpg', 'image/jpeg', 'admin', '1', '12.41KB', 'jpg', '12709', '0080AC11FAFC5B8E340B3D6229DEF0B0', '21f1fce4b3c74660b71e58c5a557b51a.jpg', '2017\\09-06\\21f1fce4b3c74660b71e58c5a557b51a.jpg', null, '1', '2', null, '1', '2017-09-06 12:26:16', '2017-09-06 12:26:16');
INSERT INTO `m_base_file` VALUES ('3', 'Desert.jpg', '2017/09-06/6d738aa7-cb28-4460-9574-bc94eca8ec4d.jpg', '2017/09-06/fcc9b2d7-94c0-4030-b9e9-ec97d2be1435.jpg', 'image/jpeg', 'admin', '1', '826.11KB', 'jpg', '845941', 'BA45C8F60456A672E003A875E469D0EB', '339dca5477064369b7a69629c3823f59.jpg', '2017\\09-06\\339dca5477064369b7a69629c3823f59.jpg', null, '1', '2', null, '1', '2017-09-06 15:13:09', '2017-09-06 15:13:09');
INSERT INTO `m_base_file` VALUES ('4', '用户信息导入.xls', 'images/fileIcon/fileicon-large-xls.png', null, 'application/vnd.ms-excel', 'admin', '4', '23.50KB', 'xls', '24064', '71B5BE2AC88A884869C1AE8C48911E14', 'b188a72546514d54a27ce4c1e6f09c31.xls', '2017\\09-06\\b188a72546514d54a27ce4c1e6f09c31.xls', '2017/09-06/9c6bb6f7cd96472cb71eeccff7934796.swf', '1', '0', null, '1', '2017-09-06 15:13:31', '2017-09-06 15:13:31');
INSERT INTO `m_base_file` VALUES ('6', '50ee6a17d6e0f89b1089a6b16865d506.jpg', '2017\\09-07\\93bfc39f-b6ad-4e57-a1ed-57815862a8b9.jpg', '2017\\09-07\\93bfc39f-b6ad-4e57-a1ed-57815862a8b9.jpg', 'image/jpeg', 'admin', '1', '10.73KB', 'jpg', '10992', '2E91ECE19A2BA38963F45638054E0E06', '51cd91a4b4e74969891995b4b7a73ea0.jpg', '2017\\09-07\\51cd91a4b4e74969891995b4b7a73ea0.jpg', null, '1', '2', null, '1', '2017-09-07 14:32:22', '2017-09-07 14:32:22');
INSERT INTO `m_base_file` VALUES ('8', '50ee6a17d6e0f89b1089a6b16865d506.jpg', '2017\\09-07\\f61be76b-7af4-4b84-a8a7-bf1d34901904.jpg', '2017\\09-07\\f61be76b-7af4-4b84-a8a7-bf1d34901904.jpg', 'image/jpeg', 'admin', '1', '10.73KB', 'jpg', '10992', '2E91ECE19A2BA38963F45638054E0E06', 'dd5abfd1f98f4988b7f5951428bcfbd3.jpg', '2017\\09-07\\dd5abfd1f98f4988b7f5951428bcfbd3.jpg', null, '1', '2', null, '1', '2017-09-07 14:36:30', '2017-09-07 14:36:30');
INSERT INTO `m_base_file` VALUES ('9', '50ee6a17d6e0f89b1089a6b16865d506.jpg', '2017\\09-07\\f69bdc1a-debb-4191-a403-d911b9fd1541.jpg', '2017\\09-07\\f69bdc1a-debb-4191-a403-d911b9fd1541.jpg', 'image/jpeg', 'admin', '1', '10.73KB', 'jpg', '10992', '2E91ECE19A2BA38963F45638054E0E06', '5fd605c4917140a0b5263bf830dd46a9.jpg', '2017\\09-07\\5fd605c4917140a0b5263bf830dd46a9.jpg', null, '1', '2', null, '1', '2017-09-07 14:48:32', '2017-09-07 14:48:32');
INSERT INTO `m_base_file` VALUES ('10', '50ee6a17d6e0f89b1089a6b16865d506.jpg', '2017\\09-07\\58e21e3b-6333-4afe-855b-6e181a3f8584.jpg', '2017\\09-07\\58e21e3b-6333-4afe-855b-6e181a3f8584.jpg', 'image/jpeg', 'admin', '1', '10.73KB', 'jpg', '10992', '2E91ECE19A2BA38963F45638054E0E06', '48fa0cd40e614d7898c13c48477c475f.jpg', '2017\\09-07\\48fa0cd40e614d7898c13c48477c475f.jpg', null, '1', '2', null, '1', '2017-09-07 14:50:27', '2017-09-07 14:50:27');
INSERT INTO `m_base_file` VALUES ('11', '50ee6a17d6e0f89b1089a6b16865d506.jpg', '2017\\09-07\\7ac6029e-9645-41f9-9cdd-b5551318b32f.jpg', '2017\\09-07\\7ac6029e-9645-41f9-9cdd-b5551318b32f.jpg', 'image/jpeg', 'admin', '1', '10.73KB', 'jpg', '10992', '2E91ECE19A2BA38963F45638054E0E06', 'f2f2b3329a9c4a5b904430ffec3cc266.jpg', '2017\\09-07\\f2f2b3329a9c4a5b904430ffec3cc266.jpg', null, '1', '2', null, '1', '2017-09-07 14:52:07', '2017-09-07 14:52:07');
INSERT INTO `m_base_file` VALUES ('16', '92ad0bdae07578e57e6c2d8c64e7c74a.jpg', '2017\\09-07\\6d2ff977-0eb6-4d35-9163-4b7d23bdea19.jpg', '2017\\09-07\\6d2ff977-0eb6-4d35-9163-4b7d23bdea19.jpg', 'image/jpeg', 'admin', '1', '69.56KB', 'jpg', '71228', 'DB8BF7CDEDC1401F5C509705055034EF', 'a8e28c55672145f2ac944e4e1c6c689b.jpg', '2017\\09-07\\a8e28c55672145f2ac944e4e1c6c689b.jpg', null, '1', '2', null, '1', '2017-09-07 16:34:10', '2017-09-07 16:34:10');
INSERT INTO `m_base_file` VALUES ('17', '指导平台接口说明.doc', 'images/fileIcon/fileicon-large-doc.png', null, 'application/msword', 'admin', '4', '58.00KB', 'doc', '59392', '77062EAAD1EE6BEDB574390F8CFA875B', '5434c275327146e68f581127955bf48b.doc', '2017\\09-15\\5434c275327146e68f581127955bf48b.doc', '2017/09-15/893c7b48616d4c32820aa825f659de15.swf', '1', '0', null, '1', '2017-09-15 15:37:13', '2017-09-15 15:37:13');
INSERT INTO `m_base_file` VALUES ('18', 'test.pdf', 'images/fileIcon/fileicon-large-pdf.png', null, 'application/pdf', 'admin', '4', '812bytes', 'pdf', '812', 'EA8CBA65FEF133C6F0D2BC42D7DFDD00', '8658e921367c479a82c407a3df8ba1b5.pdf', '2017\\09-18\\8658e921367c479a82c407a3df8ba1b5.pdf', '2017/09-18/a0c395ba713a44aaab0f4a8720e135ba.swf', '1', '0', null, '1', '2017-09-18 11:12:59', '2017-09-18 11:12:59');
INSERT INTO `m_base_file` VALUES ('20', 'template.pdf', 'images/fileIcon/fileicon-large-pdf.png', null, 'application/pdf', 'admin', '4', '41.28KB', 'pdf', '42267', 'E19EC45A5934BC5F7ACC071AD73CDD7E', '80b5426363444e198317df0a86022b3f.pdf', '2017\\09-18\\80b5426363444e198317df0a86022b3f.pdf', '2017/09-18/5c8c71ed05c243acb380c18e74667241.swf', '1', '0', null, '1', '2017-09-18 11:20:46', '2017-09-18 11:20:46');
INSERT INTO `m_base_file` VALUES ('21', 'Desert.jpg', '2017/09-18/cb7080c1-9cb1-41b9-93de-aa63e0139209.jpg', '2017/09-18/07af667b-7efb-4698-a065-d2f46f49cda5.jpg', 'image/jpeg', 'admin', '1', '826.11KB', 'jpg', '845941', 'BA45C8F60456A672E003A875E469D0EB', '9dc5fc21f4ac406ca03a32e8be80381c.jpg', '2017\\09-18\\9dc5fc21f4ac406ca03a32e8be80381c.jpg', null, '1', '2', null, '1', '2017-09-18 12:20:50', '2017-09-18 12:20:50');
INSERT INTO `m_base_file` VALUES ('22', 'Tulips.jpg', '2017/09-18/3f4f84b1-7133-4738-98a8-5a2f5f983dca.jpg', '2017/09-18/9db99d9b-6397-4bb1-9459-82d280b9fd68.jpg', 'image/jpeg', 'admin', '1', '606.34KB', 'jpg', '620888', 'FAFA5EFEAF3CBE3B23B2748D13E629A1', '89b515e2d6504dad8c7d8abc83624a31.jpg', '2017\\09-18\\89b515e2d6504dad8c7d8abc83624a31.jpg', null, '1', '2', null, '1', '2017-09-18 12:21:40', '2017-09-18 12:21:40');
INSERT INTO `m_base_file` VALUES ('23', '新建文本文档 (2).txt', 'images/fileIcon/fileicon-large-txt.png', null, 'text/plain', 'admin', '4', '7.17KB', 'txt', '7341', 'A82FC722283D91E91814E7853CD0E062', '01ab49a115d348dfbf646580032b581e.txt', '2017\\09-18\\01ab49a115d348dfbf646580032b581e.txt', '/2017/09-18/03381f0fd6054d7eb028f29f1b2f6b8f.swf', '1', '0', null, '1', '2017-09-18 12:23:07', '2017-09-18 12:23:07');
INSERT INTO `m_base_file` VALUES ('24', '新建文本文档.txt', 'images/fileIcon/fileicon-large-txt.png', null, 'text/plain', 'admin', '4', '76bytes', 'txt', '76', 'BF9E8FC101C8A7C755A74BA130E29804', 'eda59c3def6b4c839e9b39b9436387d2.txt', '2017\\09-18\\eda59c3def6b4c839e9b39b9436387d2.txt', '/2017/09-18/3dc5fabaac784efda4dc2b0aad9d47d7.swf', '1', '0', null, '1', '2017-09-18 12:27:20', '2017-09-18 12:27:20');
INSERT INTO `m_base_file` VALUES ('25', '新建文本文档.txt', 'images/fileIcon/fileicon-large-txt.png', null, 'text/plain', 'admin', '4', '76bytes', 'txt', '76', 'BF9E8FC101C8A7C755A74BA130E29804', '4b157a300ad242f4bf7a29cc04f6a3eb.txt', '2017\\09-18\\4b157a300ad242f4bf7a29cc04f6a3eb.txt', '/2017/09-18/4f289595fef94147a323cfef8585107c.swf', '1', '0', null, '1', '2017-09-18 14:32:33', '2017-09-18 14:32:33');
INSERT INTO `m_base_file` VALUES ('26', '新建文本文档.txt', 'images/fileIcon/fileicon-large-txt.png', null, 'text/plain', 'admin', '4', '76bytes', 'txt', '76', 'BF9E8FC101C8A7C755A74BA130E29804', '5c7d14ce79594520a64d929135311ab8.txt', '2017\\09-18\\5c7d14ce79594520a64d929135311ab8.txt', '/2017/09-18/fafc139957184fe1896a9ebae650153a.swf', '1', '1', null, '1', '2017-09-18 14:33:01', '2017-09-18 14:33:01');
INSERT INTO `m_base_file` VALUES ('27', 'zheng-环境搭建及系统部署文档20170213（修改版）.docx', 'images/fileIcon/Msqq.Com_docx.png', null, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'admin', '4', '7.70MB', 'docx', '8073532', '79C95DB0D09ACC77320CB9F2EB383DC7', '3f3a8b8aaaf54e64ad350d69e8a13d96.docx', '2017\\09-18\\3f3a8b8aaaf54e64ad350d69e8a13d96.docx', '2017/09-18/2cbd374f54e7492db951263622de2f7a.swf', '1', '1', null, '1', '2017-09-18 14:41:26', '2017-09-18 14:41:26');
INSERT INTO `m_base_file` VALUES ('28', '百度地图AK.txt', 'images/fileIcon/fileicon-large-txt.png', null, 'text/plain', 'admin', '4', '84bytes', 'txt', '84', '772738C976D668A66A8230B2BE37199C', '3cb90787917e45d5bc8384cc0b61e1a1.txt', '2017\\09-18\\3cb90787917e45d5bc8384cc0b61e1a1.txt', '2017/09-18/95d224d3ecca4984b0b5f48c8dc2bbc4.swf', '1', '0', null, '1', '2017-09-18 15:46:17', '2017-09-18 15:46:17');
INSERT INTO `m_base_file` VALUES ('29', 'user-template.xls', 'images/fileIcon/fileicon-large-xls.png', null, 'application/vnd.ms-excel', 'admin', '4', '23.50KB', 'xls', '24064', '71B5BE2AC88A884869C1AE8C48911E14', '0d258b0d4fd04083870792b5b19682d0.xls', '2017\\09-18\\0d258b0d4fd04083870792b5b19682d0.xls', '2017/09-18/a267030f48944ece95fe30c59bbb5f10.swf', '1', '1', null, '1', '2017-09-18 15:47:22', '2017-09-18 15:47:22');
INSERT INTO `m_base_file` VALUES ('30', 'Penguins.jpg', '2017\\10-25\\c1243e3d-e4cb-4465-aa1c-466ec6396f43.jpg', '2017\\10-25\\c1243e3d-e4cb-4465-aa1c-466ec6396f43.jpg', 'image/jpeg', 'admin', '1', '273.05KB', 'jpg', '279608', 'E873953C2744D164DFDCAC810867B200', 'c08eb96228024ffd8c1c609794410ad0.jpg', '2017\\10-25\\c08eb96228024ffd8c1c609794410ad0.jpg', null, '1', '2', null, '1', '2017-10-25 16:14:50', '2017-10-25 16:14:50');
INSERT INTO `m_base_file` VALUES ('31', 'Tulips.jpg', '2017\\10-25\\2d018bef-dde9-4491-b8dd-0c787e320f4c.jpg', '2017\\10-25\\2d018bef-dde9-4491-b8dd-0c787e320f4c.jpg', 'image/jpeg', 'admin', '1', '220.83KB', 'jpg', '226127', '7AF869D174C5A45CFA7BF6EFD4BA0B56', '7698b1e4f36d4efba0d95483c718e8e8.jpg', '2017\\10-25\\7698b1e4f36d4efba0d95483c718e8e8.jpg', null, '1', '2', null, '1', '2017-10-25 16:14:50', '2017-10-25 16:14:50');
INSERT INTO `m_base_file` VALUES ('32', 'Tulips.jpg', '2017\\10-25\\faf0cd29-43bd-4321-b1f6-52cf811a8769.jpg', '2017\\10-25\\faf0cd29-43bd-4321-b1f6-52cf811a8769.jpg', 'image/jpeg', 'admin', '1', '220.83KB', 'jpg', '226127', '7AF869D174C5A45CFA7BF6EFD4BA0B56', '4dfa11b197d9467b9530933acac6dd34.jpg', '2017\\10-25\\4dfa11b197d9467b9530933acac6dd34.jpg', null, '1', '2', null, '1', '2017-10-25 16:17:36', '2017-10-25 16:17:36');
INSERT INTO `m_base_file` VALUES ('33', 'Tulips.jpg', '2017\\10-25\\4664c7f7-d57a-49b8-9074-a0857416604a.jpg', '2017\\10-25\\4664c7f7-d57a-49b8-9074-a0857416604a.jpg', 'image/jpeg', 'admin', '1', '220.83KB', 'jpg', '226127', '7AF869D174C5A45CFA7BF6EFD4BA0B56', '76083a61d97a4af2a5f417dd879a99a8.jpg', '2017\\10-25\\76083a61d97a4af2a5f417dd879a99a8.jpg', null, '1', '2', null, '1', '2017-10-25 16:21:58', '2017-10-25 16:21:58');
INSERT INTO `m_base_file` VALUES ('34', 'Tulips.jpg', '2017\\10-25\\c2021747-df3c-4bdd-9d0c-04b00f264473.jpg', '2017\\10-25\\c2021747-df3c-4bdd-9d0c-04b00f264473.jpg', 'image/jpeg', 'admin', '1', '220.83KB', 'jpg', '226127', '7AF869D174C5A45CFA7BF6EFD4BA0B56', '51b8c4a937d1464eb604b5de91f4ed67.jpg', '2017\\10-25\\51b8c4a937d1464eb604b5de91f4ed67.jpg', null, '1', '2', null, '1', '2017-10-25 16:23:14', '2017-10-25 16:23:14');
INSERT INTO `m_base_file` VALUES ('35', 'Lighthouse.jpg', '2017\\10-25\\f51e5d89-224a-4aba-854c-7a63fa84dcc6.jpg', '2017\\10-25\\f51e5d89-224a-4aba-854c-7a63fa84dcc6.jpg', 'image/jpeg', 'admin', '1', '200.62KB', 'jpg', '205433', 'DDDF1CC064F4BA9AC057684CA451B91B', 'd7f6e94a2b5342c88ae29bea77b3d473.jpg', '2017\\10-25\\d7f6e94a2b5342c88ae29bea77b3d473.jpg', null, '1', '2', null, '1', '2017-10-25 17:36:12', '2017-10-25 17:36:12');
INSERT INTO `m_base_file` VALUES ('38', 'Jellyfish.jpg', '2017\\10-25\\4adf60ec-90d8-4558-b8eb-4849c6ba251a.jpg', '2017\\10-25\\4adf60ec-90d8-4558-b8eb-4849c6ba251a.jpg', 'image/jpeg', 'admin', '1', '132.22KB', 'jpg', '135397', '6548137DEE6DA138609386B66948B003', '4eacdf0a10514047a1a327d628e823bc.jpg', '2017\\10-25\\4eacdf0a10514047a1a327d628e823bc.jpg', null, '1', '2', null, '1', '2017-10-25 17:59:19', '2017-10-25 17:59:19');
INSERT INTO `m_base_file` VALUES ('42', 'log_web.txt', 'images/fileIcon/fileicon-large-txt.png', null, 'text/plain', 'admin', '4', '1.06MB', 'txt', '1108698', 'FFD6D59DB4ADB77E01EF4B9E0E6CFA86', '2e950669d3ee4280a67155b762bf18ed.txt', '2017\\10-25\\2e950669d3ee4280a67155b762bf18ed.txt', '2017/10-25/ac96ce00d7e9496a83d9ac7b94ceff48.swf', '1', '0', null, '1', '2017-10-25 18:19:14', '2017-10-25 18:19:14');
INSERT INTO `m_base_file` VALUES ('43', '9812955_195532282173_2.jpg', '2017\\10-26\\f2b015ef-9baf-44b6-a725-57479e0bd105.jpg', '2017\\10-26\\f2b015ef-9baf-44b6-a725-57479e0bd105.jpg', 'image/jpeg', 'admin', '1', '99.99KB', 'jpg', '102389', 'FF566EC2AA1BE0FF1C7503D44E6CF172', 'b72a30f7ca2840d38cd0ecc095f59e26.jpg', '2017\\10-26\\b72a30f7ca2840d38cd0ecc095f59e26.jpg', null, '1', '2', null, '1', '2017-10-26 16:21:17', '2017-10-26 16:21:17');
INSERT INTO `m_base_file` VALUES ('44', '6608733_084501558000_2.jpg', '2017\\10-26\\82cd334b-6441-430c-82a3-f09042999370.jpg', '2017\\10-26\\82cd334b-6441-430c-82a3-f09042999370.jpg', 'image/jpeg', 'admin', '1', '132.29KB', 'jpg', '135470', '0AD85393730888BFFD02B8800E973C4F', '60528a73c9c2445397b8033655b158aa.jpg', '2017\\10-26\\60528a73c9c2445397b8033655b158aa.jpg', null, '1', '2', null, '1', '2017-10-26 16:43:25', '2017-10-26 16:43:25');
INSERT INTO `m_base_file` VALUES ('45', '0fuxqm1e2OrXxnslha82KbWtZpG5iQ9VDw1BMYVkiwQ5E1457315450144.jpg', '2017\\10-26\\c1fa7d25-0c09-455a-a642-cace29817a29.jpg', '2017\\10-26\\c1fa7d25-0c09-455a-a642-cace29817a29.jpg', 'image/jpeg', 'admin', '1', '64.87KB', 'jpg', '66424', 'E9ED8C2B62FD46FB75C465D7999B4FC6', '6a7066c2a2034cffb3aaf9720211a4e6.jpg', '2017\\10-26\\6a7066c2a2034cffb3aaf9720211a4e6.jpg', null, '1', '2', null, '1', '2017-10-26 16:57:02', '2017-10-26 16:57:02');
INSERT INTO `m_base_file` VALUES ('46', 'i_8EIkNsHUVD4l7rbuPi4g%3D%3D%2F7916770692525301335.jpg', '2017\\10-26\\24035b8a-59d8-4258-a2f8-76d5d40ac1c3.jpg', '2017\\10-26\\24035b8a-59d8-4258-a2f8-76d5d40ac1c3.jpg', 'image/jpeg', 'admin', '1', '57.11KB', 'jpg', '58480', '2E47B8E91AA6166FC8846778FDCB7B1A', 'a8a4dc0d651443c1b08035850c2f148a.jpg', '2017\\10-26\\a8a4dc0d651443c1b08035850c2f148a.jpg', null, '1', '2', null, '1', '2017-10-26 17:36:08', '2017-10-26 17:36:08');
INSERT INTO `m_base_file` VALUES ('47', '143J145O-6.jpg', '2017\\10-27\\02ae4e23-fad1-44e2-862f-1935e6edcee6.jpg', '2017\\10-27\\02ae4e23-fad1-44e2-862f-1935e6edcee6.jpg', 'image/jpeg', 'admin', '1', '219.82KB', 'jpg', '225100', '6C7E47D4998F2A69AEB6C66BD859620B', '2f5ded1882264ab5ab3db13758b308d2.jpg', '2017\\10-27\\2f5ded1882264ab5ab3db13758b308d2.jpg', null, '1', '2', null, '1', '2017-10-27 10:27:24', '2017-10-27 10:27:24');
INSERT INTO `m_base_file` VALUES ('48', '6608733_084501558000_2.jpg', '2017\\10-27\\efb928eb-7465-4f81-8c0c-e3413701e303.jpg', '2017\\10-27\\efb928eb-7465-4f81-8c0c-e3413701e303.jpg', 'image/jpeg', 'admin', '1', '132.29KB', 'jpg', '135470', '0AD85393730888BFFD02B8800E973C4F', 'dd0d66c7afa54184a9957f0b40b4e46c.jpg', '2017\\10-27\\dd0d66c7afa54184a9957f0b40b4e46c.jpg', null, '1', '2', null, '1', '2017-10-27 17:26:25', '2017-10-27 17:26:25');
INSERT INTO `m_base_file` VALUES ('49', '88Q58PICasD_1024.jpg', '2017\\10-30\\50c4a411-50d7-493c-a78d-f9c7ca65d33b.jpg', '2017\\10-30\\50c4a411-50d7-493c-a78d-f9c7ca65d33b.jpg', 'image/jpeg', 'admin', '1', '152.29KB', 'jpg', '155945', 'CFF7F60BC36CB89D7D04DAEE9B4DC4E2', '8047c289ff834c0e80f5cb424512d13d.jpg', '2017\\10-30\\8047c289ff834c0e80f5cb424512d13d.jpg', null, '1', '2', null, '1', '2017-10-30 09:50:04', '2017-10-30 09:50:04');
INSERT INTO `m_base_file` VALUES ('50', '1297256_1.jpg', '2017\\10-30\\d98f1a1c-e8a6-44e7-ba0d-48e406675063.jpg', '2017\\10-30\\d98f1a1c-e8a6-44e7-ba0d-48e406675063.jpg', 'image/jpeg', 'admin', '1', '377.58KB', 'jpg', '386643', 'DFD11DBF8CFD13C708899F8109CD84FB', '86232c6d41e94ee38b588c561ee0afd7.jpg', '2017\\10-30\\86232c6d41e94ee38b588c561ee0afd7.jpg', null, '1', '2', null, '1', '2017-10-30 09:50:04', '2017-10-30 09:50:04');
INSERT INTO `m_base_file` VALUES ('51', 'Desert.jpg', '2017\\10-30\\aade6587-7051-4163-999a-c1d9c22b3644.jpg', '2017\\10-30\\aade6587-7051-4163-999a-c1d9c22b3644.jpg', 'image/jpeg', 'admin', '1', '331.75KB', 'jpg', '339709', '51FC1A941BC3CEA6996074887EAE0379', '7d661de558df412d8fdb72fcbfb330d2.jpg', '2017\\10-30\\7d661de558df412d8fdb72fcbfb330d2.jpg', null, '1', '2', null, '1', '2017-10-30 17:24:57', '2017-10-30 17:24:57');
INSERT INTO `m_base_file` VALUES ('52', 'Tulips.jpg', '2017\\10-30\\290c12d9-0620-4c00-a9c4-3b2b065fb32d.jpg', '2017\\10-30\\290c12d9-0620-4c00-a9c4-3b2b065fb32d.jpg', 'image/jpeg', 'admin', '1', '220.83KB', 'jpg', '226127', '7AF869D174C5A45CFA7BF6EFD4BA0B56', '6331d4126742430199c749c4ed5b9308.jpg', '2017\\10-30\\6331d4126742430199c749c4ed5b9308.jpg', null, '1', '2', null, '1', '2017-10-30 17:25:31', '2017-10-30 17:25:31');
INSERT INTO `m_base_file` VALUES ('53', 'Tulips.jpg', '2017\\10-30\\dcd994bf-95a3-413f-b10d-7a8bea66203a.jpg', '2017\\10-30\\dcd994bf-95a3-413f-b10d-7a8bea66203a.jpg', 'image/jpeg', 'admin', '1', '220.83KB', 'jpg', '226127', '7AF869D174C5A45CFA7BF6EFD4BA0B56', '05eb3600c6f64f9095424e5606b5b8b5.jpg', '2017\\10-30\\05eb3600c6f64f9095424e5606b5b8b5.jpg', null, '1', '2', null, '1', '2017-10-30 17:29:03', '2017-10-30 17:29:03');
INSERT INTO `m_base_file` VALUES ('54', 'Penguins.jpg', '2017\\10-30\\69900bc6-49e0-4e6e-a142-da81e41fe415.jpg', '2017\\10-30\\69900bc6-49e0-4e6e-a142-da81e41fe415.jpg', 'image/jpeg', 'admin', '1', '273.05KB', 'jpg', '279608', 'E873953C2744D164DFDCAC810867B200', '2190a7ee27e84ee5bed07870f5285c3a.jpg', '2017\\10-30\\2190a7ee27e84ee5bed07870f5285c3a.jpg', null, '1', '2', null, '1', '2017-10-30 17:29:37', '2017-10-30 17:29:37');
INSERT INTO `m_base_file` VALUES ('55', 'Tulips.jpg', '2017\\10-30\\3aef62f7-13fb-4243-a826-505bd876624a.jpg', '2017\\10-30\\3aef62f7-13fb-4243-a826-505bd876624a.jpg', 'image/jpeg', 'admin', '1', '220.83KB', 'jpg', '226127', '7AF869D174C5A45CFA7BF6EFD4BA0B56', '066cf41621834caeb84f6db9823c435d.jpg', '2017\\10-30\\066cf41621834caeb84f6db9823c435d.jpg', null, '1', '2', null, '1', '2017-10-30 17:29:37', '2017-10-30 17:29:37');
INSERT INTO `m_base_file` VALUES ('56', 'Hydrangeas.jpg', '2017\\10-30\\e99abd5e-a49a-4a2d-a237-8cfe129ccea4.jpg', '2017\\10-30\\e99abd5e-a49a-4a2d-a237-8cfe129ccea4.jpg', 'image/jpeg', 'admin', '1', '212.90KB', 'jpg', '218009', 'AF5546DDDEACAE895DDF9E0D86EAF4E7', '0118162389da4eeda70526e3e63d5b7e.jpg', '2017\\10-30\\0118162389da4eeda70526e3e63d5b7e.jpg', null, '1', '2', null, '1', '2017-10-30 17:33:05', '2017-10-30 17:33:05');
INSERT INTO `m_base_file` VALUES ('57', 'Jellyfish.jpg', '2017\\10-30\\f3410865-ae7b-4e61-9add-fc555b53bfa9.jpg', '2017\\10-30\\f3410865-ae7b-4e61-9add-fc555b53bfa9.jpg', 'image/jpeg', 'admin', '1', '186.20KB', 'jpg', '190672', '593DD68B73F946698FE790EF1C8C2021', 'da4d70c033e040b28f90da948b26d885.jpg', '2017\\10-30\\da4d70c033e040b28f90da948b26d885.jpg', null, '1', '2', null, '1', '2017-10-30 17:33:05', '2017-10-30 17:33:05');
INSERT INTO `m_base_file` VALUES ('58', 'Koala.jpg', '2017\\10-30\\59337003-bed3-4a96-84c8-a194f9c1f0ad.jpg', '2017\\10-30\\59337003-bed3-4a96-84c8-a194f9c1f0ad.jpg', 'image/jpeg', 'admin', '1', '298.59KB', 'jpg', '305761', '36227D7D5AE29C9C4DADE70FBA90C545', '208e83909f254f97a209fcd934d47068.jpg', '2017\\10-30\\208e83909f254f97a209fcd934d47068.jpg', null, '1', '2', null, '1', '2017-10-30 17:33:05', '2017-10-30 17:33:05');
INSERT INTO `m_base_file` VALUES ('59', '70cef7dd6acafab44efe38b253412dbc.jpg', '2017\\10-30\\46cb9740-ecaf-4348-8fb0-4a71db8ec590.jpg', '2017\\10-30\\46cb9740-ecaf-4348-8fb0-4a71db8ec590.jpg', 'image/jpeg', 'system', '1', '297.48KB', 'jpg', '304617', '3BF63F7DAF798EDA9F02E1E2BCA7CB87', '1cae16341de94188be539b1bb4c92ef6.jpg', '2017\\10-30\\1cae16341de94188be539b1bb4c92ef6.jpg', null, '1', '2', null, '1', '2017-10-30 17:35:57', '2017-10-30 17:35:57');
INSERT INTO `m_base_file` VALUES ('60', '21-niutuku.com-2055.jpg', '2017\\10-30\\e751f6d5-b101-4902-9c97-1aa56a7f1da9.jpg', '2017\\10-30\\e751f6d5-b101-4902-9c97-1aa56a7f1da9.jpg', 'image/jpeg', 'system', '1', '240.67KB', 'jpg', '246442', '10B84F4F6886BFBDDBA690D911FEC99E', '5da15c23fabe42788d2fc35637f2fa2c.jpg', '2017\\10-30\\5da15c23fabe42788d2fc35637f2fa2c.jpg', null, '1', '2', null, '1', '2017-10-30 17:53:05', '2017-10-30 17:53:05');
INSERT INTO `m_base_file` VALUES ('61', 'Desert.jpg', '2017\\10-31\\bdaa4d7b-0ee8-41d6-a849-e1271d6dc8e0.jpg', '2017\\10-31\\bdaa4d7b-0ee8-41d6-a849-e1271d6dc8e0.jpg', 'image/jpeg', 'bgs', '1', '331.75KB', 'jpg', '339709', '51FC1A941BC3CEA6996074887EAE0379', '73d30f06847941a8b4997f9c05bb466a.jpg', '2017\\10-31\\73d30f06847941a8b4997f9c05bb466a.jpg', null, '1', '2', null, '1', '2017-10-31 14:50:15', '2017-10-31 14:50:15');
INSERT INTO `m_base_file` VALUES ('62', 'Jellyfish.jpg', '2017\\10-31\\efb88898-d885-42fe-8e8f-54cd436d8a94.jpg', '2017\\10-31\\efb88898-d885-42fe-8e8f-54cd436d8a94.jpg', 'image/jpeg', 'bgs', '1', '186.20KB', 'jpg', '190672', '593DD68B73F946698FE790EF1C8C2021', '3a217cff055e42a5a74c197d36fa1286.jpg', '2017\\10-31\\3a217cff055e42a5a74c197d36fa1286.jpg', null, '1', '2', null, '1', '2017-10-31 14:51:29', '2017-10-31 14:51:29');
INSERT INTO `m_base_file` VALUES ('63', 'Penguins.jpg', '2017\\10-31\\776c9efd-e2ec-4281-a1bd-4680c184d6fb.jpg', '2017\\10-31\\776c9efd-e2ec-4281-a1bd-4680c184d6fb.jpg', 'image/jpeg', 'bgs', '1', '273.05KB', 'jpg', '279608', 'E873953C2744D164DFDCAC810867B200', 'b0d7102773f8431093776a0dfe1038a1.jpg', '2017\\10-31\\b0d7102773f8431093776a0dfe1038a1.jpg', null, '1', '2', null, '1', '2017-10-31 15:50:16', '2017-10-31 15:50:16');
INSERT INTO `m_base_file` VALUES ('64', 'Tulips.jpg', '2017\\10-31\\63fecb62-dd68-4fe4-b241-bce1f66bde8c.jpg', '2017\\10-31\\63fecb62-dd68-4fe4-b241-bce1f66bde8c.jpg', 'image/jpeg', 'bgs', '1', '220.83KB', 'jpg', '226127', '7AF869D174C5A45CFA7BF6EFD4BA0B56', '520eac4ef2d644dd9448b14298fbd48a.jpg', '2017\\10-31\\520eac4ef2d644dd9448b14298fbd48a.jpg', null, '1', '2', null, '1', '2017-10-31 15:50:16', '2017-10-31 15:50:16');
INSERT INTO `m_base_file` VALUES ('65', 'Jellyfish.jpg', '2017\\11-01\\ac482514-149d-427f-9e66-19bdf8ff748b.jpg', '2017\\11-01\\ac482514-149d-427f-9e66-19bdf8ff748b.jpg', 'image/jpeg', 'admin', '1', '186.20KB', 'jpg', '190672', '593DD68B73F946698FE790EF1C8C2021', 'e2b26e721c7c4182982f8a09657b3ed0.jpg', '2017\\11-01\\e2b26e721c7c4182982f8a09657b3ed0.jpg', null, '1', '2', null, '1', '2017-11-01 17:24:43', '2017-11-01 17:24:43');
INSERT INTO `m_base_file` VALUES ('66', 'Tulips.jpg', '2017\\11-01\\9c25ec28-3ed1-4e0c-8f71-8044f82d8e5e.jpg', '2017\\11-01\\9c25ec28-3ed1-4e0c-8f71-8044f82d8e5e.jpg', 'image/jpeg', 'admin', '1', '220.83KB', 'jpg', '226127', '7AF869D174C5A45CFA7BF6EFD4BA0B56', '7260d4fafe284c66a0f2cf0c9dc76634.jpg', '2017\\11-01\\7260d4fafe284c66a0f2cf0c9dc76634.jpg', null, '1', '2', null, '1', '2017-11-01 17:24:43', '2017-11-01 17:24:43');
INSERT INTO `m_base_file` VALUES ('67', 'temp.xls', 'images/fileIcon/fileicon-large-xls.png', null, 'application/vnd.ms-excel', 'admin', '4', '55.50KB', 'xls', '56832', '2EBD7E99BF12609FD6E5EFEC1B2DBFF0', '14d259791dc94d7dbf4f164b9d68e659.xls', '2017\\11-01\\14d259791dc94d7dbf4f164b9d68e659.xls', '2017/11-01/3d16419584bc4e5093a9d2f700d2d319.swf', '1', '0', null, '1', '2017-11-01 19:28:40', '2017-11-01 19:28:40');
INSERT INTO `m_base_file` VALUES ('68', '6cbb9949-4f43-4f85-8a52-1ca4b6a7d631.xls', 'images/fileIcon/fileicon-large-xls.png', null, 'application/vnd.ms-excel', 'admin', '4', '27.50KB', 'xls', '28160', '580AC38EFDDEB0528C25BDC3F42BEFA2', '06e2972772d844b1860088498118c1c0.xls', '2017\\11-01\\06e2972772d844b1860088498118c1c0.xls', '2017/11-01/b2490b776c8942f1bd0b3e00493908bd.swf', '1', '0', null, '1', '2017-11-01 19:28:42', '2017-11-01 19:28:42');
INSERT INTO `m_base_file` VALUES ('69', '8262a8c3-2b5e-417c-8b71-4dd116139813.xls', 'images/fileIcon/fileicon-large-xls.png', null, 'application/vnd.ms-excel', 'admin', '4', '44.50KB', 'xls', '45568', 'F9F4B69B67227D3322A1EB46A025FED2', 'fd133017913a4dd38b3f835d6b0e7453.xls', '2017\\11-01\\fd133017913a4dd38b3f835d6b0e7453.xls', '2017/11-01/406e6c65b3cd4d9da926523673cea1b2.swf', '1', '0', null, '1', '2017-11-01 19:28:42', '2017-11-01 19:28:42');
INSERT INTO `m_base_file` VALUES ('70', 'temp.xls', 'images/fileIcon/fileicon-large-xls.png', null, 'application/vnd.ms-excel', 'admin', '4', '55.50KB', 'xls', '56832', '2EBD7E99BF12609FD6E5EFEC1B2DBFF0', '5ad97995b92543ba8914fc4839214a8b.xls', '2017\\11-02\\5ad97995b92543ba8914fc4839214a8b.xls', '2017/11-02/b01164a3163740b6bede546eb1dd95b6.swf', '1', '0', null, '1', '2017-11-02 14:15:46', '2017-11-02 14:15:46');
INSERT INTO `m_base_file` VALUES ('71', '66d1970c-0611-4831-8dca-b1995f9ea1db.xls', 'images/fileIcon/fileicon-large-xls.png', null, 'application/vnd.ms-excel', 'admin', '4', '27.50KB', 'xls', '28160', '580AC38EFDDEB0528C25BDC3F42BEFA2', '6a0ecb4b3f364e4d9bc5804ae107bb6f.xls', '2017\\11-02\\6a0ecb4b3f364e4d9bc5804ae107bb6f.xls', '2017/11-02/82c009e0590446748dcf6b0e7ff5282a.swf', '1', '0', null, '1', '2017-11-02 14:15:54', '2017-11-02 14:15:54');
INSERT INTO `m_base_file` VALUES ('72', '6c1ab82e-1342-4ef9-a431-cf8359d04136.xls', 'images/fileIcon/fileicon-large-xls.png', null, 'application/vnd.ms-excel', 'admin', '4', '44.50KB', 'xls', '45568', 'F9F4B69B67227D3322A1EB46A025FED2', '611ba2f99b934534bce770f198102a61.xls', '2017\\11-02\\611ba2f99b934534bce770f198102a61.xls', '2017/11-02/3ff77650704b4c53a67399e66fa616c8.swf', '1', '0', null, '1', '2017-11-02 14:15:54', '2017-11-02 14:15:54');
INSERT INTO `m_base_file` VALUES ('73', 'temp.xls', 'images/fileIcon/fileicon-large-xls.png', null, 'application/vnd.ms-excel', 'admin', '4', '55.50KB', 'xls', '56832', '2EBD7E99BF12609FD6E5EFEC1B2DBFF0', 'ddaa6c8bffad4eeaa049cf88ee1b18d7.xls', '2017\\11-02\\ddaa6c8bffad4eeaa049cf88ee1b18d7.xls', '2017/11-02/6137f80c97084673b76e083a9fbe677b.swf', '1', '0', null, '1', '2017-11-02 17:11:07', '2017-11-02 17:11:07');
INSERT INTO `m_base_file` VALUES ('74', '86f31517-8288-46bb-ad5b-48250a0cb96c.xls', 'images/fileIcon/fileicon-large-xls.png', null, 'application/vnd.ms-excel', 'admin', '4', '27.50KB', 'xls', '28160', '580AC38EFDDEB0528C25BDC3F42BEFA2', '7525adc633484abfa4a19fec6e66251a.xls', '2017\\11-02\\7525adc633484abfa4a19fec6e66251a.xls', '2017/11-02/1e376e7a02884068a3445b7089d58a15.swf', '1', '0', null, '1', '2017-11-02 17:11:09', '2017-11-02 17:11:09');
INSERT INTO `m_base_file` VALUES ('75', '2c337bb4-e3c2-435f-9720-6bfb1f2a2740.xls', 'images/fileIcon/fileicon-large-xls.png', null, 'application/vnd.ms-excel', 'admin', '4', '44.50KB', 'xls', '45568', 'F9F4B69B67227D3322A1EB46A025FED2', 'b8052b0c86b64311ab007d3fbec16eeb.xls', '2017\\11-02\\b8052b0c86b64311ab007d3fbec16eeb.xls', '2017/11-02/592a5c2854a84df2bff7e9f1559b9354.swf', '1', '0', null, '1', '2017-11-02 17:11:09', '2017-11-02 17:11:09');
INSERT INTO `m_base_file` VALUES ('76', 'temp.xls', 'images/fileIcon/fileicon-large-xls.png', null, 'application/vnd.ms-excel', 'admin', '4', '55.50KB', 'xls', '56832', '2EBD7E99BF12609FD6E5EFEC1B2DBFF0', '8758a959116b425b98069db9ab4ecce7.xls', '2017\\11-02\\8758a959116b425b98069db9ab4ecce7.xls', '2017/11-02/f6200123137344c29c7505ca84ef3336.swf', '1', '0', null, '1', '2017-11-02 17:14:53', '2017-11-02 17:14:53');
INSERT INTO `m_base_file` VALUES ('77', '7964c5ac-d259-4a1e-87b9-073ede4d4548.xls', 'images/fileIcon/fileicon-large-xls.png', null, 'application/vnd.ms-excel', 'admin', '4', '27.50KB', 'xls', '28160', '580AC38EFDDEB0528C25BDC3F42BEFA2', '612d62a12a214f46b5d32060725126eb.xls', '2017\\11-02\\612d62a12a214f46b5d32060725126eb.xls', '2017/11-02/77522438f23442b4960110c62b853fab.swf', '1', '0', null, '1', '2017-11-02 17:15:00', '2017-11-02 17:15:00');
INSERT INTO `m_base_file` VALUES ('78', '86488a14-a658-4627-96f0-81552ede7af2.xls', 'images/fileIcon/fileicon-large-xls.png', null, 'application/vnd.ms-excel', 'admin', '4', '44.50KB', 'xls', '45568', 'F9F4B69B67227D3322A1EB46A025FED2', 'd9bfa1645ed1422f8d2479011c78c4a7.xls', '2017\\11-02\\d9bfa1645ed1422f8d2479011c78c4a7.xls', '2017/11-02/5958c6e3a39b4b8e98f9fadacc2132c9.swf', '1', '0', null, '1', '2017-11-02 17:15:00', '2017-11-02 17:15:00');
INSERT INTO `m_base_file` VALUES ('85', 'temp.xls', 'images/fileIcon/fileicon-large-xls.png', null, 'application/vnd.ms-excel', 'admin', '4', '55.50KB', 'xls', '56832', '2EBD7E99BF12609FD6E5EFEC1B2DBFF0', '92aacfb3eb7f48adaac398505a81a8d0.xls', '2017\\11-02\\92aacfb3eb7f48adaac398505a81a8d0.xls', '2017/11-02/44acf6b4efb94f63a98c036f4ceec528.swf', '1', '0', null, '1', '2017-11-02 17:28:01', '2017-11-02 17:28:01');
INSERT INTO `m_base_file` VALUES ('86', 'e74a3109-8a3a-493e-b4b6-c596af16c9ee.xls', 'images/fileIcon/fileicon-large-xls.png', null, 'application/vnd.ms-excel', 'admin', '4', '27.50KB', 'xls', '28160', '580AC38EFDDEB0528C25BDC3F42BEFA2', 'ea840924584049aaad90a5e973212551.xls', '2017\\11-02\\ea840924584049aaad90a5e973212551.xls', '2017/11-02/19d01e0099114b9298958a4e0e91a870.swf', '1', '0', null, '1', '2017-11-02 17:28:10', '2017-11-02 17:28:10');
INSERT INTO `m_base_file` VALUES ('87', 'temp.xls', 'images/fileIcon/fileicon-large-xls.png', null, 'application/vnd.ms-excel', 'admin', '4', '55.50KB', 'xls', '56832', '2EBD7E99BF12609FD6E5EFEC1B2DBFF0', 'f350fef4de5449529d008af3dbc8caab.xls', '2017\\11-03\\f350fef4de5449529d008af3dbc8caab.xls', '2017/11-03/b3afedec12c240c19a514c2da56ff122.swf', '1', '0', null, '1', '2017-11-03 12:12:44', '2017-11-03 12:12:44');
INSERT INTO `m_base_file` VALUES ('88', '88486b84-d1ea-47bc-bff3-ddda5dde406b.xls', 'images/fileIcon/fileicon-large-xls.png', null, 'application/vnd.ms-excel', 'admin', '4', '27.50KB', 'xls', '28160', '580AC38EFDDEB0528C25BDC3F42BEFA2', 'bcc9e29c5ebb4063b8febdc2dfcd1fe9.xls', '2017\\11-03\\bcc9e29c5ebb4063b8febdc2dfcd1fe9.xls', '2017/11-03/5eec77a3b53b45c1b67ac1e1f11da84d.swf', '1', '0', null, '1', '2017-11-03 12:12:47', '2017-11-03 12:12:47');
INSERT INTO `m_base_file` VALUES ('89', '13694d0a-b352-4f5d-a2d9-f6bbfc81a03a.xls', 'images/fileIcon/fileicon-large-xls.png', null, 'application/vnd.ms-excel', 'admin', '4', '44.50KB', 'xls', '45568', 'F9F4B69B67227D3322A1EB46A025FED2', 'b3281d814f554a1ca73bc8716494a9cb.xls', '2017\\11-03\\b3281d814f554a1ca73bc8716494a9cb.xls', '2017/11-03/9115d126e1e74245aad1c34dc802ff59.swf', '1', '0', null, '1', '2017-11-03 12:12:48', '2017-11-03 12:12:48');
INSERT INTO `m_base_file` VALUES ('90', '88Q58PICasD_1024.jpg', '2017\\11-03\\77cf15c6-006a-4cf7-be05-bb290e383972.jpg', '2017\\11-03\\77cf15c6-006a-4cf7-be05-bb290e383972.jpg', 'image/jpeg', 'admin', '1', '115.89KB', 'jpg', '118668', 'A47B3BF9DC171BB132A3B5380585B79D', '129734c761734e2e9a7a449b5ce847ed.jpg', '2017\\11-03\\129734c761734e2e9a7a449b5ce847ed.jpg', null, '1', '2', null, '1', '2017-11-03 14:20:21', '2017-11-03 14:20:21');

-- ----------------------------
-- Table structure for m_zone_path
-- ----------------------------
DROP TABLE IF EXISTS `m_zone_path`;
CREATE TABLE `m_zone_path` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `text` varchar(255) DEFAULT NULL,
  `priority` int(11) NOT NULL,
  `path` varchar(255) NOT NULL,
  `type` varchar(20) NOT NULL,
  `virtual_path` varchar(255) DEFAULT NULL,
  `view_path` varchar(255) DEFAULT NULL,
  `warm_value` bigint(20) DEFAULT NULL,
  `zone_name` varchar(1) DEFAULT NULL,
  `flag` smallint(6) DEFAULT NULL,
  `status` smallint(6) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of m_zone_path
-- ----------------------------
INSERT INTO `m_zone_path` VALUES ('1', '普通文件', '1', 'D:/RBSG_FILE_STORE/common-file', 'commomFile', 'D:/RBSG_FILE_STORE/common-file/view', '/attachment/view', '10000', 'D', null, null, null, null);
INSERT INTO `m_zone_path` VALUES ('2', '临时文件地址', '1', 'D:/RBSG_FILE_STORE/temp-file', 'tempFile', null, 'tempFile', '10000', 'D', null, null, null, null);

-- ----------------------------
-- Table structure for run_abnormal_receipts
-- ----------------------------
DROP TABLE IF EXISTS `run_abnormal_receipts`;
CREATE TABLE `run_abnormal_receipts` (
  `id` varchar(32) NOT NULL,
  `sort` bigint(20) NOT NULL AUTO_INCREMENT,
  `proc_inst_id` varchar(32) DEFAULT NULL,
  `user_id` varchar(32) DEFAULT NULL,
  `event_no` varchar(50) DEFAULT NULL,
  `event_date` datetime DEFAULT NULL,
  `event_desc` varchar(300) DEFAULT NULL,
  `event_reason` varchar(300) DEFAULT NULL,
  `toll_station` varchar(100) DEFAULT NULL,
  `note` varchar(300) DEFAULT NULL,
  `status` smallint(6) DEFAULT NULL COMMENT '状态',
  `flag` smallint(6) DEFAULT NULL,
  `create_by` varchar(50) DEFAULT NULL,
  `update_by` varchar(50) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_abnormal_receipts_sort` (`sort`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of run_abnormal_receipts
-- ----------------------------
INSERT INTO `run_abnormal_receipts` VALUES ('0516061dc06f11e7ab51507b9dae4454', '24', null, 'e20afce4b12511e68bc4507b9dae4454', '[2017]YY-13-0010', '2017-11-03 00:00:00', 'r12r', '12t', '123', null, '0', null, null, 'admin', '2017-11-03 16:14:40', '2017-11-03 16:14:40');
INSERT INTO `run_abnormal_receipts` VALUES ('5862085cc03e11e7ab51507b9dae4454', '23', null, 'e20afce4b12511e68bc4507b9dae4454', '1212,121', '2017-11-03 00:00:00', null, 'll', 'll', null, '0', null, null, 'e20afce4b12511e68bc4507b9dae4454', '2017-11-03 10:26:06', '2017-11-03 10:26:27');
INSERT INTO `run_abnormal_receipts` VALUES ('66ee8caebe0d11e797cd507b9dae4454', '20', null, 'ea5cd187943b11e7a354507b9dae4454', '214', '2017-10-31 00:00:00', '2414', null, '124', null, '0', null, 'ea5cd187943b11e7a354507b9dae4454', 'ea5cd187943b11e7a354507b9dae4454', '2017-10-31 15:30:49', '2017-10-31 15:30:49');
INSERT INTO `run_abnormal_receipts` VALUES ('73cdbb65bd5911e7be45507b9dae4454', '19', '73d2e991bd5911e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', 'dlas5456', '2017-10-30 00:00:00', '贵', null, '大岭山', null, '1', null, 'e20afce4b12511e68bc4507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '2017-10-30 18:02:36', '2017-10-30 18:02:36');
INSERT INTO `run_abnormal_receipts` VALUES ('91224717bd1111e7be45507b9dae4454', '13', '9127385ebd1111e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '111', '2017-10-30 09:28:01', '2222', null, '厚街站', null, '1', null, 'e20afce4b12511e68bc4507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '2017-10-30 09:28:01', '2017-10-30 09:28:01');
INSERT INTO `run_abnormal_receipts` VALUES ('9f2ba707beb611e7b827507b9dae4454', '22', '9f33816abeb611e7b827507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', 'mc787', '2017-11-01 00:00:00', '2222', null, '麻涌', null, '2', null, 'e20afce4b12511e68bc4507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '2017-11-01 11:42:02', '2017-11-01 12:32:15');
INSERT INTO `run_abnormal_receipts` VALUES ('a2a6ed7ec29611e7a044507b9dae4454', '25', null, 'e20afce4b12511e68bc4507b9dae4454', '[2017]YY-13-0001', '2017-11-06 00:00:00', 'sn测试。。', 'sn测试。。', '虎门大桥', null, '0', null, null, 'e20afce4b12511e68bc4507b9dae4454', '2017-11-06 10:03:02', '2017-11-06 10:04:10');
INSERT INTO `run_abnormal_receipts` VALUES ('a6f0507fbd1911e7be45507b9dae4454', '14', 'a6fddfd7bd1911e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '4124', '2017-10-30 10:25:58', '51255125', null, '123', null, '0', null, 'e20afce4b12511e68bc4507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '2017-10-30 10:25:58', '2017-10-30 10:25:58');
INSERT INTO `run_abnormal_receipts` VALUES ('dbed10d7bd5611e7be45507b9dae4454', '18', 'dbf289abbd5611e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '999', '2017-10-30 00:00:00', '666', null, '虎门站', null, '1', null, 'e20afce4b12511e68bc4507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '2017-10-30 17:44:02', '2017-10-30 17:44:02');
INSERT INTO `run_abnormal_receipts` VALUES ('e3be3b96bd2511e7be45507b9dae4454', '16', 'e3c2200cbd2511e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '11', '2017-10-25 00:00:00', '33', null, '樟木头', null, '1', null, 'e20afce4b12511e68bc4507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '2017-10-30 11:53:29', '2017-10-30 11:53:29');
INSERT INTO `run_abnormal_receipts` VALUES ('e4f69231bd1e11e7be45507b9dae4454', '15', 'e4fad48ebd1e11e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '111', '2017-10-30 11:03:25', '11', null, '大朗站', null, '1', null, 'e20afce4b12511e68bc4507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '2017-10-30 11:03:25', '2017-10-30 11:03:25');
INSERT INTO `run_abnormal_receipts` VALUES ('e5d41e82c85011e7a099507b9dae4454', '26', null, 'e20afce4b12511e68bc4507b9dae4454', '[2017]YY-13-0003', '2017-11-13 00:00:00', 'sn测试', 'sn测试', '虎门大桥', null, '0', null, null, 'admin', '2017-11-13 16:58:38', '2017-11-13 16:58:40');

-- ----------------------------
-- Table structure for run_staff_performance
-- ----------------------------
DROP TABLE IF EXISTS `run_staff_performance`;
CREATE TABLE `run_staff_performance` (
  `id` varchar(32) NOT NULL,
  `sort` bigint(20) NOT NULL AUTO_INCREMENT,
  `proc_inst_id` varchar(32) DEFAULT NULL,
  `proc_inst_sec_id` varchar(32) DEFAULT NULL,
  `user_id` varchar(32) DEFAULT NULL,
  `perf_no` varchar(50) DEFAULT NULL,
  `perf_date` datetime DEFAULT NULL,
  `periods` datetime DEFAULT NULL,
  `toll_station` varchar(100) DEFAULT NULL,
  `note` varchar(300) DEFAULT NULL,
  `status` smallint(6) DEFAULT NULL COMMENT '状态',
  `sec_status` smallint(6) DEFAULT NULL,
  `flag` smallint(6) DEFAULT NULL,
  `create_by` varchar(50) DEFAULT NULL,
  `update_by` varchar(50) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_performance_sort` (`sort`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of run_staff_performance
-- ----------------------------
INSERT INTO `run_staff_performance` VALUES ('3f5c1fefc04d11e7ab51507b9dae4454', '5', null, null, 'e20afce4b12511e68bc4507b9dae4454', '11', '2017-11-03 00:00:00', '2017-10-01 00:00:00', '11', null, '0', '0', null, 'admin', null, '2017-11-03 12:12:47', '2017-11-03 12:12:47');
INSERT INTO `run_staff_performance` VALUES ('47d61872bf9511e79515507b9dae4454', '2', '6e379661bf9511e79515507b9dae4454', '71b6db06bf9511e79515507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '11', '2017-11-02 00:00:00', '2017-10-01 00:00:00', '中继站', null, '1', '1', null, 'admin', null, '2017-11-02 14:15:54', '2017-11-02 14:15:54');
INSERT INTO `run_staff_performance` VALUES ('4d332310bfae11e79515507b9dae4454', '4', 'bc562c92bfb011e79515507b9dae4454', 'bf15a0d9bfb011e79515507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '3', '2017-11-02 00:00:00', '2017-11-01 00:00:00', '11', null, '1', '1', null, 'admin', null, '2017-11-02 17:15:00', '2017-11-02 17:15:00');

-- ----------------------------
-- Table structure for run_staff_performanc_file
-- ----------------------------
DROP TABLE IF EXISTS `run_staff_performanc_file`;
CREATE TABLE `run_staff_performanc_file` (
  `id` varchar(32) NOT NULL,
  `sort` bigint(20) NOT NULL AUTO_INCREMENT,
  `performance_id` varchar(32) DEFAULT NULL,
  `user_id` varchar(32) DEFAULT NULL,
  `type` smallint(6) DEFAULT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `file_type` varchar(20) DEFAULT NULL,
  `base_file_id` bigint(20) DEFAULT NULL,
  `file_view` varchar(300) DEFAULT NULL,
  `back_file_view` varchar(300) DEFAULT NULL,
  `status` smallint(6) DEFAULT NULL COMMENT '状态',
  `create_by` varchar(50) DEFAULT NULL,
  `update_by` varchar(50) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_performance_file_sort` (`sort`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of run_staff_performanc_file
-- ----------------------------
INSERT INTO `run_staff_performanc_file` VALUES ('240b4991bfb011e79515507b9dae4454', '9', '4d332310bfae11e79515507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '0', 'e74a3109-8a3a-493e-b4b6-c596af16c9ee.xls', 'xls', '86', '/attachment/view/2017/11-02/19d01e0099114b9298958a4e0e91a870.swf', null, '1', 'admin', null, '2017-11-02 17:28:10', '2017-11-02 17:28:10');
INSERT INTO `run_staff_performanc_file` VALUES ('3fbfdabdc04d11e7ab51507b9dae4454', '10', '3f5c1fefc04d11e7ab51507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '0', '88486b84-d1ea-47bc-bff3-ddda5dde406b.xls', 'xls', '88', '/attachment/view/2017/11-03/5eec77a3b53b45c1b67ac1e1f11da84d.swf', null, '1', 'admin', null, '2017-11-03 12:12:48', '2017-11-03 12:12:48');
INSERT INTO `run_staff_performanc_file` VALUES ('3fc46cb4c04d11e7ab51507b9dae4454', '11', '3f5c1fefc04d11e7ab51507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '13694d0a-b352-4f5d-a2d9-f6bbfc81a03a.xls', 'xls', '89', '/attachment/view/2017/11-03/9115d126e1e74245aad1c34dc802ff59.swf', null, '1', 'admin', null, '2017-11-03 12:12:48', '2017-11-03 12:12:48');
INSERT INTO `run_staff_performanc_file` VALUES ('4825e7e8bf9511e79515507b9dae4454', '3', '47d61872bf9511e79515507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '0', '66d1970c-0611-4831-8dca-b1995f9ea1db.xls', 'xls', '71', '/attachment/view/2017/11-02/82c009e0590446748dcf6b0e7ff5282a.swf', null, '1', 'admin', null, '2017-11-02 14:15:54', '2017-11-02 14:15:54');
INSERT INTO `run_staff_performanc_file` VALUES ('48291b5dbf9511e79515507b9dae4454', '4', '47d61872bf9511e79515507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '6c1ab82e-1342-4ef9-a431-cf8359d04136.xls', 'xls', '72', '/attachment/view/2017/11-02/3ff77650704b4c53a67399e66fa616c8.swf', null, '1', 'admin', null, '2017-11-02 14:15:54', '2017-11-02 14:15:54');
INSERT INTO `run_staff_performanc_file` VALUES ('4d3b4bd3bfae11e79515507b9dae4454', '7', '4d332310bfae11e79515507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '0', '7964c5ac-d259-4a1e-87b9-073ede4d4548.xls', 'xls', '77', '/attachment/view/2017/11-02/77522438f23442b4960110c62b853fab.swf', null, '0', 'admin', null, '2017-11-02 17:15:00', '2017-11-02 17:28:09');
INSERT INTO `run_staff_performanc_file` VALUES ('4d3e5e8abfae11e79515507b9dae4454', '8', '4d332310bfae11e79515507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '86488a14-a658-4627-96f0-81552ede7af2.xls', 'xls', '78', '/attachment/view/2017/11-02/5958c6e3a39b4b8e98f9fadacc2132c9.swf', null, '1', 'admin', null, '2017-11-02 17:15:00', '2017-11-02 17:15:00');
INSERT INTO `run_staff_performanc_file` VALUES ('c33b72a6bfad11e79515507b9dae4454', '5', 'c2fe1d8dbfad11e79515507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '0', '86f31517-8288-46bb-ad5b-48250a0cb96c.xls', 'xls', '74', '/attachment/view/2017/11-02/1e376e7a02884068a3445b7089d58a15.swf', null, '1', 'admin', null, '2017-11-02 17:11:09', '2017-11-02 17:11:09');
INSERT INTO `run_staff_performanc_file` VALUES ('c33e6b8dbfad11e79515507b9dae4454', '6', 'c2fe1d8dbfad11e79515507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '2c337bb4-e3c2-435f-9720-6bfb1f2a2740.xls', 'xls', '75', '/attachment/view/2017/11-02/592a5c2854a84df2bff7e9f1559b9354.swf', null, '1', 'admin', null, '2017-11-02 17:11:09', '2017-11-02 17:11:09');
INSERT INTO `run_staff_performanc_file` VALUES ('d003b1f2bef711e7b827507b9dae4454', '1', 'cfba7eabbef711e7b827507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '0', '6cbb9949-4f43-4f85-8a52-1ca4b6a7d631.xls', 'xls', '68', '/attachment/view/2017/11-01/b2490b776c8942f1bd0b3e00493908bd.swf', null, '1', 'admin', null, '2017-11-01 19:28:42', '2017-11-01 19:28:42');
INSERT INTO `run_staff_performanc_file` VALUES ('d0103a1cbef711e7b827507b9dae4454', '2', 'cfba7eabbef711e7b827507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '1', '8262a8c3-2b5e-417c-8b71-4dd116139813.xls', 'xls', '69', '/attachment/view/2017/11-01/406e6c65b3cd4d9da926523673cea1b2.swf', null, '1', 'admin', null, '2017-11-01 19:28:42', '2017-11-01 19:28:42');

-- ----------------------------
-- Table structure for run_take_monitor
-- ----------------------------
DROP TABLE IF EXISTS `run_take_monitor`;
CREATE TABLE `run_take_monitor` (
  `id` varchar(32) NOT NULL,
  `sort` bigint(20) NOT NULL AUTO_INCREMENT,
  `proc_inst_id` varchar(32) DEFAULT NULL,
  `user_id` varchar(32) DEFAULT NULL,
  `take_no` varchar(50) DEFAULT NULL,
  `take_date` datetime DEFAULT NULL,
  `take_unit` varchar(50) DEFAULT NULL,
  `taker_id_type` varchar(30) DEFAULT NULL,
  `taker_id_no` varchar(50) DEFAULT NULL,
  `take_res_name` varchar(300) DEFAULT NULL,
  `take_res_use` varchar(300) DEFAULT NULL,
  `take_time` datetime DEFAULT NULL,
  `copy_time` datetime DEFAULT NULL,
  `taker_name` varchar(50) DEFAULT NULL,
  `agent` varchar(50) DEFAULT NULL,
  `is_introduce` tinyint(1) DEFAULT NULL,
  `is_need_approve` tinyint(1) DEFAULT NULL,
  `note` varchar(300) DEFAULT NULL,
  `status` smallint(6) DEFAULT NULL COMMENT '状态',
  `flag` smallint(6) DEFAULT NULL,
  `create_by` varchar(50) DEFAULT NULL,
  `update_by` varchar(50) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_take_sort` (`sort`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of run_take_monitor
-- ----------------------------
INSERT INTO `run_take_monitor` VALUES ('102c92a7c04611e7ab51507b9dae4454', '31', 'ca306762c04811e7ab51507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '[2017]CH-YY-05-0004', '2017-11-20 00:00:00', '312', '32', '32132', '1321', '321', '2017-11-24 00:00:00', '2017-11-13 00:00:00', '312', '321', '1', '1', '321', '1', null, 'admin', 'admin', '2017-11-03 11:21:26', '2017-11-03 11:40:58');
INSERT INTO `run_take_monitor` VALUES ('20e14a07bee611e7b827507b9dae4454', '28', '9e8c273ebee611e7b827507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '[2017]CH-YY-05-0001', '2017-11-01 00:00:00', '虎门分公司', '身份证', '44121121112', '10.31号虎门收费站全天监控视频', '日常抽查', '2017-11-01 00:00:00', '2017-11-01 00:00:00', 'lzx', 'lzx', '1', '1', '11.1凌晨0点~2点的视频也要复制', '1', null, null, null, '2017-11-01 18:26:22', '2017-11-01 17:25:43');
INSERT INTO `run_take_monitor` VALUES ('8fc21808bf6c11e79515507b9dae4454', '29', '93dce679bf6c11e79515507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '[2017]CH-YY-05-0002', '2017-11-02 00:00:00', '常虎分公司', '身份证', '4514546', '11.1全日监控', '日常抽查', '2017-11-02 00:00:00', '2017-11-02 00:00:00', 'lzx', 'lzx', '1', '1', '无', '1', null, 'admin', 'admin', '2017-11-02 09:24:29', '2017-11-02 09:24:36');
INSERT INTO `run_take_monitor` VALUES ('a89d5fedc03f11e7ab51507b9dae4454', '30', null, 'e20afce4b12511e68bc4507b9dae4454', '[2017]CH-YY-05-0003', '2017-11-03 00:00:00', '12', '11', '12', '12', '2121', '2017-11-03 00:00:00', '2017-11-17 00:00:00', '1212', '1212', '1', '1', '', '0', '1', 'admin', 'admin', '2017-11-03 10:35:30', '2017-11-03 10:35:30');

-- ----------------------------
-- Table structure for run_take_monitor_file
-- ----------------------------
DROP TABLE IF EXISTS `run_take_monitor_file`;
CREATE TABLE `run_take_monitor_file` (
  `id` varchar(32) NOT NULL,
  `sort` bigint(20) NOT NULL AUTO_INCREMENT,
  `take_monitor_id` varchar(32) DEFAULT NULL,
  `user_id` varchar(32) DEFAULT NULL,
  `type` smallint(6) DEFAULT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `file_type` varchar(20) DEFAULT NULL,
  `base_file_id` bigint(20) DEFAULT NULL,
  `file_view` varchar(300) DEFAULT NULL,
  `back_file_view` varchar(300) DEFAULT NULL,
  `status` smallint(6) DEFAULT NULL COMMENT '状态',
  `create_by` varchar(50) DEFAULT NULL,
  `update_by` varchar(50) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_take_file_sort` (`sort`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of run_take_monitor_file
-- ----------------------------
INSERT INTO `run_take_monitor_file` VALUES ('7ac1121bbee611e7b827507b9dae4454', '5', '20e14a07bee611e7b827507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, 'Jellyfish.jpg', 'jpg', '65', '/attachment/view/null', null, '1', 'admin', 'admin', '2017-11-01 17:24:43', '2017-11-01 17:24:43');
INSERT INTO `run_take_monitor_file` VALUES ('7ac4e8a2bee611e7b827507b9dae4454', '6', '20e14a07bee611e7b827507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', null, 'Tulips.jpg', 'jpg', '66', '/attachment/view/null', null, '1', 'admin', 'admin', '2017-11-01 17:24:43', '2017-11-01 17:24:43');

-- ----------------------------
-- Table structure for run_waste_transfer
-- ----------------------------
DROP TABLE IF EXISTS `run_waste_transfer`;
CREATE TABLE `run_waste_transfer` (
  `id` varchar(32) NOT NULL,
  `sort` bigint(20) NOT NULL AUTO_INCREMENT,
  `proc_inst_id` varchar(32) DEFAULT NULL,
  `user_id` varchar(32) DEFAULT NULL,
  `transfer_no` varchar(50) DEFAULT NULL,
  `transfer_date` datetime DEFAULT NULL,
  `note` varchar(300) DEFAULT NULL,
  `status` smallint(6) DEFAULT NULL COMMENT '状态',
  `flag` smallint(6) DEFAULT NULL,
  `create_by` varchar(50) DEFAULT NULL,
  `update_by` varchar(50) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_transfer_sort` (`sort`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of run_waste_transfer
-- ----------------------------
INSERT INTO `run_waste_transfer` VALUES ('023f5a39bd3c11e7be45507b9dae4454', '5', '024b911dbd3c11e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '20171030-2', '2017-10-30 00:00:00', null, '1', '1', 'e20afce4b12511e68bc4507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '2017-10-30 14:31:54', '2017-10-30 14:31:54');
INSERT INTO `run_waste_transfer` VALUES ('0f445fffc06f11e7ab51507b9dae4454', '18', null, 'e20afce4b12511e68bc4507b9dae4454', '123', '2017-11-03 00:00:00', null, '0', '1', 'e20afce4b12511e68bc4507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '2017-11-03 16:14:57', '2017-11-03 16:14:57');
INSERT INTO `run_waste_transfer` VALUES ('2105580ebe0a11e797cd507b9dae4454', '8', null, 'ea5cd187943b11e7a354507b9dae4454', '102', '2017-10-31 00:00:00', null, '0', '1', 'ea5cd187943b11e7a354507b9dae4454', 'ea5cd187943b11e7a354507b9dae4454', '2017-10-31 15:07:23', '2017-10-31 15:07:23');
INSERT INTO `run_waste_transfer` VALUES ('3da31c03c07811e7ab51507b9dae4454', '19', null, 'e20afce4b12511e68bc4507b9dae4454', '1234', '2017-11-03 17:20:40', null, '0', '1', 'e20afce4b12511e68bc4507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '2017-11-03 17:20:40', '2017-11-03 17:20:40');
INSERT INTO `run_waste_transfer` VALUES ('442a43dfbe0b11e797cd507b9dae4454', '10', null, 'ea5cd187943b11e7a354507b9dae4454', '104', '2017-10-31 00:00:00', null, '0', '1', 'ea5cd187943b11e7a354507b9dae4454', 'ea5cd187943b11e7a354507b9dae4454', '2017-10-31 15:15:32', '2017-10-31 15:15:32');
INSERT INTO `run_waste_transfer` VALUES ('5f5f2e52c04011e7ab51507b9dae4454', '14', '5f66889bc04011e7ab51507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '[2017]CH -06-null', '2017-11-04 00:00:00', null, '1', '1', 'e20afce4b12511e68bc4507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '2017-11-03 10:40:37', '2017-11-03 10:40:37');
INSERT INTO `run_waste_transfer` VALUES ('67246b67be0a11e797cd507b9dae4454', '9', null, 'ea5cd187943b11e7a354507b9dae4454', '103', '2017-10-31 00:00:00', null, '0', '1', 'ea5cd187943b11e7a354507b9dae4454', 'ea5cd187943b11e7a354507b9dae4454', '2017-10-31 15:09:21', '2017-10-31 15:09:21');
INSERT INTO `run_waste_transfer` VALUES ('68742f67c04011e7ab51507b9dae4454', '15', null, 'e20afce4b12511e68bc4507b9dae4454', '[2017]CH -06-null', '2017-11-03 00:00:00', null, '0', '1', 'e20afce4b12511e68bc4507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '2017-11-03 10:40:52', '2017-11-03 10:40:52');
INSERT INTO `run_waste_transfer` VALUES ('73034c8bc04011e7ab51507b9dae4454', '16', '73072a1ec04011e7ab51507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '[2017]CH -06-null', '2017-11-16 00:00:00', null, '1', '1', 'e20afce4b12511e68bc4507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '2017-11-03 10:41:10', '2017-11-03 10:41:10');
INSERT INTO `run_waste_transfer` VALUES ('818cddafc04011e7ab51507b9dae4454', '17', '819462dbc04011e7ab51507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '[2017]CH -06-null', '2017-11-03 00:00:00', null, '1', '1', 'e20afce4b12511e68bc4507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '2017-11-03 10:41:34', '2017-11-03 10:41:34');
INSERT INTO `run_waste_transfer` VALUES ('8499ef6fbe0911e797cd507b9dae4454', '7', null, 'ea5cd187943b11e7a354507b9dae4454', '101', '2017-10-31 00:00:00', null, '0', '1', 'ea5cd187943b11e7a354507b9dae4454', 'ea5cd187943b11e7a354507b9dae4454', '2017-10-31 15:03:01', '2017-10-31 15:03:01');
INSERT INTO `run_waste_transfer` VALUES ('9222400bbd5a11e7be45507b9dae4454', '6', 'c17467d5bd5f11e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '4234234', '2017-10-30 00:00:00', null, '1', '1', 'e20afce4b12511e68bc4507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '2017-10-30 18:10:36', '2017-10-30 18:47:48');
INSERT INTO `run_waste_transfer` VALUES ('afd04f50bd2811e7be45507b9dae4454', '3', 'de78c1edbd5f11e7be45507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '20171030-1', '2017-10-30 00:00:00', null, '1', '1', 'e20afce4b12511e68bc4507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '2017-10-30 12:13:35', '2017-10-30 18:48:37');
INSERT INTO `run_waste_transfer` VALUES ('bdfd402cbf8511e79515507b9dae4454', '12', null, 'ea5cd187943b11e7a354507b9dae4454', '[2017]CH -06-12', '2017-11-02 12:24:46', null, '0', '1', 'ea5cd187943b11e7a354507b9dae4454', 'ea5cd187943b11e7a354507b9dae4454', '2017-11-02 12:24:46', '2017-11-02 12:24:46');
INSERT INTO `run_waste_transfer` VALUES ('c3f505ebbf9811e79515507b9dae4454', '13', null, 'ea5cd187943b11e7a354507b9dae4454', '[2017]CH -06-13', '2017-11-02 14:40:57', null, '0', '1', 'ea5cd187943b11e7a354507b9dae4454', 'ea5cd187943b11e7a354507b9dae4454', '2017-11-02 14:40:57', '2017-11-02 14:40:57');

-- ----------------------------
-- Table structure for run_waste_transfer_item
-- ----------------------------
DROP TABLE IF EXISTS `run_waste_transfer_item`;
CREATE TABLE `run_waste_transfer_item` (
  `id` varchar(32) NOT NULL,
  `sort` bigint(20) NOT NULL AUTO_INCREMENT,
  `transfer_id` varchar(32) DEFAULT NULL,
  `proc_inst_id` varchar(32) DEFAULT NULL,
  `user_id` varchar(32) DEFAULT NULL,
  `device_no` varchar(50) DEFAULT NULL,
  `device_name` varchar(100) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `is_logout` tinyint(1) DEFAULT NULL,
  `note` varchar(300) DEFAULT NULL,
  `status` smallint(6) DEFAULT NULL COMMENT '状态',
  `create_by` varchar(50) DEFAULT NULL,
  `update_by` varchar(50) DEFAULT NULL,
  `gmt_create` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_transfer_item_sort` (`sort`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of run_waste_transfer_item
-- ----------------------------
INSERT INTO `run_waste_transfer_item` VALUES ('02447b32bd3c11e7be45507b9dae4454', '9', '023f5a39bd3c11e7be45507b9dae4454', null, 'e20afce4b12511e68bc4507b9dae4454', '123', '4124', '55', '1', '51251', null, 'e20afce4b12511e68bc4507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '2017-10-30 14:31:55', '2017-10-30 14:31:55');
INSERT INTO `run_waste_transfer_item` VALUES ('02463959bd3c11e7be45507b9dae4454', '10', '023f5a39bd3c11e7be45507b9dae4454', null, 'e20afce4b12511e68bc4507b9dae4454', '515', '25125', '1', '0', '51435', null, 'e20afce4b12511e68bc4507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '2017-10-30 14:31:55', '2017-10-30 14:31:55');
INSERT INTO `run_waste_transfer_item` VALUES ('0f4994e4c06f11e7ab51507b9dae4454', '23', '0f445fffc06f11e7ab51507b9dae4454', null, 'e20afce4b12511e68bc4507b9dae4454', '2f1', '312', '123', '1', '1', null, 'e20afce4b12511e68bc4507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '2017-11-03 16:14:57', '2017-11-03 16:14:57');
INSERT INTO `run_waste_transfer_item` VALUES ('210802dbbe0a11e797cd507b9dae4454', '13', '2105580ebe0a11e797cd507b9dae4454', null, 'ea5cd187943b11e7a354507b9dae4454', '13', '4124', '51', '1', '51', null, 'ea5cd187943b11e7a354507b9dae4454', 'ea5cd187943b11e7a354507b9dae4454', '2017-10-31 15:07:23', '2017-10-31 15:07:23');
INSERT INTO `run_waste_transfer_item` VALUES ('3da85bcac07811e7ab51507b9dae4454', '24', '3da31c03c07811e7ab51507b9dae4454', null, 'e20afce4b12511e68bc4507b9dae4454', 'a1', 'b1', '1', '1', 'c1', null, 'e20afce4b12511e68bc4507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '2017-11-03 17:20:40', '2017-11-03 17:20:40');
INSERT INTO `run_waste_transfer_item` VALUES ('3dac7994c07811e7ab51507b9dae4454', '25', '3da31c03c07811e7ab51507b9dae4454', null, 'e20afce4b12511e68bc4507b9dae4454', 'a2', 'b2', '2', '0', 'c2', null, 'e20afce4b12511e68bc4507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '2017-11-03 17:20:40', '2017-11-03 17:20:40');
INSERT INTO `run_waste_transfer_item` VALUES ('3dae2575c07811e7ab51507b9dae4454', '26', '3da31c03c07811e7ab51507b9dae4454', null, 'e20afce4b12511e68bc4507b9dae4454', 'a3', 'b3', '3', '1', 'c3', null, 'e20afce4b12511e68bc4507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '2017-11-03 17:20:40', '2017-11-03 17:20:40');
INSERT INTO `run_waste_transfer_item` VALUES ('442ed4e2be0b11e797cd507b9dae4454', '15', '442a43dfbe0b11e797cd507b9dae4454', null, 'ea5cd187943b11e7a354507b9dae4454', '123', '4124', '5', '0', '', null, 'ea5cd187943b11e7a354507b9dae4454', 'ea5cd187943b11e7a354507b9dae4454', '2017-10-31 15:15:32', '2017-10-31 15:15:32');
INSERT INTO `run_waste_transfer_item` VALUES ('5f6329adc04011e7ab51507b9dae4454', '19', '5f5f2e52c04011e7ab51507b9dae4454', null, 'e20afce4b12511e68bc4507b9dae4454', '1', '2', '1', '1', '', null, 'e20afce4b12511e68bc4507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '2017-11-03 10:40:37', '2017-11-03 10:40:37');
INSERT INTO `run_waste_transfer_item` VALUES ('67298456be0a11e797cd507b9dae4454', '14', '67246b67be0a11e797cd507b9dae4454', null, 'ea5cd187943b11e7a354507b9dae4454', '124', '241', '1', '1', '', null, 'ea5cd187943b11e7a354507b9dae4454', 'ea5cd187943b11e7a354507b9dae4454', '2017-10-31 15:09:21', '2017-10-31 15:09:21');
INSERT INTO `run_waste_transfer_item` VALUES ('687546f4c04011e7ab51507b9dae4454', '20', '68742f67c04011e7ab51507b9dae4454', null, 'e20afce4b12511e68bc4507b9dae4454', '121', '12', '12', '1', '121', null, 'e20afce4b12511e68bc4507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '2017-11-03 10:40:52', '2017-11-03 10:40:52');
INSERT INTO `run_waste_transfer_item` VALUES ('73046a10c04011e7ab51507b9dae4454', '21', '73034c8bc04011e7ab51507b9dae4454', null, 'e20afce4b12511e68bc4507b9dae4454', '121', '121', '12', '1', '1212', null, 'e20afce4b12511e68bc4507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '2017-11-03 10:41:10', '2017-11-03 10:41:10');
INSERT INTO `run_waste_transfer_item` VALUES ('81909722c04011e7ab51507b9dae4454', '22', '818cddafc04011e7ab51507b9dae4454', null, 'e20afce4b12511e68bc4507b9dae4454', '121', '121', '12', '1', '12', null, 'e20afce4b12511e68bc4507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '2017-11-03 10:41:34', '2017-11-03 10:41:34');
INSERT INTO `run_waste_transfer_item` VALUES ('851d49a4be0911e797cd507b9dae4454', '12', '8499ef6fbe0911e797cd507b9dae4454', null, 'ea5cd187943b11e7a354507b9dae4454', '123', '4124', '5', '1', '15', null, 'ea5cd187943b11e7a354507b9dae4454', 'ea5cd187943b11e7a354507b9dae4454', '2017-10-31 15:03:02', '2017-10-31 15:03:02');
INSERT INTO `run_waste_transfer_item` VALUES ('9223954dbd5a11e7be45507b9dae4454', '11', '9222400bbd5a11e7be45507b9dae4454', null, 'e20afce4b12511e68bc4507b9dae4454', '1112', '33434', '1', '1', '12121', null, 'e20afce4b12511e68bc4507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '2017-10-30 18:10:36', '2017-10-30 18:47:48');
INSERT INTO `run_waste_transfer_item` VALUES ('afdb82c1bd2811e7be45507b9dae4454', '5', 'afd04f50bd2811e7be45507b9dae4454', null, 'e20afce4b12511e68bc4507b9dae4454', 'pc-101', '废旧电脑1台(1号)', '1', '1', '报废', null, 'e20afce4b12511e68bc4507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '2017-10-30 12:13:35', '2017-10-30 18:48:37');
INSERT INTO `run_waste_transfer_item` VALUES ('afddef57bd2811e7be45507b9dae4454', '6', 'afd04f50bd2811e7be45507b9dae4454', null, 'e20afce4b12511e68bc4507b9dae4454', '11', '12', '1', '0', '同报废', null, 'e20afce4b12511e68bc4507b9dae4454', 'e20afce4b12511e68bc4507b9dae4454', '2017-10-30 12:13:35', '2017-10-30 18:48:37');
INSERT INTO `run_waste_transfer_item` VALUES ('c40167f3bf9811e79515507b9dae4454', '16', 'c3f505ebbf9811e79515507b9dae4454', null, 'ea5cd187943b11e7a354507b9dae4454', 'a1', 'a2', '40', '1', '第一行', null, 'ea5cd187943b11e7a354507b9dae4454', 'ea5cd187943b11e7a354507b9dae4454', '2017-11-02 14:40:57', '2017-11-02 14:40:57');
INSERT INTO `run_waste_transfer_item` VALUES ('c4069e3ebf9811e79515507b9dae4454', '17', 'c3f505ebbf9811e79515507b9dae4454', null, 'ea5cd187943b11e7a354507b9dae4454', 'b1', 'b2', '34', '0', '第二行', null, 'ea5cd187943b11e7a354507b9dae4454', 'ea5cd187943b11e7a354507b9dae4454', '2017-11-02 14:40:57', '2017-11-02 14:40:57');
INSERT INTO `run_waste_transfer_item` VALUES ('c40a7f9abf9811e79515507b9dae4454', '18', 'c3f505ebbf9811e79515507b9dae4454', null, 'ea5cd187943b11e7a354507b9dae4454', 'c1', 'c2', '56', '1', '第三行', null, 'ea5cd187943b11e7a354507b9dae4454', 'ea5cd187943b11e7a354507b9dae4454', '2017-11-02 14:40:57', '2017-11-02 14:40:57');

-- ----------------------------
-- Table structure for sys_logs
-- ----------------------------
DROP TABLE IF EXISTS `sys_logs`;
CREATE TABLE `sys_logs` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `THREAD` varchar(100) DEFAULT NULL,
  `CLASS_NAME` varchar(200) DEFAULT NULL,
  `METHOD` varchar(100) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL,
  `LOGLEVEL` varchar(10) DEFAULT NULL,
  `MSG` varchar(5000) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=166710 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sys_logs
-- ----------------------------

-- ----------------------------
-- Procedure structure for P_ADD_USER_ROLE
-- ----------------------------
DROP PROCEDURE IF EXISTS `P_ADD_USER_ROLE`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `P_ADD_USER_ROLE`(IN `roleId` varchar(32))
BEGIN

	
  	DECLARE userId varchar(32); 
    DECLARE done INT DEFAULT FALSE;  
    DECLARE cur_mark CURSOR FOR select id FROM c_user;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    OPEN  cur_mark;  

		read_loop: LOOP
          
            FETCH  NEXT from cur_mark INTO userId;
            IF done THEN
                LEAVE read_loop;
             END IF;
 
			  INSERT INTO c_user_role(user_id, role_id) VALUES (userId, roleId);

    END LOOP;
 
 
    CLOSE cur_mark; 

END
;;
DELIMITER ;
