/**
 * 
 */
package com.spr.core.aspect.trace;

import java.lang.reflect.Modifier;
import java.util.Date;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.task.TaskExecutor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import com.spr.core.aspect.trace.dto.TraceInfoDTO;
import com.spr.core.aspect.trace.service.ITraceService;
import com.spr.core.spring.security.user.UserBO;

/**
 * @date 2019-2-28
 * @author wanve_java_cjy
 *
 */
@Aspect
@Component
public class TraceAspect {
	
	protected Logger logger = LoggerFactory.getLogger(TraceAspect.class);
	
	@Autowired
	private TaskExecutor taskExecutor;
	@Autowired
	private ITraceService traceService;
	
	public TraceAspect() {
		super();
	}

	// 配置切入点,该方法无方法体,主要为方便同类中其他方法使用此处配置的切入点
	@Pointcut("execution(* com.spr.web.api..*.*(..))")
	public void aspectApi(){}
	
	@Pointcut("execution(* com.spr.web.evaluate..*.*(..))")
	public void aspectEvaluate(){}
	
	@Pointcut("execution(* com.spr.web.flow..*.*(..))")
	public void aspectFlow(){}
	
	@Pointcut("execution(* com.spr.web.login..*.*(..))")
	public void aspectLogin(){}
	
	@Pointcut("execution(* com.spr.web.project..*.*(..))")
	public void aspectProject(){}
	
	/*
	 * 配置前置通知,使用在方法aspect()上注册的切入点
	 * 同时接受JoinPoint切入点对象,可以没有该参数
	 */
	@Before("aspectApi() " +
			"or aspectEvaluate() " +
			"or aspectFlow() " +
			"or aspectLogin() " +
			"or aspectProject()")
	public void before(JoinPoint joinPoint){
		TraceInfoDTO dto = new TraceInfoDTO();
		dto.setTraceId(TraceContext.getTraceId());
		dto.setParentId(TraceContext.getParentId());
		dto.setSpanId(TraceContext.getSpanId());
		
		dto.setClassName(joinPoint.getSignature().getDeclaringTypeName());
		dto.setMethodName(joinPoint.getSignature().getName());
		dto.setArgs(joinPoint.getArgs());
		dto.setModifier(Modifier.toString(joinPoint.getSignature().getModifiers()));
		dto.setKind(joinPoint.getKind());
		
		dto.setStartTimeMillis(System.currentTimeMillis());
		dto.setStartTime(new Date());
		TraceContext.push(dto);
	}
	
	// 配置后置通知,使用在方法aspect()上注册的切入点
	@After("aspectApi() " +
			"or aspectEvaluate() " +
			"or aspectFlow() " +
			"or aspectLogin() " +
			"or aspectProject()")
	public void after(JoinPoint joinPoint){
		TraceInfoDTO dto = TraceContext.pop();
		dto.setEndTime(new Date());
		dto.setEndTimeMillis(System.currentTimeMillis());
		dto.countRunTime();
		
		dto.setUserId(this.getNowUserId());
		taskExecutor.execute(new TraceThread(dto, traceService, logger));
	}

	public String getNowUserId() {
		if (SecurityContextHolder.getContext() == null 
		|| SecurityContextHolder.getContext().getAuthentication() == null 
		|| SecurityContextHolder.getContext().getAuthentication().getPrincipal() == null) {
			return null;
		}
		
		Object o = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		return ((UserBO) o).getId();
	}	
}
