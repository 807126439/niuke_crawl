package com.spr.web.evaluate.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spr.core.common.bean.AjaxJson;
import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.controller.BaseController;
import com.spr.web.evaluate.dto.record.EvaluateRecordInputLogDTO;
import com.spr.web.evaluate.service.IEvaluateRecordInputLogService;

@Controller
@Scope("prototype")
@RequestMapping("/evaluateRecordInputLogController")
public class EvaluateRecordInputLogController extends BaseController{

	private static final long serialVersionUID = 1L;
	
	@Resource
	private IEvaluateRecordInputLogService evaluateRecordInputLogService;	
	
	@RequestMapping(value="/list",method={RequestMethod.POST})
	@ResponseBody
	public AjaxJson listData(HttpServletRequest request,DataQuery dq, String evalId, String indexId){
		dq.setNotQueryPage();
		dq.setSidx("gmtCreate");
		dq.setSord("asc");
		
		dq.putToMap("evalId", evalId);
		dq.putToMap("indexId", indexId);
		List<EvaluateRecordInputLogDTO> list = this.evaluateRecordInputLogService.selectListByCondition(dq);
		return new AjaxJson(this.OPER_SUCCESS_MESSAGE, AjaxJson.success, list);
	}
	
	
	@RequestMapping(value="/viewPage",method={RequestMethod.GET})
	public String viewPage(HttpServletRequest request){
		this.wrapMenuTitle(request);
		
		return "evaluate/evaluateRecordInputLog/evaluateRecordInputLogList.jsp";
	}
	
	
	@RequestMapping(value="/getPageData",method={RequestMethod.POST})
	@ResponseBody
	public Map<String, Object> loadPageData(HttpServletRequest request,DataQuery dq){

		this.wrapTableQueryParams(request, dq);
				
		Page<EvaluateRecordInputLogDTO> pageResult = this.evaluateRecordInputLogService.searchByPage(dq);
		 
		return this.handlePageReult(pageResult);
	}	
	
	@RequestMapping(value="/skipAddEvaluateRecordInputLog")
	public String skipAddEvaluateRecordInputLog(HttpServletRequest request){
		
		
		return "evaluate/evaluateRecordInputLog/addEvaluateRecordInputLog.jsp";
	}
	
	
	@RequestMapping(value="/addEvaluateRecordInputLog",method={RequestMethod.POST})
	@ResponseBody
	public AjaxJson addEvaluateRecordInputLog(EvaluateRecordInputLogDTO dto) throws Exception{
	
		this.evaluateRecordInputLogService.addEvaluateRecordInputLog(dto);
		
		
		return new AjaxJson(this.ADD_SUCCESS_MESSAGE, AjaxJson.success);
	}
	
	
	@RequestMapping("/getDetail")
	public String loadDetail(HttpServletRequest request,@RequestParam(value="id",required=true)String id){
			  		
	    EvaluateRecordInputLogDTO result = this.evaluateRecordInputLogService.getDetailById(id);
		request.setAttribute("model", result);
		
	
		return "evaluate/evaluateRecordInputLog/editEvaluateRecordInputLog.jsp";
	}
	
	
	@RequestMapping(value="/editEvaluateRecordInputLog",method={RequestMethod.POST})
	@ResponseBody
	public AjaxJson updateEvaluateRecordInputLog(EvaluateRecordInputLogDTO dto){
		
		this.evaluateRecordInputLogService.updateEvaluateRecordInputLog(dto);
				
		return new AjaxJson(this.EDIT_SUCCESS_MESSAGE, AjaxJson.success);
	}
	
	
	@RequestMapping(value="/deleteEvaluateRecordInputLog",method={RequestMethod.POST})
	@ResponseBody
	public AjaxJson deleteEvaluateRecordInputLog(String[] ids){
		
		this.evaluateRecordInputLogService.deleteEvaluateRecordInputLogs(ids);
		
		
		return new AjaxJson(this.DEL_SUCCESS_MESSAGE, AjaxJson.success);
	}
	
}
