package com.spr.web.evaluate.dto.record;

import com.spr.core.common.dto.UUIDDTO;
import java.math.BigDecimal;

public class EvaluateRecordInputLogDTO extends UUIDDTO {

    private String evalId;

    private String indexId;

    private String procNodeId;

    private String userId;
    private String userName;

    private BigDecimal beforeVal;

    private BigDecimal changeVal;

    private Short status;

    private String createBy;

    private String updateBy;

    /**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEvalId() {
        return evalId;
    }

    public void setEvalId(String evalId) {
        this.evalId = evalId == null ? null : evalId.trim();
    }

    public String getIndexId() {
        return indexId;
    }

    public void setIndexId(String indexId) {
        this.indexId = indexId == null ? null : indexId.trim();
    }

    public String getProcNodeId() {
        return procNodeId;
    }

    public void setProcNodeId(String procNodeId) {
        this.procNodeId = procNodeId == null ? null : procNodeId.trim();
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId == null ? null : userId.trim();
    }

    public BigDecimal getBeforeVal() {
        return beforeVal;
    }

    public void setBeforeVal(BigDecimal beforeVal) {
        this.beforeVal = beforeVal;
    }

    public BigDecimal getChangeVal() {
        return changeVal;
    }

    public void setChangeVal(BigDecimal changeVal) {
        this.changeVal = changeVal;
    }

    public Short getStatus() {
        return status;
    }

    public void setStatus(Short status) {
        this.status = status;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }
}