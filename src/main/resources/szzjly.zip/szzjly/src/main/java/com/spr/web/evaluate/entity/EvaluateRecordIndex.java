package com.spr.web.evaluate.entity;

import com.spr.core.annotations.DbField;
import com.spr.core.common.entity.UUIDEntity;
import java.io.Serializable;

public class EvaluateRecordIndex extends UUIDEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    private String evalId;

    private String originalId;

    private Integer sortNo;

    private String sortName;

    private String indexName;

    private String score;

    private String indexConten;

    private String standard;

    private String parentId;

    private Integer level;

    private Short status;

    private Short flag;

    private String createBy;

    private String updateBy;

    @DbField(name="eval_id")
    public String getEvalId() {
        return evalId;
    }

    public void setEvalId(String evalId) {
        this.evalId = evalId == null ? null : evalId.trim();
    }

    @DbField(name="original_id")
    public String getOriginalId() {
        return originalId;
    }

    public void setOriginalId(String originalId) {
        this.originalId = originalId == null ? null : originalId.trim();
    }

    @DbField(name="sort_no")
    public Integer getSortNo() {
        return sortNo;
    }

    public void setSortNo(Integer sortNo) {
        this.sortNo = sortNo;
    }

    @DbField(name="sort_name")
    public String getSortName() {
        return sortName;
    }

    public void setSortName(String sortName) {
        this.sortName = sortName == null ? null : sortName.trim();
    }

    @DbField(name="index_name")
    public String getIndexName() {
        return indexName;
    }

    public void setIndexName(String indexName) {
        this.indexName = indexName == null ? null : indexName.trim();
    }

    @DbField(name="score")
    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score == null ? null : score.trim();
    }

    @DbField(name="index_conten")
    public String getIndexConten() {
        return indexConten;
    }

    public void setIndexConten(String indexConten) {
        this.indexConten = indexConten == null ? null : indexConten.trim();
    }

    @DbField(name="standard")
    public String getStandard() {
        return standard;
    }

    public void setStandard(String standard) {
        this.standard = standard == null ? null : standard.trim();
    }

    @DbField(name="parent_id")
    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId == null ? null : parentId.trim();
    }

    @DbField(name="level")
    public Integer getLevel() {
        return level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }

    @DbField(name="status")
    public Short getStatus() {
        return status;
    }

    public void setStatus(Short status) {
        this.status = status;
    }

    @DbField(name="flag")
    public Short getFlag() {
        return flag;
    }

    public void setFlag(Short flag) {
        this.flag = flag;
    }

    @DbField(name="create_by")
    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    @DbField(name="update_by")
    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(",Super = ").append(super.toString());
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append(", evalId=").append(evalId);
        sb.append(", originalId=").append(originalId);
        sb.append(", sortNo=").append(sortNo);
        sb.append(", sortName=").append(sortName);
        sb.append(", indexName=").append(indexName);
        sb.append(", score=").append(score);
        sb.append(", indexConten=").append(indexConten);
        sb.append(", standard=").append(standard);
        sb.append(", parentId=").append(parentId);
        sb.append(", level=").append(level);
        sb.append(", status=").append(status);
        sb.append(", flag=").append(flag);
        sb.append(", createBy=").append(createBy);
        sb.append(", updateBy=").append(updateBy);
        sb.append("]");
        return sb.toString();
    }
}