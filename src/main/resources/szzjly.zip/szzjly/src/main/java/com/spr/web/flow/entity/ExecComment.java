package com.spr.web.flow.entity;

import java.io.Serializable;

import com.spr.core.annotations.DbField;
import com.spr.core.common.entity.UUIDEntity;

public class ExecComment extends UUIDEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final short TYRP_SUCCESS = 1; // 办理成功类型
	public static final short TYRP_FAIL = 0; // 办理失败类型

	public static final short DEF_STATUS = 1;

	private String procInstId;

	private String procNodeId;

	private String userId;

	private Short type;

	private String content;

	private String note;

	private Short status;

	private String createBy;

	private String updateBy;

	@DbField(name = "proc_inst_id")
	public String getProcInstId() {
		return procInstId;
	}

	public void setProcInstId(String procInstId) {
		this.procInstId = procInstId == null ? null : procInstId.trim();
	}

	@DbField(name = "proc_node_id")
	public String getProcNodeId() {
		return procNodeId;
	}

	public void setProcNodeId(String procNodeId) {
		this.procNodeId = procNodeId == null ? null : procNodeId.trim();
	}

	@DbField(name = "user_id")
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId == null ? null : userId.trim();
	}

	@DbField(name = "type")
	public Short getType() {
		return type;
	}

	public void setType(Short type) {
		this.type = type;
	}

	@DbField(name = "content")
	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content == null ? null : content.trim();
	}

	@DbField(name = "note")
	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note == null ? null : note.trim();
	}

	@DbField(name = "status")
	public Short getStatus() {
		return status;
	}

	public void setStatus(Short status) {
		this.status = status;
	}

	@DbField(name = "create_by")
	public String getCreateBy() {
		return createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy == null ? null : createBy.trim();
	}

	@DbField(name = "update_by")
	public String getUpdateBy() {
		return updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy == null ? null : updateBy.trim();
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode());
		sb.append(",Super = ").append(super.toString());
		sb.append(", serialVersionUID=").append(serialVersionUID);
		sb.append(", procInstId=").append(procInstId);
		sb.append(", procNodeId=").append(procNodeId);
		sb.append(", userId=").append(userId);
		sb.append(", type=").append(type);
		sb.append(", content=").append(content);
		sb.append(", note=").append(note);
		sb.append(", status=").append(status);
		sb.append(", createBy=").append(createBy);
		sb.append(", updateBy=").append(updateBy);
		sb.append("]");
		return sb.toString();
	}
}