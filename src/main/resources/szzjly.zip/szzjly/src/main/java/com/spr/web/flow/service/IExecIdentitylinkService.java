package com.spr.web.flow.service;

import java.util.List;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.web.flow.dto.exec.ExecIdentitylinkDTO;
import com.spr.web.flow.entity.ExecIdentitylink;
import com.spr.web.system.dto.user.WeiUserDTO;

public interface IExecIdentitylinkService {

	Page<ExecIdentitylinkDTO> searchByPage(DataQuery dq);

	ExecIdentitylinkDTO getDetailById(String id);

	ExecIdentitylink addExecIdentitylink(ExecIdentitylinkDTO dto);

	void updateExecIdentitylink(ExecIdentitylinkDTO dto);

	void deleteExecIdentitylinks(String[] ids);

	void updateExecIdentitylinkStatus(String id, Short status);

	List<WeiUserDTO> getUsersByNodeId(String id);

}
