package com.spr.web.system.service.impl;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.spr.core.common.utils.Assert;
import com.spr.core.redis.template.RedisClientTemplate;
import com.spr.web.system.service.ICacheManager;

@Service("cacheManager")
public class CacheManagerImpl implements ICacheManager {
	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private RedisClientTemplate redisClientTemplate;

	/**
	 * 
	 * @param key
	 * @param val
	 * @param seconds
	 *            秒 2018-4-14 上午10:34:10
	 */
	@Override
	public void simpleStore(String key, String val, Integer seconds) {

		if (!StringUtils.isBlank(key) && !StringUtils.isBlank(val)) {
			String result = redisClientTemplate.set(key, val);
			if (logger.isInfoEnabled()) {
				logger.info("Redis: key=" + key + " value=" + val + " result:" + result);
			}
			if (seconds != null) {
				redisClientTemplate.expire(key, seconds);
			}

		}

	}

	@Override
	public void deleteValue(String key) {

		if (!StringUtils.isBlank(key)) {
			redisClientTemplate.del(key);
		}

	}

	@Override
	public String getVal(String key) {

		String result = redisClientTemplate.get(key);
		return result;
	}

	/**
	 * 存储短信验证码
	 */
	@Override
	public void storeSmsCode(String businessType, String phone, String code, int seconds) {
		Assert.hasText(businessType, Assert.NULL_PARAM_STR("businessType"));
		Assert.hasText(phone, Assert.NULL_PARAM_STR("phone"));
		Assert.hasText(code, Assert.NULL_PARAM_STR("code"));

		String result = redisClientTemplate.set(businessType + phone, code);
		if (logger.isInfoEnabled()) {
			logger.info("Redis: key=" + businessType + phone + " value=" + code + " result:" + result);
		}
		redisClientTemplate.expire(businessType + phone, seconds);
		System.out.println(result);
	}

	/**
	 * 获取验证码
	 * 
	 * @param businessType
	 * @param phone
	 * @return
	 */
	@Override
	public String getCodeByKey(String businessType, String phone) {
		Assert.hasText(businessType, Assert.NULL_PARAM_STR("businessType"));
		Assert.hasText(phone, Assert.NULL_PARAM_STR("phone"));

		String result = redisClientTemplate.get(businessType + phone);

		return result;
	}

}
