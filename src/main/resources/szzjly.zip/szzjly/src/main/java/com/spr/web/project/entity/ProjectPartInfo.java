package com.spr.web.project.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.spr.core.annotations.DbField;
import com.spr.core.common.entity.UUIDEntity;

public class ProjectPartInfo extends UUIDEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	private String apiProId;

	private String apiEngId;

	private String proId;

	private String partName;

	private String partNo;

	private String partAddress;

	private BigDecimal partAmount;

	private String engTypeCode;

	private String contractorUnitId;

	private Date gmtSigned;

	private String linkMan;

	private String linkTel;

	private Date registerTime;

	private Date startTime;

	private Date endTime;

	private String memo;

	private Short evaluateStatus; // 判断是否完成合同评价 0:未完成 1：完成

	private Short status;

	private Short flag;

	private String createBy;

	private String updateBy;

	private String projectManager; // 项目经理

	private String supervisionDirector; // 监理总监

	private String masterMan; // 负责人

	@DbField(name = "eng_type_code")
	public String getEngTypeCode() {
		return engTypeCode;
	}

	public void setEngTypeCode(String engTypeCode) {
		this.engTypeCode = engTypeCode;
	}

	@DbField(name = "pro_id")
	public String getProId() {
		return proId;
	}

	public void setProId(String proId) {
		this.proId = proId == null ? null : proId.trim();
	}

	@DbField(name = "part_name")
	public String getPartName() {
		return partName;
	}

	public void setPartName(String partName) {
		this.partName = partName == null ? null : partName.trim();
	}

	@DbField(name = "part_amount")
	public BigDecimal getPartAmount() {
		return partAmount;
	}

	public void setPartAmount(BigDecimal partAmount) {
		this.partAmount = partAmount;
	}

	@DbField(name = "contractor_unit_id")
	public String getContractorUnitId() {
		return contractorUnitId;
	}

	public void setContractorUnitId(String contractorUnitId) {
		this.contractorUnitId = contractorUnitId == null ? null : contractorUnitId.trim();
	}

	@DbField(name = "gmt_signed")
	public Date getGmtSigned() {
		return gmtSigned;
	}

	public void setGmtSigned(Date gmtSigned) {
		this.gmtSigned = gmtSigned;
	}

	@DbField(name = "link_man")
	public String getLinkMan() {
		return linkMan;
	}

	public void setLinkMan(String linkMan) {
		this.linkMan = linkMan == null ? null : linkMan.trim();
	}

	@DbField(name = "link_tel")
	public String getLinkTel() {
		return linkTel;
	}

	public void setLinkTel(String linkTel) {
		this.linkTel = linkTel == null ? null : linkTel.trim();
	}

	@DbField(name = "start_time")
	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	@DbField(name = "end_time")
	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	@DbField(name = "memo")
	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo == null ? null : memo.trim();
	}

	@DbField(name = "status")
	public Short getStatus() {
		return status;
	}

	public void setStatus(Short status) {
		this.status = status;
	}

	@DbField(name = "flag")
	public Short getFlag() {
		return flag;
	}

	public void setFlag(Short flag) {
		this.flag = flag;
	}

	@DbField(name = "create_by")
	public String getCreateBy() {
		return createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy == null ? null : createBy.trim();
	}

	@DbField(name = "update_by")
	public String getUpdateBy() {
		return updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy == null ? null : updateBy.trim();
	}

	@DbField(name = "api_pro_id")
	public String getApiProId() {
		return apiProId;
	}

	public void setApiProId(String apiProId) {
		this.apiProId = apiProId;
	}

	@DbField(name = "api_eng_id")
	public String getApiEngId() {
		return apiEngId;
	}

	public void setApiEngId(String apiEngId) {
		this.apiEngId = apiEngId;
	}

	@DbField(name = "part_address")
	public String getPartAddress() {
		return partAddress;
	}

	public void setPartAddress(String partAddress) {
		this.partAddress = partAddress;
	}

	@DbField(name = "register_time")
	public Date getRegisterTime() {
		return registerTime;
	}

	public void setRegisterTime(Date registerTime) {
		this.registerTime = registerTime;
	}

	public String getPartNo() {
		return partNo;
	}

	public void setPartNo(String partNo) {
		this.partNo = partNo;
	}

	@DbField(name = "project_manager")
	public String getProjectManager() {
		return projectManager;
	}

	public void setProjectManager(String projectManager) {
		this.projectManager = projectManager;
	}

	@DbField(name = "supervision_director")
	public String getSupervisionDirector() {
		return supervisionDirector;
	}

	public void setSupervisionDirector(String supervisionDirector) {
		this.supervisionDirector = supervisionDirector;
	}

	@DbField(name = "master_man")
	public String getMasterMan() {
		return masterMan;
	}

	public void setMasterMan(String masterMan) {
		this.masterMan = masterMan;
	}

	@DbField(name = "evaluate_status")
	public Short getEvaluateStatus() {
		return evaluateStatus;
	}

	public void setEvaluateStatus(Short evaluateStatus) {
		this.evaluateStatus = evaluateStatus;
	}

}