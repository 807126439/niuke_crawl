package com.spr.web.system.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.dto.ZtreeDTO;
import com.spr.core.common.exception.BusinessException;
import com.spr.core.common.service.BaseService;
import com.spr.core.common.utils.Assert;
import com.spr.core.gobal.GobalVal;
import com.spr.web.system.dao.IEngineeringTypeDao;
import com.spr.web.system.dto.engineering.EngineeringTypeDTO;
import com.spr.web.system.entity.ContractorType;
import com.spr.web.system.entity.EngineeringType;
import com.spr.web.system.service.IEngineeringTypeService;

@Service("engineeringTypeService")
@Transactional
public class EngineeringTypeServiceImpl extends BaseService implements IEngineeringTypeService {

	@Resource
	private IEngineeringTypeDao engineeringTypeDao;

	@Override
	public Map<String, String> selectCodeNameMapByCondition(DataQuery dq) {
		dq.assemblePageOffset();
		dq.assembleOrderInfo(ContractorType.class, null);
		List<EngineeringTypeDTO> resultlist = this.engineeringTypeDao.selectListByCondition(dq.getQueryMap());
		Map<String, String> map = new HashMap<String, String>(resultlist.size());
		for (EngineeringTypeDTO dto : resultlist) {
			map.put(dto.getTypeCode(), dto.getTypeName());
		}
		return map;
	}

	@Override
	public EngineeringTypeDTO selectOneByCondition(DataQuery dq) {
		dq.setPageSize(1);
		List<EngineeringTypeDTO> resultlist = this.selectListByCondition(dq);

		if (resultlist == null || resultlist.isEmpty()) {
			return null;
		}
		return resultlist.get(0);
	}

	@Override
	public List<EngineeringTypeDTO> selectListByCondition(DataQuery dq) {
		dq.assemblePageOffset();
		dq.assembleOrderInfo(EngineeringType.class, null);
		List<EngineeringTypeDTO> resultlist = this.engineeringTypeDao.selectListByCondition(dq.getQueryMap());
		return resultlist;
	}

	/**
	 * 分页查询
	 * 
	 * @param dq
	 */
	@Override
	public Page<EngineeringTypeDTO> searchByPage(DataQuery dq) {

		Long recTotal = this.engineeringTypeDao.countByCondition(dq.assemblePageOffset().getQueryMap());
		dq.assembleOrderInfo(EngineeringType.class, null);
		List<EngineeringTypeDTO> resultlist = this.engineeringTypeDao.selectListByCondition(dq.getQueryMap());

		return new Page<EngineeringTypeDTO>(dq.getCurrentPage(), dq.getPageSize(), resultlist, recTotal);
	}

	/**
	 * 查询详细
	 * 
	 * @param id
	 */
	@Override
	public EngineeringTypeDTO getDetailById(String id) {
		Assert.hasText(id, Assert.NULL_PARAM_STR("id"));

		EngineeringTypeDTO result = this.engineeringTypeDao.getDetailById(id);
		Assert.notNull(result, Assert.EMPTY_REOCRD_STR);

		return result;
	}

	/**
	 * 添加
	 * 
	 * @param dto
	 */
	@Override
	public void addEngineeringType(EngineeringTypeDTO dto) {
		Assert.notNull(dto.getSortNo(), "请填写排序号");
		Assert.hasText(dto.getTypeName(), "请填写类型名称");
		Assert.hasText(dto.getTypeCode(), "请填写类型代码");

		if (judgeTypeCodeExist(dto.getTypeCode())) {
			throw new BusinessException("该类型代码已存在，请勿重复添加");
		}

		EngineeringType model = new EngineeringType();
		model.setSortNo(dto.getSortNo());
		model.setTypeName(dto.getTypeName());
		model.setTypeCode(dto.getTypeCode());
		model.setStatus(GobalVal.STATUS_ENABLE);
		model.setCreateBy(getNowUser().getUsername());
		this.engineeringTypeDao.insert(model);

		this.writeInfoLog("Add: " + model.toString());

	}

	/**
	 * 修改
	 * 
	 * @param dto
	 */
	@Override
	public void updateEngineeringType(EngineeringTypeDTO dto) {
		Assert.notNull(dto.getSortNo(), "请填写排序号");
		Assert.hasText(dto.getTypeName(), "请填写类型名称");
		Assert.hasText(dto.getTypeCode(), "请填写类型代码");
		Assert.hasText(dto.getId(), Assert.NULL_PARAM_STR("id"));

		EngineeringType model = this.engineeringTypeDao.getById(dto.getId());
		Assert.notNull(model, Assert.EMPTY_REOCRD_STR);

		if (!model.getTypeCode().equals(dto.getTypeCode())) {
			if (judgeTypeCodeExist(dto.getTypeCode())) {
				throw new BusinessException("该类型代码已存在，请勿重复添加");
			}
		}

		model.setSortNo(dto.getSortNo());
		model.setTypeName(dto.getTypeName());
		model.setTypeCode(dto.getTypeCode());
		model.setUpdateBy(getNowUser().getChineseName());
		model.setGmtModified(new Date());

		this.engineeringTypeDao.update(model);

		this.writeInfoLog("Update: " + model.toString());

	}

	/**
	 * 删除
	 * 
	 * @param ids
	 */
	@Override
	public void deleteEngineeringTypes(String[] ids) {
		for (int i = 0; i < ids.length; i++) {
			this.engineeringTypeDao.deleteById(ids[i]);

			this.writeInfoLog("Delete id:" + ids[i]);

		}
	}

	@Override
	public Boolean judgeTypeCodeExist(String typeCode) {
		DataQuery dq = new DataQuery();
		dq.putToMap("typeCode", typeCode);
		Long num = this.engineeringTypeDao.countByCondition(dq.getQueryMap());
		if (num > 0) {
			return true;
		}
		return false;
	}

	@Override
	public List<ZtreeDTO> getUnitTreeData() {
		List<ZtreeDTO> resultList = new ArrayList<ZtreeDTO>();
		DataQuery dq = new DataQuery();

		dq.getQueryMap().put("sidx", "sort_no");
		dq.getQueryMap().put("sord", "asc");
		List<EngineeringTypeDTO> engTypeList = this.engineeringTypeDao.selectListByCondition(dq.getQueryMap());
		if (engTypeList != null && engTypeList.size() > 0) {
			for (EngineeringTypeDTO engTypeDTO : engTypeList) {
				ZtreeDTO ztreeDTO = new ZtreeDTO();
				ztreeDTO.setId(engTypeDTO.getTypeCode());
				ztreeDTO.setName(engTypeDTO.getTypeName());
				resultList.add(ztreeDTO);
			}
		}
		return resultList;
	}

	@Override
	public EngineeringTypeDTO getDetailByTypeCode(String typeCode) {
		DataQuery dq = new DataQuery();
		dq.putToMap("typeCode", typeCode);
		return this.selectOneByCondition(dq);
	}

}
