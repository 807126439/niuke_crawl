package com.spr.web.project.dto.part;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.spr.core.common.dto.UUIDDTO;

public class ProjectPartInfoDTO extends UUIDDTO {

	private String proId;

	private String apiProId;

	private String apiEngId;

	private String proName;// 所属工程名

	private String partNo;

	private String partAddress;

	private String agentUnitId; // 项目代建单位ID，用于判断是否代建项目

	private String partName;

	private BigDecimal partAmount;

	private String engTypeCode;

	private String engTypeName;

	private String contractorUnitId;

	private String contractorUnitName;

	private Date gmtSigned;

	private String linkMan;

	private String linkTel;

	private Date registerTime;

	private Date startTime;

	private Date endTime;

	private String memo;

	private Short evaluateStatus;

	private Short status;

	private Short flag;

	private String createBy;

	private String updateBy;

	private String projectManager; // 项目经理

	private String supervisionDirector; // 监理总监

	private String masterMan; // 负责人

	public String getEngTypeName() {
		return engTypeName;
	}

	public void setEngTypeName(String engTypeName) {
		this.engTypeName = engTypeName;
	}

	public String getEngTypeCode() {
		return engTypeCode;
	}

	public void setEngTypeCode(String engTypeCode) {
		this.engTypeCode = engTypeCode;
	}

	public String getContractorUnitName() {
		return contractorUnitName;
	}

	public void setContractorUnitName(String contractorUnitName) {
		this.contractorUnitName = contractorUnitName;
	}

	public String getProName() {
		return proName;
	}

	public void setProName(String proName) {
		this.proName = proName;
	}

	public String getProId() {
		return proId;
	}

	public void setProId(String proId) {
		this.proId = proId == null ? null : proId.trim();
	}

	public String getPartName() {
		return partName;
	}

	public void setPartName(String partName) {
		this.partName = partName == null ? null : partName.trim();
	}

	public BigDecimal getPartAmount() {
		return partAmount;
	}

	public void setPartAmount(BigDecimal partAmount) {
		this.partAmount = partAmount;
	}

	public String getContractorUnitId() {
		return contractorUnitId;
	}

	public void setContractorUnitId(String contractorUnitId) {
		this.contractorUnitId = contractorUnitId == null ? null : contractorUnitId.trim();
	}

	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
	public Date getGmtSigned() {
		return gmtSigned;
	}

	public void setGmtSigned(Date gmtSigned) {
		this.gmtSigned = gmtSigned;
	}

	public String getLinkMan() {
		return linkMan;
	}

	public void setLinkMan(String linkMan) {
		this.linkMan = linkMan == null ? null : linkMan.trim();
	}

	public String getLinkTel() {
		return linkTel;
	}

	public void setLinkTel(String linkTel) {
		this.linkTel = linkTel == null ? null : linkTel.trim();
	}

	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo == null ? null : memo.trim();
	}

	public Short getStatus() {
		return status;
	}

	public void setStatus(Short status) {
		this.status = status;
	}

	public Short getFlag() {
		return flag;
	}

	public void setFlag(Short flag) {
		this.flag = flag;
	}

	public String getCreateBy() {
		return createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy == null ? null : createBy.trim();
	}

	public String getUpdateBy() {
		return updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy == null ? null : updateBy.trim();
	}

	public String getAgentUnitId() {
		return agentUnitId;
	}

	public void setAgentUnitId(String agentUnitId) {
		this.agentUnitId = agentUnitId;
	}

	public String getApiProId() {
		return apiProId;
	}

	public void setApiProId(String apiProId) {
		this.apiProId = apiProId;
	}

	public String getApiEngId() {
		return apiEngId;
	}

	public void setApiEngId(String apiEngId) {
		this.apiEngId = apiEngId;
	}

	public String getPartAddress() {
		return partAddress;
	}

	public void setPartAddress(String partAddress) {
		this.partAddress = partAddress;
	}

	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
	public Date getRegisterTime() {
		return registerTime;
	}

	public void setRegisterTime(Date registerTime) {
		this.registerTime = registerTime;
	}

	public String getPartNo() {
		return partNo;
	}

	public void setPartNo(String partNo) {
		this.partNo = partNo;
	}

	public String getProjectManager() {
		return projectManager;
	}

	public void setProjectManager(String projectManager) {
		this.projectManager = projectManager;
	}

	public String getSupervisionDirector() {
		return supervisionDirector;
	}

	public void setSupervisionDirector(String supervisionDirector) {
		this.supervisionDirector = supervisionDirector;
	}

	public String getMasterMan() {
		return masterMan;
	}

	public void setMasterMan(String masterMan) {
		this.masterMan = masterMan;
	}

	public Short getEvaluateStatus() {
		return evaluateStatus;
	}

	public void setEvaluateStatus(Short evaluateStatus) {
		this.evaluateStatus = evaluateStatus;
	}

}