package com.spr.web.evaluate.entity;

import com.spr.core.annotations.DbField;
import com.spr.core.common.entity.UUIDEntity;
import java.io.Serializable;
import java.math.BigDecimal;

public class EvaluateRecordInput extends UUIDEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    private String evalId;

    private String formId;

    private String indexId;

    private BigDecimal inputVal;

    private BigDecimal orginalVal;

    private Byte isModified;

    private Short status;

    private String createBy;

    private String updateBy;

    @DbField(name="eval_id")
    public String getEvalId() {
        return evalId;
    }

    public void setEvalId(String evalId) {
        this.evalId = evalId == null ? null : evalId.trim();
    }

    @DbField(name="form_id")
    public String getFormId() {
        return formId;
    }

    public void setFormId(String formId) {
        this.formId = formId == null ? null : formId.trim();
    }

    @DbField(name="index_id")
    public String getIndexId() {
        return indexId;
    }

    public void setIndexId(String indexId) {
        this.indexId = indexId == null ? null : indexId.trim();
    }

    @DbField(name="input_val")
    public BigDecimal getInputVal() {
        return inputVal;
    }

    public void setInputVal(BigDecimal inputVal) {
        this.inputVal = inputVal;
    }

    @DbField(name="orginal_val")
    public BigDecimal getOrginalVal() {
        return orginalVal;
    }

    public void setOrginalVal(BigDecimal orginalVal) {
        this.orginalVal = orginalVal;
    }

    @DbField(name="is_modified")
    public Byte getIsModified() {
        return isModified;
    }

    public void setIsModified(Byte isModified) {
        this.isModified = isModified;
    }

    @DbField(name="status")
    public Short getStatus() {
        return status;
    }

    public void setStatus(Short status) {
        this.status = status;
    }

    @DbField(name="create_by")
    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    @DbField(name="update_by")
    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(",Super = ").append(super.toString());
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append(", evalId=").append(evalId);
        sb.append(", formId=").append(formId);
        sb.append(", indexId=").append(indexId);
        sb.append(", inputVal=").append(inputVal);
        sb.append(", status=").append(status);
        sb.append(", createBy=").append(createBy);
        sb.append(", updateBy=").append(updateBy);
        sb.append("]");
        return sb.toString();
    }
}