package com.spr.web.evaluate.dto.form;

import java.math.BigDecimal;
import java.util.List;

import com.spr.core.common.dto.UUIDDTO;

public class EvaluateFormIndexDTO extends UUIDDTO {
	
	// 评分指标层数
	public static final int LEVEL_START = 0;
	public static final int LEVEL_END = 3;

    private Integer sortNo;

    private String sortName;

    private String indexName;

    private String score;

    private String indexConten;

    private String standard;

    private String parentId;

    private Integer level;

    private Short status;

    private Short flag;

    private String createBy;

    private String updateBy;
    
    private List<EvaluateFormIndexDTO> subIndexList;

    private BigDecimal inputVal;
    
    
    /**
	 * @return the inputVal
	 */
	public BigDecimal getInputVal() {
		return inputVal;
	}

	/**
	 * @param inputVal the inputVal to set
	 */
	public void setInputVal(BigDecimal inputVal) {
		this.inputVal = inputVal;
	}

	/**
	 * @return the subIndexList
	 */
	public List<EvaluateFormIndexDTO> getSubIndexList() {
		return subIndexList;
	}

	/**
	 * @param subIndexList the subIndexList to set
	 */
	public void setSubIndexList(List<EvaluateFormIndexDTO> subIndexList) {
		this.subIndexList = subIndexList;
	}

	public Integer getSortNo() {
        return sortNo;
    }

    public void setSortNo(Integer sortNo) {
        this.sortNo = sortNo;
    }

    public String getSortName() {
        return sortName;
    }

    public void setSortName(String sortName) {
        this.sortName = sortName == null ? null : sortName.trim();
    }

    public String getIndexName() {
        return indexName;
    }

    public void setIndexName(String indexName) {
        this.indexName = indexName == null ? null : indexName.trim();
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    public String getIndexConten() {
        return indexConten;
    }

    public void setIndexConten(String indexConten) {
        this.indexConten = indexConten == null ? null : indexConten.trim();
    }

    public String getStandard() {
        return standard;
    }

    public void setStandard(String standard) {
        this.standard = standard == null ? null : standard.trim();
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId == null ? null : parentId.trim();
    }

    public Integer getLevel() {
        return level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }

    public Short getStatus() {
        return status;
    }

    public void setStatus(Short status) {
        this.status = status;
    }

    public Short getFlag() {
        return flag;
    }

    public void setFlag(Short flag) {
        this.flag = flag;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }
}