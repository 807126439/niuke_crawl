package com.spr.web.system.controller;

import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spr.core.common.bean.AjaxJson;
import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.controller.BaseController;
import com.spr.web.system.dto.unit.UnitEvaluatorRelationDTO;
import com.spr.web.system.service.IUnitEvaluatorRelationService;

@Controller
@Scope("prototype")
@RequestMapping("/unitEvaluatorRelationController")
public class UnitEvaluatorRelationController extends BaseController {

	private static final long serialVersionUID = 1L;

	@Resource
	private IUnitEvaluatorRelationService unitEvaluatorRelationService;

	@RequestMapping(value = "/getunitEvaluatorList", method = { RequestMethod.POST })
	@ResponseBody
	public String getunitEvaluatorList(String unitId) {
		return this.unitEvaluatorRelationService.getunitEvaluatorList(unitId);
	}

	@RequestMapping(value = "/setUnitEvaluatorRelation", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson setUnitEvaluatorRelation(String unitId, String userIds) {

		this.unitEvaluatorRelationService.setUnitEvaluatorRelation(unitId, userIds);

		return new AjaxJson(this.SAVE_SUCCESS_MESSAGE, AjaxJson.success);
	}

	// --------------------------------------------------------------------------//

	@RequestMapping(value = "/viewPage", method = { RequestMethod.GET })
	public String viewPage(HttpServletRequest request) {
		this.wrapMenuTitle(request);

		return "system/unitEvaluatorRelation/unitEvaluatorRelationList.jsp";
	}

	@RequestMapping(value = "/getPageData", method = { RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> loadPageData(HttpServletRequest request, DataQuery dq) {

		this.wrapTableQueryParams(request, dq);

		Page<UnitEvaluatorRelationDTO> pageResult = this.unitEvaluatorRelationService.searchByPage(dq);

		return this.handlePageReult(pageResult);
	}

	@RequestMapping(value = "/skipAddUnitEvaluatorRelation")
	public String skipAddUnitEvaluatorRelation(HttpServletRequest request) {

		return "system/unitEvaluatorRelation/addUnitEvaluatorRelation.jsp";
	}

	@RequestMapping(value = "/addUnitEvaluatorRelation", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson addUnitEvaluatorRelation(UnitEvaluatorRelationDTO dto) throws Exception {

		this.unitEvaluatorRelationService.addUnitEvaluatorRelation(dto);

		return new AjaxJson(this.ADD_SUCCESS_MESSAGE, AjaxJson.success);
	}

	@RequestMapping("/getDetail")
	public String loadDetail(HttpServletRequest request, @RequestParam(value = "id", required = true) String id) {

		UnitEvaluatorRelationDTO result = this.unitEvaluatorRelationService.getDetailById(id);
		request.setAttribute("model", result);

		return "system/unitEvaluatorRelation/editUnitEvaluatorRelation.jsp";
	}

	@RequestMapping(value = "/editUnitEvaluatorRelation", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson updateUnitEvaluatorRelation(UnitEvaluatorRelationDTO dto) {

		this.unitEvaluatorRelationService.updateUnitEvaluatorRelation(dto);

		return new AjaxJson(this.EDIT_SUCCESS_MESSAGE, AjaxJson.success);
	}

	@RequestMapping(value = "/deleteUnitEvaluatorRelation", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson deleteUnitEvaluatorRelation(String[] ids) {

		this.unitEvaluatorRelationService.deleteUnitEvaluatorRelations(ids);

		return new AjaxJson(this.DEL_SUCCESS_MESSAGE, AjaxJson.success);
	}

}
