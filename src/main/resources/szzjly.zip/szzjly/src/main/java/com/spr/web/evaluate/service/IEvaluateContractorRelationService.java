package com.spr.web.evaluate.service;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.web.evaluate.dto.relation.EvaluateContractorRelationDTO;

public interface IEvaluateContractorRelationService {

	Page<EvaluateContractorRelationDTO> searchByPage(DataQuery dq);

	EvaluateContractorRelationDTO getDetailById(String id);

	void addEvaluateContractorRelation(EvaluateContractorRelationDTO dto);

	void updateEvaluateContractorRelation(EvaluateContractorRelationDTO dto);

	void deleteEvaluateContractorRelations(String[] ids);

}
