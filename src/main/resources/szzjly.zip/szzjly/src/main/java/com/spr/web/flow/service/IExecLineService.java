package com.spr.web.flow.service;

import com.spr.web.flow.dto.exec.ExecLineDTO;
import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;

public interface IExecLineService {

	 Page<ExecLineDTO> searchByPage(DataQuery dq);
	
	 ExecLineDTO getDetailById(String id);
	
	 void addExecLine(ExecLineDTO dto);
	
	 void updateExecLine(ExecLineDTO dto);
	
	 void deleteExecLines(String[] ids);

}
