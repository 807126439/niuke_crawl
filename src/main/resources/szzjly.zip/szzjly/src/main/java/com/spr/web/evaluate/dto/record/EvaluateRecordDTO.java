package com.spr.web.evaluate.dto.record;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.spr.core.common.dto.UUIDDTO;
import com.spr.web.evaluate.dto.form.EvaluateFormDTO;

public class EvaluateRecordDTO extends UUIDDTO {

	// 用于标识代建记录是由哪个单位评价
	public static final String RECORD_TYPE_BUILD_UNIT = "buildUnit"; // 建设单位评价
	public static final String RECORD_TYPE_ZJ_UNIT = "zjUnit"; // 住建单位评价
	public static final String RECORD_TYPE_FG_UNIT = "fgUnit"; // 发改局评价
	public static final String RECORD_TYPE_TOTAL = "total"; // 总记录

	public static final String ENG_TYPE_CODE_DJ = "DJ"; // 代建
	public static final String ENG_TYPE_CODE_SG = "SG"; // 施工
	public static final String ENG_TYPE_CODE_KC = "KC"; // 勘察
	public static final String ENG_TYPE_CODE_JL = "JL"; // 监理
	public static final String ENG_TYPE_CODE_SJ = "SJ"; // 设计
	public static final String ENG_TYPE_CODE_ZJZX = "ZJZX"; // 造价咨询
	public static final String ENG_TYPE_CODE_ZBDL = "ZBDL"; // 招标代理
	@SuppressWarnings("serial")
	public static final Map<String, String> ENG_TYPE_CODE_TEXT = new HashMap<String, String>() {
		{
			put(ENG_TYPE_CODE_DJ, "代建");
			put(ENG_TYPE_CODE_SG, "施工");
			put(ENG_TYPE_CODE_KC, "勘察");
			put(ENG_TYPE_CODE_JL, "监理");
			put(ENG_TYPE_CODE_SJ, "设计");
			put(ENG_TYPE_CODE_ZJZX, "造价咨询");
			put(ENG_TYPE_CODE_ZBDL, "招标代理");
		}
	};

	public static final String FORM_TYPE_SEASON = "season"; // 季度履约评价
	public static final String FORM_TYPE_CONTRACT = "contract"; // 合同完成履约评价
	public static final String FORM_TYPE_COMPREHENSIVE = "comprehensive"; // 综合履约评价
	public static final String FORM_TYPE_YEAR = "year"; // 年度履约评价
	@SuppressWarnings("serial")
	public static final Map<String, String> FORM_TYPE_TEXT = new HashMap<String, String>() {
		{
			put(FORM_TYPE_SEASON, "季度履约评价");
			put(FORM_TYPE_CONTRACT, "合同完成履约评价");
			put(FORM_TYPE_COMPREHENSIVE, "综合履约评价");
			put(FORM_TYPE_YEAR, "年度履约评价 ");
		}
	};

	// 评价等级：0：不合格 1：一般 2：良好 3：优秀
	public static final short EVAL_GRADE_BAD = 0;
	public static final short EVAL_GRADE_GOOD = 1;
	public static final short EVAL_GRADE_BETTER = 2;
	public static final short EVAL_GRADE_BEST = 3;
	@SuppressWarnings("serial")
	public static final Map<Short, String> EVAL_GRADE_TEXT = new HashMap<Short, String>() {
		{
			put(EVAL_GRADE_BAD, "不合格");
			put(EVAL_GRADE_GOOD, "一般");
			put(EVAL_GRADE_BETTER, "良好");
			put(EVAL_GRADE_BEST, "优秀");
		}
	};

	// 状态：0：未提交 1：正在审核 2: 审核通过 3: 审核不通过
	public static final short STATUS_UNSUBMIT = 0;
	public static final short STATUS_AUDITING = 1;
	public static final short STATUS_SUCCEED = 2;
	public static final short STATUS_FAILED = 3;
	@SuppressWarnings("serial")
	public static final Map<Short, String> STATUS_TEXT = new HashMap<Short, String>() {
		{
			put(STATUS_UNSUBMIT, "未提交");
			put(STATUS_AUDITING, "正在审核");
			put(STATUS_SUCCEED, "审核通过");
			put(STATUS_FAILED, "审核不通过");
		}
	};

	// 申辩状态：0：默认 1：提交申辩 2：已回复
	public static final short PLEA_STATUS_DEFAULT = 0;
	public static final short PLEA_STATUS_SUBMIT = 1;
	public static final short PLEA_STATUS_REPLIED = 2;
	@SuppressWarnings("serial")
	public static final Map<Short, String> PLEA_STATUS_TEXT = new HashMap<Short, String>() {
		{
			put(PLEA_STATUS_DEFAULT, "默认");
			put(PLEA_STATUS_SUBMIT, "提交申辩");
			put(PLEA_STATUS_REPLIED, "已回复");
		}
	};

	// 评价记录状态：0：定时删除 1：完成归档
	public static final short FLAG_TODELETE = 0;
	public static final short FLAG_ARCHIVED = 1;

	// 评价记录状态：0：定时删除 1：完成归档
	public static final short CHECKED_FALSE = 0;
	public static final short CHECKED_TRUE = 1;
	
	// 具体阶段
	@SuppressWarnings("serial")
	public static final List<String> SPECIFICSTEPs = new ArrayList<String>() {
		{
			add("预算");
			add("概算");
			add("决算");
			add("结算");
		}
	};

	private String connectRecordId; // 非代建：季度，合同对应综合 代建: 多个季度/合同对应一条季度/合同

	private String proId;

	private String partId;
	private String partName;
	private String engTypeCode;
	private String engTypeCodeName;

	private String targetUnitId;
	private String targetUnitName;

	private String evalUserId;
	private String evalUserName;

	private String evalUnitId;
	private String evalUnitName;

	private String formId;
	private EvaluateFormDTO form;

	private String recordType;

	private String formType;
	private String formTypeText;

	private String specificStep;

	private BigDecimal totalScore;
	private BigDecimal avgScore;

	private Short evalGrade;
	private String evalGradeText;

	private Date gmtEval;

	private String proName;

	private String contractorName;

	private String buildUnitName;

	private String situationGoods;
	private String situationBads;

	private String memo;
	private String statusText;

	private Short status;
	private String pleaStatusText;

	private Short pleaStatus;

	private Date gmtPlea;

	private String pleaContent;

	private String pleaReply;

	private Short flag;

	private String createBy;
	private Map<String, BigDecimal> inputMap;

	private String updateBy;

	private String indexIds;
	private String indexVals;

	private String statusName;// 当前自定义流程状态的名称
	private Short procStatus;// 文书正在执行流程的状态
	private String procDefName;// 流程的名称
	private String nodeType;// 正在执行节点的类别：start/node/end
	private Short flowStatus;

	private Short checked;// 标记是否已阅

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "EvaluateRecordDTO [connectRecordId=" + connectRecordId
				+ ", proId=" + proId + ", partId=" + partId + ", partName="
				+ partName + ", engTypeCode=" + engTypeCode
				+ ", engTypeCodeName=" + engTypeCodeName + ", targetUnitId="
				+ targetUnitId + ", targetUnitName=" + targetUnitName
				+ ", evalUserId=" + evalUserId + ", evalUserName="
				+ evalUserName + ", evalUnitId=" + evalUnitId
				+ ", evalUnitName=" + evalUnitName + ", formId=" + formId
				+ ", form=" + form + ", recordType=" + recordType
				+ ", formType=" + formType + ", formTypeText=" + formTypeText
				+ ", specificStep=" + specificStep + ", totalScore="
				+ totalScore + ", avgScore=" + avgScore + ", evalGrade="
				+ evalGrade + ", evalGradeText=" + evalGradeText + ", gmtEval="
				+ gmtEval + ", proName=" + proName + ", contractorName="
				+ contractorName + ", buildUnitName=" + buildUnitName
				+ ", situationGoods=" + situationGoods + ", situationBads="
				+ situationBads + ", memo=" + memo + ", statusText="
				+ statusText + ", status=" + status + ", pleaStatusText="
				+ pleaStatusText + ", pleaStatus=" + pleaStatus + ", gmtPlea="
				+ gmtPlea + ", pleaContent=" + pleaContent + ", pleaReply="
				+ pleaReply + ", flag=" + flag + ", createBy=" + createBy
				+ ", inputMap=" + inputMap + ", updateBy=" + updateBy
				+ ", indexIds=" + indexIds + ", indexVals=" + indexVals
				+ ", statusName=" + statusName + ", procStatus=" + procStatus
				+ ", procDefName=" + procDefName + ", nodeType=" + nodeType
				+ ", flowStatus=" + flowStatus + ", checked=" + checked + "]";
	}

	public Short getChecked() {
		return checked;
	}

	public void setChecked(Short checked) {
		this.checked = checked;
	}

	/**
	 * @return the situationGoods
	 */
	public String getSituationGoods() {
		return situationGoods;
	}

	/**
	 * @param situationGoods
	 *            the situationGoods to set
	 */
	public void setSituationGoods(String situationGoods) {
		this.situationGoods = situationGoods;
	}

	/**
	 * @return the situationBads
	 */
	public String getSituationBads() {
		return situationBads;
	}

	/**
	 * @param situationBads
	 *            the situationBads to set
	 */
	public void setSituationBads(String situationBads) {
		this.situationBads = situationBads;
	}

	/**
	 * @return the avgScore
	 */
	public BigDecimal getAvgScore() {
		return avgScore;
	}

	/**
	 * @param avgScore
	 *            the avgScore to set
	 */
	public void setAvgScore(BigDecimal avgScore) {
		this.avgScore = avgScore;
	}

	/**
	 * @return the targetUnitName
	 */
	public String getTargetUnitName() {
		return targetUnitName;
	}

	/**
	 * @param targetUnitName
	 *            the targetUnitName to set
	 */
	public void setTargetUnitName(String targetUnitName) {
		this.targetUnitName = targetUnitName;
	}

	/**
	 * @return the evalUserName
	 */
	public String getEvalUserName() {
		return evalUserName;
	}

	/**
	 * @param evalUserName
	 *            the evalUserName to set
	 */
	public void setEvalUserName(String evalUserName) {
		this.evalUserName = evalUserName;
	}

	public Short getFlowStatus() {
		return flowStatus;
	}

	public void setFlowStatus(Short flowStatus) {
		this.flowStatus = flowStatus;
	}

	public String getStatusName() {
		return statusName;
	}

	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}

	public Short getProcStatus() {
		return procStatus;
	}

	public void setProcStatus(Short procStatus) {
		this.procStatus = procStatus;
	}

	public String getProcDefName() {
		return procDefName;
	}

	public void setProcDefName(String procDefName) {
		this.procDefName = procDefName;
	}

	public String getNodeType() {
		return nodeType;
	}

	public void setNodeType(String nodeType) {
		this.nodeType = nodeType;
	}

	/**
	 * @return the inputMap
	 */
	public Map<String, BigDecimal> getInputMap() {
		return inputMap;
	}

	/**
	 * @param inputMap
	 *            the inputMap to set
	 */
	public void setInputMap(Map<String, BigDecimal> inputMap) {
		this.inputMap = inputMap;
	}

	/**
	 * @return the partName
	 */
	public String getPartName() {
		return partName;
	}

	/**
	 * @param partName
	 *            the partName to set
	 */
	public void setPartName(String partName) {
		this.partName = partName;
	}

	/**
	 * @return the formTypeText
	 */
	public String getFormTypeText() {
		return formTypeText;
	}

	/**
	 * @param formTypeText
	 *            the formTypeText to set
	 */
	public void setFormTypeText(String formTypeText) {
		this.formTypeText = formTypeText;
	}

	/**
	 * @return the evalGradeText
	 */
	public String getEvalGradeText() {
		return evalGradeText;
	}

	/**
	 * @param evalGradeText
	 *            the evalGradeText to set
	 */
	public void setEvalGradeText(String evalGradeText) {
		this.evalGradeText = evalGradeText;
	}

	/**
	 * @return the statusText
	 */
	public String getStatusText() {
		return statusText;
	}

	/**
	 * @param statusText
	 *            the statusText to set
	 */
	public void setStatusText(String statusText) {
		this.statusText = statusText;
	}

	/**
	 * @return the pleaStatusText
	 */
	public String getPleaStatusText() {
		return pleaStatusText;
	}

	/**
	 * @param pleaStatusText
	 *            the pleaStatusText to set
	 */
	public void setPleaStatusText(String pleaStatusText) {
		this.pleaStatusText = pleaStatusText;
	}

	/**
	 * @return the indexIds
	 */
	public String getIndexIds() {
		return indexIds;
	}

	/**
	 * @param indexIds
	 *            the indexIds to set
	 */
	public void setIndexIds(String indexIds) {
		this.indexIds = indexIds;
	}

	/**
	 * @return the indexVals
	 */
	public String getIndexVals() {
		return indexVals;
	}

	/**
	 * @param indexVals
	 *            the indexVals to set
	 */
	public void setIndexVals(String indexVals) {
		this.indexVals = indexVals;
	}

	/**
	 * @return the form
	 */
	public EvaluateFormDTO getForm() {
		return form;
	}

	/**
	 * @param form
	 *            the form to set
	 */
	public void setForm(EvaluateFormDTO form) {
		this.form = form;
	}

	public String getProId() {
		return proId;
	}

	public void setProId(String proId) {
		this.proId = proId == null ? null : proId.trim();
	}

	public String getPartId() {
		return partId;
	}

	public void setPartId(String partId) {
		this.partId = partId == null ? null : partId.trim();
	}

	public String getTargetUnitId() {
		return targetUnitId;
	}

	public void setTargetUnitId(String targetUnitId) {
		this.targetUnitId = targetUnitId == null ? null : targetUnitId.trim();
	}

	public String getEvalUserId() {
		return evalUserId;
	}

	public void setEvalUserId(String evalUserId) {
		this.evalUserId = evalUserId == null ? null : evalUserId.trim();
	}

	public String getFormId() {
		return formId;
	}

	public void setFormId(String formId) {
		this.formId = formId == null ? null : formId.trim();
	}

	public String getRecordType() {
		return recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType == null ? null : recordType.trim();
	}

	public String getFormType() {
		return formType;
	}

	public void setFormType(String formType) {
		this.formType = formType == null ? null : formType.trim();
	}

	public String getSpecificStep() {
		return specificStep;
	}

	public void setSpecificStep(String specificStep) {
		this.specificStep = specificStep == null ? null : specificStep.trim();
	}

	public BigDecimal getTotalScore() {
		return totalScore;
	}

	public void setTotalScore(BigDecimal totalScore) {
		this.totalScore = totalScore;
	}

	public static Short getEvalGradeByTotalScore(BigDecimal totalScore) {
		if (totalScore != null) {
			BigDecimal hundred = new BigDecimal(100);
			BigDecimal ninty = new BigDecimal(90);
			BigDecimal seventy_five = new BigDecimal(75);
			BigDecimal sixty = new BigDecimal(60);

			if ((totalScore.compareTo(ninty) >= 0) && (totalScore.compareTo(hundred) <= 0)) {
				// >=90 && <=100
				return EVAL_GRADE_BEST;
			} else if (totalScore.compareTo(seventy_five) >= 0) {
				// >=75 && < 90
				return EVAL_GRADE_BETTER;
			} else if (totalScore.compareTo(sixty) >= 0) {
				// >=60 && <75
				return EVAL_GRADE_GOOD;
			} else {
				// <60
				return EVAL_GRADE_BAD;
			}
		}
		return null;
	}

	public Short getEvalGrade() {
		return evalGrade;
	}

	public void setEvalGrade(Short evalGrade) {
		this.evalGrade = evalGrade;
	}

	public Date getGmtEval() {
		return gmtEval;
	}

	public void setGmtEval(Date gmtEval) {
		this.gmtEval = gmtEval;
	}

	public String getProName() {
		return proName;
	}

	public void setProName(String proName) {
		this.proName = proName == null ? null : proName.trim();
	}

	public String getContractorName() {
		return contractorName;
	}

	public void setContractorName(String contractorName) {
		this.contractorName = contractorName == null ? null : contractorName.trim();
	}

	public String getBuildUnitName() {
		return buildUnitName;
	}

	public void setBuildUnitName(String buildUnitName) {
		this.buildUnitName = buildUnitName == null ? null : buildUnitName.trim();
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo == null ? null : memo.trim();
	}

	public Short getStatus() {
		return status;
	}

	public void setStatus(Short status) {
		this.status = status;
	}

	public Short getPleaStatus() {
		return pleaStatus;
	}

	public void setPleaStatus(Short pleaStatus) {
		this.pleaStatus = pleaStatus;
	}

	public Date getGmtPlea() {
		return gmtPlea;
	}

	public void setGmtPlea(Date gmtPlea) {
		this.gmtPlea = gmtPlea;
	}

	public String getPleaContent() {
		return pleaContent;
	}

	public void setPleaContent(String pleaContent) {
		this.pleaContent = pleaContent == null ? null : pleaContent.trim();
	}

	public String getPleaReply() {
		return pleaReply;
	}

	public void setPleaReply(String pleaReply) {
		this.pleaReply = pleaReply == null ? null : pleaReply.trim();
	}

	public Short getFlag() {
		return flag;
	}

	public void setFlag(Short flag) {
		this.flag = flag;
	}

	public String getCreateBy() {
		return createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy == null ? null : createBy.trim();
	}

	public String getUpdateBy() {
		return updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy == null ? null : updateBy.trim();
	}

	public String getEngTypeCode() {
		return engTypeCode;
	}

	public void setEngTypeCode(String engTypeCode) {
		this.engTypeCode = engTypeCode;
	}

	public String getEvalUnitName() {
		return evalUnitName;
	}

	public void setEvalUnitName(String evalUnitName) {
		this.evalUnitName = evalUnitName;
	}

	public String getEvalUnitId() {
		return evalUnitId;
	}

	public void setEvalUnitId(String evalUnitId) {
		this.evalUnitId = evalUnitId;
	}

	public String getConnectRecordId() {
		return connectRecordId;
	}

	public void setConnectRecordId(String connectRecordId) {
		this.connectRecordId = connectRecordId;
	}

	public String getEngTypeCodeName() {
		return engTypeCodeName;
	}

	public void setEngTypeCodeName(String engTypeCodeName) {
		this.engTypeCodeName = engTypeCodeName;
	}

}