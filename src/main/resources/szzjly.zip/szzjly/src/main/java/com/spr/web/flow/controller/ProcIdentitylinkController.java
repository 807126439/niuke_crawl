package com.spr.web.flow.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spr.core.common.bean.AjaxJson;
import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.controller.BaseController;
import com.spr.web.flow.dto.def.ProcIdentitylinkDTO;
import com.spr.web.flow.service.IProcIdentitylinkService;
import com.spr.web.system.dto.user.WeiUserDTO;

@Controller
@Scope("prototype")
@RequestMapping("/procIdentitylinkController")
public class ProcIdentitylinkController extends BaseController {

	private static final long serialVersionUID = 1L;

	@Resource
	private IProcIdentitylinkService procIdentitylinkService;

	/**
	 * 通过流程码查询流程开始节点下一节点的默认负责人
	 * 
	 * @param processCode
	 * @return
	 */
	@RequestMapping(value = "/getNodeAfterStartUsers")
	@ResponseBody
	public AjaxJson getNodeAfterStartUsers(String processCode) {

		List<WeiUserDTO> users = this.procIdentitylinkService.getNodeAfterStartUser(processCode);

		return new AjaxJson("success", AjaxJson.success, users);
	}

	/**
	 * 通过节点id查找负责人
	 * 
	 * @param nodeId
	 * @return
	 */
	@RequestMapping(value = "/getUsersByNodeId")
	@ResponseBody
	public AjaxJson getUsersByNodeId(String procNodeId) {

		List<WeiUserDTO> users = this.procIdentitylinkService.getUsersByNodeId(procNodeId);
		return new AjaxJson("success", AjaxJson.success, users);
	}

	@RequestMapping(value = "/viewPage", method = { RequestMethod.GET })
	public String viewPage(HttpServletRequest request) {
		this.wrapMenuTitle(request);

		return "flow/procIdentitylink/procIdentitylinkList.jsp";
	}

	@RequestMapping(value = "/getPageData", method = { RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> loadPageData(HttpServletRequest request, DataQuery dq) {

		this.wrapTableQueryParams(request, dq);

		Page<ProcIdentitylinkDTO> pageResult = this.procIdentitylinkService.searchByPage(dq);

		return this.handlePageReult(pageResult);
	}

	@RequestMapping(value = "/skipAddProcIdentitylink")
	public String skipAddProcIdentitylink(HttpServletRequest request) {

		return "flow/procIdentitylink/addProcIdentitylink.jsp";
	}

	@RequestMapping(value = "/addProcIdentitylink", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson addProcIdentitylink(ProcIdentitylinkDTO dto) throws Exception {

		this.procIdentitylinkService.addProcIdentitylink(dto);

		return new AjaxJson(this.ADD_SUCCESS_MESSAGE, AjaxJson.success);
	}

	@RequestMapping("/getDetail")
	public String loadDetail(HttpServletRequest request, @RequestParam(value = "id", required = true) String id) {

		ProcIdentitylinkDTO result = this.procIdentitylinkService.getDetailById(id);
		request.setAttribute("model", result);

		return "flow/procIdentitylink/editProcIdentitylink.jsp";
	}

	@RequestMapping(value = "/editProcIdentitylink", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson updateProcIdentitylink(ProcIdentitylinkDTO dto) {

		this.procIdentitylinkService.updateProcIdentitylink(dto);

		return new AjaxJson(this.EDIT_SUCCESS_MESSAGE, AjaxJson.success);
	}

	@RequestMapping(value = "/deleteProcIdentitylink", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson deleteProcIdentitylink(String[] ids) {

		this.procIdentitylinkService.deleteProcIdentitylinks(ids);

		return new AjaxJson(this.DEL_SUCCESS_MESSAGE, AjaxJson.success);
	}

}
