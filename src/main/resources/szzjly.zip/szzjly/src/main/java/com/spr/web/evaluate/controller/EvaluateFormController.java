package com.spr.web.evaluate.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spr.core.common.bean.AjaxJson;
import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.controller.BaseController;
import com.spr.core.common.dto.ZtreeDTO;
import com.spr.web.evaluate.dto.form.EvaluateFormDTO;
import com.spr.web.evaluate.dto.form.EvaluateFormIndexDTO;
import com.spr.web.evaluate.dto.record.EvaluateRecordDTO;
import com.spr.web.evaluate.service.IEvaluateFormService;
import com.spr.web.system.dto.engineering.EngineeringTypeDTO;
import com.spr.web.system.service.IEngineeringTypeService;

@Controller
@Scope("prototype")
@RequestMapping("/evaluateFormController")
public class EvaluateFormController extends BaseController {

	private static final long serialVersionUID = 1L;

	@Resource
	private IEvaluateFormService evaluateFormService;
	@Resource
	private IEngineeringTypeService engineeringTypeService;

	@RequestMapping(value = "/viewPage", method = { RequestMethod.GET })
	public String viewPage(HttpServletRequest request) {
		this.wrapMenuTitle(request);
		return "evaluate/evaluateForm/evaluateFormList.jsp";
	}

	@RequestMapping(value = "/getPageData", method = { RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> loadPageData(HttpServletRequest request, DataQuery dq, String formName) {
		this.wrapTableQueryParams(request, dq);

		dq.putToMap("likeFormName", StringUtils.isBlank(formName) ? null : "%" + formName + "%");
		Page<EvaluateFormDTO> pageResult = this.evaluateFormService.searchByPage(dq);
		return this.handlePageReult(pageResult);
	}

	@RequestMapping(value = "/skipAddEvaluateForm")
	public String skipAddEvaluateForm(HttpServletRequest request, DataQuery dq) {
		dq.clear();
		dq.setNotQueryPage();
		dq.setSidx("sortNo");
		dq.setSord("asc");
		List<EngineeringTypeDTO> engTypeList = this.engineeringTypeService.selectListByCondition(dq);
		request.setAttribute("engTypeList", engTypeList);

		request.setAttribute("formtTypeMap", EvaluateFormDTO.FORMTYPE_MAP);
		return "evaluate/evaluateForm/addEvaluateForm.jsp";
	}

	@RequestMapping(value = "/addEvaluateForm", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson addEvaluateForm(EvaluateFormDTO dto, EvaluateFormIndexDTO index) throws Exception {
		this.evaluateFormService.addEvaluateForm(dto, index);
		return new AjaxJson(this.ADD_SUCCESS_MESSAGE, AjaxJson.success);
	}

	@RequestMapping("/getDetail")
	public String loadDetail(HttpServletRequest request, DataQuery dq, @RequestParam(value = "id", required = true) String id) {
		EvaluateFormDTO result = this.evaluateFormService.getDetailById(id);
		request.setAttribute("model", result);

		dq.clear();
		dq.setNotQueryPage();
		dq.setSidx("sortNo");
		dq.setSord("asc");
		List<EngineeringTypeDTO> engTypeList = this.engineeringTypeService.selectListByCondition(dq);
		request.setAttribute("engTypeList", engTypeList);

		request.setAttribute("formtTypeMap", EvaluateFormDTO.FORMTYPE_MAP);
		return "evaluate/evaluateForm/editEvaluateForm.jsp";
	}

	@RequestMapping(value = "/editEvaluateForm", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson updateEvaluateForm(EvaluateFormDTO dto, EvaluateFormIndexDTO index) {
		this.evaluateFormService.updateEvaluateForm(dto, index);
		return new AjaxJson(this.EDIT_SUCCESS_MESSAGE, AjaxJson.success);
	}

	@RequestMapping(value = "/deleteEvaluateForm", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson deleteEvaluateForm(String[] ids) {
		this.evaluateFormService.deleteEvaluateForms(ids);// TODO
		return new AjaxJson(this.DEL_SUCCESS_MESSAGE, AjaxJson.success);
	}

	// 查看模板
	@RequestMapping(value = "/skipViewEvaluateForm")
	public String skipViewEvaluateForm(HttpServletRequest request, @RequestParam String id) {
		EvaluateFormDTO dto = this.evaluateFormService.getDetailById(id);
		request.setAttribute("model", dto);

		request.setAttribute("evalGradeText", EvaluateRecordDTO.EVAL_GRADE_TEXT);
		return "evaluate/evaluateForm/viewEvaluateForm.jsp";
	}

	/**
	 * 跳转选择评分标准
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/skipEvaluateFormTree", method = { RequestMethod.GET })
	public String skipEvaluateFormTree(HttpServletRequest request, @RequestParam(value = "engTypeCode", required = true) String engTypeCode) {

		request.setAttribute("engTypeCode", engTypeCode);
		return "evaluate/evaluateForm/selectEvaluateForm.jsp";
	}

	/**
	 * 获取单位数据
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/getEvaluateFormTreeData", method = { RequestMethod.POST })
	@ResponseBody
	public List<ZtreeDTO> getEvaluateFormTreeData(HttpServletRequest request, String engTypeCode) {
		return this.evaluateFormService.getEvaluateFormTreeData(engTypeCode);
	}

	// @RequestMapping(value = "/publish", method = { RequestMethod.POST })
	// @ResponseBody
	// public AjaxJson publishEvaluateForm(@RequestParam String id) {
	// this.evaluateFormService.publishEvaluateForm(id);
	// return new AjaxJson("发布成功", AjaxJson.success);
	// }

	// @RequestMapping(value = "/enable", method = { RequestMethod.POST })
	// @ResponseBody
	// public AjaxJson enableEvaluateForm(@RequestParam String id, @RequestParam
	// String engTypeCode) {
	// this.evaluateFormService.enableEvaluateForm(id, engTypeCode);
	// return new AjaxJson("启用成功", AjaxJson.success);
	// }

}
