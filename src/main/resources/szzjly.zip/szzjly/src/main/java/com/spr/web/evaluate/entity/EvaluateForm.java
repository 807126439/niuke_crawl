package com.spr.web.evaluate.entity;

import java.io.Serializable;

import com.spr.core.annotations.DbField;
import com.spr.core.common.entity.UUIDEntity;

public class EvaluateForm extends UUIDEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer sortNo;

    private String formName;

    private String engTypeCode;

    private String formType;

    private String memo;

    private Short status;

    private Short flag;

    private String createBy;

    private String updateBy;

    @DbField(name="sort_no")
    public Integer getSortNo() {
        return sortNo;
    }

    public void setSortNo(Integer sortNo) {
        this.sortNo = sortNo;
    }

    @DbField(name="form_name")
    public String getFormName() {
        return formName;
    }

    public void setFormName(String formName) {
        this.formName = formName == null ? null : formName.trim();
    }

    @DbField(name="eng_type_code")
	public String getEngTypeCode() {
		return engTypeCode;
	}

    public void setEngTypeCode(String engTypeCode) {
		this.engTypeCode = engTypeCode == null ? null : engTypeCode.trim();
	}

	@DbField(name="form_type")
    public String getFormType() {
        return formType;
    }

    public void setFormType(String formType) {
        this.formType = formType == null ? null : formType.trim();
    }

    @DbField(name="memo")
    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo == null ? null : memo.trim();
    }

    @DbField(name="status")
    public Short getStatus() {
        return status;
    }

    public void setStatus(Short status) {
        this.status = status;
    }

    @DbField(name="flag")
    public Short getFlag() {
        return flag;
    }

    public void setFlag(Short flag) {
        this.flag = flag;
    }

    @DbField(name="create_by")
    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    @DbField(name="update_by")
    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(",Super = ").append(super.toString());
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append(", sortNo=").append(sortNo);
        sb.append(", formName=").append(formName);
        sb.append(", formType=").append(formType);
        sb.append(", memo=").append(memo);
        sb.append(", status=").append(status);
        sb.append(", flag=").append(flag);
        sb.append(", createBy=").append(createBy);
        sb.append(", updateBy=").append(updateBy);
        sb.append("]");
        return sb.toString();
    }
}