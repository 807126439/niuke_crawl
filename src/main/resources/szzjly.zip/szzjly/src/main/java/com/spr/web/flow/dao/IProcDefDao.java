package com.spr.web.flow.dao;

import java.util.List;
import java.util.Map;

import com.spr.core.common.dao.IBaseDao;
import com.spr.web.flow.dto.def.ProcDefDTO;
import com.spr.web.flow.entity.ProcDef;

public interface IProcDefDao extends IBaseDao<String, ProcDef> {

	Long countByCondition(Map<String, Object> queryMap);

	List<ProcDefDTO> selectListByCondition(Map<String, Object> queryMap);

	ProcDefDTO getDetailById(String id);

	List<ProcDef> getByProcDefId(String procDefId);

	ProcDef getByProcessCode(String processCode);

	List<String> getProcDefCode(Map<String, Object> queryMap);

	ProcDefDTO getDetailByParam(Map<String, Object> queryMap);

}