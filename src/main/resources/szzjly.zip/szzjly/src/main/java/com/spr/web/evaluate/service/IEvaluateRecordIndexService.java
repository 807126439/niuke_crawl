package com.spr.web.evaluate.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.web.evaluate.dto.record.EvaluateRecordDTO;
import com.spr.web.evaluate.dto.record.EvaluateRecordIndexDTO;
import com.spr.web.evaluate.dto.record.EvaluateRecordInputDTO;

public interface IEvaluateRecordIndexService {
	/**
	 * originalId - Model 映射
	 * 
	 * @param dq
	 * @return
	 * @date 2019-2-27
	 * @author wanve_java_cjy
	 */
	 Map<String, EvaluateRecordIndexDTO> selectOriginModelMapByCondition(DataQuery dq);

	 EvaluateRecordIndexDTO selectOneByCondition(DataQuery dq);
	 
	 List<EvaluateRecordIndexDTO> selectListByCondition(DataQuery dq);

	 Page<EvaluateRecordIndexDTO> searchByPage(DataQuery dq);
	
	 EvaluateRecordIndexDTO getDetailById(String id);
	
	 String addEvaluateRecordIndex(EvaluateRecordIndexDTO dto);
	
	 void updateEvaluateRecordIndex(EvaluateRecordIndexDTO dto);
	
	 void deleteEvaluateRecordIndexs(String[] ids);

	 List<EvaluateRecordIndexDTO> getSubIndexList(DataQuery dq, String parentId);

	 List<EvaluateRecordIndexDTO> getSubIndexList(DataQuery dq, String parentId, Map<String, BigDecimal> indexInputMap);
	 
	 List<EvaluateRecordIndexDTO> getSubIndexListWithModified(DataQuery dq, String parentId, Map<String, EvaluateRecordInputDTO> indexInputMap);
	 
	 Map<String, EvaluateRecordIndexDTO> copyIndex(EvaluateRecordDTO dto);
}
