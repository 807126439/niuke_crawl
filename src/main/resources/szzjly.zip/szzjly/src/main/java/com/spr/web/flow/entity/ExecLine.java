package com.spr.web.flow.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import com.spr.core.annotations.DbField;
import com.spr.core.common.entity.UUIDEntity;

public class ExecLine extends UUIDEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final short DEF_STATUS = 1;

	private String procDefId;

	private String tlLineId;

	private String procInstId;

	private String lineName;

	private String lineType;

	private String lineCode;

	private Byte lineAlt;

	private BigDecimal midPos;

	private String preNodeId;

	private String nextNodeId;

	private Short status;

	private String createBy;

	private String updateBy;

	@DbField(name = "proc_def_id")
	public String getProcDefId() {
		return procDefId;
	}

	public void setProcDefId(String procDefId) {
		this.procDefId = procDefId == null ? null : procDefId.trim();
	}

	@DbField(name = "tl_line_id")
	public String getTlLineId() {
		return tlLineId;
	}

	public void setTlLineId(String tlLineId) {
		this.tlLineId = tlLineId == null ? null : tlLineId.trim();
	}

	@DbField(name = "proc_inst_id")
	public String getProcInstId() {
		return procInstId;
	}

	public void setProcInstId(String procInstId) {
		this.procInstId = procInstId == null ? null : procInstId.trim();
	}

	@DbField(name = "line_name")
	public String getLineName() {
		return lineName;
	}

	public void setLineName(String lineName) {
		this.lineName = lineName == null ? null : lineName.trim();
	}

	@DbField(name = "line_type")
	public String getLineType() {
		return lineType;
	}

	public void setLineType(String lineType) {
		this.lineType = lineType == null ? null : lineType.trim();
	}

	@DbField(name = "line_code")
	public String getLineCode() {
		return lineCode;
	}

	public void setLineCode(String lineCode) {
		this.lineCode = lineCode == null ? null : lineCode.trim();
	}

	@DbField(name = "line_alt")
	public Byte getLineAlt() {
		return lineAlt;
	}

	public void setLineAlt(Byte lineAlt) {
		this.lineAlt = lineAlt;
	}

	@DbField(name = "mid_pos")
	public BigDecimal getMidPos() {
		return midPos;
	}

	public void setMidPos(BigDecimal midPos) {
		this.midPos = midPos;
	}

	@DbField(name = "pre_node_id")
	public String getPreNodeId() {
		return preNodeId;
	}

	public void setPreNodeId(String preNodeId) {
		this.preNodeId = preNodeId == null ? null : preNodeId.trim();
	}

	@DbField(name = "next_node_id")
	public String getNextNodeId() {
		return nextNodeId;
	}

	public void setNextNodeId(String nextNodeId) {
		this.nextNodeId = nextNodeId == null ? null : nextNodeId.trim();
	}

	@DbField(name = "status")
	public Short getStatus() {
		return status;
	}

	public void setStatus(Short status) {
		this.status = status;
	}

	@DbField(name = "create_by")
	public String getCreateBy() {
		return createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy == null ? null : createBy.trim();
	}

	@DbField(name = "update_by")
	public String getUpdateBy() {
		return updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy == null ? null : updateBy.trim();
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode());
		sb.append(",Super = ").append(super.toString());
		sb.append(", serialVersionUID=").append(serialVersionUID);
		sb.append(", procDefId=").append(procDefId);
		sb.append(", tlLineId=").append(tlLineId);
		sb.append(", procInstId=").append(procInstId);
		sb.append(", lineName=").append(lineName);
		sb.append(", lineType=").append(lineType);
		sb.append(", lineCode=").append(lineCode);
		sb.append(", lineAlt=").append(lineAlt);
		sb.append(", midPos=").append(midPos);
		sb.append(", preNodeId=").append(preNodeId);
		sb.append(", nextNodeId=").append(nextNodeId);
		sb.append(", status=").append(status);
		sb.append(", createBy=").append(createBy);
		sb.append(", updateBy=").append(updateBy);
		sb.append("]");
		return sb.toString();
	}
}