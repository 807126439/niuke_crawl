/**
 * 
 */
package com.spr.web.evaluate.controller;

import java.util.Date;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.controller.BaseController;
import com.spr.web.evaluate.dto.record.EvaluateRecordDTO;
import com.spr.web.evaluate.service.IEvaluateRecordService;

/**
 * @date 2019-3-14
 * @author wanve_java_cjy
 *
 */
@Controller
@Scope("prototype")
@RequestMapping("/evaluateStatisticsController")
public class EvaluateStatisticsController extends BaseController {

	@Resource
	private IEvaluateRecordService evaluateRecordService;

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@RequestMapping(value = "/viewPage", method = { RequestMethod.GET })
	public String viewPage(HttpServletRequest request) {
		this.wrapMenuTitle(request);
		return "evaluate/evaluateRecord/statistic/evaluateAvgScoreList.jsp";
	}

	@RequestMapping(value = "/getPageData", method = { RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> loadPageData(HttpServletRequest request, 
											DataQuery dq, 
											Date gmtEvalStart, 
											Date gmtEvalEnd, 
											String targetUnitName) {
		this.wrapTableQueryParams(request, dq);
		
		dq.putToMap("sidx", dq.getSidx());
		dq.putToMap("sord", dq.getSord());
		dq.putToMap("likeUnitName", StringUtils.isBlank(targetUnitName) ? null : "%" + targetUnitName + "%");
		dq.putToMap("gmtEvalStart", gmtEvalStart == null ? null : gmtEvalStart);
		dq.putToMap("gmtEvalEnd", gmtEvalEnd == null ? null : gmtEvalEnd);
		Page<EvaluateRecordDTO> pageResult = this.evaluateRecordService.avgScoreByPage(dq);
		return this.handlePageReult(pageResult);
	}
}
