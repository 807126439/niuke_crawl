package com.spr.web.flow.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.service.BaseService;
import com.spr.core.common.utils.Assert;
import com.spr.web.flow.dao.IProcLineDao;
import com.spr.web.flow.dto.def.ProcLineDTO;
import com.spr.web.flow.entity.ProcLine;
import com.spr.web.flow.service.IProcLineService;

@Service("procLineService")
@Transactional
public class ProcLineServiceImpl extends BaseService implements IProcLineService {

	@Resource
	private IProcLineDao procLineDao;

	/**
	 * 分页查询
	 * 
	 * @param dq
	 */
	@Override
	public Page<ProcLineDTO> searchByPage(DataQuery dq) {

		Long recTotal = this.procLineDao.countByCondition(dq.assemblePageOffset().getQueryMap());
		dq.assembleOrderInfo(ProcLine.class, null);
		List<ProcLineDTO> resultlist = this.procLineDao.selectListByCondition(dq.getQueryMap());

		return new Page<ProcLineDTO>(dq.getCurrentPage(), dq.getPageSize(), resultlist, recTotal);
	}

	/**
	 * 查询详细
	 * 
	 * @param id
	 */
	@Override
	public ProcLineDTO getDetailById(String id) {
		Assert.hasText(id, Assert.NULL_PARAM_STR("id"));

		ProcLineDTO result = this.procLineDao.getDetailById(id);
		Assert.notNull(result, Assert.EMPTY_REOCRD_STR);

		return result;
	}

	/**
	 * 添加
	 * 
	 * @param dto
	 */
	@Override
	public void addProcLine(ProcLineDTO dto) {

		ProcLine model = new ProcLine();
		model.setProcDefId(dto.getProcDefId());
		model.setLineName(dto.getLineName());
		model.setLineType(dto.getLineType());
		model.setLineCode(dto.getLineCode());
		model.setLineAlt(dto.getLineAlt());
		model.setMidPos(dto.getMidPos());
		model.setPreNodeId(dto.getPreNodeId());
		model.setNextNodeId(dto.getNextNodeId());
		model.setStatus(dto.getStatus());
		model.setCreateBy(dto.getCreateBy());
		model.setUpdateBy(dto.getUpdateBy());
		model.setGmtCreate(dto.getGmtCreate());
		model.setGmtModified(dto.getGmtModified());

		this.procLineDao.insert(model);

		if (this.logger.isInfoEnabled()) {
			this.logger.info("Add: " + model.toString());
		}
	}

	/**
	 * 修改
	 * 
	 * @param dto
	 */
	@Override
	public void updateProcLine(ProcLineDTO dto) {
		Assert.hasText(dto.getId(), Assert.NULL_PARAM_STR("id"));

		ProcLine model = this.procLineDao.getById(dto.getId());
		Assert.notNull(model, Assert.EMPTY_REOCRD_STR);

		model.setProcDefId(dto.getProcDefId());
		model.setLineName(dto.getLineName());
		model.setLineType(dto.getLineType());
		model.setLineCode(dto.getLineCode());
		model.setLineAlt(dto.getLineAlt());
		model.setMidPos(dto.getMidPos());
		model.setPreNodeId(dto.getPreNodeId());
		model.setNextNodeId(dto.getNextNodeId());
		model.setStatus(dto.getStatus());
		model.setCreateBy(dto.getCreateBy());
		model.setUpdateBy(dto.getUpdateBy());
		model.setGmtCreate(dto.getGmtCreate());
		model.setGmtModified(dto.getGmtModified());

		this.procLineDao.update(model);

		if (this.logger.isInfoEnabled()) {
			this.logger.info("Update: " + model.toString());
		}
	}

	/**
	 * 删除
	 * 
	 * @param ids
	 */
	@Override
	public void deleteProcLines(String[] ids) {
		for (int i = 0; i < ids.length; i++) {
			this.procLineDao.deleteById(ids[i]);

			if (this.logger.isInfoEnabled()) {
				this.logger.info("Delete：:" + ids[i]);
			}
		}
	}

}
