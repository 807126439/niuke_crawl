package com.spr.web.flow.dto.exec;

import com.spr.core.common.dto.UUIDDTO;
import java.math.BigDecimal;

public class ExecLineDTO extends UUIDDTO {

    private String procDefId;

    private String tlLineId;

    private String procInstId;

    private String lineName;

    private String lineType;

    private String lineCode;

    private Byte lineAlt;

    private BigDecimal midPos;

    private String preNodeId;

    private String nextNodeId;

    private Short status;

    private String createBy;

    private String updateBy;

    public String getProcDefId() {
        return procDefId;
    }

    public void setProcDefId(String procDefId) {
        this.procDefId = procDefId == null ? null : procDefId.trim();
    }

    public String getTlLineId() {
        return tlLineId;
    }

    public void setTlLineId(String tlLineId) {
        this.tlLineId = tlLineId == null ? null : tlLineId.trim();
    }

    public String getProcInstId() {
        return procInstId;
    }

    public void setProcInstId(String procInstId) {
        this.procInstId = procInstId == null ? null : procInstId.trim();
    }

    public String getLineName() {
        return lineName;
    }

    public void setLineName(String lineName) {
        this.lineName = lineName == null ? null : lineName.trim();
    }

    public String getLineType() {
        return lineType;
    }

    public void setLineType(String lineType) {
        this.lineType = lineType == null ? null : lineType.trim();
    }

    public String getLineCode() {
        return lineCode;
    }

    public void setLineCode(String lineCode) {
        this.lineCode = lineCode == null ? null : lineCode.trim();
    }

    public Byte getLineAlt() {
        return lineAlt;
    }

    public void setLineAlt(Byte lineAlt) {
        this.lineAlt = lineAlt;
    }

    public BigDecimal getMidPos() {
        return midPos;
    }

    public void setMidPos(BigDecimal midPos) {
        this.midPos = midPos;
    }

    public String getPreNodeId() {
        return preNodeId;
    }

    public void setPreNodeId(String preNodeId) {
        this.preNodeId = preNodeId == null ? null : preNodeId.trim();
    }

    public String getNextNodeId() {
        return nextNodeId;
    }

    public void setNextNodeId(String nextNodeId) {
        this.nextNodeId = nextNodeId == null ? null : nextNodeId.trim();
    }

    public Short getStatus() {
        return status;
    }

    public void setStatus(Short status) {
        this.status = status;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }
}