package com.spr.web.flow.service;

import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.dto.DownLoadDTO;
import com.spr.web.flow.dto.exec.ExecAttachmentDTO;

public interface IExecAttachmentService {

	Page<ExecAttachmentDTO> searchByPage(DataQuery dq);

	ExecAttachmentDTO getDetailById(String id);

	void addExecAttachment(String procNodeId, Short attachmentType, CommonsMultipartFile uploadFile);

	void updateExecAttachment(ExecAttachmentDTO dto);

	void deleteExecAttachments(String[] ids);

	DownLoadDTO getDownLoadInfo(String id);

}
