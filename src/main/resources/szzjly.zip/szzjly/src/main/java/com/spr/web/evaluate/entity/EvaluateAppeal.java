package com.spr.web.evaluate.entity;

import com.spr.core.annotations.DbField;
import com.spr.core.common.entity.UUIDEntity;
import java.io.Serializable;

public class EvaluateAppeal extends UUIDEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    private String evaluateRecordId;

    private String content;

    private String replyUserId;

    private String replyUnitId;

    private String targetUnitId;

    private Short status;

    private Short flag;

    private String createBy;

    private String updateBy;

    @DbField(name="evaluate_record_id")
    public String getEvaluateRecordId() {
        return evaluateRecordId;
    }

    public void setEvaluateRecordId(String evaluateRecordId) {
        this.evaluateRecordId = evaluateRecordId == null ? null : evaluateRecordId.trim();
    }

    @DbField(name="content")
    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content == null ? null : content.trim();
    }

    @DbField(name="reply_user_id")
    public String getReplyUserId() {
        return replyUserId;
    }

    public void setReplyUserId(String replyUserId) {
        this.replyUserId = replyUserId == null ? null : replyUserId.trim();
    }

    @DbField(name="reply_unit_id")
    public String getReplyUnitId() {
        return replyUnitId;
    }

    public void setReplyUnitId(String replyUnitId) {
        this.replyUnitId = replyUnitId == null ? null : replyUnitId.trim();
    }

    @DbField(name="target_unit_id")
    public String getTargetUnitId() {
        return targetUnitId;
    }

    public void setTargetUnitId(String targetUnitId) {
        this.targetUnitId = targetUnitId == null ? null : targetUnitId.trim();
    }

    @DbField(name="status")
    public Short getStatus() {
        return status;
    }

    public void setStatus(Short status) {
        this.status = status;
    }

    @DbField(name="flag")
    public Short getFlag() {
        return flag;
    }

    public void setFlag(Short flag) {
        this.flag = flag;
    }

    @DbField(name="create_by")
    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    @DbField(name="update_by")
    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(",Super = ").append(super.toString());
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append(", evaluateRecordId=").append(evaluateRecordId);
        sb.append(", content=").append(content);
        sb.append(", replyUserId=").append(replyUserId);
        sb.append(", replyUnitId=").append(replyUnitId);
        sb.append(", targetUnitId=").append(targetUnitId);
        sb.append(", status=").append(status);
        sb.append(", flag=").append(flag);
        sb.append(", createBy=").append(createBy);
        sb.append(", updateBy=").append(updateBy);
        sb.append("]");
        return sb.toString();
    }
}