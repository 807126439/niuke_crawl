package com.spr.web.evaluate.service.impl;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spr.core.common.service.BaseService;
import com.spr.core.utils.DateUtil;
import com.spr.web.evaluate.dto.time.EvaluateTimeDTO;
import com.spr.web.evaluate.service.IEvaluateTimeSettingService;

@Service("evaluateTimeSettingService")
@Transactional
public class EvaluateTimeSettingServiceImpl extends BaseService implements IEvaluateTimeSettingService {

	private final static Logger logger = LoggerFactory.getLogger(EvaluateTimeSettingServiceImpl.class);

	private static final String FILE_NAME = "evaluateTimeConfig.properties";

	private static Properties properties;

	private static String FIRST_SEASON_EVALUATE_START_TIME = "FIRST_SEASON_EVALUATE_START_TIME";
	private static String FIRST_SEASON_EVALUATE_END_TIME = "FIRST_SEASON_EVALUATE_END_TIME";
	private static String SECOND_SEASON_EVALUATE_START_TIME = "SECOND_SEASON_EVALUATE_START_TIME";
	private static String SECOND_SEASON_EVALUATE_END_TIME = "SECOND_SEASON_EVALUATE_END_TIME";
	private static String THIRD_SEASON_EVALUATE_START_TIME = "THIRD_SEASON_EVALUATE_START_TIME";
	private static String THIRD_SEASON_EVALUATE_END_TIME = "THIRD_SEASON_EVALUATE_END_TIME";
	private static String FOURTH_SEASON_EVALUATE_START_TIME = "FOURTH_SEASON_EVALUATE_START_TIME";
	private static String FOURTH_SEASON_EVALUATE_END_TIME = "FOURTH_SEASON_EVALUATE_END_TIME";

	static {
		loadPropertiesFromSrc();
	}

	@Override
	public Boolean isTodayBetweenEvaluateTime() {

		Boolean flag = false;
		Date today = new Date();
		EvaluateTimeDTO evaluateTimeDTO = this.getEvaluateTime();

		// 判断当前时间是否处于第一季度评价时间中
		if (evaluateTimeDTO.getFirstSeasonEvaluateStartTime() != null && evaluateTimeDTO.getFirstSeasonEvaluateEndTime() != null) {
			if ((today.getTime() >= evaluateTimeDTO.getFirstSeasonEvaluateStartTime().getTime())
					&& (today.getTime() <= evaluateTimeDTO.getFirstSeasonEvaluateEndTime().getTime())) {
				flag = true;
			}
		}

		if (flag == false) {
			// 判断当前时间是否处于第二季度评价时间中
			if (evaluateTimeDTO.getSecondSeasonEvaluateStartTime() != null && evaluateTimeDTO.getSecondSeasonEvaluateEndTime() != null) {
				if ((today.getTime() >= evaluateTimeDTO.getSecondSeasonEvaluateStartTime().getTime())
						&& (today.getTime() <= evaluateTimeDTO.getSecondSeasonEvaluateEndTime().getTime())) {
					flag = true;
				}
			}
		}

		if (flag == false) {
			// 判断当前时间是否处于第三季度评价时间中
			if (evaluateTimeDTO.getThirdSeasonEvaluateStartTime() != null && evaluateTimeDTO.getThirdSeasonEvaluateEndTime() != null) {
				if ((today.getTime() >= evaluateTimeDTO.getThirdSeasonEvaluateStartTime().getTime())
						&& (today.getTime() <= evaluateTimeDTO.getThirdSeasonEvaluateEndTime().getTime())) {
					flag = true;
				}
			}
		}

		if (flag == false) {
			// 判断当前时间是否处于第四季度评价时间中
			if (evaluateTimeDTO.getFourthSeasonEvaluateStartTime() != null && evaluateTimeDTO.getFourthSeasonEvaluateEndTime() != null) {
				if ((today.getTime() >= evaluateTimeDTO.getFourthSeasonEvaluateStartTime().getTime())
						&& (today.getTime() <= evaluateTimeDTO.getFourthSeasonEvaluateEndTime().getTime())) {
					flag = true;
				}
			}
		}
		return flag;
	}

	@Override
	public EvaluateTimeDTO getEvaluateTime() {
		EvaluateTimeDTO result = new EvaluateTimeDTO();

		String firstSeasonEvaluateStartTime = properties.getProperty(FIRST_SEASON_EVALUATE_START_TIME);
		if (StringUtils.isNotBlank(firstSeasonEvaluateStartTime)) {
			result.setFirstSeasonEvaluateStartTime(DateUtil.strToDate(firstSeasonEvaluateStartTime));
		}

		String firstSeasonEvaluateEndTime = properties.getProperty(FIRST_SEASON_EVALUATE_END_TIME);
		if (StringUtils.isNotBlank(firstSeasonEvaluateEndTime)) {
			result.setFirstSeasonEvaluateEndTime(DateUtil.strToDate(firstSeasonEvaluateEndTime));
		}

		String secondSeasonEvaluateStartTime = properties.getProperty(SECOND_SEASON_EVALUATE_START_TIME);
		if (StringUtils.isNotBlank(secondSeasonEvaluateStartTime)) {
			result.setSecondSeasonEvaluateStartTime(DateUtil.strToDate(secondSeasonEvaluateStartTime));
		}

		String secondSeasonEvaluateEndTime = properties.getProperty(SECOND_SEASON_EVALUATE_END_TIME);
		if (StringUtils.isNotBlank(secondSeasonEvaluateEndTime)) {
			result.setSecondSeasonEvaluateEndTime(DateUtil.strToDate(secondSeasonEvaluateEndTime));
		}

		String thirdSeasonEvaluateStartTime = properties.getProperty(THIRD_SEASON_EVALUATE_START_TIME);
		if (StringUtils.isNotBlank(thirdSeasonEvaluateStartTime)) {
			result.setThirdSeasonEvaluateStartTime(DateUtil.strToDate(thirdSeasonEvaluateStartTime));
		}

		String thirdSeasonEvaluateEndTime = properties.getProperty(THIRD_SEASON_EVALUATE_END_TIME);
		if (StringUtils.isNotBlank(thirdSeasonEvaluateEndTime)) {
			result.setThirdSeasonEvaluateEndTime(DateUtil.strToDate(thirdSeasonEvaluateEndTime));
		}

		String fourthSeasonEvaluateStartTime = properties.getProperty(FOURTH_SEASON_EVALUATE_START_TIME);
		if (StringUtils.isNotBlank(fourthSeasonEvaluateStartTime)) {
			result.setFourthSeasonEvaluateStartTime(DateUtil.strToDate(fourthSeasonEvaluateStartTime));
		}

		String fourthSeasonEvaluateEndTime = properties.getProperty(FOURTH_SEASON_EVALUATE_END_TIME);
		if (StringUtils.isNotBlank(fourthSeasonEvaluateEndTime)) {
			result.setFourthSeasonEvaluateEndTime(DateUtil.strToDate(fourthSeasonEvaluateEndTime));
		}

		return result;
	}

	@Override
	public void setEvaluateTime(EvaluateTimeDTO dto) {

		String filePath = EvaluateTimeSettingServiceImpl.class.getClassLoader().getResource(FILE_NAME).getFile();
		OutputStream fos = null;
		try {
			fos = new FileOutputStream(filePath);

			String firstSeasonEvaluateStartTime = "";
			if (dto.getFirstSeasonEvaluateStartTime() != null) {
				firstSeasonEvaluateStartTime = DateUtil.dateToStrByPattern(dto.getFirstSeasonEvaluateStartTime(), "yyyy-MM-dd HH:mm:ss");
			}
			properties.setProperty(FIRST_SEASON_EVALUATE_START_TIME, firstSeasonEvaluateStartTime);
			properties.store(fos, "Update " + FIRST_SEASON_EVALUATE_START_TIME + " name");

			String firstSeasonEvaluateEndTime = "";
			if (dto.getFirstSeasonEvaluateEndTime() != null) {
				firstSeasonEvaluateEndTime = DateUtil.dateToStrByPattern(dto.getFirstSeasonEvaluateEndTime(), "yyyy-MM-dd HH:mm:ss");
			}
			properties.setProperty(FIRST_SEASON_EVALUATE_END_TIME, firstSeasonEvaluateEndTime);
			properties.store(fos, "Update " + FIRST_SEASON_EVALUATE_END_TIME + " name");

			String secondSeasonEvaluateStartTime = "";
			if (dto.getSecondSeasonEvaluateStartTime() != null) {
				secondSeasonEvaluateStartTime = DateUtil.dateToStrByPattern(dto.getSecondSeasonEvaluateStartTime(), "yyyy-MM-dd HH:mm:ss");
			}
			properties.setProperty(SECOND_SEASON_EVALUATE_START_TIME, secondSeasonEvaluateStartTime);
			properties.store(fos, "Update " + SECOND_SEASON_EVALUATE_START_TIME + " name");

			String secondSeasonEvaluateEndTime = "";
			if (dto.getSecondSeasonEvaluateEndTime() != null) {
				secondSeasonEvaluateEndTime = DateUtil.dateToStrByPattern(dto.getSecondSeasonEvaluateEndTime(), "yyyy-MM-dd HH:mm:ss");
			}
			properties.setProperty(secondSeasonEvaluateEndTime, secondSeasonEvaluateEndTime);
			properties.store(fos, "Update " + secondSeasonEvaluateEndTime + " name");

			String thirdSeasonEvaluateStartTime = "";
			if (dto.getThirdSeasonEvaluateStartTime() != null) {
				thirdSeasonEvaluateStartTime = DateUtil.dateToStrByPattern(dto.getThirdSeasonEvaluateStartTime(), "yyyy-MM-dd HH:mm:ss");
			}
			properties.setProperty(THIRD_SEASON_EVALUATE_START_TIME, thirdSeasonEvaluateStartTime);
			properties.store(fos, "Update " + THIRD_SEASON_EVALUATE_START_TIME + " name");

			String thirdSeasonEvaluateEndTime = "";
			if (dto.getThirdSeasonEvaluateEndTime() != null) {
				thirdSeasonEvaluateEndTime = DateUtil.dateToStrByPattern(dto.getThirdSeasonEvaluateEndTime(), "yyyy-MM-dd HH:mm:ss");
			}
			properties.setProperty(THIRD_SEASON_EVALUATE_END_TIME, thirdSeasonEvaluateEndTime);
			properties.store(fos, "Update " + THIRD_SEASON_EVALUATE_END_TIME + " name");

			String fourthSeasonEvaluateStartTime = "";
			if (dto.getFourthSeasonEvaluateStartTime() != null) {
				fourthSeasonEvaluateStartTime = DateUtil.dateToStrByPattern(dto.getFourthSeasonEvaluateStartTime(), "yyyy-MM-dd HH:mm:ss");
			}
			properties.setProperty(FOURTH_SEASON_EVALUATE_START_TIME, fourthSeasonEvaluateStartTime);
			properties.store(fos, "Update " + FOURTH_SEASON_EVALUATE_START_TIME + " name");

			String fourthSeasonEvaluateEndTime = "";
			if (dto.getFourthSeasonEvaluateEndTime() != null) {
				fourthSeasonEvaluateEndTime = DateUtil.dateToStrByPattern(dto.getFourthSeasonEvaluateEndTime(), "yyyy-MM-dd HH:mm:ss");
			}
			properties.setProperty(FOURTH_SEASON_EVALUATE_END_TIME, fourthSeasonEvaluateEndTime);
			properties.store(fos, "Update " + FOURTH_SEASON_EVALUATE_END_TIME + " name");

			fos.close();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	private static void loadPropertiesFromSrc() {
		InputStream in = null;
		try {

			in = EvaluateTimeSettingServiceImpl.class.getClassLoader().getResourceAsStream(FILE_NAME);
			if (null != in) {
				properties = new Properties();
				try {
					properties.load(in);
				} catch (IOException e) {
					throw e;
				}
			} else {
				return;
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		} finally {
			if (null != in) {
				try {
					in.close();
				} catch (IOException e) {
					logger.error(e.getMessage(), e);
				}
			}
		}
	}

	@Override
	public Map<String, Date> getSeasonEvaluateTime() {
		Map<String, Date> resultMap = new HashMap<String, Date>();
		Boolean flag = false;
		Date today = new Date();
		EvaluateTimeDTO evaluateTimeDTO = this.getEvaluateTime();

		// 判断当前时间是否处于第一季度评价时间中
		if (evaluateTimeDTO.getFirstSeasonEvaluateStartTime() != null && evaluateTimeDTO.getFirstSeasonEvaluateEndTime() != null) {
			if ((today.getTime() >= evaluateTimeDTO.getFirstSeasonEvaluateStartTime().getTime())
					&& (today.getTime() <= evaluateTimeDTO.getFirstSeasonEvaluateEndTime().getTime())) {

				resultMap.put("beginTime", evaluateTimeDTO.getFirstSeasonEvaluateStartTime());
				resultMap.put("endTime", evaluateTimeDTO.getFirstSeasonEvaluateEndTime());
				flag = true;
			}
		}

		if (flag == false) {
			// 判断当前时间是否处于第二季度评价时间中
			if (evaluateTimeDTO.getSecondSeasonEvaluateStartTime() != null && evaluateTimeDTO.getSecondSeasonEvaluateEndTime() != null) {
				if ((today.getTime() >= evaluateTimeDTO.getSecondSeasonEvaluateStartTime().getTime())
						&& (today.getTime() <= evaluateTimeDTO.getSecondSeasonEvaluateEndTime().getTime())) {

					resultMap.put("beginTime", evaluateTimeDTO.getSecondSeasonEvaluateStartTime());
					resultMap.put("endTime", evaluateTimeDTO.getSecondSeasonEvaluateEndTime());
					flag = true;
				}
			}
		}

		if (flag == false) {
			// 判断当前时间是否处于第三季度评价时间中
			if (evaluateTimeDTO.getThirdSeasonEvaluateStartTime() != null && evaluateTimeDTO.getThirdSeasonEvaluateEndTime() != null) {
				if ((today.getTime() >= evaluateTimeDTO.getThirdSeasonEvaluateStartTime().getTime())
						&& (today.getTime() <= evaluateTimeDTO.getThirdSeasonEvaluateEndTime().getTime())) {

					resultMap.put("beginTime", evaluateTimeDTO.getThirdSeasonEvaluateStartTime());
					resultMap.put("endTime", evaluateTimeDTO.getThirdSeasonEvaluateEndTime());
					flag = true;
				}
			}
		}

		if (flag == false) {
			// 判断当前时间是否处于第四季度评价时间中
			if (evaluateTimeDTO.getFourthSeasonEvaluateStartTime() != null && evaluateTimeDTO.getFourthSeasonEvaluateEndTime() != null) {
				if ((today.getTime() >= evaluateTimeDTO.getFourthSeasonEvaluateStartTime().getTime())
						&& (today.getTime() <= evaluateTimeDTO.getFourthSeasonEvaluateEndTime().getTime())) {

					resultMap.put("beginTime", evaluateTimeDTO.getFourthSeasonEvaluateStartTime());
					resultMap.put("endTime", evaluateTimeDTO.getFourthSeasonEvaluateEndTime());
					flag = true;
				}
			}
		}

		return resultMap;
	}

}
