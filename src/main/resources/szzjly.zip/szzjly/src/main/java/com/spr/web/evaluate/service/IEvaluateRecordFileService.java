package com.spr.web.evaluate.service;

import java.util.List;

import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.dto.DownLoadDTO;
import com.spr.web.evaluate.dto.record.EvaluateRecordFileDTO;

public interface IEvaluateRecordFileService {

	 List<EvaluateRecordFileDTO> selectListByCondition(DataQuery dq);
	 
	 Page<EvaluateRecordFileDTO> searchByPage(DataQuery dq);
	
	 EvaluateRecordFileDTO getDetailById(String id);
	
	 void addEvaluateRecordFile(EvaluateRecordFileDTO dto);

	 void addEvaluateRecordFile(CommonsMultipartFile file, String evalId);
	
	 void updateEvaluateRecordFile(EvaluateRecordFileDTO dto);
	
	 void deleteEvaluateRecordFiles(String[] ids);

	 void deleteEvaluateRecordFilesByCondition(DataQuery dq);

	DownLoadDTO getDownLoadInfo(String fileId);

}
