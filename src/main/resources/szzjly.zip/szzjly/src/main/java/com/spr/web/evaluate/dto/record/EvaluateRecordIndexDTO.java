package com.spr.web.evaluate.dto.record;

import java.math.BigDecimal;
import java.util.List;

import com.spr.core.common.dto.UUIDDTO;

public class EvaluateRecordIndexDTO extends UUIDDTO {

    private String evalId;

    private String originalId;

    private Integer sortNo;

    private String sortName;

    private String indexName;

    private String score;

    private String indexConten;

    private String standard;

    private String parentId;

    private Integer level;

    private Short status;

    private Short flag;

    private String createBy;

    private String updateBy;
    
    private List<EvaluateRecordIndexDTO> subIndexList;

    private BigDecimal inputVal;

	private Byte isModified;

    /**
	 * @return the isModified
	 */
	public Byte getIsModified() {
		return isModified;
	}

	/**
	 * @param isModified the isModified to set
	 */
	public void setIsModified(Byte isModified) {
		this.isModified = isModified;
	}

	/**
	 * @return the inputVal
	 */
	public BigDecimal getInputVal() {
		return inputVal;
	}

	/**
	 * @param inputVal the inputVal to set
	 */
	public void setInputVal(BigDecimal inputVal) {
		this.inputVal = inputVal;
	}

	/**
	 * @return the subIndexList
	 */
	public List<EvaluateRecordIndexDTO> getSubIndexList() {
		return subIndexList;
	}

	/**
	 * @param subIndexList the subIndexList to set
	 */
	public void setSubIndexList(List<EvaluateRecordIndexDTO> subIndexList) {
		this.subIndexList = subIndexList;
	}

	public String getEvalId() {
        return evalId;
    }

    public void setEvalId(String evalId) {
        this.evalId = evalId == null ? null : evalId.trim();
    }

    public String getOriginalId() {
        return originalId;
    }

    public void setOriginalId(String originalId) {
        this.originalId = originalId == null ? null : originalId.trim();
    }

    public Integer getSortNo() {
        return sortNo;
    }

    public void setSortNo(Integer sortNo) {
        this.sortNo = sortNo;
    }

    public String getSortName() {
        return sortName;
    }

    public void setSortName(String sortName) {
        this.sortName = sortName == null ? null : sortName.trim();
    }

    public String getIndexName() {
        return indexName;
    }

    public void setIndexName(String indexName) {
        this.indexName = indexName == null ? null : indexName.trim();
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score == null ? null : score.trim();
    }

    public String getIndexConten() {
        return indexConten;
    }

    public void setIndexConten(String indexConten) {
        this.indexConten = indexConten == null ? null : indexConten.trim();
    }

    public String getStandard() {
        return standard;
    }

    public void setStandard(String standard) {
        this.standard = standard == null ? null : standard.trim();
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId == null ? null : parentId.trim();
    }

    public Integer getLevel() {
        return level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }

    public Short getStatus() {
        return status;
    }

    public void setStatus(Short status) {
        this.status = status;
    }

    public Short getFlag() {
        return flag;
    }

    public void setFlag(Short flag) {
        this.flag = flag;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }
}