package com.spr.web.flow.dto.exec;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.spr.core.common.dto.UUIDDTO;

public class ExecNodeDTO extends UUIDDTO {

	private String procDefId;

	private String tlNodeId;

	private String dataId;

	private String dataType;

	private String procInstId;

	private String progressText;

	private String nodeName;

	private String nodeCode;

	private String nodeType;

	private BigDecimal leftPos;

	private BigDecimal topPos;

	private String width;

	private String height;

	private String subDefId;

	private String procType;

	private String title;

	private String requirement;

	private String note;

	private Integer limitDay;

	private String dutyDepartId;

	private String dutyUserId;

	private String dutyUserName;// 负责人名称

	private Short allotStrategy;

	private Date startTime;

	private Short status;

	private Short checkStatus;

	private Short flowStatus;

	private Short flag;

	private String createBy;

	private String updateBy;

	private List<ExecCommentDTO> comments = new ArrayList<ExecCommentDTO>();
	private List<ExecAttachmentDTO> attachments = new ArrayList<ExecAttachmentDTO>();

	private Boolean authHandle = false;

	private String procDefName;

	public String getDutyUserName() {
		return dutyUserName;
	}

	public void setDutyUserName(String dutyUserName) {
		this.dutyUserName = dutyUserName;
	}

	public String getProcDefName() {
		return procDefName;
	}

	public void setProcDefName(String procDefName) {
		this.procDefName = procDefName;
	}

	public String getProcDefId() {
		return procDefId;
	}

	public void setProcDefId(String procDefId) {
		this.procDefId = procDefId == null ? null : procDefId.trim();
	}

	public String getTlNodeId() {
		return tlNodeId;
	}

	public void setTlNodeId(String tlNodeId) {
		this.tlNodeId = tlNodeId == null ? null : tlNodeId.trim();
	}

	public String getDataId() {
		return dataId;
	}

	public void setDataId(String dataId) {
		this.dataId = dataId == null ? null : dataId.trim();
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType == null ? null : dataType.trim();
	}

	public String getProcInstId() {
		return procInstId;
	}

	public void setProcInstId(String procInstId) {
		this.procInstId = procInstId == null ? null : procInstId.trim();
	}

	public String getProgressText() {
		return progressText;
	}

	public void setProgressText(String progressText) {
		this.progressText = progressText == null ? null : progressText.trim();
	}

	public String getNodeName() {
		return nodeName;
	}

	public void setNodeName(String nodeName) {
		this.nodeName = nodeName == null ? null : nodeName.trim();
	}

	public String getNodeCode() {
		return nodeCode;
	}

	public void setNodeCode(String nodeCode) {
		this.nodeCode = nodeCode == null ? null : nodeCode.trim();
	}

	public String getNodeType() {
		return nodeType;
	}

	public void setNodeType(String nodeType) {
		this.nodeType = nodeType == null ? null : nodeType.trim();
	}

	public BigDecimal getLeftPos() {
		return leftPos;
	}

	public void setLeftPos(BigDecimal leftPos) {
		this.leftPos = leftPos;
	}

	public BigDecimal getTopPos() {
		return topPos;
	}

	public void setTopPos(BigDecimal topPos) {
		this.topPos = topPos;
	}

	public String getWidth() {
		return width;
	}

	public void setWidth(String width) {
		this.width = width == null ? null : width.trim();
	}

	public String getHeight() {
		return height;
	}

	public void setHeight(String height) {
		this.height = height == null ? null : height.trim();
	}

	public String getSubDefId() {
		return subDefId;
	}

	public void setSubDefId(String subDefId) {
		this.subDefId = subDefId == null ? null : subDefId.trim();
	}

	public String getProcType() {
		return procType;
	}

	public void setProcType(String procType) {
		this.procType = procType == null ? null : procType.trim();
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title == null ? null : title.trim();
	}

	public String getRequirement() {
		return requirement;
	}

	public void setRequirement(String requirement) {
		this.requirement = requirement == null ? null : requirement.trim();
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note == null ? null : note.trim();
	}

	public Integer getLimitDay() {
		return limitDay;
	}

	public void setLimitDay(Integer limitDay) {
		this.limitDay = limitDay;
	}

	public String getDutyDepartId() {
		return dutyDepartId;
	}

	public void setDutyDepartId(String dutyDepartId) {
		this.dutyDepartId = dutyDepartId == null ? null : dutyDepartId.trim();
	}

	public String getDutyUserId() {
		return dutyUserId;
	}

	public void setDutyUserId(String dutyUserId) {
		this.dutyUserId = dutyUserId == null ? null : dutyUserId.trim();
	}

	public Short getAllotStrategy() {
		return allotStrategy;
	}

	public void setAllotStrategy(Short allotStrategy) {
		this.allotStrategy = allotStrategy;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Short getStatus() {
		return status;
	}

	public void setStatus(Short status) {
		this.status = status;
	}

	public Short getCheckStatus() {
		return checkStatus;
	}

	public void setCheckStatus(Short checkStatus) {
		this.checkStatus = checkStatus;
	}

	public Short getFlowStatus() {
		return flowStatus;
	}

	public void setFlowStatus(Short flowStatus) {
		this.flowStatus = flowStatus;
	}

	public Short getFlag() {
		return flag;
	}

	public void setFlag(Short flag) {
		this.flag = flag;
	}

	public String getCreateBy() {
		return createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy == null ? null : createBy.trim();
	}

	public String getUpdateBy() {
		return updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy == null ? null : updateBy.trim();
	}

	public List<ExecCommentDTO> getComments() {
		return comments;
	}

	public void setComments(List<ExecCommentDTO> comments) {
		this.comments = comments;
	}

	public List<ExecAttachmentDTO> getAttachments() {
		return attachments;
	}

	public void setAttachments(List<ExecAttachmentDTO> attachments) {
		this.attachments = attachments;
	}

	public Boolean getAuthHandle() {
		return authHandle;
	}

	public void setAuthHandle(Boolean authHandle) {
		this.authHandle = authHandle;
	}

}