package com.spr.web.flow.service.impl;

import com.spr.web.flow.service.IExecLineService;
import com.spr.core.common.service.BaseService;
import com.spr.web.flow.dao.IExecLineDao;
import com.spr.web.flow.entity.ExecLine;
import com.spr.web.flow.dto.exec.ExecLineDTO;

import javax.annotation.Resource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.utils.Assert;

@Service("execLineService")
@Transactional
public class ExecLineServiceImpl extends BaseService implements IExecLineService {

	
   @Resource
   private IExecLineDao execLineDao;
   
   
   /**
    * 分页查询
    * @param dq
    */
   @Override
   public Page<ExecLineDTO> searchByPage(DataQuery dq) {
   		
   		Long recTotal = this.execLineDao.countByCondition(dq.assemblePageOffset().getQueryMap());
		dq.assembleOrderInfo(ExecLine.class, null);
		List<ExecLineDTO> resultlist = this.execLineDao.selectListByCondition(dq.getQueryMap());
   
   		return new Page<ExecLineDTO>(dq.getCurrentPage(), dq.getPageSize(), resultlist, recTotal);
   }
   
   
   /**
    * 查询详细
    * @param id
    */
   @Override
   public ExecLineDTO getDetailById(String id){
   	   Assert.hasText(id, Assert.NULL_PARAM_STR("id")); 
   	   
   
   	   ExecLineDTO result = this.execLineDao.getDetailById(id);
   	   Assert.notNull(result,Assert.EMPTY_REOCRD_STR);
   	   
   	   return result;
   }
   
   
   
   
   /**
    * 添加
    * @param dto
   	*/
   @Override
   public void addExecLine(ExecLineDTO dto){
   
   	  ExecLine model = new ExecLine();
	  model.setProcDefId(dto.getProcDefId()); 	  
	  model.setProcInstId(dto.getProcInstId()); 	  
	  model.setLineName(dto.getLineName()); 	  
	  model.setLineType(dto.getLineType()); 	  
	  model.setLineCode(dto.getLineCode()); 	  
	  model.setLineAlt(dto.getLineAlt()); 	  
	  model.setMidPos(dto.getMidPos()); 	  
	  model.setPreNodeId(dto.getPreNodeId()); 	  
	  model.setNextNodeId(dto.getNextNodeId()); 	  
	  model.setStatus(dto.getStatus()); 	  
	  model.setCreateBy(dto.getCreateBy()); 	  
	  model.setUpdateBy(dto.getUpdateBy()); 	  
	  model.setGmtCreate(dto.getGmtCreate()); 	  
	  model.setGmtModified(dto.getGmtModified()); 	  
   
   	  this.execLineDao.insert(model);
   	  
   	  if(this.logger.isInfoEnabled()){
    	 this.logger.info("Add: "+model.toString());
      }
   }
   
   
   
   /**
    * 修改
    * @param dto
   	*/
   @Override
   public void updateExecLine(ExecLineDTO dto){
   	    Assert.hasText(dto.getId(), Assert.NULL_PARAM_STR("id")); 
    	
    	ExecLine model = this.execLineDao.getById(dto.getId());
    	Assert.notNull(model,Assert.EMPTY_REOCRD_STR);
    	
	  	model.setProcDefId(dto.getProcDefId()); 	  
	  	model.setProcInstId(dto.getProcInstId()); 	  
	  	model.setLineName(dto.getLineName()); 	  
	  	model.setLineType(dto.getLineType()); 	  
	  	model.setLineCode(dto.getLineCode()); 	  
	  	model.setLineAlt(dto.getLineAlt()); 	  
	  	model.setMidPos(dto.getMidPos()); 	  
	  	model.setPreNodeId(dto.getPreNodeId()); 	  
	  	model.setNextNodeId(dto.getNextNodeId()); 	  
	  	model.setStatus(dto.getStatus()); 	  
	  	model.setCreateBy(dto.getCreateBy()); 	  
	  	model.setUpdateBy(dto.getUpdateBy()); 	  
	  	model.setGmtCreate(dto.getGmtCreate()); 	  
	  	model.setGmtModified(dto.getGmtModified()); 	  
    	    	
    	this.execLineDao.update(model);
    	
    	if(this.logger.isInfoEnabled()){
    	  this.logger.info("Update: "+model.toString());
        }
   }
   
   
   
    /**
   	 * 删除
   	 * @param ids
   	 */
   	@Override
    public void deleteExecLines(String[] ids){
    	for (int i = 0; i < ids.length; i++) {
			this.execLineDao.deleteById(ids[i]);
			
			if(this.logger.isInfoEnabled()){
	    	   this.logger.info("Delete：:"+ids[i]);
	        }
		}
    }
   

}
