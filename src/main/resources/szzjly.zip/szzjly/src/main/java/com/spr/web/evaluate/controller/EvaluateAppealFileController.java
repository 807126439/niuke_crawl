package com.spr.web.evaluate.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.spr.core.common.bean.AjaxJson;
import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.controller.BaseController;
import com.spr.web.evaluate.dto.appeal.EvaluateAppealFileDTO;
import com.spr.web.evaluate.dto.record.EvaluateRecordDTO;
import com.spr.web.evaluate.service.IEvaluateAppealFileService;
import com.spr.web.evaluate.service.IEvaluateRecordService;

@Controller
@Scope("prototype")
@RequestMapping("/evaluateAppealFileController")
public class EvaluateAppealFileController extends BaseController {

	private static final long serialVersionUID = 1L;

	@Resource
	private IEvaluateAppealFileService evaluateAppealFileService;
	@Resource
	private IEvaluateRecordService evaluateRecordService;

	@RequestMapping(value = "/viewPage", method = { RequestMethod.GET })
	public String viewPage(HttpServletRequest request) {
		this.wrapMenuTitle(request);

		return "evaluate/evaluateAppealFile/evaluateAppealFileList.jsp";
	}

	@RequestMapping(value = "/getPageData", method = { RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> loadPageData(HttpServletRequest request, DataQuery dq) {

		this.wrapTableQueryParams(request, dq);

		Page<EvaluateAppealFileDTO> pageResult = this.evaluateAppealFileService.searchByPage(dq);

		return this.handlePageReult(pageResult);
	}

	@RequestMapping(value = "/skipAddEvaluateAppealFile")
	public String skipAddEvaluateAppealFile(HttpServletRequest request) {

		return "evaluate/evaluateAppealFile/addEvaluateAppealFile.jsp";
	}

	@RequestMapping(value = "/addEvaluateAppealFile", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson addEvaluateAppealFile(EvaluateAppealFileDTO dto) throws Exception {

		// this.evaluateAppealFileService.addEvaluateAppealFile(dto);

		return new AjaxJson(this.ADD_SUCCESS_MESSAGE, AjaxJson.success);
	}

	@RequestMapping("/getDetail")
	public String loadDetail(HttpServletRequest request, @RequestParam(value = "id", required = true) String id) {

		EvaluateAppealFileDTO result = this.evaluateAppealFileService.getDetailById(id);
		request.setAttribute("model", result);

		return "evaluate/evaluateAppealFile/editEvaluateAppealFile.jsp";
	}

	@RequestMapping(value = "/editEvaluateAppealFile", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson updateEvaluateAppealFile(EvaluateAppealFileDTO dto) {

		this.evaluateAppealFileService.updateEvaluateAppealFile(dto);

		return new AjaxJson(this.EDIT_SUCCESS_MESSAGE, AjaxJson.success);
	}

    // 删除
	@RequestMapping(value = "/deleteEvaluateRecordFile", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson deleteEvaluateAppealFile(String[] ids) {
		this.evaluateAppealFileService.deleteEvaluateAppealFiles(ids);
		return new AjaxJson(this.DEL_SUCCESS_MESSAGE, AjaxJson.success);
	}
	
    // ====================附件处理====================
    // 分页查询
    @RequestMapping(value = "/getMyFileData", method = { RequestMethod.POST })
    @ResponseBody
    public Map<String, Object> loadFileByPage(HttpServletRequest request, DataQuery dq, String fileName, String recordId) {
    	dq.putToMap("createBy", this.getNowUser().getUnitId());
		dq.putToMap("evaluateRecordId", recordId);
		dq.putToMap("likeFileName", StringUtils.isBlank(fileName) ? null : '%' + fileName + '%');
		Page<EvaluateAppealFileDTO> pageResult = this.evaluateAppealFileService.searchByPage(dq);
	return this.handleLayerPageReult(pageResult);
    }

    // 上传
    @RequestMapping("/uploadFile")
    @ResponseBody
    public AjaxJson uploadFile(@RequestParam(value = "file") CommonsMultipartFile file, String recordId) {
    	this.evaluateAppealFileService.addEvaluateAppealFile(file, recordId);
    	return new AjaxJson(this.UPLOAD_SUCCESS_MESSAGE, AjaxJson.success);
    }

    // 下载
    @RequestMapping(value = "/downFile")
    public void downFile(HttpServletRequest request, HttpServletResponse response, @RequestParam(required = true) String dataId) {
    	this.createDownLoadStream(request, response, this.evaluateAppealFileService.getDownLoadInfo(dataId));
    }
    
    // 加载申辩材料
    @RequestMapping(value = "/getContentFiles", method = { RequestMethod.POST })
    @ResponseBody
    public AjaxJson getContentFiles(HttpServletRequest request, DataQuery dq, String fileName, String recordId) {
    	EvaluateRecordDTO record = this.evaluateRecordService.getDetailById(recordId);
    	
    	dq.setNotQueryPage();
    	dq.putToMap("createBy", record.getTargetUnitId());
		dq.putToMap("evaluateRecordId", recordId);
		dq.putToMap("likeFileName", StringUtils.isBlank(fileName) ? null : '%' + fileName + '%');
		List<EvaluateAppealFileDTO> data = this.evaluateAppealFileService.selectListByCondition(dq);
		return new AjaxJson(this.OPER_SUCCESS_MESSAGE, AjaxJson.success, data);
    }
    
    // 加载回复材料
    @RequestMapping(value = "/getReplyFiles", method = { RequestMethod.POST })
    @ResponseBody
    public AjaxJson getReplyFiles(HttpServletRequest request, DataQuery dq, String fileName, String recordId) {
    	EvaluateRecordDTO record = this.evaluateRecordService.getDetailById(recordId);
    	
    	dq.setNotQueryPage();
    	dq.putToMap("updateBy", record.getEvalUserId());
		dq.putToMap("evaluateRecordId", recordId);
		dq.putToMap("likeFileName", StringUtils.isBlank(fileName) ? null : '%' + fileName + '%');
		List<EvaluateAppealFileDTO> data = this.evaluateAppealFileService.selectListByCondition(dq);
		return new AjaxJson(this.OPER_SUCCESS_MESSAGE, AjaxJson.success, data);
    }

}
