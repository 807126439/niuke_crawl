package com.spr.web.flow.service.impl;

import java.util.Date;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.spr.web.evaluate.dto.record.EvaluateRecordDTO;
import com.spr.web.evaluate.service.IEvaluateRecordService;
import com.spr.web.flow.service.AdditionOperation;

@Component("additionOperation")
public class AdditionOperationImpl implements AdditionOperation {

	@Resource
	private IEvaluateRecordService evaluateRecordService;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.spr.web.flow.service.AdditionOperation#processEnd(java.lang.String)
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.spr.web.flow.service.AdditionOperation#processEnd(java.lang.String)
	 */
	@Override
	public void processEnd(String dataId) {
		EvaluateRecordDTO evaluateRecord = this.evaluateRecordService.getDetailById(dataId);
		if (evaluateRecord != null) {
			evaluateRecord.setStatus(EvaluateRecordDTO.STATUS_SUCCEED);
			evaluateRecord.setPleaStatus(EvaluateRecordDTO.PLEA_STATUS_DEFAULT);
			evaluateRecord.setGmtModified(new Date());
			this.evaluateRecordService.updateEvaluateRecord(evaluateRecord);

			// 完成合同履约评价后,生成综合评价
			if (EvaluateRecordDTO.FORM_TYPE_CONTRACT.equals(evaluateRecord.getFormType())) {
				if (evaluateRecord.getEngTypeCode().equals(EvaluateRecordDTO.ENG_TYPE_CODE_DJ)) {
					// 代建
					this.evaluateRecordService.createDjEvaluateRecord(evaluateRecord);
				} else {
					// 非代建
					this.evaluateRecordService.createNotDjComprehensiveEvaluateRecord(evaluateRecord);
				}
			}

		}

	}

	@Override
	public void processFail(String dataId) {
		EvaluateRecordDTO evaluateRecord = this.evaluateRecordService.getDetailById(dataId);
		if (evaluateRecord != null) {
			evaluateRecord.setStatus(EvaluateRecordDTO.STATUS_FAILED);
			this.evaluateRecordService.updateEvaluateRecord(evaluateRecord);
		}

	}

}
