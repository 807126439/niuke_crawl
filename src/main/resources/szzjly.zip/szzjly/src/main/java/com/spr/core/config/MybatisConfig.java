/**
 * 
 */
package com.spr.core.config;


/**
 * @date 2019-4-12
 * @author wanve_java_cjy
 * 
 */
//@Configuration
//@MapperScan("com.spr.core.aspect.trace.dao")
public class MybatisConfig {
	
//	@Resource
//	private DataSource dataSource;
//
//	@Bean
//	public DataSource dataSource2() {
//		DruidDataSource dataSource = new DruidDataSource();
//		dataSource.setUrl("");
//		dataSource.setUsername("root");
//		dataSource.setPassword("root");
//		return dataSource;
//	}
//	
//	public DataSource dataSource() {
//		return this.dataSource;
//	}
//
//	@Bean(name = "sqlSessionFactoryBean")
//	public SqlSessionFactoryBean sqlSessionFactoryBean() throws Exception {
//		SqlSessionFactoryBean sqlSessionFactoryBean = new SqlSessionFactoryBean();
//		ResourcePatternResolver resourcePatternResolver = new PathMatchingResourcePatternResolver();
//        // 设置数据源
//		sqlSessionFactoryBean.setDataSource(dataSource());
//        // 设置 mapper接口 所在的包
//		sqlSessionFactoryBean.setTypeAliasesPackage("com.spr.core.aspect.trace.entity");
//        // 设置 mapper 对应的 XML文件 的路径
//		sqlSessionFactoryBean.setMapperLocations(resourcePatternResolver.getResources("classpath:com/spr/core/aspect/trace/dao/TraceInfoMapper.xml"));
//		return sqlSessionFactoryBean;
//	}
//	
//	@Bean
//	public MapperScannerConfigurer mapperScannerConfigurer() {
//		MapperScannerConfigurer mapperScannerConfigurer = new MapperScannerConfigurer();
//		mapperScannerConfigurer.setSqlSessionFactoryBeanName("sqlSessionFactoryBean");
//		mapperScannerConfigurer.setBasePackage("com.spr.core.aspect.trace.dao");
//		return mapperScannerConfigurer;
//	}
}
