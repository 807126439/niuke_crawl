/**
 * 
 */
package com.spr.core.config;

import javax.annotation.Resource;

import org.bson.Document;
import org.springframework.core.env.Environment;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.spr.core.aspect.trace.dao.TraceInfoRepository;
import com.spr.core.aspect.trace.dao.TraceInfoRepositoryImpl;


/**
 * @date 2019-4-28
 * @author wanve_java_cjy
 *
 */
//@Configuration
//@PropertySource("classpath:mongo.properties")
public class MongoConfig {

	@Resource
	private Environment env;   
	
//	@Bean
	public TraceInfoRepository traceInfoRepository() {
		TraceInfoRepositoryImpl traceInfoRepository = new TraceInfoRepositoryImpl();
		traceInfoRepository.setMongoCollection(getCollection("trace_info"));
		return traceInfoRepository;
	}
	
	private MongoCollection<Document> getCollection(String collectionName) {
		return mongoDatabase().getCollection(collectionName);
	}
	
	private MongoDatabase mongoDatabase() {
		return mongoClient().getDatabase(dbname());
	}
	
	private MongoClient mongoClient() {
		return new MongoClient(host(), port());
	}
	
	private String host() {
		return env.getProperty("mongo.host");
	}
	
	private int port() {
		return Integer.parseInt(env.getProperty("mongo.port"));
	}
	
	private String dbname() {
		return env.getProperty("mongo.dbname");
	}
	
	private String username() {
		return env.getProperty("mongo.username");
	}
	
	private String password() {
		return env.getProperty("mongo.password");
	}
	
	private int connectionsPerHost() {
		return Integer.parseInt(env.getProperty("mongo.connectionsPerHost"));
	}
	
	private int minConnectionsPerHost() {
		return Integer.parseInt(env.getProperty("mongo.minConnectionsPerHost"));
	}
	
	private int threadsAllowedToBlockForConnectionMultiplier() {
		return Integer.parseInt(env.getProperty("mongo.threadsAllowedToBlockForConnectionMultiplier"));
	}
	
	private int connectTimeout() {
		return Integer.parseInt(env.getProperty("mongo.connectTimeout"));
	}
	
	private int maxWaitTime() {
		return Integer.parseInt(env.getProperty("mongo.maxWaitTime"));
	}
	
	private boolean socketKeepAlive() {
		return Boolean.parseBoolean(env.getProperty("mongo.socketKeepAlive"));
	}
	
	private int socketTimeout() {
		return Integer.parseInt(env.getProperty("mongo.socketTimeout"));
	}
}
