package com.spr.web.evaluate.dao;

import com.spr.core.common.dao.IBaseDao;
import com.spr.web.evaluate.dto.record.EvaluateRecordFileDTO;
import com.spr.web.evaluate.entity.EvaluateRecordFile;
import java.util.List;
import java.util.Map;

public interface IEvaluateRecordFileDao extends IBaseDao<String, EvaluateRecordFile> {

    Long countByCondition(Map<String, Object> queryMap);

    List<EvaluateRecordFileDTO> selectListByCondition(Map<String, Object> queryMap);

    EvaluateRecordFileDTO getDetailById(String id);
	
	int deleteByCondition(Map<String, Object> queryMap);
}