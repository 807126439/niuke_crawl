package com.spr.web.flow.controller;

import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.spr.core.common.bean.AjaxJson;
import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.controller.BaseController;
import com.spr.core.common.dto.DownLoadDTO;
import com.spr.web.flow.dto.exec.ExecAttachmentDTO;
import com.spr.web.flow.service.IExecAttachmentService;

@Controller
@Scope("prototype")
@RequestMapping("/execAttachmentController")
public class ExecAttachmentController extends BaseController {

	private static final long serialVersionUID = 1L;

	@Resource
	private IExecAttachmentService execAttachmentService;

	@RequestMapping(value = "/viewPage", method = { RequestMethod.GET })
	public String viewPage(HttpServletRequest request) {
		this.wrapMenuTitle(request);

		return "flow/execAttachment/execAttachmentList.jsp";
	}

	@RequestMapping(value = "/getPageData", method = { RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> loadPageData(HttpServletRequest request, DataQuery dq) {

		this.wrapTableQueryParams(request, dq);

		Page<ExecAttachmentDTO> pageResult = this.execAttachmentService.searchByPage(dq);

		return this.handlePageReult(pageResult);
	}

	@RequestMapping(value = "/skipAddExecAttachment")
	public String skipAddExecAttachment(HttpServletRequest request) {

		return "flow/execAttachment/addExecAttachment.jsp";
	}

	/**
	 * 上传附件
	 * 
	 * @param dto
	 * @param file
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/uploadExecAttachment", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson addExecAttachment(String procNodeId, Short attachmentType, @RequestParam(value = "file") CommonsMultipartFile file) throws Exception {

		try {
			this.execAttachmentService.addExecAttachment(procNodeId, attachmentType, file);
			return new AjaxJson(this.UPLOAD_SUCCESS_MESSAGE, AjaxJson.success);

		} catch (Exception e) {

			return new AjaxJson(e.getMessage(), AjaxJson.error);
		}

	}

	/**
	 * 下载文件
	 * 
	 * @param request
	 * @param response
	 * @param id
	 */
	@RequestMapping(value = "/downloadAttachment", method = { RequestMethod.GET })
	public void downloadFile(HttpServletRequest request, HttpServletResponse response, String dataId) {

		DownLoadDTO dto = this.execAttachmentService.getDownLoadInfo(dataId);

		this.createDownLoadStream(request, response, dto);
	}

	// @RequestMapping("/getDetail")
	// public String loadDetail(HttpServletRequest request, @RequestParam(value
	// = "id", required = true) String id) {
	//
	// ExecAttachmentDTO result = this.execAttachmentService.getDetailById(id);
	// request.setAttribute("model", result);
	//
	// return "flow/execAttachment/editExecAttachment.jsp";
	// }
	//
	// @RequestMapping(value = "/editExecAttachment", method = {
	// RequestMethod.POST })
	// @ResponseBody
	// public AjaxJson updateExecAttachment(ExecAttachmentDTO dto) {
	//
	// this.execAttachmentService.updateExecAttachment(dto);
	//
	// return new AjaxJson(this.EDIT_SUCCESS_MESSAGE, AjaxJson.success);
	// }

	@RequestMapping(value = "/deleteExecAttachment", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson deleteExecAttachment(String[] ids) {

		this.execAttachmentService.deleteExecAttachments(ids);

		return new AjaxJson(this.DEL_SUCCESS_MESSAGE, AjaxJson.success);
	}

}
