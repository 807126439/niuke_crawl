package com.spr.web.evaluate.service;

import java.util.List;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.web.evaluate.dto.appeal.EvaluateAppealDTO;
import com.spr.web.evaluate.dto.record.EvaluateRecordDTO;

public interface IEvaluateAppealService {

	List<EvaluateAppealDTO> selectListByCondition(DataQuery dq);
	
	Page<EvaluateAppealDTO> searchByPage(DataQuery dq);

	EvaluateAppealDTO getDetailById(String id);

	void addEvaluateAppeal(EvaluateAppealDTO dto);

	/**
	 * 添加履约异议反馈
	 * 
	 * @param dto
	 * @date 2019-3-29
	 * @author wanve_java_cjy
	 */
	void addEvaluateAppealPleaContent(EvaluateRecordDTO dto);

	/**
	 * 添加异议反馈回复
	 * 
	 * @param dto
	 * @date 2019-3-29
	 * @author wanve_java_cjy
	 */
	void addEvaluateAppealPleaReply(EvaluateRecordDTO dto);

	void updateEvaluateAppeal(EvaluateAppealDTO dto);

	void deleteEvaluateAppeals(String[] ids);

	/**
	 * 根据评价记录ID查询申辩以及申辩文件
	 * 
	 * @param evaluateRecordId
	 * @return
	 */
	List<EvaluateAppealDTO> selectEvaluateAppealAndFileList(String evaluateRecordId);

}
