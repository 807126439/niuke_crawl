package com.spr.web.flow.dto.exec;

import com.spr.core.common.dto.UUIDDTO;

public class ExecCommentDTO extends UUIDDTO {

	private String procInstId;

	private String procNodeId;

	private String userId;

	private Short type;

	private String content;

	private String note;

	private Short status;

	private String createBy;

	private String updateBy;

	private String userName;

	private String chineseName;

	private String unitName;

	public ExecCommentDTO() {
	}

	public ExecCommentDTO(String procInstId, String procNodeId, String userId, Short type, String content) {
		super();
		this.procInstId = procInstId;
		this.procNodeId = procNodeId;
		this.userId = userId;
		this.type = type;
		this.content = content;
	}

	public String getUnitName() {
		return unitName;
	}

	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	public String getProcInstId() {
		return procInstId;
	}

	public void setProcInstId(String procInstId) {
		this.procInstId = procInstId == null ? null : procInstId.trim();
	}

	public String getProcNodeId() {
		return procNodeId;
	}

	public void setProcNodeId(String procNodeId) {
		this.procNodeId = procNodeId == null ? null : procNodeId.trim();
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId == null ? null : userId.trim();
	}

	public Short getType() {
		return type;
	}

	public void setType(Short type) {
		this.type = type;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content == null ? null : content.trim();
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note == null ? null : note.trim();
	}

	public Short getStatus() {
		return status;
	}

	public void setStatus(Short status) {
		this.status = status;
	}

	public String getCreateBy() {
		return createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy == null ? null : createBy.trim();
	}

	public String getUpdateBy() {
		return updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy == null ? null : updateBy.trim();
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getChineseName() {
		return chineseName;
	}

	public void setChineseName(String chineseName) {
		this.chineseName = chineseName;
	}

}