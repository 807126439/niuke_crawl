package com.spr.web.system.service;

public interface ICacheManager {

	void storeSmsCode(String businessType, String phone, String code, int seconds);

	String getCodeByKey(String businessType, String phone);

	void simpleStore(String key, String val, Integer seconds);

	String getVal(String key);

	void deleteValue(String key);

}
