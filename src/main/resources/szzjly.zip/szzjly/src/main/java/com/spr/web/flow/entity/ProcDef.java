package com.spr.web.flow.entity;

import java.io.Serializable;

import com.spr.core.annotations.DbField;
import com.spr.core.common.entity.UUIDEntity;

public class ProcDef extends UUIDEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	private String processCode;

	private String processName;

	private String description;

	private String numbTemplate;

	private String year;

	private int sn;

	private Short status;

	private Short flag;

	private String createBy;

	private String updateBy;

	private String unitId;

	@DbField(name = "unit_id")
	public String getUnitId() {
		return unitId;
	}

	public void setUnitId(String unitId) {
		this.unitId = unitId;
	}

	@DbField(name = "process_code")
	public String getProcessCode() {
		return processCode;
	}

	public void setProcessCode(String processCode) {
		this.processCode = processCode == null ? null : processCode.trim();
	}

	@DbField(name = "process_name")
	public String getProcessName() {
		return processName;
	}

	public void setProcessName(String processName) {
		this.processName = processName == null ? null : processName.trim();
	}

	@DbField(name = "description")
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description == null ? null : description.trim();
	}

	@DbField(name = "numb_template")
	public String getNumbTemplate() {
		return numbTemplate;
	}

	public void setNumbTemplate(String numbTemplate) {
		this.numbTemplate = numbTemplate;
	}

	@DbField(name = "curr_year")
	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	@DbField(name = "curr_sn")
	public int getSn() {
		return sn;
	}

	public void setSn(int sn) {
		this.sn = sn;
	}

	@DbField(name = "status")
	public Short getStatus() {
		return status;
	}

	public void setStatus(Short status) {
		this.status = status;
	}

	@DbField(name = "flag")
	public Short getFlag() {
		return flag;
	}

	public void setFlag(Short flag) {
		this.flag = flag;
	}

	@DbField(name = "create_by")
	public String getCreateBy() {
		return createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy == null ? null : createBy.trim();
	}

	@DbField(name = "update_by")
	public String getUpdateBy() {
		return updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy == null ? null : updateBy.trim();
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode());
		sb.append(",Super = ").append(super.toString());
		sb.append(", serialVersionUID=").append(serialVersionUID);
		sb.append(", processCode=").append(processCode);
		sb.append(", processName=").append(processName);
		sb.append(", description=").append(description);
		sb.append(", status=").append(status);
		sb.append(", flag=").append(flag);
		sb.append(", createBy=").append(createBy);
		sb.append(", updateBy=").append(updateBy);
		sb.append("]");
		return sb.toString();
	}
}