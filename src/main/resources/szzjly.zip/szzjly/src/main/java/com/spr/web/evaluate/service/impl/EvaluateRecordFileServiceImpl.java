package com.spr.web.evaluate.service.impl;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.dto.DownLoadDTO;
import com.spr.core.common.service.BaseService;
import com.spr.core.common.utils.Assert;
import com.spr.core.utils.IconPathUtil;
import com.spr.web.evaluate.dao.IEvaluateRecordFileDao;
import com.spr.web.evaluate.dto.record.EvaluateRecordFileDTO;
import com.spr.web.evaluate.entity.EvaluateRecordFile;
import com.spr.web.evaluate.service.IEvaluateRecordFileService;
import com.spr.web.file.dto.baseFile.SaveResult;
import com.spr.web.file.entity.BaseFile;
import com.spr.web.file.entity.ZonePath;
import com.spr.web.file.service.IBaseFileService;
import com.spr.web.file.service.IZonePathService;

@Service("evaluateRecordFileService")
@Transactional
public class EvaluateRecordFileServiceImpl extends BaseService implements IEvaluateRecordFileService {

	
   @Resource
   private IEvaluateRecordFileDao evaluateRecordFileDao;
	@Resource
	private IBaseFileService baseFileService;
	@Resource
	private IZonePathService zonePathService;
	
	   @Override
	   public List<EvaluateRecordFileDTO> selectListByCondition(DataQuery dq) {
		   dq.assemblePageOffset();
			dq.assembleOrderInfo(EvaluateRecordFile.class, "erf");
			List<EvaluateRecordFileDTO> resultlist = this.evaluateRecordFileDao.selectListByCondition(dq.getQueryMap());
	   		return resultlist;
	   }
   
   
   /**
    * 分页查询
    * @param dq
    */
   @Override
   public Page<EvaluateRecordFileDTO> searchByPage(DataQuery dq) {
   		
   		Long recTotal = this.evaluateRecordFileDao.countByCondition(dq.assemblePageOffset().getQueryMap());
		dq.assembleOrderInfo(EvaluateRecordFile.class, "erf");
		List<EvaluateRecordFileDTO> resultlist = this.evaluateRecordFileDao.selectListByCondition(dq.getQueryMap());

		// 设置图片预览路径
		for (EvaluateRecordFileDTO item : resultlist) {
			this.initText(item);
		}
   		return new Page<EvaluateRecordFileDTO>(dq.getCurrentPage(), dq.getPageSize(), resultlist, recTotal);
   }

	private void initText(EvaluateRecordFileDTO dto) {
		// 设置图片预览路径
		if (BaseFile.FILE_KIND_PICTURE == dto.getFileKind()) {
			dto.setPattern(dto.getFileViewPath());
			dto.setBigPattern(dto.getFileViewPath());
		}
		// 设置图标
		dto.setTypeIcon(IconPathUtil.getIconMatchType(dto.getFileType()));
	}
   
   
   /**
    * 查询详细
    * @param id
    */
   @Override
   public EvaluateRecordFileDTO getDetailById(String id){
   	   Assert.hasText(id, Assert.NULL_PARAM_STR("id")); 
   	   
   
   	   EvaluateRecordFileDTO result = this.evaluateRecordFileDao.getDetailById(id);
   	   Assert.notNull(result,Assert.EMPTY_REOCRD_STR);
   	   
   	   return result;
   }
   
   
   
   
   /**
    * 添加
    * @param dto
   	*/
   @Override
   public void addEvaluateRecordFile(EvaluateRecordFileDTO dto){
   
   	  EvaluateRecordFile model = new EvaluateRecordFile();
	  model.setEvalId(dto.getEvalId()); 	  
	  model.setType(dto.getType()); 	  
	  model.setFileName(dto.getFileName()); 	  
	  model.setFileSize(dto.getFileSize()); 	  
	  model.setFileType(dto.getFileType()); 	  
	  model.setFileViewPath(dto.getFileViewPath()); 	  
	  model.setBaseFileId(dto.getBaseFileId()); 	  
	  model.setStatus(dto.getStatus()); 	  
	  model.setFlag(dto.getFlag()); 	  
	  model.setCreateBy(dto.getCreateBy()); 	  
	  model.setUpdateBy(dto.getUpdateBy()); 	  
	  model.setGmtCreate(dto.getGmtCreate()); 	  
	  model.setGmtModified(dto.getGmtModified()); 	  
   
   	  this.evaluateRecordFileDao.insert(model);
   	  
   
      this.writeInfoLog("Add: "+model.toString());
      
   }
   
   @Override
   public void addEvaluateRecordFile(CommonsMultipartFile file, String evalId){
		Assert.hasText(evalId, "evalId must not be empty");
		Assert.notNull(file, "上传文件不能为空！");

		SaveResult as = this.baseFileService.addBaseFile(file, ZonePath.COMMON_FILE);
	   	EvaluateRecordFile model = new EvaluateRecordFile();
		model.setEvalId(evalId); 	  
		// model.setType(dto.getType()); 	  
		model.setFileName(as.getFileName());
		model.setFileType(as.getFileType());
		model.setFileSize(as.getFileSize()); 	  
		// model.setFileView(as.getViewBigPattern());
		if (BaseFile.FILE_KIND_PICTURE == as.getFileKind()) {
			// 图片文件
			model.setFileViewPath(as.getViewPattern());
		} else {
			// 办公文件、视频文件
			model.setFileViewPath(as.getViewPath());
		}
		model.setBaseFileId(as.getId());
		// model.setStatus(status);
		// model.setFlag(dto.getFlag()); 	  
		model.setCreateBy(this.getNowUser().getChineseName());
		model.setUpdateBy(this.getNowUser().getChineseName());
		model.setGmtCreate(new Date());
		model.setGmtModified(new Date());

	   this.evaluateRecordFileDao.insert(model);
      this.writeInfoLog("Add: "+model.toString());
      
   }

   
   /**
    * 修改
    * @param dto
   	*/
   @Override
   public void updateEvaluateRecordFile(EvaluateRecordFileDTO dto){
   	    Assert.hasText(dto.getId(), Assert.NULL_PARAM_STR("id")); 
    	
    	EvaluateRecordFile model = this.evaluateRecordFileDao.getById(dto.getId());
    	Assert.notNull(model,Assert.EMPTY_REOCRD_STR);
    	
	  	model.setEvalId(dto.getEvalId()); 	  
	  	model.setType(dto.getType()); 	  
	  	model.setFileName(dto.getFileName()); 	  
	  	model.setFileSize(dto.getFileSize()); 	  
	  	model.setFileType(dto.getFileType()); 	  
	  	model.setFileViewPath(dto.getFileViewPath()); 	  
	  	model.setBaseFileId(dto.getBaseFileId()); 	  
	  	model.setStatus(dto.getStatus()); 	  
	  	model.setFlag(dto.getFlag()); 	  
	  	model.setCreateBy(dto.getCreateBy()); 	  
	  	model.setUpdateBy(dto.getUpdateBy()); 	  
	  	model.setGmtCreate(dto.getGmtCreate()); 	  
	  	model.setGmtModified(dto.getGmtModified()); 	  
    	    	
    	this.evaluateRecordFileDao.update(model);
    	
   
    	this.writeInfoLog("Update: "+model.toString());
        
   }
   
   
   
    /**
   	 * 删除
   	 * @param ids
   	 */
   	@Override
    public void deleteEvaluateRecordFiles(String[] ids){
    	for (int i = 0; i < ids.length; i++) {
			this.evaluateRecordFileDao.deleteById(ids[i]);
			
			
	        this.writeInfoLog("Delete id:" + ids[i]);
	        
		}
    }
   	
   	public void deleteEvaluateRecordFilesByCondition(DataQuery dq) {
   		// 获取评价记录附件
   		dq.setNotQueryPage();
   		List<EvaluateRecordFileDTO> list = this.selectListByCondition(dq);
   		// 删除评价记录附件
   		this.evaluateRecordFileDao.deleteByCondition(dq.getQueryMap());
   		
   		// 删除实体文件
   		for (EvaluateRecordFileDTO dto : list) {
   			this.baseFileService.realDeteleFile(dto.getBaseFileId());
   		}
   	}

	// 下载
	@Override
	public DownLoadDTO getDownLoadInfo(String fileId) {
		Assert.notNull(fileId, "fileId must not be null");
		EvaluateRecordFile model = this.evaluateRecordFileDao.getById(fileId);
		if (model != null && model.getBaseFileId() != null) {
			return this.baseFileService.getDownLoadInfoById(model.getBaseFileId());
		}
		return null;
	}

}
