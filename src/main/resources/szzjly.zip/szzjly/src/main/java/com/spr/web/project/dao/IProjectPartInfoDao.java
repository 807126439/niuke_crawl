package com.spr.web.project.dao;

import java.util.List;
import java.util.Map;

import com.spr.core.common.dao.IBaseDao;
import com.spr.web.project.dto.part.ProjectPartInfoDTO;
import com.spr.web.project.entity.ProjectPartInfo;

public interface IProjectPartInfoDao extends IBaseDao<String, ProjectPartInfo> {

	Long countByCondition(Map<String, Object> queryMap);

	List<ProjectPartInfoDTO> selectListByCondition(Map<String, Object> queryMap);

	ProjectPartInfoDTO getDetailById(String id);

	List<Map<String, Object>> selectNotEvaluateList(Map<String, Object> queryMap);
}