package com.spr.web.evaluate.dao;

import com.spr.core.common.dao.IBaseDao;
import com.spr.web.evaluate.dto.form.EvaluateFormDTO;
import com.spr.web.evaluate.entity.EvaluateForm;
import java.util.List;
import java.util.Map;

public interface IEvaluateFormDao extends IBaseDao<String, EvaluateForm> {

    Long countByCondition(Map<String, Object> queryMap);

    List<EvaluateFormDTO> selectListByCondition(Map<String, Object> queryMap);

    EvaluateFormDTO getDetailById(String id);
	
	int deleteByCondition(Map<String, Object> queryMap);
	
	int updateStatus(EvaluateForm entity);
}