package com.spr.web.evaluate.dto.time;

import java.util.Date;

public class EvaluateTimeDTO {

	private Date firstSeasonEvaluateStartTime;

	private Date firstSeasonEvaluateEndTime;

	private Date secondSeasonEvaluateStartTime;

	private Date secondSeasonEvaluateEndTime;

	private Date thirdSeasonEvaluateStartTime;

	private Date thirdSeasonEvaluateEndTime;

	private Date fourthSeasonEvaluateStartTime;

	private Date fourthSeasonEvaluateEndTime;

	public Date getFirstSeasonEvaluateStartTime() {
		return firstSeasonEvaluateStartTime;
	}

	public void setFirstSeasonEvaluateStartTime(Date firstSeasonEvaluateStartTime) {
		this.firstSeasonEvaluateStartTime = firstSeasonEvaluateStartTime;
	}

	public Date getFirstSeasonEvaluateEndTime() {
		return firstSeasonEvaluateEndTime;
	}

	public void setFirstSeasonEvaluateEndTime(Date firstSeasonEvaluateEndTime) {
		this.firstSeasonEvaluateEndTime = firstSeasonEvaluateEndTime;
	}

	public Date getSecondSeasonEvaluateStartTime() {
		return secondSeasonEvaluateStartTime;
	}

	public void setSecondSeasonEvaluateStartTime(Date secondSeasonEvaluateStartTime) {
		this.secondSeasonEvaluateStartTime = secondSeasonEvaluateStartTime;
	}

	public Date getSecondSeasonEvaluateEndTime() {
		return secondSeasonEvaluateEndTime;
	}

	public void setSecondSeasonEvaluateEndTime(Date secondSeasonEvaluateEndTime) {
		this.secondSeasonEvaluateEndTime = secondSeasonEvaluateEndTime;
	}

	public Date getThirdSeasonEvaluateStartTime() {
		return thirdSeasonEvaluateStartTime;
	}

	public void setThirdSeasonEvaluateStartTime(Date thirdSeasonEvaluateStartTime) {
		this.thirdSeasonEvaluateStartTime = thirdSeasonEvaluateStartTime;
	}

	public Date getThirdSeasonEvaluateEndTime() {
		return thirdSeasonEvaluateEndTime;
	}

	public void setThirdSeasonEvaluateEndTime(Date thirdSeasonEvaluateEndTime) {
		this.thirdSeasonEvaluateEndTime = thirdSeasonEvaluateEndTime;
	}

	public Date getFourthSeasonEvaluateStartTime() {
		return fourthSeasonEvaluateStartTime;
	}

	public void setFourthSeasonEvaluateStartTime(Date fourthSeasonEvaluateStartTime) {
		this.fourthSeasonEvaluateStartTime = fourthSeasonEvaluateStartTime;
	}

	public Date getFourthSeasonEvaluateEndTime() {
		return fourthSeasonEvaluateEndTime;
	}

	public void setFourthSeasonEvaluateEndTime(Date fourthSeasonEvaluateEndTime) {
		this.fourthSeasonEvaluateEndTime = fourthSeasonEvaluateEndTime;
	}

}
