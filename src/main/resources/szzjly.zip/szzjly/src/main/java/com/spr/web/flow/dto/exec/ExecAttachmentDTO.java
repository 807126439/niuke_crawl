package com.spr.web.flow.dto.exec;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.spr.core.common.dto.UUIDDTO;


public class ExecAttachmentDTO extends UUIDDTO {

	private String procInstId;

	private String procNodeId;

	private String userId;

	private String fileName;

	private Short type;

	private String fileType;

	private Long baseFileId;

	private String fileView;

	private String backFileView;

	private Short status;

	private String createBy;

	private String updateBy;

	private String iconPath;

	private String viewPath;

	public String getProcInstId() {
		return procInstId;
	}

	public void setProcInstId(String procInstId) {
		this.procInstId = procInstId == null ? null : procInstId.trim();
	}

	public String getProcNodeId() {
		return procNodeId;
	}

	public void setProcNodeId(String procNodeId) {
		this.procNodeId = procNodeId == null ? null : procNodeId.trim();
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId == null ? null : userId.trim();
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName == null ? null : fileName.trim();
	}

	public Short getType() {
		return type;
	}

	public void setType(Short type) {
		this.type = type;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType == null ? null : fileType.trim();
	}

	public Long getBaseFileId() {
		return baseFileId;
	}

	public void setBaseFileId(Long baseFileId) {
		this.baseFileId = baseFileId;
	}

	public String getFileView() {
		return fileView;
	}

	public void setFileView(String fileView) {
		this.fileView = fileView == null ? null : fileView.trim();
	}

	public String getBackFileView() {
		return backFileView;
	}

	public void setBackFileView(String backFileView) {
		this.backFileView = backFileView == null ? null : backFileView.trim();
	}

	public Short getStatus() {
		return status;
	}

	public void setStatus(Short status) {
		this.status = status;
	}

	public String getCreateBy() {
		return createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy == null ? null : createBy.trim();
	}

	public String getUpdateBy() {
		return updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy == null ? null : updateBy.trim();
	}

	public String getIconPath() {
		return iconPath;
	}

	public void setIconPath(String iconPath) {
		this.iconPath = iconPath;
	}

	public String getViewPath() {
		
		return viewPath;
	}

	public void setViewPath(String viewPath) {
		this.viewPath = viewPath;
	}

}