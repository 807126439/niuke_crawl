package com.spr.web.system.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spr.core.common.bean.AjaxJson;
import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.controller.BaseController;
import com.spr.core.common.dto.ZtreeDTO;
import com.spr.web.system.dto.engineering.EngineeringTypeDTO;
import com.spr.web.system.service.IEngineeringTypeService;

@Controller
@Scope("prototype")
@RequestMapping("/engineeringTypeController")
public class EngineeringTypeController extends BaseController {

	private static final long serialVersionUID = 1L;

	@Resource
	private IEngineeringTypeService engineeringTypeService;

	@RequestMapping(value = "/viewPage", method = { RequestMethod.GET })
	public String viewPage(HttpServletRequest request) {
		this.wrapMenuTitle(request);

		return "system/engineeringType/engineeringTypeList.jsp";
	}

	@RequestMapping(value = "/getPageData", method = { RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> loadPageData(HttpServletRequest request, DataQuery dq, String typeName, String typeCode) {

		this.wrapTableQueryParams(request, dq);
		dq.putToMap("typeName", StringUtils.isNotBlank(typeName) ? typeName : null);
		dq.putToMap("typeCode", StringUtils.isNotBlank(typeCode) ? typeCode : null);
		Page<EngineeringTypeDTO> pageResult = this.engineeringTypeService.searchByPage(dq);

		return this.handlePageReult(pageResult);
	}

	@RequestMapping(value = "/skipAddEngineeringType")
	public String skipAddEngineeringType(HttpServletRequest request) {

		return "system/engineeringType/addEngineeringType.jsp";
	}

	@RequestMapping(value = "/addEngineeringType", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson addEngineeringType(EngineeringTypeDTO dto) throws Exception {

		this.engineeringTypeService.addEngineeringType(dto);

		return new AjaxJson(this.ADD_SUCCESS_MESSAGE, AjaxJson.success);
	}

	@RequestMapping("/getDetail")
	public String loadDetail(HttpServletRequest request, @RequestParam(value = "id", required = true) String id) {

		EngineeringTypeDTO result = this.engineeringTypeService.getDetailById(id);
		request.setAttribute("model", result);

		return "system/engineeringType/editEngineeringType.jsp";
	}

	@RequestMapping(value = "/editEngineeringType", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson updateEngineeringType(EngineeringTypeDTO dto) {

		this.engineeringTypeService.updateEngineeringType(dto);

		return new AjaxJson(this.EDIT_SUCCESS_MESSAGE, AjaxJson.success);
	}

	@RequestMapping(value = "/deleteEngineeringType", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson deleteEngineeringType(String[] ids) {

		this.engineeringTypeService.deleteEngineeringTypes(ids);

		return new AjaxJson(this.DEL_SUCCESS_MESSAGE, AjaxJson.success);
	}

	/**
	 * 跳转选择工程类型
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/skipEngTypeTree", method = { RequestMethod.GET })
	public String skipEngTypeTree(HttpServletRequest request) {

		return "system/engineeringType/selectEngType.jsp";
	}

	/**
	 * 获取工程类型
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/getEngTreeData", method = { RequestMethod.POST })
	@ResponseBody
	public List<ZtreeDTO> getEngTreeData(HttpServletRequest request) {
		return this.engineeringTypeService.getUnitTreeData();
	}

}
