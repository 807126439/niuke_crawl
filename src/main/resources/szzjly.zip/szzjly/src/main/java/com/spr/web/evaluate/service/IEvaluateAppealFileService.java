package com.spr.web.evaluate.service;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.dto.DownLoadDTO;
import com.spr.web.evaluate.dto.appeal.EvaluateAppealFileDTO;

public interface IEvaluateAppealFileService {

	/**
	 * evaluateAppealId - list
	 * 
	 * @param evaluateRecordId
	 * @return
	 * @date 2019-4-23
	 * @author wanve_java_cjy
	 */
	Map<String, List<EvaluateAppealFileDTO>> selectAppealListMapByRecordId(String evaluateRecordId);

	List<EvaluateAppealFileDTO> selectListByCondition(DataQuery dq);
	
	Page<EvaluateAppealFileDTO> searchByPage(DataQuery dq);

	EvaluateAppealFileDTO getDetailById(String id);

	void addEvaluateAppealFile(CommonsMultipartFile file, String recordId);
	
	void addEvaluateAppealFile(String evaluateRecordId, String evaluateAppealId, String ucode);

	void updateEvaluateAppealFile(EvaluateAppealFileDTO dto);

	void deleteEvaluateAppealFiles(String[] ids);

	DownLoadDTO getDownLoadInfo(String fileId);

}
