package com.spr.web.system.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.service.BaseService;
import com.spr.core.common.utils.Assert;
import com.spr.core.gobal.GobalVal;
import com.spr.web.system.dao.IUnitEvaluatorRelationDao;
import com.spr.web.system.dto.unit.UnitEvaluatorRelationDTO;
import com.spr.web.system.entity.UnitEvaluatorRelation;
import com.spr.web.system.service.IUnitEvaluatorRelationService;

@Service("unitEvaluatorRelationService")
@Transactional
public class UnitEvaluatorRelationServiceImpl extends BaseService implements IUnitEvaluatorRelationService {

	@Resource
	private IUnitEvaluatorRelationDao unitEvaluatorRelationDao;

	@Override
	public void setUnitEvaluatorRelation(String unitId, String userIds) {
		Assert.hasText("unitId", "unitId null error");
		Assert.hasText("userIds", "userIds null error");
		String[] userIdArray = userIds.split(",");

		if (userIdArray.length > 0) {
			this.unitEvaluatorRelationDao.deleteByUnitId(unitId);
			for (String userId : userIdArray) {
				UnitEvaluatorRelation model = new UnitEvaluatorRelation();
				model.setUnitId(unitId);
				model.setUserId(userId);
				model.setSingleStatus((short) 1);
				model.setStatus(GobalVal.STATUS_ENABLE);
				model.setCreateBy(getNowUser().getUsername());
				this.unitEvaluatorRelationDao.insert(model);
				this.writeInfoLog("Add: " + model.toString());
			}
		}
	}

	@Override
	public String getunitEvaluatorList(String unitId) {
		String ids = "";
		DataQuery dq = new DataQuery();
		dq.putToMap("unitId", unitId);

		List<UnitEvaluatorRelationDTO> resultList = this.unitEvaluatorRelationDao.selectListByCondition(dq.getQueryMap());
		if (resultList != null && !resultList.isEmpty()) {
			int i = 1;
			for (UnitEvaluatorRelationDTO unitEvaluatorRelationDTO : resultList) {
				if (i == 1) {
					ids = unitEvaluatorRelationDTO.getUserId();
				} else {
					ids = "," + unitEvaluatorRelationDTO.getUserId();
				}
				i++;
			}
		}

		return ids;
	}

	@Override
	public List<UnitEvaluatorRelationDTO> selectListByCondition(DataQuery dq) {
		dq.assemblePageOffset();
		dq.assembleOrderInfo(UnitEvaluatorRelation.class, null);
		List<UnitEvaluatorRelationDTO> resultlist = this.unitEvaluatorRelationDao.selectListByCondition(dq.getQueryMap());
		return resultlist;
	}
	
	/**
	 * 分页查询
	 * 
	 * @param dq
	 */
	@Override
	public Page<UnitEvaluatorRelationDTO> searchByPage(DataQuery dq) {

		Long recTotal = this.unitEvaluatorRelationDao.countByCondition(dq.assemblePageOffset().getQueryMap());
		dq.assembleOrderInfo(UnitEvaluatorRelation.class, null);
		List<UnitEvaluatorRelationDTO> resultlist = this.unitEvaluatorRelationDao.selectListByCondition(dq.getQueryMap());

		return new Page<UnitEvaluatorRelationDTO>(dq.getCurrentPage(), dq.getPageSize(), resultlist, recTotal);
	}

	/**
	 * 查询详细
	 * 
	 * @param id
	 */
	@Override
	public UnitEvaluatorRelationDTO getDetailById(String id) {
		Assert.hasText(id, Assert.NULL_PARAM_STR("id"));

		UnitEvaluatorRelationDTO result = this.unitEvaluatorRelationDao.getDetailById(id);
		Assert.notNull(result, Assert.EMPTY_REOCRD_STR);

		return result;
	}

	/**
	 * 添加
	 * 
	 * @param dto
	 */
	@Override
	public void addUnitEvaluatorRelation(UnitEvaluatorRelationDTO dto) {

		UnitEvaluatorRelation model = new UnitEvaluatorRelation();
		model.setSortNo(dto.getSortNo());
		model.setUnitId(dto.getUnitId());
		model.setUserId(dto.getUserId());
		model.setSingleStatus(dto.getSingleStatus());
		model.setStatus(dto.getStatus());
		model.setCreateBy(dto.getCreateBy());
		model.setUpdateBy(dto.getUpdateBy());
		model.setGmtCreate(dto.getGmtCreate());
		model.setGmtModified(dto.getGmtModified());

		this.unitEvaluatorRelationDao.insert(model);

		this.writeInfoLog("Add: " + model.toString());

	}

	/**
	 * 修改
	 * 
	 * @param dto
	 */
	@Override
	public void updateUnitEvaluatorRelation(UnitEvaluatorRelationDTO dto) {
		Assert.hasText(dto.getId(), Assert.NULL_PARAM_STR("id"));

		UnitEvaluatorRelation model = this.unitEvaluatorRelationDao.getById(dto.getId());
		Assert.notNull(model, Assert.EMPTY_REOCRD_STR);

		model.setSortNo(dto.getSortNo());
		model.setUnitId(dto.getUnitId());
		model.setUserId(dto.getUserId());
		model.setSingleStatus(dto.getSingleStatus());
		model.setStatus(dto.getStatus());
		model.setCreateBy(dto.getCreateBy());
		model.setUpdateBy(dto.getUpdateBy());
		model.setGmtCreate(dto.getGmtCreate());
		model.setGmtModified(dto.getGmtModified());

		this.unitEvaluatorRelationDao.update(model);

		this.writeInfoLog("Update: " + model.toString());

	}

	/**
	 * 删除
	 * 
	 * @param ids
	 */
	@Override
	public void deleteUnitEvaluatorRelations(String[] ids) {
		for (int i = 0; i < ids.length; i++) {
			this.unitEvaluatorRelationDao.deleteById(ids[i]);

			this.writeInfoLog("Delete id:" + ids[i]);

		}
	}

}
