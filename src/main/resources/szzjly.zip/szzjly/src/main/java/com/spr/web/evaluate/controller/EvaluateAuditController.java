package com.spr.web.evaluate.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spr.core.common.bean.AjaxJson;
import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.controller.BaseController;
import com.spr.core.common.exception.BusinessException;
import com.spr.core.spring.security.utils.SecurityPrincipalUtil;
import com.spr.core.utils.DateUtil;
import com.spr.web.evaluate.dto.record.EvaluateRecordDTO;
import com.spr.web.evaluate.service.IEvaluateAuditService;
import com.spr.web.evaluate.service.IEvaluateRecordService;
import com.spr.web.flow.dao.IProcNodeDao;
import com.spr.web.flow.dto.def.ProcDefDTO;
import com.spr.web.flow.dto.def.ProcNodeDTO;
import com.spr.web.flow.dto.exec.ExecCommentDTO;
import com.spr.web.flow.dto.exec.ExecNodeDTO;
import com.spr.web.flow.entity.ExecNode;
import com.spr.web.flow.entity.ProcNode;
import com.spr.web.flow.service.IExecIdentitylinkService;
import com.spr.web.flow.service.IExecNodeService;
import com.spr.web.flow.service.IProcDefService;
import com.spr.web.flow.service.IProcIdentitylinkService;
import com.spr.web.flow.service.IProcNodeService;
import com.spr.web.project.dto.part.ProjectPartInfoDTO;
import com.spr.web.project.dto.project.ProjectInfoDTO;
import com.spr.web.project.service.IProjectInfoService;
import com.spr.web.project.service.IProjectPartInfoService;
import com.spr.web.system.dto.user.WeiUserDTO;
import com.spr.web.system.entity.Role;
import com.spr.web.system.service.IUnitService;
import com.spr.web.system.service.IUserService;

@Controller
@Scope("prototype")
@RequestMapping("/evaluateAuditController")
public class EvaluateAuditController extends BaseController {

	private static final long serialVersionUID = 1L;

	@Resource
	private IEvaluateRecordService evaluateRecordService;
	@Resource
	private IProjectInfoService projectInfoService;
	@Resource
	private IProjectPartInfoService projectPartInfoService;
	@Resource
	private IExecNodeService execNodeService;
	@Resource
	private IEvaluateAuditService evaluateAuditService;
	@Resource
	private IUnitService unitService;
	@Resource
	private IProcDefService procDefService;
	@Resource
	private IUserService userService;
	@Resource
	private IExecIdentitylinkService execIdentitylinkService;
	@Resource
	private IProcNodeDao procNodeDao;
	@Resource
	private IProcIdentitylinkService procIdentitylinkService;
	@Resource
	private IProcNodeService procNodeService;

	/**
	 * 审核列表
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/viewPage", method = { RequestMethod.GET })
	public String viewPage(HttpServletRequest request) {
		this.wrapMenuTitle(request);

		return "evaluate/evaluateAudit/evaluateAuditList.jsp";
	}

	/**
	 * 管理单位专用可查看所有
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/viewManagePage", method = { RequestMethod.GET })
	public String viewManagePage(HttpServletRequest request) {
		this.wrapMenuTitle(request);

		return "evaluate/evaluateAudit/evaluateAuditManageList.jsp";
	}

	@RequestMapping(value = "/getPageData", method = { RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> loadPageData(HttpServletRequest request, DataQuery dq, String proName, String queryStatus) {
		this.wrapTableQueryParams(request, dq);
		// 可选参数
		dq.putToMap("likeProName", StringUtils.isBlank(proName) ? null : "%" + proName + "%");

		if (queryStatus != null && queryStatus.equals("done")) {
			// 节点为正在审核
			dq.getQueryMap().put("flowStatus", ExecNode.FLOW_STATUS_HISTORY);
			dq.getQueryMap().put("handlerOnly", this.getNowUser().getId());
		} else if (queryStatus != null && queryStatus.equals("auditing")) {
			// 节点为正在审核
			dq.getQueryMap().put("flowStatus", ExecNode.FLOW_STATUS_CURR);
			// 第一个办理人不定，handler可为空
			dq.getQueryMap().put("handlerOnly", this.getNowUser().getId());
			// 单位符合
			// dq.getQueryMap().put("auditerUnitId",
			// this.getNowUser().getUnitId());
		} else {
			// 节点为退回
			dq.getQueryMap().put("flowStatus", ExecNode.FLOW_STATUS_FAIL);
			dq.getQueryMap().put("handlerOnly", this.getNowUser().getId());
		}

		Page<EvaluateRecordDTO> pageResult = this.evaluateRecordService.searchByPageWithExec(dq);

		return this.handlePageReult(pageResult);
	}

	@RequestMapping(value = "/getManagePageData", method = { RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> loadManagePageData(HttpServletRequest request, DataQuery dq, String proName, String queryStatus, String formType,
			Date gmtEvalStart, Date gmtEvalEnd) {
		this.wrapTableQueryParams(request, dq);

		if (queryStatus != null && queryStatus.equals("fail")) {
			dq.getQueryMap().put("flowStatus", ExecNode.FLOW_STATUS_FAIL);
			dq.getQueryMap().put("nodeType", "start");
		} else if (queryStatus != null && queryStatus.equals("done")) {
			dq.getQueryMap().put("flowStatus", ExecNode.FLOW_STATUS_HISTORY);
			dq.getQueryMap().put("nodeType", "end");
		} else {
			dq.getQueryMap().put("flowStatus", ExecNode.FLOW_STATUS_CURR);
		}

		dq.getQueryMap().put("formType", StringUtils.isNotBlank(formType) ? formType : null);
		dq.getQueryMap().put("evalBeginTime", gmtEvalStart != null ? gmtEvalStart : null);
		dq.getQueryMap().put("evalEndTime", gmtEvalEnd != null ? DateUtil.strToDate(DateUtil.date2Str(gmtEvalEnd) + " 23:59:59") : null);

		// 可选参数
		dq.putToMap("likeProName", StringUtils.isBlank(proName) ? null : "%" + proName + "%");

		Page<EvaluateRecordDTO> pageResult = this.evaluateRecordService.searchByPageWithExec(dq);

		return this.handlePageReult(pageResult);
	}

	@RequestMapping(value = "/skipAuditPage", method = { RequestMethod.GET })
	public String skipAuditPage(HttpServletRequest request, @RequestParam(value = "id", required = true) String id) {
		this.wrapMenuTitle(request);
		EvaluateRecordDTO record = this.evaluateRecordService.getDetailById(id);
		List listContainer = new ArrayList();
		listContainer.add(record);
		this.evaluateRecordService.initText(listContainer);
		request.setAttribute("model", record);

		// 获取项目和单项项目信息
		ProjectInfoDTO project = this.projectInfoService.getDetailById(record.getProId());
		request.setAttribute("project", project);
		if (StringUtils.isNotBlank(record.getPartId())) {
			ProjectPartInfoDTO projectPart = this.projectPartInfoService.getDetailById(record.getPartId());
			request.setAttribute("projectPart", projectPart);
		}

		// 获取附件信息
		// TODO

		// 获取之前的审核信息
		ExecNodeDTO currNode = this.execNodeService.getCurrNodeByDateId(id);
		// 获取下一节点
		ExecNodeDTO nextNode = this.execNodeService.getNextNode(currNode);
		// 下一节点办理单位ID
		String nextHandleUnit = "";
		if (nextNode != null) {
			// TODO
			List<WeiUserDTO> dutyUserIds = this.execIdentitylinkService.getUsersByNodeId(nextNode.getId());
			// ------------------单选人，有多选情况再改进
			if (dutyUserIds != null && !dutyUserIds.isEmpty()) {
				for (WeiUserDTO user : dutyUserIds) {
					nextNode.setDutyUserId(user.getId());
					nextNode.setDutyUserName(user.getUserName());
				}
			}

			if (nextNode.getProcType() != null && nextNode.getProcType().equals("build")) {
				nextHandleUnit = project.getBuildUnitId();
			} else {
				nextHandleUnit = this.getNowUser().getUnitId();
			}
		}

		List<ExecNodeDTO> resultNodes = this.execNodeService.getStraightStructureProccess(currNode.getProcInstId(), null);
		request.setAttribute("resultNodes", resultNodes);
		request.setAttribute("currNode", currNode);
		request.setAttribute("nextNode", nextNode);
		request.setAttribute("nextHandleUnit", nextHandleUnit);

		return "evaluate/evaluateAudit/auditPage.jsp";
	}

	@RequestMapping(value = "/skipCheckPage", method = { RequestMethod.GET })
	public String skipCheckPage(HttpServletRequest request, @RequestParam(value = "id", required = true) String id, Integer checked) {
		this.wrapMenuTitle(request);
		EvaluateRecordDTO record = this.evaluateRecordService.getDetailById(id);
		// 查看标记存在则设为已查看
		if (checked != null && checked == 1) {
			record.setChecked(EvaluateRecordDTO.CHECKED_TRUE);
			this.evaluateRecordService.updateChecked(record);
		}
		List listContainer = new ArrayList();
		listContainer.add(record);
		this.evaluateRecordService.initText(listContainer);
		request.setAttribute("model", record);

		// 获取项目和单项项目信息
		ProjectInfoDTO project = this.projectInfoService.getDetailById(record.getProId());
		request.setAttribute("project", project);
		if (StringUtils.isNotBlank(record.getPartId())) {
			ProjectPartInfoDTO projectPart = this.projectPartInfoService.getDetailById(record.getPartId());
			request.setAttribute("projectPart", projectPart);
		}

		// 获取附件信息
		// TODO

		// 获取之前的审核信息
		ExecNodeDTO currNode = this.execNodeService.getCurrNodeByDateId(id);
		// 获取下一节点
		ExecNodeDTO nextNode = this.execNodeService.getNextNode(currNode);

		List<ExecNodeDTO> resultNodes = this.execNodeService.getStraightStructureProccess(currNode.getProcInstId(), null);
		if (currNode.getFlowStatus() == ExecNode.FLOW_STATUS_CURR) {
			List<WeiUserDTO> dutyUserIds = this.execIdentitylinkService.getUsersByNodeId(currNode.getId());
			// ------------------单选人，有多选情况再改进
			if (dutyUserIds != null && !dutyUserIds.isEmpty()) {
				for (ExecNodeDTO execNode : resultNodes) {
					if (execNode.getId().equals(currNode.getId())) {
						ExecCommentDTO comment = new ExecCommentDTO();
						comment.setType((short) 2);
						comment.setContent("审核中...");
						comment.setUserName(dutyUserIds.get(0).getUserName());
						comment.setUnitName(dutyUserIds.get(0).getUnitName());
						comment.setGmtModified(new Date());
						execNode.getComments().add(comment);
					}
				}
			}
		}
		request.setAttribute("resultNodes", resultNodes);
		request.setAttribute("currNode", currNode);
		request.setAttribute("nextNode", nextNode);

		boolean flag = false;
		for (GrantedAuthority authority : this.getNowUser().getAuthorities()) {
			if (authority.getAuthority().equals("ROLE_CONSTRACTOR")) {
				flag = true;
				break;
			}
		}

		if (SecurityPrincipalUtil.checkIsHasRole(Role.ROLE_AGENT_BUILD_UNIT)) {
			if (record.getEngTypeCode().equals("DJ")) {
				flag = true;
			}
		}

		// 承包商查看评价详细/代建单位查看代建评价情况
		if (flag) {
			return "evaluate/evaluateAudit/contractor/checkPage.jsp";
		}
		return "evaluate/evaluateAudit/checkPage.jsp";
	}

	/**
	 * 检查审核人是否已选
	 * 
	 * @param id
	 *            评分记录id
	 * @return
	 */
	@RequestMapping(value = "/checkAuditor", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson checkAuditor(@RequestParam(value = "id", required = true) String id) {

		// 获取执行流程
		ProcDefDTO procDef = this.evaluateAuditService.checkDefIfExist(id);
		// 获取流程第一步人员
		List<ProcNode> nodes = this.procNodeDao.getByProcDefId(procDef.getId());
		ProcNode startNode = null;
		ProcNodeDTO startNodeDTO = new ProcNodeDTO();
		for (ProcNode node : nodes) {
			if (node.getNodeType().equals("start")) {
				startNode = node;
				break;
			}
		}
		if (startNode == null) {
			throw new BusinessException("流程设置错误，没有开始流程");
		} else {
			startNodeDTO.setId(startNode.getId());
			startNodeDTO.setProcDefId(startNode.getProcDefId());
		}
		ProcNodeDTO secNode = this.procNodeService.getNextNode(startNodeDTO);
		List<WeiUserDTO> users = this.procIdentitylinkService.getUsersByNodeId(secNode.getId());

		if (users == null || users.size() == 0) {
			String unitId = "";
			EvaluateRecordDTO record = this.evaluateRecordService.getDetailById(id);
			ProjectInfoDTO project = this.projectInfoService.getDetailById(record.getProId());
			// if (secNode.getProcType().equals("build")) {
			// unitId = project.getBuildUnitId();
			// } else {
			// unitId = project.getAgentUnitId();
			// }
			if (secNode != null)
				unitId = this.getNowUser().getUnitId();

			return new AjaxJson("不存在用户", "nouser", unitId);
		}

		return new AjaxJson("存在用户", "hasuser");
	}

	// -------------------流程的推进与失败操作在文件流execNodeController中处理---------------------

	/**
	 * 撤回评分审核
	 * 
	 * @param id
	 *            评分记录id
	 * @return
	 */
	@RequestMapping(value = "/withdrawRecord", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson withdrawRecord(@RequestParam(value = "id", required = true) String id) {
		// 尝试删除
		this.evaluateAuditService.withdrawEvaluate(id);

		return new AjaxJson("撤回成功", AjaxJson.success);
	}

	/**
	 * 提交审核----------------------------不使用，保存记录的Controller调用Service方法
	 * 
	 * @param id
	 *            评分记录ID
	 * @return
	 */
	@RequestMapping(value = "/submitAudit", method = { RequestMethod.GET })
	@ResponseBody
	public AjaxJson submitAudit(@RequestParam(value = "id", required = true) String id, String auditor) {

		this.evaluateAuditService.submitAudit(id, auditor);

		return new AjaxJson("提交成功", AjaxJson.success);
	}

}
