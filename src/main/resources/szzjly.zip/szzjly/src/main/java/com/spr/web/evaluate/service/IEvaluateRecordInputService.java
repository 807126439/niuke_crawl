package com.spr.web.evaluate.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.web.evaluate.dto.form.EvaluateFormIndexDTO;
import com.spr.web.evaluate.dto.record.EvaluateRecordDTO;
import com.spr.web.evaluate.dto.record.EvaluateRecordIndexDTO;
import com.spr.web.evaluate.dto.record.EvaluateRecordInputDTO;

public interface IEvaluateRecordInputService {

	 Map<String, EvaluateRecordInputDTO> selectIndexModelMapByCondition(DataQuery dq);

	 Map<String, BigDecimal> selectIndexInputMapByCondition(DataQuery dq);

	 List<EvaluateRecordInputDTO> selectListByCondition(DataQuery dq);

	 Page<EvaluateRecordInputDTO> searchByPage(DataQuery dq);
	
	 EvaluateRecordInputDTO getDetailById(String id);
	
	 void addEvaluateRecordInput(EvaluateRecordInputDTO dto);
	
	 void updateEvaluateRecordInput(EvaluateRecordInputDTO dto);
	
	 void deleteEvaluateRecordInputs(String[] ids);
	
	 void deleteEvaluateRecordInputsByCondition(DataQuery dq);

	 List<EvaluateFormIndexDTO> getSubIndexList(DataQuery dq, String parentId, Map<String, BigDecimal> indexInputMap, Map<String, EvaluateRecordIndexDTO> originModelMap);
	 
	 void saveOrUpdate(EvaluateRecordDTO dto, String[] inputIds, String[] inputVals, Map<String, EvaluateRecordIndexDTO> originModelMap);
}
