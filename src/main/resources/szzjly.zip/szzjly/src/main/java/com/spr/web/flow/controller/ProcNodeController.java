package com.spr.web.flow.controller;

import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import net.sf.json.JSONObject;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.util.HtmlUtils;

import com.spr.core.common.bean.AjaxJson;
import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.controller.BaseController;
import com.spr.core.common.utils.Assert;
import com.spr.web.flow.dto.def.ProcNodeDTO;
import com.spr.web.flow.service.IProcNodeService;
import com.spr.web.system.service.IDepartmentService;

@Controller
@Scope("prototype")
@RequestMapping("/procNodeController")
public class ProcNodeController extends BaseController {

	private static final long serialVersionUID = 1L;

	@Resource
	private IProcNodeService procNodeService;
	@Resource
	private IDepartmentService departmentService;

	/**
	 * 设计流程
	 * 
	 * @param request
	 * @param procDefId
	 * @return
	 */
	@RequestMapping(value = "/designProcess")
	public String designProcess(HttpServletRequest request, @RequestParam(required = true) String procDefId) {

		JSONObject data = this.procNodeService.getProcessData(procDefId, null);
		if (data != null) {
			request.setAttribute("processData", data.toString());
		}
		request.setAttribute("unitId", this.getNowUser().getUnitId());
		request.setAttribute("procDefId", procDefId);

		return "flow/procNode/designProcess.jsp";
	}

	/**
	 * 保存流程数据
	 * 
	 * @param procDefId
	 * @param data
	 * @return
	 */
	@RequestMapping("/saveProcess")
	@ResponseBody
	public AjaxJson saveProcess(String procDefId, String data) {

		data = HtmlUtils.htmlUnescape(data);
		this.procNodeService.addProcess(data, procDefId);

		return new AjaxJson("保存成功！", AjaxJson.success);

	}

	@RequestMapping(value = "/viewPage", method = { RequestMethod.GET })
	public String viewPage(HttpServletRequest request) {
		this.wrapMenuTitle(request);

		return "flow/procNode/procNodeList.jsp";
	}

	@RequestMapping(value = "/getPageData", method = { RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> loadPageData(HttpServletRequest request, DataQuery dq) {

		this.wrapTableQueryParams(request, dq);

		Page<ProcNodeDTO> pageResult = this.procNodeService.searchByPage(dq);

		return this.handlePageReult(pageResult);
	}

	@RequestMapping(value = "/skipAddProcNode")
	public String skipAddProcNode(HttpServletRequest request) {

		return "flow/procNode/addProcNode.jsp";
	}

	@RequestMapping(value = "/addProcNode", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson addProcNode(ProcNodeDTO dto) throws Exception {

		this.procNodeService.addProcNode(dto);

		return new AjaxJson(this.ADD_SUCCESS_MESSAGE, AjaxJson.success);
	}

	@RequestMapping("/getDetail")
	public String loadDetail(HttpServletRequest request, @RequestParam(value = "id", required = true) String id) {

		ProcNodeDTO result = this.procNodeService.getDetailById(id);
		request.setAttribute("model", result);

		return "flow/procNode/editProcNode.jsp";
	}

	@RequestMapping(value = "/editProcNode", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson updateProcNode(ProcNodeDTO dto) {

		this.procNodeService.updateProcNode(dto);

		return new AjaxJson(this.EDIT_SUCCESS_MESSAGE, AjaxJson.success);
	}

	@RequestMapping(value = "/deleteProcNode", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson deleteProcNode(String[] ids) {

		this.procNodeService.deleteProcNodes(ids);

		return new AjaxJson(this.DEL_SUCCESS_MESSAGE, AjaxJson.success);
	}

	@RequestMapping(value = "/checkTree")
	public String skipDepartTree(HttpServletRequest request, String call) {

		Assert.hasText(call, Assert.NULL_PARAM_STR("call"));
		request.setAttribute("call", call);

		return "flow/procNode/checkTree2.jsp";
	}

}
