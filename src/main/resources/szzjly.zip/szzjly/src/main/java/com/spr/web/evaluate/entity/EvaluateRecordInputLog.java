package com.spr.web.evaluate.entity;

import com.spr.core.annotations.DbField;
import com.spr.core.common.entity.UUIDEntity;
import java.io.Serializable;
import java.math.BigDecimal;

public class EvaluateRecordInputLog extends UUIDEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    private String evalId;

    private String indexId;

    private String procNodeId;

    private String userId;

    private BigDecimal beforeVal;

    private BigDecimal changeVal;

    private Short status;

    private String createBy;

    private String updateBy;

    @DbField(name="eval_id")
    public String getEvalId() {
        return evalId;
    }

    public void setEvalId(String evalId) {
        this.evalId = evalId == null ? null : evalId.trim();
    }

    @DbField(name="index_id")
    public String getIndexId() {
        return indexId;
    }

    public void setIndexId(String indexId) {
        this.indexId = indexId == null ? null : indexId.trim();
    }

    @DbField(name="proc_node_id")
    public String getProcNodeId() {
        return procNodeId;
    }

    public void setProcNodeId(String procNodeId) {
        this.procNodeId = procNodeId == null ? null : procNodeId.trim();
    }

    @DbField(name="user_id")
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId == null ? null : userId.trim();
    }

    @DbField(name="before_val")
    public BigDecimal getBeforeVal() {
        return beforeVal;
    }

    public void setBeforeVal(BigDecimal beforeVal) {
        this.beforeVal = beforeVal;
    }

    @DbField(name="change_val")
    public BigDecimal getChangeVal() {
        return changeVal;
    }

    public void setChangeVal(BigDecimal changeVal) {
        this.changeVal = changeVal;
    }

    @DbField(name="status")
    public Short getStatus() {
        return status;
    }

    public void setStatus(Short status) {
        this.status = status;
    }

    @DbField(name="create_by")
    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    @DbField(name="update_by")
    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(",Super = ").append(super.toString());
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append(", evalId=").append(evalId);
        sb.append(", indexId=").append(indexId);
        sb.append(", procNodeId=").append(procNodeId);
        sb.append(", userId=").append(userId);
        sb.append(", beforeVal=").append(beforeVal);
        sb.append(", changeVal=").append(changeVal);
        sb.append(", status=").append(status);
        sb.append(", createBy=").append(createBy);
        sb.append(", updateBy=").append(updateBy);
        sb.append("]");
        return sb.toString();
    }
}