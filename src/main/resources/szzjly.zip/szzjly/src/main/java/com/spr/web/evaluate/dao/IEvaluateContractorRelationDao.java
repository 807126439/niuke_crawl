package com.spr.web.evaluate.dao;

import com.spr.core.common.dao.IBaseDao;
import com.spr.web.evaluate.dto.relation.EvaluateContractorRelationDTO;
import com.spr.web.evaluate.entity.EvaluateContractorRelation;
import java.util.List;
import java.util.Map;

public interface IEvaluateContractorRelationDao extends IBaseDao<String, EvaluateContractorRelation> {

    Long countByCondition(Map<String, Object> queryMap);

    List<EvaluateContractorRelationDTO> selectListByCondition(Map<String, Object> queryMap);

    EvaluateContractorRelationDTO getDetailById(String id);
}