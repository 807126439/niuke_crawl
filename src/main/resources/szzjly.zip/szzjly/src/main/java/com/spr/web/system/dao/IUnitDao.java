package com.spr.web.system.dao;

import java.util.List;
import java.util.Map;

import com.spr.core.common.dao.IBaseDao;
import com.spr.web.system.dto.unit.UnitDTO;
import com.spr.web.system.entity.Unit;

public interface IUnitDao extends IBaseDao<String, Unit> {

	Long countByCondition(Map<String, Object> queryMap);

	List<UnitDTO> selectListByCondition(Map<String, Object> queryMap);

	UnitDTO getDetailById(String id);

	UnitDTO getDetailByOrganizationCode(String organizationCode);
}