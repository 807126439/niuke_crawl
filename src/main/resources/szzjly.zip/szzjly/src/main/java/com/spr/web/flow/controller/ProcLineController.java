package com.spr.web.flow.controller;

import com.spr.web.flow.service.IProcLineService;
import com.spr.web.flow.dto.def.ProcLineDTO;
import com.spr.core.common.controller.BaseController;

import java.util.Map;
import javax.annotation.Resource;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import javax.servlet.http.HttpServletRequest;

import com.spr.core.common.bean.AjaxJson;
import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;

@Controller
@Scope("prototype")
@RequestMapping("/procLineController")
public class ProcLineController extends BaseController{

	private static final long serialVersionUID = 1L;
	
	@Resource
	private IProcLineService procLineService;
	
	
	
	@RequestMapping(value="/viewPage",method={RequestMethod.GET})
	public String viewPage(HttpServletRequest request){
		this.wrapMenuTitle(request);
		
		return "flow/procLine/procLineList.jsp";
	}
	
	
	@RequestMapping(value="/getPageData",method={RequestMethod.POST})
	@ResponseBody
	public Map<String, Object> loadPageData(HttpServletRequest request,DataQuery dq){

		this.wrapTableQueryParams(request, dq);
				
		Page<ProcLineDTO> pageResult = this.procLineService.searchByPage(dq);
		 
		return this.handlePageReult(pageResult);
	}
	
	
	@RequestMapping(value="/skipAddProcLine")
	public String skipAddProcLine(HttpServletRequest request){
		
		
		return "flow/procLine/addProcLine.jsp";
	}
	
	
	@RequestMapping(value="/addProcLine",method={RequestMethod.POST})
	@ResponseBody
	public AjaxJson addProcLine(ProcLineDTO dto) throws Exception{
	
		this.procLineService.addProcLine(dto);
		
		
		return new AjaxJson(this.ADD_SUCCESS_MESSAGE, AjaxJson.success);
	}
	
	
	@RequestMapping("/getDetail")
	public String loadDetail(HttpServletRequest request,@RequestParam(value="id",required=true)String id){
			  		
	    ProcLineDTO result = this.procLineService.getDetailById(id);
		request.setAttribute("model", result);
		
	
		return "flow/procLine/editProcLine.jsp";
	}
	
	
	@RequestMapping(value="/editProcLine",method={RequestMethod.POST})
	@ResponseBody
	public AjaxJson updateProcLine(ProcLineDTO dto){
		
		this.procLineService.updateProcLine(dto);
				
		return new AjaxJson(this.EDIT_SUCCESS_MESSAGE, AjaxJson.success);
	}
	
	
	@RequestMapping(value="/deleteProcLine",method={RequestMethod.POST})
	@ResponseBody
	public AjaxJson deleteProcLine(String[] ids){
		
		this.procLineService.deleteProcLines(ids);
		
		
		return new AjaxJson(this.DEL_SUCCESS_MESSAGE, AjaxJson.success);
	}
	
}
