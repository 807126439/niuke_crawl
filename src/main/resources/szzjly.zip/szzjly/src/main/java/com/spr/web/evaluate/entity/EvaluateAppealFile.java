package com.spr.web.evaluate.entity;

import com.spr.core.annotations.DbField;
import com.spr.core.common.entity.UUIDEntity;
import java.io.Serializable;

public class EvaluateAppealFile extends UUIDEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    private String evaluateRecordId;

    private String evaluateAppealId;

    private String fileName;

    private String fileSize;

    private String fileType;

    private String fileViewPath;

    private Long baseFileId;

    private Short status;

    private Short flag;

    private String createBy;

    private String updateBy;

    @DbField(name="evaluate_record_id")
    public String getEvaluateRecordId() {
        return evaluateRecordId;
    }

    public void setEvaluateRecordId(String evaluateRecordId) {
        this.evaluateRecordId = evaluateRecordId == null ? null : evaluateRecordId.trim();
    }

    @DbField(name="evaluate_appeal_id")
    public String getEvaluateAppealId() {
        return evaluateAppealId;
    }

    public void setEvaluateAppealId(String evaluateAppealId) {
        this.evaluateAppealId = evaluateAppealId == null ? null : evaluateAppealId.trim();
    }

    @DbField(name="file_name")
    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName == null ? null : fileName.trim();
    }

    @DbField(name="file_size")
    public String getFileSize() {
        return fileSize;
    }

    public void setFileSize(String fileSize) {
        this.fileSize = fileSize == null ? null : fileSize.trim();
    }

    @DbField(name="file_type")
    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType == null ? null : fileType.trim();
    }

    @DbField(name="file_view_path")
    public String getFileViewPath() {
        return fileViewPath;
    }

    public void setFileViewPath(String fileViewPath) {
        this.fileViewPath = fileViewPath == null ? null : fileViewPath.trim();
    }

    @DbField(name="base_file_id")
    public Long getBaseFileId() {
        return baseFileId;
    }

    public void setBaseFileId(Long baseFileId) {
        this.baseFileId = baseFileId;
    }

    @DbField(name="status")
    public Short getStatus() {
        return status;
    }

    public void setStatus(Short status) {
        this.status = status;
    }

    @DbField(name="flag")
    public Short getFlag() {
        return flag;
    }

    public void setFlag(Short flag) {
        this.flag = flag;
    }

    @DbField(name="create_by")
    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    @DbField(name="update_by")
    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(",Super = ").append(super.toString());
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append(", evaluateRecordId=").append(evaluateRecordId);
        sb.append(", evaluateAppealId=").append(evaluateAppealId);
        sb.append(", fileName=").append(fileName);
        sb.append(", fileSize=").append(fileSize);
        sb.append(", fileType=").append(fileType);
        sb.append(", fileViewPath=").append(fileViewPath);
        sb.append(", baseFileId=").append(baseFileId);
        sb.append(", status=").append(status);
        sb.append(", flag=").append(flag);
        sb.append(", createBy=").append(createBy);
        sb.append(", updateBy=").append(updateBy);
        sb.append("]");
        return sb.toString();
    }
}