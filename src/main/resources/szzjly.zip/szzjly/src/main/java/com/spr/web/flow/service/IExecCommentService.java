package com.spr.web.flow.service;

import com.spr.web.flow.dto.exec.ExecCommentDTO;
import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;

public interface IExecCommentService {

	 Page<ExecCommentDTO> searchByPage(DataQuery dq);
	
	 ExecCommentDTO getDetailById(String id);
	
	 void addExecComment(ExecCommentDTO dto);
	
	 void updateExecComment(ExecCommentDTO dto);
	
	 void deleteExecComments(String[] ids);

}
