package com.spr.web.evaluate.dto.appeal;

import com.spr.core.common.dto.UUIDDTO;

public class EvaluateAppealFileDTO extends UUIDDTO {

    private String evaluateRecordId;

    private String evaluateAppealId;

    private String fileName;

    private String fileSize;

    private String fileType;

    private String fileViewPath;

    private Long baseFileId;

    private Short status;

    private Short flag;

    private String createBy;

    private String updateBy;

    public String getEvaluateRecordId() {
        return evaluateRecordId;
    }

    public void setEvaluateRecordId(String evaluateRecordId) {
        this.evaluateRecordId = evaluateRecordId == null ? null : evaluateRecordId.trim();
    }

    public String getEvaluateAppealId() {
        return evaluateAppealId;
    }

    public void setEvaluateAppealId(String evaluateAppealId) {
        this.evaluateAppealId = evaluateAppealId == null ? null : evaluateAppealId.trim();
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName == null ? null : fileName.trim();
    }

    public String getFileSize() {
        return fileSize;
    }

    public void setFileSize(String fileSize) {
        this.fileSize = fileSize == null ? null : fileSize.trim();
    }

    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType == null ? null : fileType.trim();
    }

    public String getFileViewPath() {
        return fileViewPath;
    }

    public void setFileViewPath(String fileViewPath) {
        this.fileViewPath = fileViewPath == null ? null : fileViewPath.trim();
    }

    public Long getBaseFileId() {
        return baseFileId;
    }

    public void setBaseFileId(Long baseFileId) {
        this.baseFileId = baseFileId;
    }

    public Short getStatus() {
        return status;
    }

    public void setStatus(Short status) {
        this.status = status;
    }

    public Short getFlag() {
        return flag;
    }

    public void setFlag(Short flag) {
        this.flag = flag;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }
}