package com.spr.web.flow.dto.exec;

import com.spr.core.common.dto.UUIDDTO;

public class ExecIdentitylinkDTO extends UUIDDTO {

	private String procDefId;

	private String procInstId;

	private String nodeId;

	private String userId;

	private String departId;

	private Short type;

	private Short status;

	private String createBy;

	private String updateBy;

	public ExecIdentitylinkDTO() {
	}

	public ExecIdentitylinkDTO(String procDefId, String procInstId, String nodeId, String userId) {
		super();
		this.procDefId = procDefId;
		this.procInstId = procInstId;
		this.nodeId = nodeId;
		this.userId = userId;
	}

	public String getProcDefId() {
		return procDefId;
	}

	public void setProcDefId(String procDefId) {
		this.procDefId = procDefId == null ? null : procDefId.trim();
	}

	public String getProcInstId() {
		return procInstId;
	}

	public void setProcInstId(String procInstId) {
		this.procInstId = procInstId == null ? null : procInstId.trim();
	}

	public String getNodeId() {
		return nodeId;
	}

	public void setNodeId(String nodeId) {
		this.nodeId = nodeId == null ? null : nodeId.trim();
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId == null ? null : userId.trim();
	}

	public String getDepartId() {
		return departId;
	}

	public void setDepartId(String departId) {
		this.departId = departId == null ? null : departId.trim();
	}

	public Short getType() {
		return type;
	}

	public void setType(Short type) {
		this.type = type;
	}

	public Short getStatus() {
		return status;
	}

	public void setStatus(Short status) {
		this.status = status;
	}

	public String getCreateBy() {
		return createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy == null ? null : createBy.trim();
	}

	public String getUpdateBy() {
		return updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy == null ? null : updateBy.trim();
	}
}