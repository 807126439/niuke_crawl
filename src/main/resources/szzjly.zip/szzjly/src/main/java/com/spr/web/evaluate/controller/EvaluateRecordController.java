package com.spr.web.evaluate.controller;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.spr.core.common.bean.AjaxJson;
import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.controller.BaseController;
import com.spr.core.common.exception.BusinessException;
import com.spr.core.gobal.GobalVal;
import com.spr.core.spring.security.utils.SecurityPrincipalUtil;
import com.spr.web.evaluate.dto.form.EvaluateFormDTO;
import com.spr.web.evaluate.dto.record.EvaluateRecordDTO;
import com.spr.web.evaluate.service.IEvaluateAppealFileService;
import com.spr.web.evaluate.service.IEvaluateFormService;
import com.spr.web.evaluate.service.IEvaluateRecordService;
import com.spr.web.evaluate.service.IEvaluateTimeSettingService;
import com.spr.web.project.dto.part.ProjectPartInfoDTO;
import com.spr.web.project.dto.project.ProjectInfoDTO;
import com.spr.web.project.service.IProjectInfoService;
import com.spr.web.project.service.IProjectPartInfoService;
import com.spr.web.system.dto.engineering.EngineeringTypeDTO;
import com.spr.web.system.dto.unit.UnitDTO;
import com.spr.web.system.entity.BaseDict;
import com.spr.web.system.entity.Role;
import com.spr.web.system.service.IBaseDictService;
import com.spr.web.system.service.IEngineeringTypeService;
import com.spr.web.system.service.IUnitService;

@Controller
@Scope("prototype")
@RequestMapping("/evaluateRecordController")
public class EvaluateRecordController extends BaseController {

	private static final long serialVersionUID = 1L;

	@Resource
	private IEvaluateRecordService evaluateRecordService;
	@Resource
	private IEvaluateFormService evaluateFormService;
	@Resource
	private IProjectPartInfoService projectPartInfoService;
	@Resource
	private IProjectInfoService projectInfoService;
	@Resource
	private IUnitService unitService;
	@Resource
	private IEvaluateTimeSettingService evaluateTimeSettingService;
	@Resource
	private IEngineeringTypeService engineeringTypeService;
	@Resource
	private IBaseDictService baseDictService;
	@Resource
	private IEvaluateAppealFileService evaluateAppealFileService;

	@RequestMapping(value = "/viewPage", method = { RequestMethod.GET })
	public String viewPage(HttpServletRequest request, String proId, String partId) {
		this.wrapMenuTitle(request);
		request.setAttribute("proId", proId);
		request.setAttribute("partId", partId);
		return "evaluate/evaluateRecord/evaluateRecordList.jsp";
	}

	@RequestMapping(value = "/getPageData", method = { RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> loadPageData(HttpServletRequest request, DataQuery dq, String proId, String partId, String proName) {
		this.wrapTableQueryParams(request, dq);

		if (StringUtils.isNotBlank(partId)) {
			// 工程：查看评价记录
			dq.putToMap("partId", partId);
		} else if (StringUtils.isNoneBlank(proId)) {
			// 项目：查看评价记录
			dq.putToMap("proId", proId);
		}
		dq.putToMap("likeProName", StringUtils.isBlank(proName) ? null : "%" + proName + "%");
		Page<EvaluateRecordDTO> pageResult = this.evaluateRecordService.searchByPage(dq);
		return this.handlePageReult(pageResult);
	}

	// ==================================================
	// 住建局查看履约评价
	@RequestMapping(value = "/admin/viewPage", method = { RequestMethod.GET })
	public String adminViewPage(HttpServletRequest request, String proId, String partId) {

		this.handelRecordPageTitle(request, proId, partId, null);
		if (StringUtils.isNotBlank(proId)) {
			// 查看代建项目评分
			request.setAttribute("proId", proId);
			request.setAttribute("recordType", EvaluateRecordDTO.RECORD_TYPE_TOTAL);
			return "evaluate/evaluateRecord/admin/dj/evaluateRecordList.jsp";
		} else if (StringUtils.isNotBlank(partId)) {
			// 查看非代建项目评分
			request.setAttribute("partId", partId);
		}
		return "evaluate/evaluateRecord/admin/evaluateRecordList.jsp";
	}

	// 住建局单位:总履约评价查看细节履约评价
	@RequestMapping(value = "/admin/dj/viewDetailPage", method = { RequestMethod.GET })
	public String adminUnitViewPage(HttpServletRequest request, String connectRecordId) {
		this.handelDjDetialRecordPageTitle(request, connectRecordId);
		request.setAttribute("connectRecordId", connectRecordId);
		return "evaluate/evaluateRecord/admin/dj/detailEvaluateRecordList.jsp";
	}

	@RequestMapping(value = "/admin/getPageData", method = { RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> adminGetPageData(HttpServletRequest request, DataQuery dq, String connectRecordId, String recordType, String buildUnitName,
			String proId, String partId) {
		this.wrapTableQueryParams(request, dq);

		if (StringUtils.isNoneBlank(proId)) {
			// 项目：查看履约评价
			dq.putToMap("proId", proId);
			dq.putToMap("recordType", StringUtils.isNotBlank(recordType) ? recordType : null); // 只查总结果
			dq.putToMap("nullPartId", "nullPartId");
		} else if (StringUtils.isNoneBlank(partId)) {
			// 工程：查看履约评价
			dq.putToMap("partId", partId);
		} else if (StringUtils.isNoneBlank(connectRecordId)) {
			// 工程：查看履约评价：查看本人评价记录
			dq.putToMap("connectRecordId", connectRecordId);
		} else {
			throw new BusinessException("参数错误");
		}
		dq.putToMap("formTypes", new String[] { EvaluateRecordDTO.FORM_TYPE_SEASON, EvaluateRecordDTO.FORM_TYPE_CONTRACT });
		dq.putToMap("status", EvaluateRecordDTO.STATUS_SUCCEED);
		dq.putToMap("likeBuildUnitName", StringUtils.isBlank(buildUnitName) ? null : "%" + buildUnitName + "%");
		Page<EvaluateRecordDTO> pageResult = this.evaluateRecordService.searchByPage(dq);
		return this.handlePageReult(pageResult);
	}

	// 建设单位查看履约评价
	@RequestMapping(value = "/buildUnit/viewPage", method = { RequestMethod.GET })
	public String buildUnitViewPage(HttpServletRequest request, String proId, String partId, Short status) {
		this.wrapMenuTitle(request);
		request.setAttribute("proId", proId);
		request.setAttribute("partId", partId);
		request.setAttribute("status", status);
		request.setAttribute("evalUserId", this.getNowUser().getId());
		this.handelRecordPageTitle(request, proId, partId, null);
		return "evaluate/evaluateRecord/buildUnit/evaluateRecordList.jsp";
	}

	@RequestMapping(value = "/buildUnit/getPageData", method = { RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> buildUnitGetPageData(HttpServletRequest request, DataQuery dq, String buildUnitName, Short status, String proId, String partId) {
		this.wrapTableQueryParams(request, dq);

		if (StringUtils.isNoneBlank(proId)) {
			// 项目：查看履约评价：查看本人评价记录
			dq.putToMap("proId", proId);
			// dq.putToMap("evalUserId", this.getNowUser().getId());
			dq.putToMap("evalUnitId", this.getNowUser().getUnitId());
		} else if (StringUtils.isNoneBlank(partId)) {
			// 工程：查看履约评价：查看代建单位对承包商评价结果
			dq.putToMap("partId", partId);
			dq.putToMap("status", status);
		} else {
			throw new BusinessException("参数错误");
		}
		dq.putToMap("formTypes", new String[] { EvaluateRecordDTO.FORM_TYPE_SEASON, EvaluateRecordDTO.FORM_TYPE_CONTRACT });
		dq.putToMap("likeBuildUnitName", StringUtils.isBlank(buildUnitName) ? null : "%" + buildUnitName + "%");
		dq.setSidx("gmtEval");
		dq.setSord("desc");

		Page<EvaluateRecordDTO> pageResult = this.evaluateRecordService.searchByPage(dq);
		return this.handlePageReult(pageResult);
	}

	// 代建单位查看履约评价
	@RequestMapping(value = "/agentUnit/viewPage", method = { RequestMethod.GET })
	public String agentUnitViewPage(HttpServletRequest request, String proId, String partId) {

		this.handelRecordPageTitle(request, proId, partId, null);
		if (StringUtils.isNotBlank(proId)) {
			// 查看代建项目评分
			request.setAttribute("proId", proId);
			request.setAttribute("recordType", EvaluateRecordDTO.RECORD_TYPE_TOTAL);
			return "evaluate/evaluateRecord/agentUnit/dj/evaluateRecordList.jsp";
		} else if (StringUtils.isNotBlank(partId)) {
			// 查看非代建项目评分
			request.setAttribute("partId", partId);
			request.setAttribute("evalUserId", this.getNowUser().getId());
		}

		return "evaluate/evaluateRecord/agentUnit/evaluateRecordList.jsp";
	}

	// 代建单位:总履约评价查看细节履约评价
	@RequestMapping(value = "/agentUnit/dj/viewDetailPage", method = { RequestMethod.GET })
	public String agentUnitViewPage(HttpServletRequest request, String connectRecordId) {
		this.handelDjDetialRecordPageTitle(request, connectRecordId);
		request.setAttribute("connectRecordId", connectRecordId);
		return "evaluate/evaluateRecord/agentUnit/dj/detailEvaluateRecordList.jsp";
	}

	@RequestMapping(value = "/agentUnit/getPageData", method = { RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> agentUnitGetPageData(HttpServletRequest request, DataQuery dq, String connectRecordId, String recordType, String buildUnitName,
			String proId, String partId) {
		this.wrapTableQueryParams(request, dq);

		if (StringUtils.isNoneBlank(proId)) {
			// 项目：查看履约评价：查看建设单位/住建局/发改局对本单位代建项目的评价结果
			dq.putToMap("recordType", StringUtils.isNotBlank(recordType) ? recordType : null); // 只查总结果
			dq.putToMap("proId", proId);
			dq.putToMap("targetUnitId", this.getNowUser().getUnitId());
		} else if (StringUtils.isNoneBlank(partId)) {
			// 工程：查看履约评价：查看本人评价记录
			dq.putToMap("partId", partId);
			// dq.putToMap("evalUserId", this.getNowUser().getId());
			dq.putToMap("evalUnitId", this.getNowUser().getUnitId());
		} else if (StringUtils.isNoneBlank(connectRecordId)) {
			// 工程：查看履约评价：查看本人评价记录
			dq.putToMap("connectRecordId", connectRecordId);
		} else {
			throw new BusinessException("参数错误");
		}
		dq.putToMap("formTypes", new String[] { EvaluateRecordDTO.FORM_TYPE_SEASON, EvaluateRecordDTO.FORM_TYPE_CONTRACT });
		dq.putToMap("likeBuildUnitName", StringUtils.isBlank(buildUnitName) ? null : "%" + buildUnitName + "%");
		Page<EvaluateRecordDTO> pageResult = this.evaluateRecordService.searchByPage(dq);
		return this.handlePageReult(pageResult);
	}

	// 承包商查看履约评价
	@RequestMapping(value = "/contractor/viewPage", method = { RequestMethod.GET })
	public String contractorViewPage(HttpServletRequest request, String partId) {
		this.wrapMenuTitle(request);
		request.setAttribute("partId", partId);
		this.handelRecordPageTitle(request, null, partId, null);
		return "evaluate/evaluateRecord/contractor/evaluateRecordList.jsp";
	}

	@RequestMapping(value = "/contractor/getPageData", method = { RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> contractorGetPageData(HttpServletRequest request, DataQuery dq, String buildUnitName, String partId) {
		this.wrapTableQueryParams(request, dq);

		dq.putToMap("partId", partId);
		dq.putToMap("targetUnitId", this.getNowUser().getUnitId());
		dq.putToMap("status", EvaluateRecordDTO.STATUS_SUCCEED);
		dq.putToMap("likeBuildUnitName", StringUtils.isBlank(buildUnitName) ? null : "%" + buildUnitName + "%");
		dq.putToMap("formTypes", new String[] { EvaluateRecordDTO.FORM_TYPE_SEASON, EvaluateRecordDTO.FORM_TYPE_CONTRACT });
		Page<EvaluateRecordDTO> pageResult = this.evaluateRecordService.searchByPage(dq);
		return this.handlePageReult(pageResult);
	}

	// 承包商查看：用实际指标
	@RequestMapping("/contractor/view")
	public String contractorView(HttpServletRequest request, DataQuery dq, @RequestParam(value = "id", required = true) String id, Integer checked) {
		EvaluateRecordDTO result = this.evaluateRecordService.getDetailById(id);
		request.setAttribute("model", result);

		dq.clear();
		dq.setSidx("dictValue");
		dq.setSord("asc");
		// 不得评为“优秀”、“良好”情形
		dq.putToMap("dictType", BaseDict.EVAL_GRADE_SITUATION_GOOD);
		request.setAttribute("situationGoods", this.baseDictService.searchListByCondition(dq));
		// 直接评为“不合格”情形
		dq.putToMap("dictType", BaseDict.EVAL_GRADE_SITUATION_BAD);
		request.setAttribute("situationBads", this.baseDictService.searchListByCondition(dq));

		request.setAttribute("evalGradeText", EvaluateRecordDTO.EVAL_GRADE_TEXT);

		// 查看标记存在则设为已查看
		if (checked != null && checked == 1) {
			result.setChecked(EvaluateRecordDTO.CHECKED_TRUE);
			this.evaluateRecordService.updateChecked(result);
		}

		return "evaluate/evaluateRecord/contractor/viewEvaluateRecord.jsp";
	}

	@RequestMapping(value = "/skipAddEvaluateRecord")
	@Deprecated
	public String skipAddEvaluateRecord(HttpServletRequest request, DataQuery dq, String proId, String partId) {
		// 选评价表格 TODO
		dq.clear();
		dq.setNotQueryPage();
		dq.setSidx("sortNo");
		dq.setSord("asc");
		List<EvaluateFormDTO> forms = this.evaluateFormService.selectListByCondition(dq);
		request.setAttribute("forms", forms);

		request.setAttribute("proId", proId);
		request.setAttribute("partId", partId);

		// // 选项目 TODO
		dq.clear();
		dq.setNotQueryPage();
		dq.setSidx("proName");
		dq.setSord("asc");
		List<ProjectInfoDTO> projects = this.projectInfoService.selectListByCondition(dq);
		request.setAttribute("projects", projects);

		// 选工程 TODO
		dq.clear();
		dq.setNotQueryPage();
		dq.setSidx("proName");
		dq.setSord("asc");
		List<ProjectPartInfoDTO> projectInfos = this.projectPartInfoService.selectListByCondition(dq);
		request.setAttribute("projectInfos", projectInfos);
		return "evaluate/evaluateRecord/addEvaluateRecord.jsp";
	}

	@RequestMapping(value = "/addEvaluateRecord", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson addEvaluateRecord(EvaluateRecordDTO dto, @RequestParam String formId, String formType, String specificStep, String proId, String partId)
			throws Exception {

		String id = null;
		if (StringUtils.isBlank(partId)) {
			this.evaluateRecordService.judgeIfEvaluateRecordExist(formId, formType, proId, null);
			// 工程id为空，评价项目
			ProjectInfoDTO projectInfo = this.projectInfoService.getDetailById(proId);
			id = this.evaluateRecordService.addEvaluateRecord(formId, formType, projectInfo);
		} else {
			this.evaluateRecordService.judgeIfEvaluateRecordExist(formId, formType, null, partId);
			// 工程id非空，评价工程
			ProjectPartInfoDTO projectPartInfo = this.projectPartInfoService.getDetailById(partId);
			ProjectInfoDTO projectInfo = this.projectInfoService.getDetailById(projectPartInfo.getProId());
			id = this.evaluateRecordService.addEvaluateRecord(formId, formType, specificStep, projectInfo, projectPartInfo);
		}
		return new AjaxJson("评分表创建成功", AjaxJson.success, id);
	}

	@RequestMapping("/getDetail")
	public String loadDetail(HttpServletRequest request, DataQuery dq, @RequestParam(value = "id", required = true) String id) {
		EvaluateRecordDTO result = this.evaluateRecordService.getDetailById(id);
		request.setAttribute("model", result);

		// 选评价表格 TODO
		dq.clear();
		dq.setNotQueryPage();
		dq.setSidx("sortNo");
		dq.setSord("asc");
		List<EvaluateFormDTO> forms = this.evaluateFormService.selectListByCondition(dq);
		request.setAttribute("forms", forms);

		// 选项目 TODO
		dq.clear();
		dq.setNotQueryPage();
		dq.setSidx("proName");
		dq.setSord("asc");
		List<ProjectInfoDTO> projects = this.projectInfoService.selectListByCondition(dq);
		request.setAttribute("projects", projects);

		// 选工程 TODO
		dq.clear();
		dq.setNotQueryPage();
		dq.setSidx("proName");
		dq.setSord("asc");
		List<ProjectPartInfoDTO> projectInfos = this.projectPartInfoService.selectListByCondition(dq);
		request.setAttribute("projectInfos", projectInfos);
		return "evaluate/evaluateRecord/editEvaluateRecord.jsp";
	}

	@RequestMapping(value = "/editEvaluateRecord", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson updateEvaluateRecord(EvaluateRecordDTO dto) {

		this.evaluateRecordService.updateEvaluateRecord(dto);

		return new AjaxJson(this.EDIT_SUCCESS_MESSAGE, AjaxJson.success);
	}

	@RequestMapping(value = "/deleteEvaluateRecord", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson deleteEvaluateRecord(String[] ids) {
		this.evaluateRecordService.deleteEvaluateRecords(ids);
		return new AjaxJson(this.DEL_SUCCESS_MESSAGE, AjaxJson.success);
	}

	// ===============================================================

	// 住建局/发改局/建设单位 对代建单位：添加评价项目
	@RequestMapping(value = "/evaluate/project", method = { RequestMethod.GET })
	public String addEvaluateRecordForPro(HttpServletRequest request, DataQuery dq, @RequestParam String proId) throws Exception {

		// 住建局/发改局只评合同，不评季度

		// 代建单位 - 工程类型代码
		String engTypeCode = "DJ";
		dq.setNotQueryPage();
		dq.setSidx("sortNo");
		dq.setSord("asc");
		dq.putToMap("engTypeCode", engTypeCode);
		if (SecurityPrincipalUtil.checkIsHasRole(Role.ROLE_FG)) {
			// 发改局角色
			dq.putToMap("formName", "%发改%");
		} else if (SecurityPrincipalUtil.checkIsHasRole(Role.ROLE_HOUSING)) {
			// 住建局角色
			dq.putToMap("formName", "%住建%");
		} else if (SecurityPrincipalUtil.checkIsHasRole(Role.ROLE_BUILD_UNIT)) {
			// 住建局角色
			dq.putToMap("formName", "%建设单位%");
		}

		// 查出代建评分表
		List<EvaluateFormDTO> forms = this.evaluateFormService.selectListByCondition(dq);

		// 评价形式
		this.handleFormType(request);

		request.setAttribute("proId", proId);
		request.setAttribute("forms", forms);
		return "evaluate/evaluateRecord/addEvaluateRecord.jsp";
	}

	// 建设单位/代建单位对承包商：添加评价工程
	@RequestMapping(value = "/evaluate/projectPart", method = { RequestMethod.GET })
	public String addEvaluateRecordForPart(HttpServletRequest request, DataQuery dq, @RequestParam String partId) throws Exception {

		// 工程类型代码 => 评价表格
		ProjectPartInfoDTO projectPartInfo = this.projectPartInfoService.getDetailById(partId);
		dq.setNotQueryPage();
		dq.setSidx("sortNo");
		dq.setSord("asc");
		dq.putToMap("engTypeCode", projectPartInfo.getEngTypeCode());
		List<EvaluateFormDTO> forms = this.evaluateFormService.selectListByCondition(dq);

		// 评价形式
		this.handleFormType(request);

		// 造价咨询选择具体阶段
		if (EvaluateRecordDTO.ENG_TYPE_CODE_ZJZX.equals(projectPartInfo.getEngTypeCode())) {
			request.setAttribute("specificSteps", EvaluateRecordDTO.SPECIFICSTEPs);
		}

		request.setAttribute("partId", partId);
		request.setAttribute("forms", forms);
		return "evaluate/evaluateRecord/addEvaluateRecord.jsp";
	}

	// 填表：用模板指标
	@RequestMapping("/fillin")
	public String fillin(HttpServletRequest request, DataQuery dq, @RequestParam(value = "id", required = true) String id) {
		EvaluateRecordDTO result = this.evaluateRecordService.getDetailById(id);

		request.setAttribute("model", result);
		request.setAttribute("evalGradeText", EvaluateRecordDTO.EVAL_GRADE_TEXT);
		// 标识当前是填表页面
		request.setAttribute("pageType", "fillin");

		dq.clear();
		dq.setSidx("dictValue");
		dq.setSord("asc");
		// 不得评为“优秀”、“良好”情形
		dq.putToMap("dictType", BaseDict.EVAL_GRADE_SITUATION_GOOD);
		request.setAttribute("situationGoods", this.baseDictService.searchListByCondition(dq));
		// 直接评为“不合格”情形
		dq.putToMap("dictType", BaseDict.EVAL_GRADE_SITUATION_BAD);
		request.setAttribute("situationBads", this.baseDictService.searchListByCondition(dq));

		return "evaluate/evaluateRecord/fillinEvaluateRecord.jsp";
	}

	// 填表保存 & 提交
	@RequestMapping(value = "/addFillin", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson addFillin(HttpServletRequest request, DataQuery dq, EvaluateRecordDTO dto, String auditor) {
		this.evaluateRecordService.addEvaluateRecord(dto, dto.getIndexIds(), dto.getIndexVals(), auditor);
		return new AjaxJson(this.OPER_SUCCESS_MESSAGE, AjaxJson.success);
	}

	// 查看：用实际指标
	@RequestMapping("/view")
	public String view(HttpServletRequest request, DataQuery dq, @RequestParam(value = "id", required = true) String id) {
		EvaluateRecordDTO result = this.evaluateRecordService.getDetailById(id);
		request.setAttribute("model", result);

		dq.clear();
		dq.setSidx("dictValue");
		dq.setSord("asc");
		// 不得评为“优秀”、“良好”情形
		dq.putToMap("dictType", BaseDict.EVAL_GRADE_SITUATION_GOOD);
		request.setAttribute("situationGoods", this.baseDictService.searchListByCondition(dq));
		// 直接评为“不合格”情形
		dq.putToMap("dictType", BaseDict.EVAL_GRADE_SITUATION_BAD);
		request.setAttribute("situationBads", this.baseDictService.searchListByCondition(dq));

		request.setAttribute("evalGradeText", EvaluateRecordDTO.EVAL_GRADE_TEXT);
		return "evaluate/evaluateRecord/viewEvaluateRecord.jsp";
	}

	// 审核：用实际指标
	@RequestMapping("/audit")
	public String audit(HttpServletRequest request, DataQuery dq, @RequestParam(value = "id", required = true) String id) {
		EvaluateRecordDTO result = this.evaluateRecordService.getDetailById(id);
		request.setAttribute("model", result);

		dq.clear();
		dq.setSidx("dictValue");
		dq.setSord("asc");
		// 不得评为“优秀”、“良好”情形
		dq.putToMap("dictType", BaseDict.EVAL_GRADE_SITUATION_GOOD);
		request.setAttribute("situationGoods", this.baseDictService.searchListByCondition(dq));
		// 直接评为“不合格”情形
		dq.putToMap("dictType", BaseDict.EVAL_GRADE_SITUATION_BAD);
		request.setAttribute("situationBads", this.baseDictService.searchListByCondition(dq));

		request.setAttribute("evalGradeText", EvaluateRecordDTO.EVAL_GRADE_TEXT);
		return "evaluate/evaluateRecord/auditEvaluateRecord.jsp";
	}

	// 审核保存
	@RequestMapping(value = "/saveAudit", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson saveAudit(HttpServletRequest request, DataQuery dq, String id, String formType, BigDecimal totalScore, Short evalGrade,
			String situationGoods, String situationBads, String nodeId, String note, String[] indexIds, String[] indexVals) {
		this.evaluateRecordService.updateEvaluateRecord(dq, id, formType, totalScore, evalGrade, situationGoods, situationBads, nodeId, note, indexIds,
				indexVals);
		return new AjaxJson(this.OPER_SUCCESS_MESSAGE, AjaxJson.success);
	}

	// 履约异议反馈
	@RequestMapping("/getPleaContent")
	public String getPleaContent(HttpServletRequest request, DataQuery dq, @RequestParam(value = "id", required = true) String id) {
		EvaluateRecordDTO result = this.evaluateRecordService.getDetailById(id);
		request.setAttribute("model", result);
		return "evaluate/evaluateRecord/contractor/editPleaContent.jsp";
	}

	@RequestMapping(value = "/updatePleaContent", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson updatePleaContent(EvaluateRecordDTO dto) {
		this.evaluateRecordService.updatePleaContent(dto);
		return new AjaxJson("提交成功", AjaxJson.success);
	}

	// 查看反馈结果
	@RequestMapping("/viewPleaReply")
	public String viewPleaReply(HttpServletRequest request, DataQuery dq, @RequestParam(value = "id", required = true) String id) {
		EvaluateRecordDTO result = this.evaluateRecordService.getDetailById(id);
		request.setAttribute("model", result);
		return "evaluate/evaluateRecord/contractor/viewPleaReply.jsp";
	}

	// 异议反馈回复
	@RequestMapping("/getPleaReply")
	public String getPleaReply(HttpServletRequest request, DataQuery dq, @RequestParam(value = "id", required = true) String id) {
		EvaluateRecordDTO result = this.evaluateRecordService.getDetailById(id);
		request.setAttribute("model", result);
		return "evaluate/evaluateRecord/editPleaReply.jsp";
	}

	@RequestMapping(value = "/updatePleaReply", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson updatePleaReply(EvaluateRecordDTO dto) {
		this.evaluateRecordService.updatePleaReply(dto);
		return new AjaxJson("回复成功", AjaxJson.success);
	}

	// ========== ========== ========== 统计分析 ========== ========== ==========
	@RequestMapping(value = "/bestUnitTopK", method = { RequestMethod.POST, RequestMethod.GET })
	@ResponseBody
	public AjaxJson bestUnitTop20(DataQuery dq, EvaluateRecordDTO dto) {
		dq.putToMap("engTypeCode", StringUtils.isBlank(dto.getEngTypeCode()) ? null : dto.getEngTypeCode());
		List<Map<String, Object>> list = this.evaluateRecordService.bestUnitTopK(dq);
		return new AjaxJson("success", AjaxJson.success, list);
	}

	@RequestMapping(value = "/worstUnitTopK", method = { RequestMethod.POST, RequestMethod.GET })
	@ResponseBody
	public AjaxJson badUnitTop20(DataQuery dq, EvaluateRecordDTO dto) {
		dq.putToMap("engTypeCode", StringUtils.isBlank(dto.getEngTypeCode()) ? null : dto.getEngTypeCode());
		List<Map<String, Object>> list = this.evaluateRecordService.worstUnitTopK(dq);
		return new AjaxJson("success", AjaxJson.success, list);
	}

	@RequestMapping(value = "/yearUnitTopK", method = { RequestMethod.POST, RequestMethod.GET })
	@ResponseBody
	public AjaxJson yearUnitTop50(DataQuery dq, EvaluateRecordDTO dto) {
		String nowYear = new SimpleDateFormat("yyyy").format(new Date());
		dq.putToMap("year", Integer.valueOf(nowYear)); // 查询本年度的年度分数
		dq.putToMap("engTypeCode", StringUtils.isBlank(dto.getEngTypeCode()) ? null : dto.getEngTypeCode());
		List<Map<String, Object>> list = this.evaluateRecordService.yearUnitTopK(dq);
		return new AjaxJson("success", AjaxJson.success, list);
	}

	// 2019.03.11 查看红黑榜承包商履约评价
	@RequestMapping(value = "/statistic/viewPage", method = { RequestMethod.GET })
	public String statisticViewPage(HttpServletRequest request, @RequestParam String unitId) {
		this.wrapMenuTitle(request);
		request.setAttribute("unitId", unitId);
		this.handelRecordPageTitle(request, null, null, unitId);
		return "evaluate/evaluateRecord/statistic/evaluateRecordList.jsp";
	}

	@RequestMapping(value = "/statistic/getPageData", method = { RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> statisticLoadPageData(HttpServletRequest request, DataQuery dq, @RequestParam String unitId, String proName) {
		this.wrapTableQueryParams(request, dq);

		dq.putToMap("targetUni" + "" + "tId", unitId);
		dq.putToMap("status", EvaluateRecordDTO.STATUS_SUCCEED);
		dq.putToMap("likeProName", StringUtils.isBlank(proName) ? null : "%" + proName.trim() + "%");
		dq.putToMap("formTypes", new String[] { EvaluateRecordDTO.FORM_TYPE_SEASON, EvaluateRecordDTO.FORM_TYPE_CONTRACT });
		Page<EvaluateRecordDTO> pageResult = this.evaluateRecordService.searchByPage(dq);
		return this.handlePageReult(pageResult);
	}

	@RequestMapping(value = "/statUnitAvgScore", method = { RequestMethod.POST, RequestMethod.GET })
	@ResponseBody
	public AjaxJson statUnitAvgScore(EvaluateRecordDTO dto) {
		JSONObject obj = this.evaluateRecordService.statUnitAvgScore();

		// System.out.println(obj.toString());

		return new AjaxJson("success", AjaxJson.success, obj);
	}

	@RequestMapping(value = "/statContractorTypeAvgScore", method = { RequestMethod.POST, RequestMethod.GET })
	@ResponseBody
	public AjaxJson statContractorTypeAvgScore() {
		JSONObject obj = this.evaluateRecordService.statContractorTypeAvgScore();

		// System.out.println(obj.toString());

		return new AjaxJson("success", AjaxJson.success, obj);
	}

	@RequestMapping(value = "/getNumOfEngType", method = { RequestMethod.POST, RequestMethod.GET })
	@ResponseBody
	public AjaxJson getNumOfEngType() {
		JSONObject obj = this.evaluateRecordService.getNumOfEngType();

		// System.out.println(obj.toString());

		return new AjaxJson("success", AjaxJson.success, obj);
	}

	@RequestMapping(value = "/statUnitScoreTime", method = { RequestMethod.POST, RequestMethod.GET })
	@ResponseBody
	public AjaxJson statUnitScoreTime(EvaluateRecordDTO dto) {
		JSONObject obj = this.evaluateRecordService.statUnitScoreTime();

		System.out.println(obj.toString());

		return new AjaxJson("success", AjaxJson.success, obj);
	}

	// -----------------------承包商年度履约评价----------------------------//
	@RequestMapping(value = "/contractorYearEvaluateRecord", method = { RequestMethod.GET })
	public String contractorYearEvaluateRecord(HttpServletRequest request) {
		this.wrapMenuTitle(request);

		List<EngineeringTypeDTO> allType = this.engineeringTypeService.selectListByCondition(new DataQuery());
		EngineeringTypeDTO djType = new EngineeringTypeDTO();
		djType.setTypeCode("DJ");
		djType.setTypeName("代建");
		allType.add(djType);
		request.setAttribute("allEngType", allType);

		return "evaluate/evaluateRecord/statistic/contractorYearEvaluateRecordList.jsp";
	}

	@RequestMapping(value = "/getContractorYearEvaluateRecordPageData", method = { RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> getContractorYearEvaluateRecordPageData(HttpServletRequest request, DataQuery dq, String targetUnitName, String engTypeCode) {
		this.wrapTableQueryParams(request, dq);

		dq.putToMap("targetUnitName", StringUtils.isBlank(targetUnitName) ? null : "%" + targetUnitName + "%");
		dq.putToMap("engTypeCode", StringUtils.isBlank(engTypeCode) ? null : engTypeCode);
		dq.putToMap("formType", EvaluateRecordDTO.FORM_TYPE_YEAR);
		dq.putToMap("certainYear", Calendar.getInstance().get(Calendar.YEAR));
		Page<EvaluateRecordDTO> pageResult = this.evaluateRecordService.searchContractorYearEvaluateRecordByPage(dq);
		return this.handlePageReult(pageResult);
	}

	@RequestMapping(value = "/createContractorYearEvaluateRecord", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson createContractorYearEvaluateRecord() {
		this.evaluateRecordService.createContractorYearEvaluateRecord();
		return new AjaxJson("生成成功", AjaxJson.success);
	}

	/**
	 * 查看本年度所有季度评价
	 * 
	 * @param request
	 * @param targetUnitId
	 * @param engTypeCode
	 * @return
	 */
	@RequestMapping(value = "/contractorAllEvaluateRecordList", method = { RequestMethod.GET })
	public String contractorYearEvaluateRecord(HttpServletRequest request, String targetUnitId, String engTypeCode) {
		UnitDTO targetUnit = this.unitService.getDetailById(targetUnitId);
		request.setAttribute("targetUnitName", targetUnit.getUnitName());
		request.setAttribute("targetUnitId", targetUnitId);
		request.setAttribute("engTypeCode", engTypeCode);
		return "evaluate/evaluateRecord/statistic/contractorAllEvaluateRecordList.jsp";
	}

	@RequestMapping(value = "/getContractorAllEvaluateRecordPageData", method = { RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> getContractorAllEvaluateRecordPageData(HttpServletRequest request, DataQuery dq, String targetUnitId, String engTypeCode) {
		this.wrapTableQueryParams(request, dq);

		dq.putToMap("targetUnitId", targetUnitId);
		dq.putToMap("engTypeCode", engTypeCode);
		dq.putToMap("formTypes", new String[] { EvaluateRecordDTO.FORM_TYPE_SEASON, EvaluateRecordDTO.FORM_TYPE_CONTRACT });
		dq.putToMap("certainYear", Calendar.getInstance().get(Calendar.YEAR));
		Page<EvaluateRecordDTO> pageResult = this.evaluateRecordService.searchByPageWithExec(dq);
		return this.handlePageReult(pageResult);
	}

	// -----------------------------------------------------------//

	/**
	 * 处理【查看履约评价】标题
	 * 
	 * @param request
	 * @param proId
	 * @param partId
	 * @param unitId
	 */
	private void handelRecordPageTitle(HttpServletRequest request, String proId, String partId, String unitId) {
		String title = "";

		if (StringUtils.isNotBlank(proId)) {
			ProjectInfoDTO projectInfoDTO = this.projectInfoService.getDetailById(proId);
			title = projectInfoDTO.getProName();
			if (GobalVal.EVALUATE_END == projectInfoDTO.getEvaluateStatus()) {
				// 查询该合同的综合评分
				DataQuery dq = new DataQuery();
				dq.putToMap("proId", partId);
				dq.putToMap("formType", EvaluateRecordDTO.FORM_TYPE_COMPREHENSIVE);
				EvaluateRecordDTO recordDTO = this.evaluateRecordService.selectOneByCondition(dq);
				if (recordDTO != null) {
					title = title + "[综合得分:" + recordDTO.getTotalScore() + "]";
				}
			}
		}
		if (StringUtils.isNotBlank(unitId)) {
			UnitDTO unitDTO = this.unitService.getDetailById(unitId);
			title = unitDTO.getUnitName();
		} else if (StringUtils.isNotBlank(partId)) {
			ProjectPartInfoDTO partInfoDTO = this.projectPartInfoService.getDetailById(partId);
			title = partInfoDTO.getPartName();
			if (GobalVal.EVALUATE_END == partInfoDTO.getEvaluateStatus()) {
				// 查询该合同的综合评分
				DataQuery dq = new DataQuery();
				dq.putToMap("partId", partId);
				dq.putToMap("formType", EvaluateRecordDTO.FORM_TYPE_COMPREHENSIVE);
				EvaluateRecordDTO recordDTO = this.evaluateRecordService.selectOneByCondition(dq);
				if (recordDTO != null) {
					title = title + "[综合得分:" + recordDTO.getTotalScore() + "]";
				}
			}

		}
		title = title + " - 履约评价管理";
		request.setAttribute("TITLE", title);

	}

	private void handelDjDetialRecordPageTitle(HttpServletRequest request, String connectRecordId) {

		EvaluateRecordDTO recordDTO = this.evaluateRecordService.getDetailById(connectRecordId);
		String title = recordDTO.getProName();

		if (recordDTO.getFormType().equals(EvaluateRecordDTO.FORM_TYPE_CONTRACT)) {
			title = title + " - 合同履约评价详情";
		}
		if (recordDTO.getFormType().equals(EvaluateRecordDTO.FORM_TYPE_SEASON)) {
			title = title + " - 季度履约评价详情";
		}
		request.setAttribute("TITLE", title);
	}

	/**
	 * 设置评价形式
	 */
	private void handleFormType(HttpServletRequest request) {
		Map<String, String> resultMap = new LinkedHashMap<String, String>();

		// 判断当前时间能否进行季度履约评价
		Boolean canSeasonEvaluate = this.evaluateTimeSettingService.isTodayBetweenEvaluateTime();
		if (canSeasonEvaluate == true)
			// 住建局，发改不需要进行季度履约评价
			if (SecurityPrincipalUtil.checkIsHasRole(Role.ROLE_FG) == false && SecurityPrincipalUtil.checkIsHasRole(Role.ROLE_HOUSING) == false) {
				resultMap.put("季度履约评价", EvaluateRecordDTO.FORM_TYPE_SEASON);
			}
		resultMap.put("合同完成履约评价", EvaluateRecordDTO.FORM_TYPE_CONTRACT);
		request.setAttribute("formTypeMap", resultMap);

	}
}
