package com.spr.web.system.service;

import java.util.List;
import java.util.Map;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.dto.ZtreeDTO;
import com.spr.web.system.dto.engineering.EngineeringTypeDTO;

public interface IEngineeringTypeService {

	Page<EngineeringTypeDTO> searchByPage(DataQuery dq);

	Map<String, String> selectCodeNameMapByCondition(DataQuery dq);

	EngineeringTypeDTO selectOneByCondition(DataQuery dq);

	List<EngineeringTypeDTO> selectListByCondition(DataQuery dq);

	EngineeringTypeDTO getDetailById(String id);

	EngineeringTypeDTO getDetailByTypeCode(String typeCode);

	void addEngineeringType(EngineeringTypeDTO dto);

	void updateEngineeringType(EngineeringTypeDTO dto);

	void deleteEngineeringTypes(String[] ids);

	Boolean judgeTypeCodeExist(String typeCode);

	List<ZtreeDTO> getUnitTreeData();

}
