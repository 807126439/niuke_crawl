package com.spr.web.project.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.spr.core.annotations.DbField;
import com.spr.core.common.entity.UUIDEntity;

public class ProjectInfo extends UUIDEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final Short IMPORT_SRC = 1; // 导入来源

	public static final Short INTERFACE_SRC = 2; // 接口来源

	public static final Short INPUT_SRC = 3; // 手动录入

	private String apiProId; // 用于记录接口导入的项目id

	private String buildNo;

	private String proName;

	private String proAddr;

	private String buildUnitId;

	private String agentUnitId;

	private Date registerTime;

	private Date applyTime;

	private BigDecimal investAmount;

	private String linkMan;

	private String linkTel;

	private Date gmtInput;

	private String memo;

	private Short evaluateStatus; // 判断是否完成合同评价 0:未完成 1：完成

	private Short status;

	private Short flag;

	private Short srcFlag;

	private String createBy;

	private String updateBy;

	public ProjectInfo() {
		super();
	}

	@DbField(name = "build_no")
	public String getBuildNo() {
		return buildNo;
	}

	public void setBuildNo(String buildNo) {
		this.buildNo = buildNo == null ? null : buildNo.trim();
	}

	@DbField(name = "pro_name")
	public String getProName() {
		return proName;
	}

	public void setProName(String proName) {
		this.proName = proName == null ? null : proName.trim();
	}

	@DbField(name = "pro_addr")
	public String getProAddr() {
		return proAddr;
	}

	public void setProAddr(String proAddr) {
		this.proAddr = proAddr == null ? null : proAddr.trim();
	}

	@DbField(name = "build_unit_id")
	public String getBuildUnitId() {
		return buildUnitId;
	}

	public void setBuildUnitId(String buildUnitId) {
		this.buildUnitId = buildUnitId == null ? null : buildUnitId.trim();
	}

	@DbField(name = "agent_unit_id")
	public String getAgentUnitId() {
		return agentUnitId;
	}

	public void setAgentUnitId(String agentUnitId) {
		this.agentUnitId = agentUnitId == null ? null : agentUnitId.trim();
	}

	@DbField(name = "api_pro_id")
	public String getApiProId() {
		return apiProId;
	}

	public void setApiProId(String apiProId) {
		this.apiProId = apiProId;
	}

	@DbField(name = "register_time")
	public Date getRegisterTime() {
		return registerTime;
	}

	public void setRegisterTime(Date registerTime) {
		this.registerTime = registerTime;
	}

	@DbField(name = "apply_time")
	public Date getApplyTime() {
		return applyTime;
	}

	public void setApplyTime(Date applyTime) {
		this.applyTime = applyTime;
	}

	@DbField(name = "invest_amount")
	public BigDecimal getInvestAmount() {
		return investAmount;
	}

	public void setInvestAmount(BigDecimal investAmount) {
		this.investAmount = investAmount;
	}

	@DbField(name = "link_man")
	public String getLinkMan() {
		return linkMan;
	}

	public void setLinkMan(String linkMan) {
		this.linkMan = linkMan == null ? null : linkMan.trim();
	}

	@DbField(name = "link_tel")
	public String getLinkTel() {
		return linkTel;
	}

	public void setLinkTel(String linkTel) {
		this.linkTel = linkTel == null ? null : linkTel.trim();
	}

	@DbField(name = "gmt_input")
	public Date getGmtInput() {
		return gmtInput;
	}

	public void setGmtInput(Date gmtInput) {
		this.gmtInput = gmtInput;
	}

	@DbField(name = "memo")
	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo == null ? null : memo.trim();
	}

	@DbField(name = "status")
	public Short getStatus() {
		return status;
	}

	public void setStatus(Short status) {
		this.status = status;
	}

	@DbField(name = "flag")
	public Short getFlag() {
		return flag;
	}

	public void setFlag(Short flag) {
		this.flag = flag;
	}

	@DbField(name = "src_flag")
	public Short getSrcFlag() {
		return srcFlag;
	}

	public void setSrcFlag(Short srcFlag) {
		this.srcFlag = srcFlag;
	}

	@DbField(name = "create_by")
	public String getCreateBy() {
		return createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy == null ? null : createBy.trim();
	}

	@DbField(name = "update_by")
	public String getUpdateBy() {
		return updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy == null ? null : updateBy.trim();
	}

	@DbField(name = "evaluate_status")
	public Short getEvaluateStatus() {
		return evaluateStatus;
	}

	public void setEvaluateStatus(Short evaluateStatus) {
		this.evaluateStatus = evaluateStatus;
	}

	@Override
	public String toString() {
		return "ProjectInfo [apiProId=" + apiProId + ", buildNo=" + buildNo + ", proName=" + proName + ", proAddr=" + proAddr + ", buildUnitId=" + buildUnitId
				+ ", agentUnitId=" + agentUnitId + ", registerTime=" + registerTime + ", applyTime=" + applyTime + ", investAmount=" + investAmount
				+ ", linkMan=" + linkMan + ", linkTel=" + linkTel + ", gmtInput=" + gmtInput + ", memo=" + memo + ", status=" + status + ", flag=" + flag
				+ ", srcFlag=" + srcFlag + ", createBy=" + createBy + ", updateBy=" + updateBy + "]";
	}

}