package com.spr.web.evaluate.dto.relation;

import com.spr.core.common.dto.UUIDDTO;

public class EvaluateContractorRelationDTO extends UUIDDTO {

    private Integer sortNo;

    private String contractorTypeCode;

    private String evalFormId;

    private Short evalWay;

    private Short status;

    private String createBy;

    private String updateBy;

    public Integer getSortNo() {
        return sortNo;
    }

    public void setSortNo(Integer sortNo) {
        this.sortNo = sortNo;
    }

    public String getContractorTypeCode() {
        return contractorTypeCode;
    }

    public void setContractorTypeCode(String contractorTypeCode) {
        this.contractorTypeCode = contractorTypeCode == null ? null : contractorTypeCode.trim();
    }

    public String getEvalFormId() {
        return evalFormId;
    }

    public void setEvalFormId(String evalFormId) {
        this.evalFormId = evalFormId == null ? null : evalFormId.trim();
    }

    public Short getEvalWay() {
        return evalWay;
    }

    public void setEvalWay(Short evalWay) {
        this.evalWay = evalWay;
    }

    public Short getStatus() {
        return status;
    }

    public void setStatus(Short status) {
        this.status = status;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }
}