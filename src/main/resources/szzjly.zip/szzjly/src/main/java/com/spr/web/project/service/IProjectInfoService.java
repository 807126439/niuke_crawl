package com.spr.web.project.service;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.dto.ZtreeDTO;
import com.spr.web.project.dto.project.ProjectInfoDTO;

public interface IProjectInfoService {

	/**
	 * id : proName
	 * 
	 * @param dq
	 * @return
	 * @date 2019-2-25
	 * @author wanve_java_cjy
	 */
	Map<String, String> selectIdNameMapByCondition(DataQuery dq);

	List<ProjectInfoDTO> selectListByCondition(DataQuery dq);

	Page<ProjectInfoDTO> searchByPage(DataQuery dq);

	ProjectInfoDTO getDetailById(String id);

	void deleteProjectInfos(String[] ids);

	String importProjectInfo(CommonsMultipartFile file);

	String importProjectInfoAndEvaluate(CommonsMultipartFile file);

	List<ZtreeDTO> getProjectInfoTreeData();

	/**
	 * 将项目的评价状态设置为完成
	 * 
	 * @param proId
	 */
	void setProjectEvaluateStatus(String proId, Short evaluateStatus);

	/**
	 * 判断项目评价状态是否完成(true:完成,false:未完成)
	 * 
	 * @param partId
	 * @return
	 */
	Boolean isProjectEvaluateStatusFinished(String proId);

	void updateProjectInfo(ProjectInfoDTO dto);

	void addProjectInfo(ProjectInfoDTO dto);

	List<Map<String, Object>> getNotEvaluateProList();
}
