package com.spr.web.system.constant;

public class AuthTypeIconConsts {
	
	public static final String AUTH_MENU = "images/auth/auth_menu.png";
	public static final String AUTH_ACCESS = "images/auth/auth_access.png";
	public static final String AUTH_BUTTON = "images/auth/auth_button.png";

}
