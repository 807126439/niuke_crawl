package com.spr.web.flow.service;

import java.util.List;
import java.util.Map;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.GeneralizeParam;
import com.spr.core.common.bean.Page;
import com.spr.web.flow.constant.DefinitionCodeConsts;
import com.spr.web.flow.dto.def.ProcDefDTO;

public interface IProcDefService {

	Page<ProcDefDTO> searchByPage(DataQuery dq);

	ProcDefDTO getDetailById(String id);

	void addProcDef(ProcDefDTO dto);

	void updateProcDef(ProcDefDTO dto);

	void updateSnByCode(String eventNo, String processCode);

	void deleteProcDefs(String[] ids);

	List<DefinitionCodeConsts> getProcDefCode(String mycode);

	String generalizeNumbTemplate(String processCode, GeneralizeParam param);

	int getSnByCode(String year, String processCode);

	ProcDefDTO getDetailByParam(Map<String, Object> queryMap);

}
