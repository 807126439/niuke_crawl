package com.spr.web.system.dao;

import com.spr.core.common.dao.IBaseDao;
import com.spr.web.system.dto.white.SysWhiteDomainDTO;
import com.spr.web.system.entity.SysWhiteDomain;
import java.util.List;
import java.util.Map;

public interface ISysWhiteDomainDao extends IBaseDao<String, SysWhiteDomain> {

    Long countByCondition(Map<String, Object> queryMap);

    List<SysWhiteDomainDTO> selectListByCondition(Map<String, Object> queryMap);

    SysWhiteDomainDTO getDetailById(String id);
}