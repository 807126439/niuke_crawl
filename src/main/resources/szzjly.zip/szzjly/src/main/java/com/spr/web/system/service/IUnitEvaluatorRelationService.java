package com.spr.web.system.service;

import java.util.List;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.web.system.dto.unit.UnitEvaluatorRelationDTO;

public interface IUnitEvaluatorRelationService {

	List<UnitEvaluatorRelationDTO> selectListByCondition(DataQuery dq);

	Page<UnitEvaluatorRelationDTO> searchByPage(DataQuery dq);

	UnitEvaluatorRelationDTO getDetailById(String id);

	void addUnitEvaluatorRelation(UnitEvaluatorRelationDTO dto);

	void updateUnitEvaluatorRelation(UnitEvaluatorRelationDTO dto);

	void deleteUnitEvaluatorRelations(String[] ids);

	void setUnitEvaluatorRelation(String unitId, String userIds);

	String getunitEvaluatorList(String unitId);

}
