package com.spr.web.evaluate.service.impl;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.service.BaseService;
import com.spr.core.common.utils.Assert;
import com.spr.web.evaluate.dao.IEvaluateRecordIndexDao;
import com.spr.web.evaluate.dto.form.EvaluateFormIndexDTO;
import com.spr.web.evaluate.dto.record.EvaluateRecordDTO;
import com.spr.web.evaluate.dto.record.EvaluateRecordIndexDTO;
import com.spr.web.evaluate.dto.record.EvaluateRecordInputDTO;
import com.spr.web.evaluate.entity.EvaluateRecordIndex;
import com.spr.web.evaluate.service.IEvaluateFormIndexService;
import com.spr.web.evaluate.service.IEvaluateRecordIndexService;

@Service("evaluateRecordIndexService")
@Transactional
public class EvaluateRecordIndexServiceImpl extends BaseService implements IEvaluateRecordIndexService {

	
   @Resource
   private IEvaluateRecordIndexDao evaluateRecordIndexDao;
	@Resource
	private IEvaluateFormIndexService evaluateFormIndexService;

   @Override
   public Map<String, EvaluateRecordIndexDTO> selectOriginModelMapByCondition(DataQuery dq) {
		List<EvaluateRecordIndexDTO> resultlist = this.selectListByCondition(dq);
		
		Map<String, EvaluateRecordIndexDTO> map = new HashMap<String, EvaluateRecordIndexDTO>();
		for (EvaluateRecordIndexDTO dto : resultlist) {
			map.put(dto.getOriginalId(), dto);
		}
   		return map;
   }

   @Override
   public EvaluateRecordIndexDTO selectOneByCondition(DataQuery dq) {
	   dq.setPageSize(1);
		List<EvaluateRecordIndexDTO> resultlist = this.selectListByCondition(dq);
		
		if (resultlist == null || resultlist.isEmpty()) {
			return null;
		}
   		return resultlist.get(0);
   }
   
   @Override
   public List<EvaluateRecordIndexDTO> selectListByCondition(DataQuery dq) {
	   dq.assemblePageOffset();
	   dq.assembleOrderInfo(EvaluateRecordIndex.class, null);
	   List<EvaluateRecordIndexDTO> resultlist = this.evaluateRecordIndexDao.selectListByCondition(dq.getQueryMap());
	   return resultlist;
   }
   
   /**
    * 分页查询
    * @param dq
    */
   @Override
   public Page<EvaluateRecordIndexDTO> searchByPage(DataQuery dq) {
   		
   		Long recTotal = this.evaluateRecordIndexDao.countByCondition(dq.assemblePageOffset().getQueryMap());
		dq.assembleOrderInfo(EvaluateRecordIndex.class, null);
		List<EvaluateRecordIndexDTO> resultlist = this.evaluateRecordIndexDao.selectListByCondition(dq.getQueryMap());
   
   		return new Page<EvaluateRecordIndexDTO>(dq.getCurrentPage(), dq.getPageSize(), resultlist, recTotal);
   }
   
   
   /**
    * 查询详细
    * @param id
    */
   @Override
   public EvaluateRecordIndexDTO getDetailById(String id){
   	   Assert.hasText(id, Assert.NULL_PARAM_STR("id")); 
   	   
   
   	   EvaluateRecordIndexDTO result = this.evaluateRecordIndexDao.getDetailById(id);
   	   Assert.notNull(result,Assert.EMPTY_REOCRD_STR);
   	   
   	   return result;
   }
   
   
   
   
   /**
    * 添加
    * @param dto
   	*/
   @Override
   public String addEvaluateRecordIndex(EvaluateRecordIndexDTO dto){
   
   	  EvaluateRecordIndex model = new EvaluateRecordIndex();
	  model.setEvalId(dto.getEvalId()); 	  
	  model.setOriginalId(dto.getOriginalId()); 	  
	  model.setSortNo(dto.getSortNo()); 	  
	  model.setSortName(dto.getSortName()); 	  
	  model.setIndexName(dto.getIndexName()); 	  
	  model.setScore(dto.getScore()); 	  
	  model.setIndexConten(dto.getIndexConten()); 	  
	  model.setStandard(dto.getStandard()); 	  
	  model.setParentId(dto.getParentId()); 	  
	  model.setLevel(dto.getLevel()); 	  
	  model.setStatus(dto.getStatus()); 	  
	  model.setFlag(dto.getFlag()); 	  
	  model.setCreateBy(this.getNowUser().getUsername()); 	  
	  model.setUpdateBy(this.getNowUser().getUsername()); 	  
	  model.setGmtCreate(new Date()); 	  
	  model.setGmtModified(new Date()); 	  
   
   	  this.evaluateRecordIndexDao.insert(model);
   	  
   
      this.writeInfoLog("Add: "+model.toString());
      
      return model.getId();
   }
   
   
   
   /**
    * 修改
    * @param dto
   	*/
   @Override
   public void updateEvaluateRecordIndex(EvaluateRecordIndexDTO dto){
   	    Assert.hasText(dto.getId(), Assert.NULL_PARAM_STR("id")); 
    	
    	EvaluateRecordIndex model = this.evaluateRecordIndexDao.getById(dto.getId());
    	Assert.notNull(model,Assert.EMPTY_REOCRD_STR);
    	
	  	model.setEvalId(dto.getEvalId()); 	  
	  	model.setOriginalId(dto.getOriginalId()); 	  
	  	model.setSortNo(dto.getSortNo()); 	  
	  	model.setSortName(dto.getSortName()); 	  
	  	model.setIndexName(dto.getIndexName()); 	  
	  	model.setScore(dto.getScore()); 	  
	  	model.setIndexConten(dto.getIndexConten()); 	  
	  	model.setStandard(dto.getStandard()); 	  
	  	model.setParentId(dto.getParentId()); 	  
	  	model.setLevel(dto.getLevel()); 	  
	  	model.setStatus(dto.getStatus()); 	  
	  	model.setFlag(dto.getFlag()); 	  
	  	// model.setCreateBy(this.getNowUser().getUsername()); 	  
	  	model.setUpdateBy(this.getNowUser().getUsername()); 	  
	  	// model.setGmtCreate(new Date()); 	  
	  	model.setGmtModified(new Date()); 	  
    	    	
    	this.evaluateRecordIndexDao.update(model);
    	
   
    	this.writeInfoLog("Update: "+model.toString());
        
   }
   
   
   
    /**
   	 * 删除
   	 * @param ids
   	 */
   	@Override
    public void deleteEvaluateRecordIndexs(String[] ids){
    	for (int i = 0; i < ids.length; i++) {
			this.evaluateRecordIndexDao.deleteById(ids[i]);
			
			
	        this.writeInfoLog("Delete id:" + ids[i]);
	        
		}
    }


	// 获取子评分指标
	@Override
	public List<EvaluateRecordIndexDTO> getSubIndexList(DataQuery dq, String parentId) {
		dq.clear();
		dq.setNotQueryPage();
		dq.setSidx("sortNo");
		dq.setSord("asc");
		dq.putToMap("parentId", parentId);
		List<EvaluateRecordIndexDTO> list = this.selectListByCondition(dq);
		if (list == null || list.isEmpty()) {
			return null;
		}

		for (EvaluateRecordIndexDTO dto : list) {
			List<EvaluateRecordIndexDTO> subList = this.getSubIndexList(dq, dto.getId());
			dto.setSubIndexList(subList);
		}
		return list;
	}
	
	// 获取子评分指标
	@Override
	public List<EvaluateRecordIndexDTO> getSubIndexList(DataQuery dq, String parentId, Map<String, BigDecimal> indexInputMap) {
		dq.clear();
		dq.setNotQueryPage();
		dq.setSidx("sortNo");
		dq.setSord("asc");
		dq.putToMap("parentId", parentId);
		List<EvaluateRecordIndexDTO> list = this.selectListByCondition(dq);
		if (list == null || list.isEmpty()) {
			return null;
		}

		for (EvaluateRecordIndexDTO dto : list) {
   			dto.setInputVal(indexInputMap.get(dto.getId()));
			List<EvaluateRecordIndexDTO> subList = this.getSubIndexList(dq, dto.getId(), indexInputMap);
			dto.setSubIndexList(subList);
		}
		return list;
	}
	
	// 获取子评分指标
	@Override
	public List<EvaluateRecordIndexDTO> getSubIndexListWithModified(DataQuery dq, String parentId, Map<String, EvaluateRecordInputDTO> indexInputMap) {
		dq.clear();
		dq.setNotQueryPage();
		dq.setSidx("sortNo");
		dq.setSord("asc");
		dq.putToMap("parentId", parentId);
		List<EvaluateRecordIndexDTO> list = this.selectListByCondition(dq);
		if (list == null || list.isEmpty()) {
			return null;
		}

		for (EvaluateRecordIndexDTO dto : list) {
			EvaluateRecordInputDTO input = indexInputMap.get(dto.getId());
   			dto.setInputVal(input == null ? null : input.getInputVal());
   			dto.setIsModified(input == null ? null : input.getIsModified());
			List<EvaluateRecordIndexDTO> subList = this.getSubIndexListWithModified(dq, dto.getId(), indexInputMap);
			dto.setSubIndexList(subList);
		}
		return list;
	}
	
	
	// copy index from form to record
	public Map<String, EvaluateRecordIndexDTO> copyIndex(EvaluateRecordDTO dto) {
		// 获取 模板指标id-实际指标 映射
		DataQuery dq = new DataQuery();
		dq.setNotQueryPage();
		dq.putToMap("evalId", dto.getId());
		Map<String, EvaluateRecordIndexDTO> originModelMap = this.selectOriginModelMapByCondition(dq);
		// 获取模板指标树
		List<EvaluateFormIndexDTO> formIndexList = this.evaluateFormIndexService.getSubIndexList(dq, dto.getFormId());
		
		// copy level by level
		for (EvaluateFormIndexDTO formIndex : formIndexList) {
			this.copyIndex(dto, originModelMap, formIndex);
		}
		return originModelMap;
	}
	
	// TODO delete not exists
	private void copyIndex(EvaluateRecordDTO dto, Map<String, EvaluateRecordIndexDTO> originModelMap, EvaluateFormIndexDTO formIndex) {
		EvaluateRecordIndexDTO recordIndex = originModelMap.get(formIndex.getId());
		if (recordIndex != null) {
			// already exists, update
			recordIndex.setSortName(formIndex.getSortName());
			recordIndex.setIndexName(formIndex.getIndexName());
			recordIndex.setScore(formIndex.getScore());
			recordIndex.setIndexConten(formIndex.getIndexConten());
			recordIndex.setStandard(formIndex.getStandard());
			this.updateEvaluateRecordIndex(recordIndex);
		} else {
			// not exists, add
			recordIndex = new EvaluateRecordIndexDTO();
			EvaluateRecordIndexDTO parentIndex = originModelMap.get(formIndex.getParentId());
			recordIndex.setEvalId(dto.getId());
			recordIndex.setOriginalId(formIndex.getId());
			recordIndex.setSortNo(formIndex.getSortNo());
			recordIndex.setSortName(formIndex.getSortName());
			recordIndex.setIndexName(formIndex.getIndexName());
			recordIndex.setScore(formIndex.getScore());
			recordIndex.setIndexConten(formIndex.getIndexConten());
			recordIndex.setStandard(formIndex.getStandard());
			recordIndex.setParentId(parentIndex == null ? dto.getId() : parentIndex.getId());
			recordIndex.setLevel(formIndex.getLevel());
			recordIndex.setStatus(formIndex.getStatus());
			recordIndex.setFlag(formIndex.getFlag());
			String id = this.addEvaluateRecordIndex(recordIndex);
			recordIndex.setId(id);
			originModelMap.put(recordIndex.getOriginalId(), recordIndex);
		}
		
		// copy sub index
		if (formIndex.getSubIndexList() == null || formIndex.getSubIndexList().isEmpty()) {
			return;
		}
		for (EvaluateFormIndexDTO subFormIndex : formIndex.getSubIndexList()) {
			this.copyIndex(dto, originModelMap, subFormIndex);
		}
	}
}
