package com.spr.web.flow.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.spr.core.common.dao.IBaseDao;
import com.spr.web.flow.dto.exec.ExecIdentitylinkDTO;
import com.spr.web.flow.entity.ExecIdentitylink;
import com.spr.web.system.dto.user.WeiUserDTO;

public interface IExecIdentitylinkDao extends IBaseDao<String, ExecIdentitylink> {

	Long countByCondition(Map<String, Object> queryMap);

	List<ExecIdentitylinkDTO> selectListByCondition(Map<String, Object> queryMap);

	ExecIdentitylinkDTO getDetailById(String id);

	int deleteByProcInstId(String procInstId);

	int updateStatusByNodeId(@Param("status") Short status, @Param("nodeId") String nodeId);

	List<WeiUserDTO> getUserInfoByNodeId(String nodeId);

}