package com.spr.web.evaluate.dto.form;

import java.util.HashMap;
import java.util.Map;

import com.spr.core.common.dto.UUIDDTO;

public class EvaluateFormDTO extends UUIDDTO {
	
	// 阶段：stage:阶段, end:最终
	public static final String FORMTYPE_STAGE = "stage";
	public static final String FORMTYPE_END = "end";
	@SuppressWarnings({ "serial" })
	public static final Map<String, String> FORMTYPE_MAP = new HashMap<String, String>(){
		{
			put(FORMTYPE_STAGE, "阶段");
			put(FORMTYPE_END, "最终");
		}
	};
	
	// 状态：0: 禁用 1: 启用
	@Deprecated
	public static final short STATUS_DISABLE = 0;
	@Deprecated
	public static final short STATUS_ENABLE = 1;
	@SuppressWarnings("serial")
	@Deprecated
	public static final Map<Short, String> STATUS_MAP = new HashMap<Short, String>(){
		{
			put(STATUS_DISABLE, "禁用");
			put(STATUS_ENABLE, "启用");
		}
	};
	
	// 发布状态：0: 未发布 1: 已发布
	@Deprecated
	public static final short FLAG_UNPUBLISHED = 0;
	@Deprecated
	public static final short FLAG_PUBLISHED = 1;
	@SuppressWarnings("serial")
	@Deprecated
	public static final Map<Short, String> FLAG_MAP = new HashMap<Short, String>(){
		{
			put(FLAG_UNPUBLISHED, "未发布");
			put(FLAG_PUBLISHED, "已发布");
		}
	};

    private Integer sortNo;

    private String formName;

    private String engTypeCode;
    private String engTypeName;

    private String formType;

    private String memo;

    private Short status;
    private String statusText;

    private Short flag;
    private String flagText;

    private String createBy;

    private String updateBy;
    
    private String indexId;
    private EvaluateFormIndexDTO index;
    
    /**
	 * @return the statusText
	 */
	public String getStatusText() {
		return statusText;
	}

	/**
	 * @param statusText the statusText to set
	 */
	public void setStatusText(String statusText) {
		this.statusText = statusText;
	}

	/**
	 * @return the flagText
	 */
	public String getFlagText() {
		return flagText;
	}

	/**
	 * @param flagText the flagText to set
	 */
	public void setFlagText(String flagText) {
		this.flagText = flagText;
	}


	/**
	 * @return the engTypeCode
	 */
	public String getEngTypeCode() {
		return engTypeCode;
	}

	/**
	 * @param engTypeCode the engTypeCode to set
	 */
	public void setEngTypeCode(String engTypeCode) {
		this.engTypeCode = engTypeCode;
	}

	/**
	 * @return the engTypeName
	 */
	public String getEngTypeName() {
		return engTypeName;
	}

	/**
	 * @param engTypeName the engTypeName to set
	 */
	public void setEngTypeName(String engTypeName) {
		this.engTypeName = engTypeName;
	}

	/**
	 * @return the indexId
	 */
	public String getIndexId() {
		return indexId;
	}

	/**
	 * @param indexId the indexId to set
	 */
	public void setIndexId(String indexId) {
		this.indexId = indexId;
	}

	/**
	 * @return the index
	 */
	public EvaluateFormIndexDTO getIndex() {
		return index;
	}

	/**
	 * @param index the index to set
	 */
	public void setIndex(EvaluateFormIndexDTO index) {
		this.index = index;
	}

	public Integer getSortNo() {
        return sortNo;
    }

    public void setSortNo(Integer sortNo) {
        this.sortNo = sortNo;
    }

    public String getFormName() {
        return formName;
    }

    public void setFormName(String formName) {
        this.formName = formName == null ? null : formName.trim();
    }


    public String getFormType() {
        return formType;
    }

    public void setFormType(String formType) {
        this.formType = formType == null ? null : formType.trim();
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo == null ? null : memo.trim();
    }

    public Short getStatus() {
        return status;
    }

    public void setStatus(Short status) {
        this.status = status;
    }

    public Short getFlag() {
        return flag;
    }

    public void setFlag(Short flag) {
        this.flag = flag;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }
}