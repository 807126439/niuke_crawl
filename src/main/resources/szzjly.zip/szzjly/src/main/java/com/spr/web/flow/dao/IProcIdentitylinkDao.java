package com.spr.web.flow.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.spr.core.common.dao.IBaseDao;
import com.spr.web.flow.dto.def.ProcIdentitylinkDTO;
import com.spr.web.flow.entity.ProcIdentitylink;
import com.spr.web.system.dto.user.WeiUserDTO;

public interface IProcIdentitylinkDao extends IBaseDao<String, ProcIdentitylink> {

	Long countByCondition(Map<String, Object> queryMap);

	List<ProcIdentitylinkDTO> selectListByCondition(Map<String, Object> queryMap);

	ProcIdentitylinkDTO getDetailById(String id);

	List<String> getUserIdsByNodeId(String nodeId);

	int deleteByUserIdAndNodeId(@Param("userId") String userId, @Param("nodeId") String nodeId);

	List<WeiUserDTO> getUserInfoByNodeIds(@Param("nodeIds") List<String> nodeIds);

	List<WeiUserDTO> getUserInfoByNodeId(String nodeId);

	int deleteByProcDefId(String procDefId);
}