package com.spr.web.evaluate.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSONObject;
import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.web.evaluate.dto.record.EvaluateRecordDTO;
import com.spr.web.project.dto.part.ProjectPartInfoDTO;
import com.spr.web.project.dto.project.ProjectInfoDTO;

public interface IEvaluateRecordService {

	EvaluateRecordDTO selectOneByCondition(DataQuery dq);

	List<EvaluateRecordDTO> selectListByCondition(DataQuery dq);

	Page<EvaluateRecordDTO> searchByPage(DataQuery dq);

	EvaluateRecordDTO getDetailById(String id);

	String addEvaluateRecord(EvaluateRecordDTO dto);

	void addEvaluateRecord(EvaluateRecordDTO dto, String indexIds, String indexVals, String auditor);

	/**
	 * 根据工程信息添加评价记录：合同期3个月以内的，可不进行阶段履约评价，只进行最终履约评价；合同工期1年以上的，至少进行一次阶段履约评价。
	 * 招标代理合同只需要进行最终履约评价。
	 * 
	 * @param projectPartInfo
	 * @date 2019-2-25
	 * @author wanve_java_cjy
	 */
	String addEvaluateRecord(ProjectPartInfoDTO projectPartInfo);

	/**
	 * 根据项目信息与工程信息添加承包商评价记录：合同期3个月以内的，可不进行阶段履约评价，只进行最终履约评价；合同工期1年以上的，
	 * 至少进行一次阶段履约评价。 招标代理合同只需要进行最终履约评价。
	 * 
	 * @param projectInfo
	 * @param projectPartInfo
	 * @date 2019-2-25
	 * @author wanve_java_cjy
	 */
	@Deprecated
	String addEvaluateRecord(ProjectInfoDTO projectInfo, ProjectPartInfoDTO projectPartInfo);

	String addEvaluateRecord(String formId, String formType, String specificStep, ProjectInfoDTO projectInfo, ProjectPartInfoDTO projectPartInfo);

	/**
	 * 根据项目信息添加代建单位评价记录：合同期3个月以内的，可不进行阶段履约评价，只进行最终履约评价；合同工期1年以上的，至少进行一次阶段履约评价。
	 * 招标代理合同只需要进行最终履约评价。
	 * 
	 * @param projectInfo
	 * @return
	 * @date 2019-2-27
	 * @author wanve_java_cjy
	 */
	@Deprecated
	String addEvaluateRecord(ProjectInfoDTO projectInfo);

	String addEvaluateRecord(String formId, String formType, ProjectInfoDTO projectInfo);

	/**
	 * 审核修改
	 * 
	 * @param dq
	 * @param id
	 * @param totalScore
	 * @param evalGrade
	 * @param auditLog
	 * @param indexIds
	 * @param indexVals
	 * @date 2019-3-12
	 * @author wanve_java_cjy
	 */
	void updateEvaluateRecord(DataQuery dq, String id, String formType, BigDecimal totalScore, Short evalGrade, String situationGoods, String situationBads,
			String nodeId, String note, String[] indexIds, String[] indexVals);

	void updateEvaluateRecord(EvaluateRecordDTO dto);

	void updatePleaContent(EvaluateRecordDTO dto);

	void updatePleaReply(EvaluateRecordDTO dto);

	void updateSituation(EvaluateRecordDTO dto);

	void deleteEvaluateRecords(String[] ids);

	void deleteEvaluateRecordsByCondition(DataQuery dq);

	/**
	 * 查询列表附带流程相关信息与要求
	 * 
	 * @param dq
	 * @return
	 */
	Page<EvaluateRecordDTO> searchByPageWithExec(DataQuery dq);

	void initText(List<EvaluateRecordDTO> list);

	Page<EvaluateRecordDTO> avgScoreByPage(DataQuery dq);

	List<Map<String, Object>> bestUnitTopK(DataQuery dq);

	List<Map<String, Object>> worstUnitTopK(DataQuery dq);

	JSONObject statUnitAvgScore();

	JSONObject statUnitScoreTime();

	JSONObject statContractorTypeAvgScore();

	JSONObject getNumOfEngType();

	/**
	 * 临时导入
	 * 
	 * @param engTypeName
	 *            工程类别名
	 * @param proId
	 *            项目id
	 * @param partId
	 *            工程id
	 * @param proName
	 *            工程名称
	 * @param buildUnitName
	 *            建设单位名称
	 * @param targetUnitId
	 *            评价目标单位id（被评价的承包商单位id）
	 * @param contractorName
	 *            承包商名称
	 * @param formType
	 *            评价周期形式
	 * @param totalScore
	 *            总得分
	 * @param engTypeCode
	 *            合同类型
	 * @date 2019-3-5
	 * @author wanve_java_cjy
	 */
	void tempImport(String engTypeName, String proId, String partId, String proName, String buildUnitName, String targetUnitId, String contractorName,
			String specificStep, String totalScore, String engTypeCode);

	/**
	 * 判断同一单位评价记录是否已经存在
	 * 
	 * 季度（同一季度只能存在一条） 合同（只能存在一条）
	 */
	void judgeIfEvaluateRecordExist(String formId, String formType, String proId, String partId);

	// --------------年度履约评价相关-----------------//

	Page<EvaluateRecordDTO> searchContractorYearEvaluateRecordByPage(DataQuery dq);

	void createContractorYearEvaluateRecord();

	void updateChecked(EvaluateRecordDTO dto);

	List<Map<String, Object>> yearUnitTopK(DataQuery dq);

	// ------------- 代建类型专用 -----------------//

	/**
	 * 添加非代建综合评价(合同评价完成后)
	 */
	void createNotDjComprehensiveEvaluateRecord(EvaluateRecordDTO evaluateRecord);

	/**
	 * 生成代建季度总评价/合同总评价(建设单位60% + 住建 20% + 发改 20%)
	 * 
	 * @param evaluateRecord
	 */
	void createDjEvaluateRecord(EvaluateRecordDTO evaluateRecord);

	/**
	 * 定时任务 
	 * 
	 * @date 2019-5-8
	 * @author wanve_java_cjy
	 */
	void deleteInvalidScheduling();
}
