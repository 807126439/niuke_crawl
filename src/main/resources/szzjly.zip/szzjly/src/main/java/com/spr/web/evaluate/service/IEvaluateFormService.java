package com.spr.web.evaluate.service;

import java.util.List;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.dto.ZtreeDTO;
import com.spr.web.evaluate.dto.form.EvaluateFormDTO;
import com.spr.web.evaluate.dto.form.EvaluateFormIndexDTO;

public interface IEvaluateFormService {

	EvaluateFormDTO selectOneByCondition(DataQuery dq);

	List<EvaluateFormDTO> selectListByCondition(DataQuery dq);

	Page<EvaluateFormDTO> searchByPage(DataQuery dq);

	EvaluateFormDTO getDetailById(String id);

	void addEvaluateForm(EvaluateFormDTO dto);

	void addEvaluateForm(EvaluateFormDTO dto, EvaluateFormIndexDTO index);

	void updateEvaluateForm(EvaluateFormDTO dto);

	void updateEvaluateForm(EvaluateFormDTO dto, EvaluateFormIndexDTO index);

	@Deprecated
	void publishEvaluateForm(String id);

	@Deprecated
	void enableEvaluateForm(String id, String engTypeCode);

	void deleteEvaluateForms(String[] ids);

	void deleteEvaluateFormsByCondition(DataQuery dq);

	EvaluateFormDTO getFormByTypeName(String engTypeName);

	List<ZtreeDTO> getEvaluateFormTreeData(String engTypeCode);
}
