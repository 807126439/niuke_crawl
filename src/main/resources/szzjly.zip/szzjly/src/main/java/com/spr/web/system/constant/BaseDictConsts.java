package com.spr.web.system.constant;

public class BaseDictConsts {

	public static final String MANAGE_UNIT_TYPE = "manage_unit_type"; // 业务主管单位类型
	public static final String MSG_GROUP_TYPE = "group_type"; // 单位组类型

	public static final String GUIDE_SEND_TYPE = "guide_send_type"; // 监督指引发送介质类型

	public static final String PROJECT_STATUS_TYPE = "project_status_type"; // 项目状态类型

	public static final String PROJECT_IMPORTANT_LEVEL_TYPE = "project_important_level"; // 项目重要级别

	public static final String PROJECT_INVEST_TYPE = "project_invest_level"; // 投资类别

	public static final String PROJECT_PROGRESS = "project_progress"; // 工程进度

	public static final String ICON_TYPE = "icon_type"; // 图标类型
}
