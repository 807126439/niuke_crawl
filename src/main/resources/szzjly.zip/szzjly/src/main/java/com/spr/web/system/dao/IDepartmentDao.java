package com.spr.web.system.dao;

import com.spr.core.common.dao.IBaseDao;
import com.spr.web.system.dto.department.DepartmentDTO;
import com.spr.web.system.entity.Department;
import java.util.List;
import java.util.Map;

public interface IDepartmentDao extends IBaseDao<String, Department> {

    Long countByCondition(Map<String, Object> queryMap);

    List<DepartmentDTO> selectListByCondition(Map<String, Object> queryMap);

    DepartmentDTO getDetailById(String id);
}