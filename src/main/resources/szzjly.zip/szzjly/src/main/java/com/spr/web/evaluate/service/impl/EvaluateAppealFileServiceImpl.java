package com.spr.web.evaluate.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.dto.DownLoadDTO;
import com.spr.core.common.service.BaseService;
import com.spr.core.common.utils.Assert;
import com.spr.core.gobal.GobalVal;
import com.spr.web.evaluate.dao.IEvaluateAppealFileDao;
import com.spr.web.evaluate.dto.appeal.EvaluateAppealFileDTO;
import com.spr.web.evaluate.entity.EvaluateAppealFile;
import com.spr.web.evaluate.service.IEvaluateAppealFileService;
import com.spr.web.file.dto.baseFile.SaveResult;
import com.spr.web.file.entity.BaseFile;
import com.spr.web.file.entity.ZonePath;
import com.spr.web.file.service.IBaseFileService;

@Service("evaluateAppealFileService")
@Transactional
public class EvaluateAppealFileServiceImpl extends BaseService implements IEvaluateAppealFileService {

	@Resource
	private IEvaluateAppealFileDao evaluateAppealFileDao;
	@Resource
	private IBaseFileService baseFileService;
	
	@Override
	public Map<String, List<EvaluateAppealFileDTO>> selectAppealListMapByRecordId(String evaluateRecordId) {
		DataQuery dq = new DataQuery();
		dq.setNotQueryPage();
		dq.setSidx("gmtCreate");
		dq.setSord("asc");
		
		dq.putToMap("evaluateRecordId", evaluateRecordId);
		List<EvaluateAppealFileDTO> list = this.selectListByCondition(dq);
		if (list == null || list.isEmpty()) {
			return null;
		}
		
		Map<String, List<EvaluateAppealFileDTO>> map = new HashMap<>();
		for (EvaluateAppealFileDTO dto : list) {
			if (!map.containsKey(dto.getEvaluateAppealId())) {
				map.put(dto.getEvaluateAppealId(), new ArrayList<EvaluateAppealFileDTO>());
			}
			map.get(dto.getEvaluateAppealId()).add(dto);
		}
		return map;
	}

	@Override
	public List<EvaluateAppealFileDTO> selectListByCondition(DataQuery dq) {
		dq.assemblePageOffset();
		dq.assembleOrderInfo(EvaluateAppealFile.class, null);
		List<EvaluateAppealFileDTO> resultlist = this.evaluateAppealFileDao.selectListByCondition(dq.getQueryMap());
		return resultlist;
	}
	
	/**
	 * 分页查询
	 * 
	 * @param dq
	 */
	@Override
	public Page<EvaluateAppealFileDTO> searchByPage(DataQuery dq) {

		Long recTotal = this.evaluateAppealFileDao.countByCondition(dq.assemblePageOffset().getQueryMap());
		dq.assembleOrderInfo(EvaluateAppealFile.class, null);
		List<EvaluateAppealFileDTO> resultlist = this.evaluateAppealFileDao.selectListByCondition(dq.getQueryMap());

		return new Page<EvaluateAppealFileDTO>(dq.getCurrentPage(), dq.getPageSize(), resultlist, recTotal);
	}

	/**
	 * 查询详细
	 * 
	 * @param id
	 */
	@Override
	public EvaluateAppealFileDTO getDetailById(String id) {
		Assert.hasText(id, Assert.NULL_PARAM_STR("id"));

		EvaluateAppealFileDTO result = this.evaluateAppealFileDao.getDetailById(id);
		Assert.notNull(result, Assert.EMPTY_REOCRD_STR);

		return result;
	}

	/**
	 * 修改
	 * 
	 * @param dto
	 */
	@Override
	public void updateEvaluateAppealFile(EvaluateAppealFileDTO dto) {
		Assert.hasText(dto.getId(), Assert.NULL_PARAM_STR("id"));

		EvaluateAppealFile model = this.evaluateAppealFileDao.getById(dto.getId());
		Assert.notNull(model, Assert.EMPTY_REOCRD_STR);

		model.setEvaluateRecordId(dto.getEvaluateRecordId());
		model.setEvaluateAppealId(dto.getEvaluateAppealId());
		model.setFileName(dto.getFileName());
		model.setFileSize(dto.getFileSize());
		model.setFileType(dto.getFileType());
		model.setFileViewPath(dto.getFileViewPath());
		model.setBaseFileId(dto.getBaseFileId());
		model.setStatus(dto.getStatus());
		model.setFlag(dto.getFlag());
		model.setCreateBy(dto.getCreateBy());
		model.setUpdateBy(dto.getUpdateBy());
		model.setGmtCreate(dto.getGmtCreate());
		model.setGmtModified(dto.getGmtModified());

		this.evaluateAppealFileDao.update(model);

		this.writeInfoLog("Update: " + model.toString());

	}

	/**
	 * 删除
	 * 
	 * @param ids
	 */
	@Override
	public void deleteEvaluateAppealFiles(String[] ids) {
		for (int i = 0; i < ids.length; i++) {
			this.evaluateAppealFileDao.deleteById(ids[i]);

			this.writeInfoLog("Delete id:" + ids[i]);

		}
	}

	@Override
	public void addEvaluateAppealFile(String evaluateRecordId, String evaluateAppealId, String ucode) {

		Map<String, List<SaveResult>> fileMap = this.baseFileService.getTempCacheVal(ucode);
		if (fileMap != null && !fileMap.isEmpty()) {
			for (Map.Entry<String, List<SaveResult>> entry : fileMap.entrySet()) {
				for (SaveResult saveResult : entry.getValue()) {
					EvaluateAppealFile model = new EvaluateAppealFile();
					model.setEvaluateRecordId(evaluateRecordId);
					model.setEvaluateAppealId(evaluateAppealId);
					model.setFileName(saveResult.getFileName());
					model.setFileSize(saveResult.getFileSize());
					model.setFileType(saveResult.getFileType());
					model.setFileViewPath(saveResult.getViewPattern());
					model.setBaseFileId(saveResult.getId());
					model.setStatus(GobalVal.STATUS_ENABLE);
					model.setFlag(GobalVal.NORMAL_FLAG);
					model.setCreateBy(getNowUser().getUsername());

					this.evaluateAppealFileDao.insert(model);

					this.writeInfoLog("Add: " + model.toString());
				}
			}
		}
	}
	   
	   @Override
	   public void addEvaluateAppealFile(CommonsMultipartFile file, String recordId) {
			Assert.hasText(recordId, "recordId must not be empty");
			Assert.notNull(file, "上传文件不能为空！");

			SaveResult as = this.baseFileService.addBaseFile(file, ZonePath.COMMON_FILE);
			EvaluateAppealFile model = new EvaluateAppealFile();
			model.setEvaluateRecordId(recordId); 	  
			// model.setType(dto.getType()); 	  
			model.setFileName(as.getFileName());
			model.setFileType(as.getFileType());
			model.setFileSize(as.getFileSize()); 	  
			// model.setFileView(as.getViewBigPattern());
			if (BaseFile.FILE_KIND_PICTURE == as.getFileKind()) {
				// 图片文件
				model.setFileViewPath(as.getViewPattern());
			} else {
				// 办公文件、视频文件
				model.setFileViewPath(as.getViewPath());
			}
			model.setBaseFileId(as.getId());
			// model.setStatus(status);
			// model.setFlag(dto.getFlag()); 	  
			model.setCreateBy(this.getNowUser().getUnitId());
			model.setUpdateBy(this.getNowUser().getId());
			model.setGmtCreate(new Date());
			model.setGmtModified(new Date());

		   this.evaluateAppealFileDao.insert(model);
	       this.writeInfoLog("Add: "+model.toString());	      
	   }

		// 下载
		@Override
		public DownLoadDTO getDownLoadInfo(String fileId) {
			Assert.notNull(fileId, "fileId must not be null");
			EvaluateAppealFile model = this.evaluateAppealFileDao.getById(fileId);
			if (model != null && model.getBaseFileId() != null) {
				return this.baseFileService.getDownLoadInfoById(model.getBaseFileId());
			}
			return null;
		}
		
}
