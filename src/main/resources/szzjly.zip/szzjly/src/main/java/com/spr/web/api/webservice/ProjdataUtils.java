package com.spr.web.api.webservice;

import com.spr.web.api.webservice.ProjdataServiceStub.ProcessData;
import com.spr.web.api.webservice.ProjdataServiceStub.ProcessDataE;
import com.spr.web.api.webservice.ProjdataServiceStub.ProcessDataResponse;
import com.spr.web.api.webservice.ProjdataServiceStub.ProcessDataResponseE;

public class ProjdataUtils {

	/**
	 * 根据区号获取的项目
	 * 
	 * @param DepartmentCode
	 *            区号
	 * @param pageNum
	 *            页码 1
	 * @param pageSize
	 *            每页记录数 30
	 * @return
	 */
	public static String getProjectData(String DepartmentCode, String pageNum, String pageSize) {

		String reqPacket = "<ReqPacket>" + "<Header>" + "<requestId>402881ed491324d1014913260a410001</requestId>" + "<from>xxxxx</from>"
				+ "<instruct>ProjectCodeService.project.getListByDepartment</instruct>" + "</Header>"
				+ "<Content><![CDATA[<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + "<ProjectCodeServiceRequest>" + "<formTemplateFlag>1</formTemplateFlag>"
				+ "<formTemplateDepartment>" + DepartmentCode + "</formTemplateDepartment>" + "<formTemplatePageNumber>" + pageNum
				+ "</formTemplatePageNumber>" + "<formTemplatePageSize>" + pageSize + "</formTemplatePageSize>" + "</ProjectCodeServiceRequest>"
				+ "]]></Content>" + "</ReqPacket>";

		return getApiData(reqPacket);
	}

	/**
	 * 根据项目ID获取工程
	 * 
	 * @param proId
	 * @return
	 */
	public static String getEngData(String proId) {
		String reqPacket = "<ReqPacket>" + "<Header>" + "<requestId>402881ed491324d1014913260a410001</requestId>" + "<from>xxxxx</from>"
				+ "<instruct>ProjectCodeService.engineering.getAllByProID</instruct>" + "</Header>"
				+ "<Content><![CDATA[<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + "<ProjectCodeServiceRequest>" + "<formTemplateProId>" + proId
				+ "</formTemplateProId>" + "</ProjectCodeServiceRequest>" + "]]></Content>" + "</ReqPacket>";
		return getApiData(reqPacket);

	}

	/**
	 * 根据项目总记录数
	 * 
	 * @param DepartmentCode
	 * @return
	 */
	public static String getProjectTotalNum(String DepartmentCode) {

		String reqPacket = "<ReqPacket>" + "<Header>" + "<requestId>402881ed491324d1014913260a410001</requestId>" + "<from>xxxxx</from>"
				+ "<instruct>ProjectCodeService.project.getListByDepartment</instruct>" + "</Header>"
				+ "<Content><![CDATA[<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + "<ProjectCodeServiceRequest>" + "<formTemplateFlag>1</formTemplateFlag>"
				+ "<formTemplateDepartment>" + DepartmentCode + "</formTemplateDepartment>" + "</ProjectCodeServiceRequest>" + "]]></Content>" + "</ReqPacket>";

		return getApiData(reqPacket);
	}

	private static String getApiData(String reqPacket) {
		try {

			ProjdataServiceStub stub = new ProjdataServiceStub();

			stub._getServiceClient().getOptions().setProperty(org.apache.axis2.Constants.Configuration.DISABLE_SOAP_ACTION, true);

			ProcessData processData = new ProcessData();
			processData.setReqPacket(reqPacket);

			ProcessDataE processDataE = new ProcessDataE();
			processDataE.setProcessData(processData);

			ProcessDataResponseE responseE = stub.processData(processDataE);
			ProcessDataResponse response = responseE.getProcessDataResponse();
			String result = response.get_return();

			return result;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
