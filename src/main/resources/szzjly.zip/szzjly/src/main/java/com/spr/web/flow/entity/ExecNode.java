package com.spr.web.flow.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.spr.core.annotations.DbField;
import com.spr.core.common.entity.UUIDEntity;

public class ExecNode extends UUIDEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final short STATUS_STATIC = 0; // 未完成
	public static final short STATUS_FINISH = 1; // 完成
	public static final Short STATUS_BACK = 2; // 退回
	public static final Short STATUS_FAIL = 3; // 失败

	// public static final short CHECK_STATIC_fail = 0; // 不通过审批
	// public static final short CHECK_STATIC_pass = 1; // 通过审批
	// public static final short CHECK_STATIC_ready = 2; // 待审批
	// public static final short CHECK_STATIC_static = 10; // 初始值

	public static final short FLOW_STATUS_CURR = 1; // 当前任务
	public static final short FLOW_STATUS_STATiC = 0; // 静止状态
	public static final short FLOW_STATUS_HISTORY = 2; // 历史状态
	public static final short FLOW_STATUS_BACK = 3; // 退回状态
	public static final short FLOW_STATUS_FAIL = 4; // 撤回状态，功能停止

	public static final short DEF_FLAG = 1;

	private String procDefId;

	private String tlNodeId;

	private String dataId;

	private String dataType;

	private String procInstId;

	private String progressText;

	private String nodeName;

	private String nodeCode;

	private String nodeType;

	private BigDecimal leftPos;

	private BigDecimal topPos;

	private String width;

	private String height;

	private String subDefId;

	private String procType;

	private String title;

	private String requirement;

	private String note;

	private Integer limitDay;

	private String dutyDepartId;

	private String dutyUserId;

	private Short allotStrategy;

	private Date startTime;

	private Short status;

	private Short checkStatus;

	private Short flowStatus;

	private Short flag;

	private String createBy;

	private String updateBy;

	@DbField(name = "proc_def_id")
	public String getProcDefId() {
		return procDefId;
	}

	public void setProcDefId(String procDefId) {
		this.procDefId = procDefId == null ? null : procDefId.trim();
	}

	@DbField(name = "tl_node_id")
	public String getTlNodeId() {
		return tlNodeId;
	}

	public void setTlNodeId(String tlNodeId) {
		this.tlNodeId = tlNodeId == null ? null : tlNodeId.trim();
	}

	@DbField(name = "data_id")
	public String getDataId() {
		return dataId;
	}

	public void setDataId(String dataId) {
		this.dataId = dataId == null ? null : dataId.trim();
	}

	@DbField(name = "data_type")
	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType == null ? null : dataType.trim();
	}

	@DbField(name = "proc_inst_id")
	public String getProcInstId() {
		return procInstId;
	}

	public void setProcInstId(String procInstId) {
		this.procInstId = procInstId == null ? null : procInstId.trim();
	}

	@DbField(name = "progress_text")
	public String getProgressText() {
		return progressText;
	}

	public void setProgressText(String progressText) {
		this.progressText = progressText == null ? null : progressText.trim();
	}

	@DbField(name = "node_name")
	public String getNodeName() {
		return nodeName;
	}

	public void setNodeName(String nodeName) {
		this.nodeName = nodeName == null ? null : nodeName.trim();
	}

	@DbField(name = "node_code")
	public String getNodeCode() {
		return nodeCode;
	}

	public void setNodeCode(String nodeCode) {
		this.nodeCode = nodeCode == null ? null : nodeCode.trim();
	}

	@DbField(name = "node_type")
	public String getNodeType() {
		return nodeType;
	}

	public void setNodeType(String nodeType) {
		this.nodeType = nodeType == null ? null : nodeType.trim();
	}

	@DbField(name = "left_pos")
	public BigDecimal getLeftPos() {
		return leftPos;
	}

	public void setLeftPos(BigDecimal leftPos) {
		this.leftPos = leftPos;
	}

	@DbField(name = "top_pos")
	public BigDecimal getTopPos() {
		return topPos;
	}

	public void setTopPos(BigDecimal topPos) {
		this.topPos = topPos;
	}

	@DbField(name = "width")
	public String getWidth() {
		return width;
	}

	public void setWidth(String width) {
		this.width = width == null ? null : width.trim();
	}

	@DbField(name = "height")
	public String getHeight() {
		return height;
	}

	public void setHeight(String height) {
		this.height = height == null ? null : height.trim();
	}

	@DbField(name = "sub_def_id")
	public String getSubDefId() {
		return subDefId;
	}

	public void setSubDefId(String subDefId) {
		this.subDefId = subDefId == null ? null : subDefId.trim();
	}

	@DbField(name = "proc_type")
	public String getProcType() {
		return procType;
	}

	public void setProcType(String procType) {
		this.procType = procType == null ? null : procType.trim();
	}

	@DbField(name = "title")
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title == null ? null : title.trim();
	}

	@DbField(name = "requirement")
	public String getRequirement() {
		return requirement;
	}

	public void setRequirement(String requirement) {
		this.requirement = requirement == null ? null : requirement.trim();
	}

	@DbField(name = "note")
	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note == null ? null : note.trim();
	}

	@DbField(name = "limit_day")
	public Integer getLimitDay() {
		return limitDay;
	}

	public void setLimitDay(Integer limitDay) {
		this.limitDay = limitDay;
	}

	@DbField(name = "duty_depart_id")
	public String getDutyDepartId() {
		return dutyDepartId;
	}

	public void setDutyDepartId(String dutyDepartId) {
		this.dutyDepartId = dutyDepartId == null ? null : dutyDepartId.trim();
	}

	@DbField(name = "duty_user_id")
	public String getDutyUserId() {
		return dutyUserId;
	}

	public void setDutyUserId(String dutyUserId) {
		this.dutyUserId = dutyUserId == null ? null : dutyUserId.trim();
	}

	@DbField(name = "allot_strategy")
	public Short getAllotStrategy() {
		return allotStrategy;
	}

	public void setAllotStrategy(Short allotStrategy) {
		this.allotStrategy = allotStrategy;
	}

	@DbField(name = "start_time")
	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	@DbField(name = "status")
	public Short getStatus() {
		return status;
	}

	public void setStatus(Short status) {
		this.status = status;
	}

	@DbField(name = "check_status")
	public Short getCheckStatus() {
		return checkStatus;
	}

	public void setCheckStatus(Short checkStatus) {
		this.checkStatus = checkStatus;
	}

	@DbField(name = "flow_status")
	public Short getFlowStatus() {
		return flowStatus;
	}

	public void setFlowStatus(Short flowStatus) {
		this.flowStatus = flowStatus;
	}

	@DbField(name = "flag")
	public Short getFlag() {
		return flag;
	}

	public void setFlag(Short flag) {
		this.flag = flag;
	}

	@DbField(name = "create_by")
	public String getCreateBy() {
		return createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy == null ? null : createBy.trim();
	}

	@DbField(name = "update_by")
	public String getUpdateBy() {
		return updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy == null ? null : updateBy.trim();
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode());
		sb.append(",Super = ").append(super.toString());
		sb.append(", serialVersionUID=").append(serialVersionUID);
		sb.append(", procDefId=").append(procDefId);
		sb.append(", tlNodeId=").append(tlNodeId);
		sb.append(", dataId=").append(dataId);
		sb.append(", dataType=").append(dataType);
		sb.append(", procInstId=").append(procInstId);
		sb.append(", progressText=").append(progressText);
		sb.append(", nodeName=").append(nodeName);
		sb.append(", nodeCode=").append(nodeCode);
		sb.append(", nodeType=").append(nodeType);
		sb.append(", leftPos=").append(leftPos);
		sb.append(", topPos=").append(topPos);
		sb.append(", width=").append(width);
		sb.append(", height=").append(height);
		sb.append(", subDefId=").append(subDefId);
		sb.append(", procType=").append(procType);
		sb.append(", title=").append(title);
		sb.append(", requirement=").append(requirement);
		sb.append(", note=").append(note);
		sb.append(", limitDay=").append(limitDay);
		sb.append(", dutyDepartId=").append(dutyDepartId);
		sb.append(", dutyUserId=").append(dutyUserId);
		sb.append(", allotStrategy=").append(allotStrategy);
		sb.append(", startTime=").append(startTime);
		sb.append(", status=").append(status);
		sb.append(", checkStatus=").append(checkStatus);
		sb.append(", flowStatus=").append(flowStatus);
		sb.append(", flag=").append(flag);
		sb.append(", createBy=").append(createBy);
		sb.append(", updateBy=").append(updateBy);
		sb.append("]");
		return sb.toString();
	}

}