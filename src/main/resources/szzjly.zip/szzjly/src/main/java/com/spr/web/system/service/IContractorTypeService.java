package com.spr.web.system.service;

import java.util.List;
import java.util.Map;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.web.system.dto.contractor.ContractorTypeDTO;

public interface IContractorTypeService {

	Map<String, String> selectCodeNameMapByCondition(DataQuery dq);

	List<ContractorTypeDTO> selectListByCondition(DataQuery dq);

	Page<ContractorTypeDTO> searchByPage(DataQuery dq);

	ContractorTypeDTO getDetailById(String id);

	void addContractorType(ContractorTypeDTO dto);

	void updateContractorType(ContractorTypeDTO dto);

	void deleteContractorTypes(String[] ids);

	List<ContractorTypeDTO> selectList(DataQuery dq);

}
