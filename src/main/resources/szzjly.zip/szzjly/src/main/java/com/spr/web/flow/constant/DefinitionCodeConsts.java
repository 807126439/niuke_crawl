package com.spr.web.flow.constant;

import java.util.ArrayList;
import java.util.List;

/**
 * 流程定义码
 * 
 * @author wb_java_zjr
 * 
 */
public enum DefinitionCodeConsts {
	run_process("run_process", "申请审核流程");
	// run_agent_process("run_agent_process", "代建单位申请审核流程"),
	// run_build_process("run_build_process", "建设单位申请审核流程");

	String code;
	String title;

	DefinitionCodeConsts(String code, String title) {
		this.code = code;
		this.title = title;
	}

	public String code() {
		return this.code;
	}

	public String title() {
		return this.title;
	}

	public static List<DefinitionCodeConsts> codes = new ArrayList<DefinitionCodeConsts>();

	static {
		codes.add(run_process);
		// codes.add(run_agent_process);
		// codes.add(run_build_process);

	}
}
