package com.spr.web.evaluate.dao;

import com.spr.core.common.dao.IBaseDao;
import com.spr.web.evaluate.dto.appeal.EvaluateAppealDTO;
import com.spr.web.evaluate.entity.EvaluateAppeal;
import java.util.List;
import java.util.Map;

public interface IEvaluateAppealDao extends IBaseDao<String, EvaluateAppeal> {

    Long countByCondition(Map<String, Object> queryMap);

    List<EvaluateAppealDTO> selectListByCondition(Map<String, Object> queryMap);

    EvaluateAppealDTO getDetailById(String id);
}