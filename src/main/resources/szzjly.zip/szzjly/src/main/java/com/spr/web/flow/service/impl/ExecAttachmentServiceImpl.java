package com.spr.web.flow.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.dto.DownLoadDTO;
import com.spr.core.common.exception.BusinessException;
import com.spr.core.common.service.BaseService;
import com.spr.core.common.utils.Assert;
import com.spr.web.file.dto.baseFile.SaveResult;
import com.spr.web.file.entity.ZonePath;
import com.spr.web.file.service.IBaseFileService;
import com.spr.web.flow.dao.IExecAttachmentDao;
import com.spr.web.flow.dao.IExecNodeDao;
import com.spr.web.flow.dto.exec.ExecAttachmentDTO;
import com.spr.web.flow.entity.ExecAttachment;
import com.spr.web.flow.entity.ExecNode;
import com.spr.web.flow.service.IExecAttachmentService;

@Service("execAttachmentService")
@Transactional
public class ExecAttachmentServiceImpl extends BaseService implements IExecAttachmentService {

	@Resource
	private IExecAttachmentDao execAttachmentDao;
	@Resource
	private IBaseFileService baseFileService;
	@Resource
	private IExecNodeDao execNodeDao;

	/**
	 * 分页查询
	 * 
	 * @param dq
	 */
	@Override
	public Page<ExecAttachmentDTO> searchByPage(DataQuery dq) {

		Long recTotal = this.execAttachmentDao.countByCondition(dq.assemblePageOffset().getQueryMap());
		dq.assembleOrderInfo(ExecAttachment.class, null);
		List<ExecAttachmentDTO> resultlist = this.execAttachmentDao.selectListByCondition(dq.getQueryMap());

		return new Page<ExecAttachmentDTO>(dq.getCurrentPage(), dq.getPageSize(), resultlist, recTotal);
	}

	/**
	 * 查询详细
	 * 
	 * @param id
	 */
	@Override
	public ExecAttachmentDTO getDetailById(String id) {
		Assert.hasText(id, Assert.NULL_PARAM_STR("id"));

		ExecAttachmentDTO result = this.execAttachmentDao.getDetailById(id);
		Assert.notNull(result, Assert.EMPTY_REOCRD_STR);

		return result;
	}

	/**
	 * 添加
	 * 
	 * @param dto
	 */
	@Override
	public void addExecAttachment(String procNodeId, Short attachmentType, CommonsMultipartFile uploadFile) {
		Assert.hasText(procNodeId, Assert.NULL_PARAM_STR("procNodeId"));

		ExecNode node = this.execNodeDao.getById(procNodeId);
		Assert.notNull(node, Assert.EMPTY_REOCRD_STR);

		SaveResult as = this.baseFileService.addBaseFile(uploadFile, ZonePath.COMMON_FILE);

		ExecAttachment model = new ExecAttachment();
		model.setProcInstId(node.getProcInstId());
		model.setProcNodeId(node.getId());
		model.setUserId(getNowUserId());
		model.setType(attachmentType);
		model.setFileName(as.getFileName());
		model.setFileType(as.getFileType());
		model.setBaseFileId(as.getId());
		// TODO 改为365预览路径
		model.setFileView(as.getViewPath());
		model.setBackFileView(as.getViewPath());
		model.setStatus(ExecAttachment.DEF_STATUS);
		model.setCreateBy(getNowUser().getUsername());

		this.execAttachmentDao.insert(model);

		if (this.logger.isInfoEnabled()) {
			this.logger.info("Add: " + model.toString());
		}
	}

	/**
	 * 修改
	 * 
	 * @param dto
	 */
	@Override
	public void updateExecAttachment(ExecAttachmentDTO dto) {
		Assert.hasText(dto.getId(), Assert.NULL_PARAM_STR("id"));

		ExecAttachment model = this.execAttachmentDao.getById(dto.getId());
		Assert.notNull(model, Assert.EMPTY_REOCRD_STR);

		model.setProcInstId(dto.getProcInstId());
		model.setProcNodeId(dto.getProcNodeId());
		model.setUserId(dto.getUserId());
		model.setType(dto.getType());
		model.setFileType(dto.getFileType());
		model.setBaseFileId(dto.getBaseFileId());
		model.setFileView(dto.getFileView());
		model.setBackFileView(dto.getBackFileView());
		model.setStatus(dto.getStatus());
		model.setCreateBy(dto.getCreateBy());
		model.setUpdateBy(dto.getUpdateBy());
		model.setGmtCreate(dto.getGmtCreate());
		model.setGmtModified(dto.getGmtModified());

		this.execAttachmentDao.update(model);

		if (this.logger.isInfoEnabled()) {
			this.logger.info("Update: " + model.toString());
		}
	}

	/**
	 * 下载文件
	 * 
	 * @param id
	 * @return
	 */
	@Override
	public DownLoadDTO getDownLoadInfo(String id) {
		Assert.hasText(id, Assert.NULL_PARAM_STR("id"));

		ExecAttachment model = this.execAttachmentDao.getById(id);
		if (model.getBaseFileId() != null) {
			DownLoadDTO result = this.baseFileService.getDownLoadInfoById(model.getBaseFileId());

			return result;
		} else {
			throw new BusinessException("download error");
		}

	}

	/**
	 * 删除
	 * 
	 * @param ids
	 */
	@Override
	public void deleteExecAttachments(String[] ids) {
		for (int i = 0; i < ids.length; i++) {

			ExecAttachment model = this.execAttachmentDao.getById(ids[i]);
			if (model != null) {
				this.baseFileService.deleteBaseFile(model.getId());

				this.execAttachmentDao.deleteById(model.getId());
				if (this.logger.isInfoEnabled()) {
					this.logger.info("Delete：:" + model.toString());
				}
			}

		}
	}

}
