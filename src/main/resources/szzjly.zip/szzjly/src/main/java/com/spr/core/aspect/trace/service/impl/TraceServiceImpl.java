/**
 * 
 */
package com.spr.core.aspect.trace.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.spr.core.aspect.trace.dao.TraceInfoDao;
import com.spr.core.aspect.trace.dto.TraceInfoDTO;
import com.spr.core.aspect.trace.entity.TraceInfo;
import com.spr.core.aspect.trace.service.ITraceService;
import com.spr.core.common.service.BaseService;

/**
 * @date 2019-4-12
 * @author wanve_java_cjy
 *
 */
@Service("traceService")
public class TraceServiceImpl extends BaseService implements ITraceService {

	@Resource
	private TraceInfoDao traceInfoDao;
//	@Resource
//	private TraceInfoRepository traceInfoRepository;

	@Override
	public void add(TraceInfoDTO dto) {
		if (dto.getUserId() == null) {
			return;
		}
		
		TraceInfo model = new TraceInfo();
		model.setTraceId(dto.getTraceId());
		model.setParentId(dto.getParentId());
		model.setSpanId(dto.getSpanId());
		model.setRunTime(dto.getRunTime());
		model.setStartTimeMillis(dto.getStartTimeMillis());
		model.setEndTimeMillis(dto.getEndTimeMillis());
		model.setStartTime(dto.getStartTime());
		model.setEndTime(dto.getEndTime());
		model.setClassName(dto.getClassName());
		model.setMethodName(dto.getMethodName());
		// model.setArgs(Arrays.toString(dto.getArgs()));
		model.setModifier(dto.getModifier());
		model.setKind(dto.getKind());
		model.setContextPath(dto.getContextPath());
		model.setUserId(dto.getUserId());
		
		this.traceInfoDao.insert(model);
//		this.traceInfoRepository.insert(model);
	}
}
