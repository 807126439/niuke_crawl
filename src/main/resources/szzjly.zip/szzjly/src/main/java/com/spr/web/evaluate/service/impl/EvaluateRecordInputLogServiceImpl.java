package com.spr.web.evaluate.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.service.BaseService;
import com.spr.core.common.utils.Assert;
import com.spr.web.evaluate.dao.IEvaluateRecordInputLogDao;
import com.spr.web.evaluate.dto.record.EvaluateRecordInputLogDTO;
import com.spr.web.evaluate.entity.EvaluateRecordInputLog;
import com.spr.web.evaluate.service.IEvaluateRecordInputLogService;
import com.spr.web.system.service.IUserService;

@Service("evaluateRecordInputLogService")
@Transactional
public class EvaluateRecordInputLogServiceImpl extends BaseService implements IEvaluateRecordInputLogService {

	
   @Resource
   private IEvaluateRecordInputLogDao evaluateRecordInputLogDao;
	@Resource
	private IUserService userService;
   
   private void initText(List<EvaluateRecordInputLogDTO> list) {
	   if (list == null || list.isEmpty()) {
		   return;
	   }
	   
	   String[] userIds = new String[list.size()];
	   for (int i = 0; i < list.size(); i++) {
		   userIds[i] = list.get(i).getUserId();
	   }
	   
	   DataQuery dq = new DataQuery();
	   dq.setNotQueryPage();
	   dq.putToMap("ids", userIds);
	   Map<String, String> userIdNameMap = this.userService.selectIdNameMapByCondition(dq);
	   
	   for (EvaluateRecordInputLogDTO dto : list) {
		   dto.setUserName(userIdNameMap.get(dto.getUserId()));
	   }
   } 

   @Override
   public List<EvaluateRecordInputLogDTO> selectListByCondition(DataQuery dq) {
	   dq.assemblePageOffset();
		dq.assembleOrderInfo(EvaluateRecordInputLog.class, null);
		List<EvaluateRecordInputLogDTO> resultlist = this.evaluateRecordInputLogDao.selectListByCondition(dq.getQueryMap());
		
		this.initText(resultlist);
   		return resultlist;
   }
   
   /**
    * 分页查询
    * @param dq
    */
   @Override
   public Page<EvaluateRecordInputLogDTO> searchByPage(DataQuery dq) {
   		
   		Long recTotal = this.evaluateRecordInputLogDao.countByCondition(dq.assemblePageOffset().getQueryMap());
		dq.assembleOrderInfo(EvaluateRecordInputLog.class, null);
		List<EvaluateRecordInputLogDTO> resultlist = this.evaluateRecordInputLogDao.selectListByCondition(dq.getQueryMap());
   
   		return new Page<EvaluateRecordInputLogDTO>(dq.getCurrentPage(), dq.getPageSize(), resultlist, recTotal);
   }
   
   
   /**
    * 查询详细
    * @param id
    */
   @Override
   public EvaluateRecordInputLogDTO getDetailById(String id){
   	   Assert.hasText(id, Assert.NULL_PARAM_STR("id")); 
   	   
   
   	   EvaluateRecordInputLogDTO result = this.evaluateRecordInputLogDao.getDetailById(id);
   	   Assert.notNull(result,Assert.EMPTY_REOCRD_STR);
   	   
   	   return result;
   }
   
   
   
   
   /**
    * 添加
    * @param dto
   	*/
   @Override
   public void addEvaluateRecordInputLog(EvaluateRecordInputLogDTO dto){
   
   	  EvaluateRecordInputLog model = new EvaluateRecordInputLog();
	  model.setEvalId(dto.getEvalId()); 	  
	  model.setIndexId(dto.getIndexId()); 	  
	  model.setProcNodeId(dto.getProcNodeId()); 	  
	  model.setUserId(dto.getUserId()); 	  
	  model.setBeforeVal(dto.getBeforeVal()); 	  
	  model.setChangeVal(dto.getChangeVal()); 	  
	  model.setStatus(dto.getStatus()); 	  
	  model.setCreateBy(this.getNowUser().getUsername()); 	  
	  model.setUpdateBy(this.getNowUser().getUsername()); 	  
	  model.setGmtCreate(new Date()); 	  
	  model.setGmtModified(new Date()); 	  
   
   	  this.evaluateRecordInputLogDao.insert(model);
   	  
   
      this.writeInfoLog("Add: "+model.toString());
      
   }
   
   
   
   /**
    * 修改
    * @param dto
   	*/
   @Override
   public void updateEvaluateRecordInputLog(EvaluateRecordInputLogDTO dto){
   	    Assert.hasText(dto.getId(), Assert.NULL_PARAM_STR("id")); 
    	
    	EvaluateRecordInputLog model = this.evaluateRecordInputLogDao.getById(dto.getId());
    	Assert.notNull(model,Assert.EMPTY_REOCRD_STR);
    	
	  	model.setEvalId(dto.getEvalId()); 	  
	  	model.setIndexId(dto.getIndexId()); 	  
	  	model.setProcNodeId(dto.getProcNodeId()); 	  
	  	model.setUserId(dto.getUserId()); 	  
	  	model.setBeforeVal(dto.getBeforeVal()); 	  
	  	model.setChangeVal(dto.getChangeVal()); 	  
	  	model.setStatus(dto.getStatus()); 	  
	  	model.setCreateBy(dto.getCreateBy()); 	  
	  	model.setUpdateBy(dto.getUpdateBy()); 	  
	  	model.setGmtCreate(dto.getGmtCreate()); 	  
	  	model.setGmtModified(dto.getGmtModified()); 	  
    	    	
    	this.evaluateRecordInputLogDao.update(model);
    	
   
    	this.writeInfoLog("Update: "+model.toString());
        
   }
   
   
   
    /**
   	 * 删除
   	 * @param ids
   	 */
   	@Override
    public void deleteEvaluateRecordInputLogs(String[] ids){
    	for (int i = 0; i < ids.length; i++) {
			this.evaluateRecordInputLogDao.deleteById(ids[i]);
			
			
	        this.writeInfoLog("Delete id:" + ids[i]);
	        
		}
    }
   

}
