package com.spr.web.evaluate.service.impl;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.exception.BusinessException;
import com.spr.core.common.service.BaseService;
import com.spr.core.common.utils.Assert;
import com.spr.web.evaluate.dao.IEvaluateFormIndexDao;
import com.spr.web.evaluate.dto.form.EvaluateFormIndexDTO;
import com.spr.web.evaluate.entity.EvaluateFormIndex;
import com.spr.web.evaluate.service.IEvaluateFormIndexService;

@Service("evaluateFormIndexService")
@Transactional
public class EvaluateFormIndexServiceImpl extends BaseService implements IEvaluateFormIndexService {

	@Resource
	private IEvaluateFormIndexDao evaluateFormIndexDao;

	@Override
	public EvaluateFormIndexDTO selectOneByCondition(DataQuery dq) {
		dq.setPageSize(1);
		List<EvaluateFormIndexDTO> list = this.selectListByCondition(dq);
		if (list == null || list.isEmpty()) {
			return null;
		}
		return list.get(0);
	}

	@Override
	public List<EvaluateFormIndexDTO> selectListByCondition(DataQuery dq) {
		dq.assemblePageOffset().getQueryMap();
		dq.assembleOrderInfo(EvaluateFormIndex.class, null);
		List<EvaluateFormIndexDTO> resultlist = this.evaluateFormIndexDao.selectListByCondition(dq.getQueryMap());
		return resultlist;
	}

	/**
	 * 分页查询
	 * 
	 * @param dq
	 */
	@Override
	public Page<EvaluateFormIndexDTO> searchByPage(DataQuery dq) {

		Long recTotal = this.evaluateFormIndexDao.countByCondition(dq.assemblePageOffset().getQueryMap());
		dq.assembleOrderInfo(EvaluateFormIndex.class, null);
		List<EvaluateFormIndexDTO> resultlist = this.evaluateFormIndexDao.selectListByCondition(dq.getQueryMap());

		return new Page<EvaluateFormIndexDTO>(dq.getCurrentPage(), dq.getPageSize(), resultlist, recTotal);
	}

	/**
	 * 查询详细
	 * 
	 * @param id
	 */
	@Override
	public EvaluateFormIndexDTO getDetailById(String id) {
		Assert.hasText(id, Assert.NULL_PARAM_STR("id"));

		EvaluateFormIndexDTO result = this.evaluateFormIndexDao.getDetailById(id);
		Assert.notNull(result, Assert.EMPTY_REOCRD_STR);

		return result;
	}

	/**
	 * 添加
	 * 
	 * @param dto
	 */
	@Override
	public void addEvaluateFormIndex(EvaluateFormIndexDTO dto) {

		EvaluateFormIndex model = new EvaluateFormIndex();
		model.setSortNo(dto.getSortNo());
		model.setSortName(dto.getSortName());
		model.setIndexName(dto.getIndexName());
		model.setScore(dto.getScore());
		model.setIndexConten(dto.getIndexConten());
		model.setStandard(dto.getStandard());
		model.setParentId(dto.getParentId());
		model.setLevel(dto.getLevel());
		model.setStatus(dto.getStatus());
		model.setFlag(dto.getFlag());
		model.setCreateBy(this.getNowUser().getUsername());
		model.setUpdateBy(this.getNowUser().getUsername());
		model.setGmtCreate(new Date());
		model.setGmtModified(new Date());

		this.evaluateFormIndexDao.insert(model);

		this.writeInfoLog("Add: " + model.toString());

	}

	/**
	 * 修改
	 * 
	 * @param dto
	 */
	@Override
	public void updateEvaluateFormIndex(EvaluateFormIndexDTO dto) {
		Assert.hasText(dto.getId(), Assert.NULL_PARAM_STR("id"));

		EvaluateFormIndex model = this.evaluateFormIndexDao.getById(dto.getId());
		Assert.notNull(model, Assert.EMPTY_REOCRD_STR);

		model.setSortNo(dto.getSortNo());
		model.setSortName(dto.getSortName());
		model.setIndexName(dto.getIndexName());
		model.setScore(dto.getScore());
		model.setIndexConten(dto.getIndexConten());
		model.setStandard(dto.getStandard());
		model.setParentId(dto.getParentId());
		model.setLevel(dto.getLevel());
		model.setStatus(dto.getStatus());
		model.setFlag(dto.getFlag());
		// model.setCreateBy(this.getNowUser().getUsername());
		model.setUpdateBy(this.getNowUser().getUsername());
		// model.setGmtCreate(new Date());
		model.setGmtModified(new Date());

		this.evaluateFormIndexDao.update(model);

		this.writeInfoLog("Update: " + model.toString());

	}

	/**
	 * 删除
	 * 
	 * @param ids
	 */
	@Override
	public void deleteEvaluateFormIndexs(String[] ids) {
		// for (int i = 0; i < ids.length; i++) {
		// this.evaluateFormIndexDao.deleteById(ids[i]);
		// this.writeInfoLog("Delete id:" + ids[i]);
		// }

		if (ids != null && ids.length > 0) {
			for (String id : ids) {
				DataQuery dq = new DataQuery();
				dq.putToMap("parentId", id);
				Long num = this.evaluateFormIndexDao.countByCondition(dq.getQueryMap());
				if (num > 0) {
					throw new BusinessException("请先删除子评价细则");
				} else {
					this.evaluateFormIndexDao.deleteById(id);
				}

			}
		}

		// if (ids == null || ids.length < 1) {
		// return;
		// }
		//
		// DataQuery dq = new DataQuery();
		// dq.putToMap("parentIds", ids);
		// this.deleteEvaluateFormIndexsByCondition(dq);
	}

	@Override
	public void deleteEvaluateFormIndexsByCondition(DataQuery dq) {
		// 获取指标项
		dq.setNotQueryPage();
		List<EvaluateFormIndexDTO> list = this.selectListByCondition(dq);
		// 删除指标项
		this.evaluateFormIndexDao.deleteByCondition(dq.getQueryMap());

		// 删除子指标项
		if (list == null || list.isEmpty()) {
			return;
		}
		String[] ids = new String[list.size()];
		for (int i = 0; i < list.size(); i++) {
			ids[i] = list.get(i).getId();
		}
		dq.clear();
		dq.putToMap("parentIds", ids);
		this.deleteEvaluateFormIndexsByCondition(dq);
	}

	// 获取子评分指标
	@Override
	public List<EvaluateFormIndexDTO> getSubIndexList(DataQuery dq, String parentId) {
		dq.clear();
		dq.setNotQueryPage();
		dq.setSidx("sortNo");
		dq.setSord("asc");
		dq.putToMap("parentId", parentId);
		List<EvaluateFormIndexDTO> list = this.selectListByCondition(dq);
		if (list == null || list.isEmpty()) {
			return null;
		}

		for (EvaluateFormIndexDTO dto : list) {
			List<EvaluateFormIndexDTO> subList = this.getSubIndexList(dq, dto.getId());
			dto.setSubIndexList(subList);
		}
		return list;
	}

	@Override
	public List<EvaluateFormIndexDTO> getEvaluateFormIndexTreeData(String parentId, Boolean isFormId) {
		DataQuery dq = new DataQuery();
		dq.putToMap("parentId", parentId);
		if (isFormId != null && isFormId) {

			EvaluateFormIndexDTO levelZeroDTO = this.selectOneByCondition(dq);
			parentId = levelZeroDTO.getId();
		}
		dq.clear();
		dq.putToMap("sidx", "sort_no");
		dq.putToMap("sord", "asc");
		dq.putToMap("parentId", parentId);
		List<EvaluateFormIndexDTO> resultList = this.evaluateFormIndexDao.selectListByCondition(dq.getQueryMap());
		return resultList;

	}

	@Override
	public EvaluateFormIndexDTO getTitleByParentId(String parentId) {
		return this.evaluateFormIndexDao.getTitleByParentId(parentId);
	}
}
