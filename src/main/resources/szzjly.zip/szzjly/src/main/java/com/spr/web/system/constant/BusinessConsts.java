package com.spr.web.system.constant;

public class BusinessConsts {

	public static final String VERIFY_PHONE = "VP";

}
