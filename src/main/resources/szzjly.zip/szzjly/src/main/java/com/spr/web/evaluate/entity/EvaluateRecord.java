package com.spr.web.evaluate.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.spr.core.annotations.DbField;
import com.spr.core.common.entity.UUIDEntity;

public class EvaluateRecord extends UUIDEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	private String connectRecordId; // 非代建：季度，合同对应综合 代建: 多个季度/合同对应一条季度/合同

	private String proId;

	private String partId;

	private String targetUnitId;

	private String evalUserId;

	private String evalUnitId;

	private String formId;

	private String recordType;

	private String formType;

	private String specificStep;

	private BigDecimal totalScore;

	private Short evalGrade;

	private Date gmtEval;

	private String proName;

	private String contractorName;

	private String buildUnitName;

	private String situationGoods;

	private String situationBads;

	private String memo;

	private String engTypeCode;

	private Short status;

	private Short pleaStatus;

	private Date gmtPlea;

	private String pleaContent;

	private String pleaReply;

	private Short flag;

	private String createBy;

	private String updateBy;

	private Short checked;// 标记是否已阅

	@DbField(name = "checked")
	public Short getChecked() {
		return checked;
	}

	public void setChecked(Short checked) {
		this.checked = checked;
	}

	@DbField(name = "pro_id")
	public String getProId() {
		return proId;
	}

	public void setProId(String proId) {
		this.proId = proId == null ? null : proId.trim();
	}

	@DbField(name = "part_id")
	public String getPartId() {
		return partId;
	}

	public void setPartId(String partId) {
		this.partId = partId == null ? null : partId.trim();
	}

	@DbField(name = "target_unit_id")
	public String getTargetUnitId() {
		return targetUnitId;
	}

	public void setTargetUnitId(String targetUnitId) {
		this.targetUnitId = targetUnitId == null ? null : targetUnitId.trim();
	}

	@DbField(name = "eval_user_id")
	public String getEvalUserId() {
		return evalUserId;
	}

	public void setEvalUserId(String evalUserId) {
		this.evalUserId = evalUserId == null ? null : evalUserId.trim();
	}

	@DbField(name = "form_id")
	public String getFormId() {
		return formId;
	}

	public void setFormId(String formId) {
		this.formId = formId == null ? null : formId.trim();
	}

	@DbField(name = "record_type")
	public String getRecordType() {
		return recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType == null ? null : recordType.trim();
	}

	@DbField(name = "form_type")
	public String getFormType() {
		return formType;
	}

	public void setFormType(String formType) {
		this.formType = formType == null ? null : formType.trim();
	}

	@DbField(name = "specific_step")
	public String getSpecificStep() {
		return specificStep;
	}

	public void setSpecificStep(String specificStep) {
		this.specificStep = specificStep == null ? null : specificStep.trim();
	}

	@DbField(name = "total_score")
	public BigDecimal getTotalScore() {
		return totalScore;
	}

	public void setTotalScore(BigDecimal totalScore) {
		this.totalScore = totalScore;
	}

	@DbField(name = "eval_grade")
	public Short getEvalGrade() {
		return evalGrade;
	}

	public void setEvalGrade(Short evalGrade) {
		this.evalGrade = evalGrade;
	}

	@DbField(name = "gmt_eval")
	public Date getGmtEval() {
		return gmtEval;
	}

	public void setGmtEval(Date gmtEval) {
		this.gmtEval = gmtEval;
	}

	@DbField(name = "pro_name")
	public String getProName() {
		return proName;
	}

	public void setProName(String proName) {
		this.proName = proName == null ? null : proName.trim();
	}

	@DbField(name = "contractor_name")
	public String getContractorName() {
		return contractorName;
	}

	public void setContractorName(String contractorName) {
		this.contractorName = contractorName == null ? null : contractorName.trim();
	}

	@DbField(name = "build_unit_name")
	public String getBuildUnitName() {
		return buildUnitName;
	}

	public void setBuildUnitName(String buildUnitName) {
		this.buildUnitName = buildUnitName == null ? null : buildUnitName.trim();
	}

	/**
	 * @return the situationGoods
	 */
	@DbField(name = "situation_goods")
	public String getSituationGoods() {
		return situationGoods;
	}

	/**
	 * @param situationGoods
	 *            the situationGoods to set
	 */
	public void setSituationGoods(String situationGoods) {
		this.situationGoods = situationGoods == null ? null : situationGoods.trim();
	}

	/**
	 * @return the situationBads
	 */
	@DbField(name = "situation_bads")
	public String getSituationBads() {
		return situationBads;
	}

	/**
	 * @param situationBads
	 *            the situationBads to set
	 */
	public void setSituationBads(String situationBads) {
		this.situationBads = situationBads == null ? null : situationBads.trim();
	}

	@DbField(name = "memo")
	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo == null ? null : memo.trim();
	}

	@DbField(name = "status")
	public Short getStatus() {
		return status;
	}

	public void setStatus(Short status) {
		this.status = status;
	}

	@DbField(name = "plea_status")
	public Short getPleaStatus() {
		return pleaStatus;
	}

	public void setPleaStatus(Short pleaStatus) {
		this.pleaStatus = pleaStatus;
	}

	@DbField(name = "gmt_plea")
	public Date getGmtPlea() {
		return gmtPlea;
	}

	public void setGmtPlea(Date gmtPlea) {
		this.gmtPlea = gmtPlea;
	}

	@DbField(name = "plea_content")
	public String getPleaContent() {
		return pleaContent;
	}

	public void setPleaContent(String pleaContent) {
		this.pleaContent = pleaContent == null ? null : pleaContent.trim();
	}

	@DbField(name = "plea_reply")
	public String getPleaReply() {
		return pleaReply;
	}

	public void setPleaReply(String pleaReply) {
		this.pleaReply = pleaReply == null ? null : pleaReply.trim();
	}

	@DbField(name = "flag")
	public Short getFlag() {
		return flag;
	}

	public void setFlag(Short flag) {
		this.flag = flag;
	}

	@DbField(name = "create_by")
	public String getCreateBy() {
		return createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy == null ? null : createBy.trim();
	}

	@DbField(name = "update_by")
	public String getUpdateBy() {
		return updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy == null ? null : updateBy.trim();
	}

	@DbField(name = "eng_type_code")
	public String getEngTypeCode() {
		return engTypeCode;
	}

	public void setEngTypeCode(String engTypeCode) {
		this.engTypeCode = engTypeCode;
	}

	@DbField(name = "eval_unit_id")
	public String getEvalUnitId() {
		return evalUnitId;
	}

	public void setEvalUnitId(String evalUnitId) {
		this.evalUnitId = evalUnitId;
	}

	@DbField(name = "connect_record_id")
	public String getConnectRecordId() {
		return connectRecordId;
	}

	public void setConnectRecordId(String connectRecordId) {
		this.connectRecordId = connectRecordId;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode());
		sb.append(",Super = ").append(super.toString());
		sb.append(", serialVersionUID=").append(serialVersionUID);
		sb.append(", proId=").append(proId);
		sb.append(", partId=").append(partId);
		sb.append(", targetUnitId=").append(targetUnitId);
		sb.append(", evalUserId=").append(evalUserId);
		sb.append(", formId=").append(formId);
		sb.append(", recordType=").append(recordType);
		sb.append(", formType=").append(formType);
		sb.append(", specificStep=").append(specificStep);
		sb.append(", totalScore=").append(totalScore);
		sb.append(", evalGrade=").append(evalGrade);
		sb.append(", gmtEval=").append(gmtEval);
		sb.append(", proName=").append(proName);
		sb.append(", contractorName=").append(contractorName);
		sb.append(", buildUnitName=").append(buildUnitName);
		sb.append(", memo=").append(memo);
		sb.append(", status=").append(status);
		sb.append(", pleaStatus=").append(pleaStatus);
		sb.append(", gmtPlea=").append(gmtPlea);
		sb.append(", pleaContent=").append(pleaContent);
		sb.append(", pleaReply=").append(pleaReply);
		sb.append(", flag=").append(flag);
		sb.append(", createBy=").append(createBy);
		sb.append(", updateBy=").append(updateBy);
		sb.append("]");
		return sb.toString();
	}
}