package com.spr.web.flow.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import javax.annotation.Resource;

import net.sf.json.JSONObject;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.service.BaseService;
import com.spr.core.common.utils.Assert;
import com.spr.core.utils.CountSet;
import com.spr.web.flow.dao.IProcDefDao;
import com.spr.web.flow.dao.IProcIdentitylinkDao;
import com.spr.web.flow.dao.IProcLineDao;
import com.spr.web.flow.dao.IProcNodeDao;
import com.spr.web.flow.dto.def.ProcIdentitylinkDTO;
import com.spr.web.flow.dto.def.ProcLineDTO;
import com.spr.web.flow.dto.def.ProcNodeDTO;
import com.spr.web.flow.entity.ProcDef;
import com.spr.web.flow.entity.ProcLine;
import com.spr.web.flow.entity.ProcNode;
import com.spr.web.flow.service.IProcIdentitylinkService;
import com.spr.web.flow.service.IProcNodeService;

@Service("procNodeService")
@Transactional
public class ProcNodeServiceImpl extends BaseService implements IProcNodeService {

	@Resource
	private IProcNodeDao procNodeDao;
	@Resource
	private IProcLineDao procLineDao;
	@Resource
	private IProcDefDao procDefDao;
	@Resource
	private IProcIdentitylinkService procIdentitylinkService;
	@Resource
	private IProcIdentitylinkDao procIdentitylinkDao;

	/**
	 * 添加流程
	 * 
	 * @param data
	 *            流程数据
	 * @param procDefId
	 *            流程定义id
	 */
	@Override
	public void addProcess(String data, String procDefId) {
		Assert.hasText(data, "流程数据不能为空！");
		Assert.hasText(procDefId, Assert.NULL_PARAM_STR("procDefId"));

		ProcDef procDef = this.procDefDao.getById(procDefId);
		Assert.notNull(procDef, Assert.EMPTY_REOCRD_STR);

		DataQuery dq = new DataQuery();
		dq.putToMap("procDefId", procDefId);
		if (this.procNodeDao.countByCondition(dq.getQueryMap()) > 0) {

			this.updateProcess(data, procDefId);
			return;
		}

		JSONObject model = JSONObject.fromObject(data);
		Assert.isTrue(model.containsKey("nodes"));
		Assert.isTrue(model.containsKey("lines"));
		JSONObject nodes = model.getJSONObject("nodes");
		JSONObject lines = model.getJSONObject("lines");

		Set<ProcNode> nodesSet = new HashSet<ProcNode>();
		Iterator<Entry<String, Object>> nodeIterable = nodes.entrySet().iterator();
		while (nodeIterable.hasNext()) {
			Entry<String, Object> entry = nodeIterable.next();

			JSONObject nd = JSONObject.fromObject(entry.getValue());

			ProcNode node = this.updateNode(nd, null, procDefId, entry.getKey());

			nodesSet.add(node);
		}

		Iterator<Entry<String, Object>> lineIterable = lines.entrySet().iterator();
		while (lineIterable.hasNext()) {
			Entry<String, Object> entry = lineIterable.next();
			JSONObject line = JSONObject.fromObject(entry.getValue());

			ProcNode preItem = getNodeByCode(nodesSet, line.getString(ProcNode.jfrom));
			ProcNode nextItem = getNodeByCode(nodesSet, line.getString(ProcNode.jto));

			String preNodeId = null;
			String nextNodeId = null;
			if (preItem != null) {
				preNodeId = preItem.getId();
			}
			if (nextItem != null) {
				nextNodeId = nextItem.getId();
			}

			this.addProcLine(line, preNodeId, nextNodeId, procDefId);
		}

	}

	/**
	 * 修改流程
	 * 
	 * @param data
	 * @param procDefId
	 */
	public void updateProcess(String data, String procDefId) {
		JSONObject model = JSONObject.fromObject(data);
		Assert.isTrue(model.containsKey("nodes"));
		Assert.isTrue(model.containsKey("lines"));
		JSONObject nodes = model.getJSONObject("nodes");
		JSONObject lines = model.getJSONObject("lines");

		Set<String> pushNodeIds = new HashSet<String>();
		Set<String> pushLineIds = new HashSet<String>();
		Iterator<String> nodeIterable = nodes.keySet().iterator();
		while (nodeIterable.hasNext()) {
			pushNodeIds.add(nodeIterable.next());
		}

		Iterator<String> lineIterable = lines.keySet().iterator();
		while (lineIterable.hasNext()) {
			pushLineIds.add(lineIterable.next());
		}

		// 源数据
		Set<String> orgNodeIds = new HashSet<String>(this.procNodeDao.getIdByProcDefId(procDefId));
		Set<String> orgLineIds = new HashSet<String>(this.procLineDao.getIdByProcDefId(procDefId));

		CountSet<String> lineCount = new CountSet<String>(orgLineIds, pushLineIds);
		lineCount.countComplementarySet();
		Set<String> addLines = lineCount.getTwo(); // 要添加的连线
		Set<String> delLines = lineCount.getOne(); // 要删除的连线
		if (!delLines.isEmpty()) {// 删除要删除的连线
			this.procLineDao.deleteByIds(new ArrayList<String>(delLines));
		}

		CountSet<String> nodeCount = new CountSet<String>(orgNodeIds, pushNodeIds);
		nodeCount.countComplementarySet();
		Set<String> addNodes = nodeCount.getTwo(); // 要添加的节点
		Set<String> delNodes = nodeCount.getOne(); // 要删除的节点
		Set<String> shareNodes = nodeCount.getShare(); // 要修改的节点

		if (!delNodes.isEmpty()) {// 删除要删除的节点
			for (String id : delNodes) {
				this.deleteProcNodes(new String[] { id });
			}
		}

		Set<ProcNode> nodesSet = new HashSet<ProcNode>();
		Iterator<Entry<String, Object>> nodeIterable2 = nodes.entrySet().iterator();
		while (nodeIterable2.hasNext()) {
			Entry<String, Object> entry = nodeIterable2.next();
			JSONObject nd = JSONObject.fromObject(entry.getValue());

			boolean flag = false;
			if (!shareNodes.isEmpty()) {// 修改节点
				for (String nid : shareNodes) {
					if (nid.equals(entry.getKey())) {
						ProcNode it = this.procNodeDao.getById(nid);
						it = this.updateNode(nd, it, procDefId, null);
						flag = true;
						nodesSet.add(it);
						break;
					}
				}
			}

			if (!flag) {
				if (!addNodes.isEmpty()) {// 添加新的节点
					for (String nid : addNodes) {
						if (nid.equals(entry.getKey())) {

							ProcNode it = this.updateNode(nd, null, procDefId, entry.getKey());
							nodesSet.add(it);
							break;
						}
					}
				}

			}

		}

		// 不用修改原来连线信息
		Iterator<Entry<String, Object>> lineIterable2 = lines.entrySet().iterator();
		while (lineIterable2.hasNext()) {

			Entry<String, Object> entry = lineIterable2.next();

			if (!addLines.isEmpty()) {
				for (String lid : addLines) {// 添加新的连线
					if (lid.equals(entry.getKey())) {

						JSONObject line = JSONObject.fromObject(entry.getValue());

						ProcNode preItem = getNodeByCode(nodesSet, line.getString(ProcNode.jfrom));
						ProcNode nextItem = getNodeByCode(nodesSet, line.getString(ProcNode.jto));

						String preNodeId = null;
						String nextNodeId = null;
						if (preItem != null) {
							preNodeId = preItem.getId();
						}
						if (nextItem != null) {
							nextNodeId = nextItem.getId();
						}

						this.addProcLine(line, preNodeId, nextNodeId, procDefId);

						break;
					}
				}
			}

		}

	}

	/**
	 * 根据任务标识符从节点集合中获取节点
	 * 
	 * @param nodes
	 * @param code
	 * @return
	 */
	private ProcNode getNodeByCode(Set<ProcNode> nodes, String code) {

		for (ProcNode it : nodes) {
			if (it.getNodeCode().equals(code) || it.getId().equals(code)) {
				return it;
			}
		}

		return null;
	}

	/**
	 * 获取流程图的数据 转化为流程图所需的格式数据
	 * 
	 * @param procDefId
	 *            流程定义id
	 */
	@Override
	public JSONObject getProcessData(String procDefId, Long checkUserId) {
		Assert.hasText(procDefId, Assert.NULL_PARAM_STR("procDefId"));
		ProcDef procDef = this.procDefDao.getById(procDefId);
		Assert.notNull(procDef, Assert.EMPTY_REOCRD_STR);

		List<ProcNode> nodes = this.procNodeDao.getByProcDefId(procDefId);
		List<ProcLine> lines = this.procLineDao.getByProcDefId(procDefId);

		JSONObject data = new JSONObject();
		data.put("title", procDef.getProcessName());

		if (nodes.isEmpty()) {
			return data;
		}

		JSONObject jnodes = new JSONObject();
		DataQuery dq = new DataQuery();
		for (ProcNode it : nodes) {
			JSONObject nd = new JSONObject();
			nd.put(ProcNode.jname, it.getNodeName());
			nd.put(ProcNode.jleft, it.getLeftPos());
			nd.put(ProcNode.jtop, it.getTopPos());
			nd.put(ProcNode.jtype, it.getNodeType());
			nd.put(ProcNode.jwidth, Integer.parseInt(it.getWidth()));
			nd.put(ProcNode.jheight, Integer.parseInt(it.getHeight()));

			nd.put(ProcNode.jlimittime, it.getLimitDay());

			dq.putToMap("nodeId", it.getId());
			List<ProcIdentitylinkDTO> ils = this.procIdentitylinkDao.selectListByCondition(dq.getQueryMap());

			if (!ils.isEmpty()) {
				StringBuilder userIds = new StringBuilder();
				StringBuilder chineseNames = new StringBuilder();
				for (ProcIdentitylinkDTO il : ils) {
					userIds.append(il.getUserId()).append(",");
					chineseNames.append(il.getUserName()).append(",");
				}

				userIds.deleteCharAt(userIds.length() - 1);
				chineseNames.deleteCharAt(chineseNames.length() - 1);

				nd.put(ProcNode.jdutyUserIds, userIds.toString());
				nd.put(ProcNode.jdutyUserNames, chineseNames.toString());
			}

			// nd.put(ProcNode.jdutyUserNames, it.getDutyUserName());
			nd.put(ProcNode.jtitle, it.getTitle());
			nd.put(ProcNode.jrequirement, it.getRequirement());
			nd.put(ProcNode.jnote, it.getNote());
			nd.put(ProcNode.jnodeId, it.getId());
			nd.put(ProcNode.jprocType, it.getProcType());

			// jnodes.put(it.getTaskCode(), nd);
			jnodes.put(it.getId(), nd);

		}

		JSONObject jlines = new JSONObject();
		for (ProcLine li : lines) {

			JSONObject line = new JSONObject();
			line.put(ProcNode.jlineType, li.getLineType());
			line.put(ProcNode.jfrom, li.getPreNodeId());
			line.put(ProcNode.jto, li.getNextNodeId());
			line.put(ProcNode.jlineName, li.getLineName());

			// jlines.put(li.getLineCode(), line);
			jlines.put(li.getId(), line);
		}

		data.put("nodes", jnodes);
		data.put("lines", jlines);

		data.put("initNum", jnodes.size() + jlines.size() + 1);

		return data;
	}

	/**
	 * 更新或新增流程节点
	 * 
	 * @param nd
	 *            流程数据对象
	 * @param node
	 *            流程对象
	 * @param procDefId
	 *            流程定义id
	 * @param nodeCode
	 *            流程节点码
	 * @return
	 */
	private ProcNode updateNode(JSONObject nd, ProcNode node, String procDefId, String nodeCode) {
		String title = null;
		if (nd.containsKey(ProcNode.jtitle)) {
			title = nd.getString(ProcNode.jtitle);
		}

		String requirement = null;
		if (nd.containsKey(ProcNode.jrequirement)) {
			requirement = nd.getString(ProcNode.jrequirement);
		}

		String note = null;
		if (nd.containsKey(ProcNode.jnote)) {
			note = nd.getString(ProcNode.jnote);
		}

		Integer limitDay = null;

		if (nd.containsKey(ProcNode.jlimittime)) {
			limitDay = nd.getInt(ProcNode.jlimittime);
		} else {
			limitDay = 0;
			// throw new BusinessException(nodeCode + " 未设置任务时限");
		}

		String subDefId = null;
		if (nd.containsKey(ProcNode.jsubprocessId)) {
			subDefId = StringUtils.isBlank(nd.getString(ProcNode.jsubprocessId)) ? null : nd.getString(ProcNode.jsubprocessId);
		}
		String nodeName;
		String procType;
		// 开始节点的特殊处理
		if (nd.getString(ProcNode.jtype).equals("start")) {
			nodeName = "开始";
			procType = "build";
		} else {
			nodeName = nd.getString(ProcNode.jname);
			procType = null;
		}

		if (node == null) {
			node = new ProcNode();
			node.setProcDefId(procDefId);
			node.setNodeName(nodeName);
			node.setNodeCode(nodeCode);
			node.setNodeType(nd.getString(ProcNode.jtype));
			node.setLeftPos(new BigDecimal(nd.getString(ProcNode.jleft)));
			node.setTopPos(new BigDecimal(nd.getString(ProcNode.jtop)));
			node.setWidth(nd.getString(ProcNode.jwidth));
			node.setHeight(nd.getString(ProcNode.jheight));
			node.setSubDefId(subDefId);
			// 保存审核的单位类别
			node.setProcType(procType);

			node.setTitle(title);
			node.setRequirement(requirement);
			node.setNote(note);
			node.setLimitDay(limitDay);
			// node.setDutyDepartId(dto.getDutyDepartId());
			// node.setDutyUserId(dutyUserId);
			// node.setAllotStrategy(dto.getAllotStrategy());
			node.setStatus(ProcNode.DEF_STATUS);
			node.setCreateBy(getNowUser().getUsername());

			this.procNodeDao.insert(node);

			if (this.logger.isInfoEnabled()) {
				this.logger.info("Add: " + node.toString());
			}

			// 添加负责人
			String userIds = "";

			if (nd.containsKey(ProcNode.jdutyUserIds)) {
				userIds = nd.getString(ProcNode.jdutyUserIds);
			}

			if (!StringUtils.isBlank(userIds)) {
				String[] userIdsArray = userIds.split(",");
				ProcIdentitylinkDTO il = new ProcIdentitylinkDTO(procDefId, node.getId());

				Set<String> userIdSet = new HashSet<String>(Arrays.asList(userIdsArray));
				for (String uid : userIdSet) {
					il.setUserId(uid);
					this.procIdentitylinkService.addProcIdentitylink(il);
				}
			}

		} else {

			node.setNodeName(nodeName);
			// node.setNodeCode(nodeCode);
			node.setNodeType(nd.getString(ProcNode.jtype));
			node.setLeftPos(new BigDecimal(nd.getString(ProcNode.jleft)));
			node.setTopPos(new BigDecimal(nd.getString(ProcNode.jtop)));
			node.setWidth(nd.getString(ProcNode.jwidth));
			node.setHeight(nd.getString(ProcNode.jheight));
			node.setSubDefId(subDefId);
			// node.setProcType(dto.getProcType());
			node.setTitle(title);
			node.setRequirement(requirement);
			node.setNote(note);
			node.setLimitDay(limitDay);
			// node.setDutyDepartId(dto.getDutyDepartId());
			// node.setDutyUserId(dutyUserId);
			// node.setAllotStrategy(dto.getAllotStrategy());
			node.setStatus(ProcNode.DEF_STATUS);
			node.setUpdateBy(getNowUser().getUsername());
			node.setGmtModified(new Date());

			// 保存审核的单位类别
			node.setProcType(procType);

			this.procNodeDao.update(node);

			if (this.logger.isInfoEnabled()) {
				this.logger.info("Update: " + node.toString());
			}

			// 更新负责人
			if (nd.containsKey(ProcNode.jdutyUserIds)) {

				String userIds = nd.getString(ProcNode.jdutyUserIds);
				if (!StringUtils.isBlank(userIds)) {
					String[] userIdsArray = userIds.split(",");

					// 当前群组的用户集
					List<String> currUsserIds = this.procIdentitylinkDao.getUserIdsByNodeId(node.getId());
					// 新的用户集合
					Set<String> userIdSet = new HashSet<String>(Arrays.asList(userIdsArray));

					CountSet countSet = new CountSet(new HashSet<String>(currUsserIds), userIdSet);
					countSet.countComplementarySet();

					// 计算出要删除的用户id
					Set<String> deleteSet = countSet.getOne();

					// 计算出要新插入的用户id
					Set<String> addSet = countSet.getTwo();

					for (String uid : deleteSet) {
						this.procIdentitylinkDao.deleteByUserIdAndNodeId(uid, node.getId());
					}

					if (!addSet.isEmpty()) {
						ProcIdentitylinkDTO il = new ProcIdentitylinkDTO(procDefId, node.getId());
						for (String uid : addSet) {
							il.setUserId(uid);
							this.procIdentitylinkService.addProcIdentitylink(il);
						}
					}
				} else {
					// 清空负责人
					// 当前群组的用户集
					List<String> currUsserIds = this.procIdentitylinkDao.getUserIdsByNodeId(node.getId());

					for (String uid : currUsserIds) {
						this.procIdentitylinkDao.deleteByUserIdAndNodeId(uid, node.getId());
					}
				}
			}
		}

		return node;
	}

	/**
	 * 添加连线节点
	 * 
	 * @param line
	 * @param preNodeId
	 * @param nextNodeId
	 * @param procDefId
	 * @return
	 */
	private ProcLine addProcLine(JSONObject line, String preNodeId, String nextNodeId, String procDefId) {

		ProcLine procLine = new ProcLine();

		procLine.setProcDefId(procDefId);
		procLine.setLineName(line.getString(ProcNode.jlineName));
		procLine.setLineType(line.getString(ProcNode.jlineName));
		procLine.setLineCode(line.getString(ProcNode.jlineName));
		// procLine.setLineAlt(dto.getLineAlt());
		if (line.containsKey(ProcNode.jlineMid)) {
			procLine.setMidPos(new BigDecimal(line.getString(ProcNode.jlineMid)));
		}

		procLine.setPreNodeId(preNodeId);
		procLine.setNextNodeId(nextNodeId);
		procLine.setStatus(ProcLine.DEF_STATUS);
		procLine.setCreateBy(getNowUser().getUsername());

		this.procLineDao.insert(procLine);

		return procLine;

	}

	/**
	 * 分页查询
	 * 
	 * @param dq
	 */
	@Override
	public Page<ProcNodeDTO> searchByPage(DataQuery dq) {

		Long recTotal = this.procNodeDao.countByCondition(dq.assemblePageOffset().getQueryMap());
		dq.assembleOrderInfo(ProcNode.class, "l");
		List<ProcNodeDTO> resultlist = this.procNodeDao.selectListByCondition(dq.getQueryMap());

		return new Page<ProcNodeDTO>(dq.getCurrentPage(), dq.getPageSize(), resultlist, recTotal);
	}

	/**
	 * 查询详细
	 * 
	 * @param id
	 */
	@Override
	public ProcNodeDTO getDetailById(String id) {
		Assert.hasText(id, Assert.NULL_PARAM_STR("id"));

		ProcNodeDTO result = this.procNodeDao.getDetailById(id);
		Assert.notNull(result, Assert.EMPTY_REOCRD_STR);

		return result;
	}

	/**
	 * 添加
	 * 
	 * @param dto
	 */
	@Override
	public void addProcNode(ProcNodeDTO dto) {

		ProcNode model = new ProcNode();
		model.setProcDefId(dto.getProcDefId());
		model.setNodeName(dto.getNodeName());
		model.setNodeCode(dto.getNodeCode());
		model.setNodeType(dto.getNodeType());
		model.setLeftPos(dto.getLeftPos());
		model.setTopPos(dto.getTopPos());
		model.setWidth(dto.getWidth());
		model.setHeight(dto.getHeight());
		model.setSubDefId(dto.getSubDefId());
		model.setProcType(dto.getProcType());
		model.setTitle(dto.getTitle());
		model.setRequirement(dto.getRequirement());
		model.setNote(dto.getNote());
		model.setLimitDay(dto.getLimitDay());
		model.setDutyDepartId(dto.getDutyDepartId());
		model.setDutyUserId(dto.getDutyUserId());
		model.setAllotStrategy(dto.getAllotStrategy());
		model.setStatus(dto.getStatus());
		model.setCreateBy(dto.getCreateBy());
		model.setUpdateBy(dto.getUpdateBy());
		model.setGmtCreate(dto.getGmtCreate());
		model.setGmtModified(dto.getGmtModified());

		this.procNodeDao.insert(model);

		if (this.logger.isInfoEnabled()) {
			this.logger.info("Add: " + model.toString());
		}
	}

	/**
	 * 修改
	 * 
	 * @param dto
	 */
	@Override
	public void updateProcNode(ProcNodeDTO dto) {
		Assert.hasText(dto.getId(), Assert.NULL_PARAM_STR("id"));

		ProcNode model = this.procNodeDao.getById(dto.getId());
		Assert.notNull(model, Assert.EMPTY_REOCRD_STR);

		model.setProcDefId(dto.getProcDefId());
		model.setNodeName(dto.getNodeName());
		model.setNodeCode(dto.getNodeCode());
		model.setNodeType(dto.getNodeType());
		model.setLeftPos(dto.getLeftPos());
		model.setTopPos(dto.getTopPos());
		model.setWidth(dto.getWidth());
		model.setHeight(dto.getHeight());
		model.setSubDefId(dto.getSubDefId());
		model.setProcType(dto.getProcType());
		model.setTitle(dto.getTitle());
		model.setRequirement(dto.getRequirement());
		model.setNote(dto.getNote());
		model.setLimitDay(dto.getLimitDay());
		model.setDutyDepartId(dto.getDutyDepartId());
		model.setDutyUserId(dto.getDutyUserId());
		model.setAllotStrategy(dto.getAllotStrategy());
		model.setStatus(dto.getStatus());
		model.setCreateBy(dto.getCreateBy());
		model.setUpdateBy(dto.getUpdateBy());
		model.setGmtCreate(dto.getGmtCreate());
		model.setGmtModified(dto.getGmtModified());

		this.procNodeDao.update(model);

		if (this.logger.isInfoEnabled()) {
			this.logger.info("Update: " + model.toString());
		}
	}

	/**
	 * 删除
	 * 
	 * @param ids
	 */
	@Override
	public void deleteProcNodes(String[] ids) {
		for (int i = 0; i < ids.length; i++) {
			this.procNodeDao.deleteById(ids[i]);

			if (this.logger.isInfoEnabled()) {
				this.logger.info("Delete：:" + ids[i]);
			}
		}
	}

	/**
	 * 根据当前节点获取下一个节点
	 * 
	 * @param curr
	 * @param nodes
	 * @param lines
	 * @return
	 */
	private ProcNodeDTO getNextNode(ProcNodeDTO curr, List<ProcNodeDTO> nodes, List<ProcLineDTO> lines) {
		for (ProcLineDTO l : lines) {
			if (l.getPreNodeId().equals(curr.getId())) {
				for (ProcNodeDTO nd : nodes) {
					if (nd.getId().equals(l.getNextNodeId())) {
						return nd;
					}
				}
			}
		}
		return null;
	}

	/**
	 * 获取下一节点
	 */
	@Override
	public ProcNodeDTO getNextNode(ProcNodeDTO currNode) {

		DataQuery dq = new DataQuery();
		dq.setSidx("sort");
		dq.setSord("asc");
		dq.putToMap("procDefId", currNode.getProcDefId());
		List<ProcNodeDTO> nodes = this.procNodeDao.selectListByCondition(dq.getQueryMap());
		List<ProcLineDTO> lines = this.procLineDao.selectListByCondition(dq.getQueryMap());

		return this.getNextNode(currNode, nodes, lines);
	}

}
