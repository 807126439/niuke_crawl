package com.spr.web.flow.controller;

import com.spr.web.flow.service.IExecLineService;
import com.spr.web.flow.dto.exec.ExecLineDTO;
import com.spr.core.common.controller.BaseController;

import java.util.Map;
import javax.annotation.Resource;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import javax.servlet.http.HttpServletRequest;

import com.spr.core.common.bean.AjaxJson;
import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;

@Controller
@Scope("prototype")
@RequestMapping("/execLineController")
public class ExecLineController extends BaseController{

	private static final long serialVersionUID = 1L;
	
	@Resource
	private IExecLineService execLineService;
	
	
	
	@RequestMapping(value="/viewPage",method={RequestMethod.GET})
	public String viewPage(HttpServletRequest request){
		this.wrapMenuTitle(request);
		
		return "flow/execLine/execLineList.jsp";
	}
	
	
	@RequestMapping(value="/getPageData",method={RequestMethod.POST})
	@ResponseBody
	public Map<String, Object> loadPageData(HttpServletRequest request,DataQuery dq){

		this.wrapTableQueryParams(request, dq);
				
		Page<ExecLineDTO> pageResult = this.execLineService.searchByPage(dq);
		 
		return this.handlePageReult(pageResult);
	}
	
	
	@RequestMapping(value="/skipAddExecLine")
	public String skipAddExecLine(HttpServletRequest request){
		
		
		return "flow/execLine/addExecLine.jsp";
	}
	
	
	@RequestMapping(value="/addExecLine",method={RequestMethod.POST})
	@ResponseBody
	public AjaxJson addExecLine(ExecLineDTO dto) throws Exception{
	
		this.execLineService.addExecLine(dto);
		
		
		return new AjaxJson(this.ADD_SUCCESS_MESSAGE, AjaxJson.success);
	}
	
	
	@RequestMapping("/getDetail")
	public String loadDetail(HttpServletRequest request,@RequestParam(value="id",required=true)String id){
			  		
	    ExecLineDTO result = this.execLineService.getDetailById(id);
		request.setAttribute("model", result);
		
	
		return "flow/execLine/editExecLine.jsp";
	}
	
	
	@RequestMapping(value="/editExecLine",method={RequestMethod.POST})
	@ResponseBody
	public AjaxJson updateExecLine(ExecLineDTO dto){
		
		this.execLineService.updateExecLine(dto);
				
		return new AjaxJson(this.EDIT_SUCCESS_MESSAGE, AjaxJson.success);
	}
	
	
	@RequestMapping(value="/deleteExecLine",method={RequestMethod.POST})
	@ResponseBody
	public AjaxJson deleteExecLine(String[] ids){
		
		this.execLineService.deleteExecLines(ids);
		
		
		return new AjaxJson(this.DEL_SUCCESS_MESSAGE, AjaxJson.success);
	}
	
}
