package com.spr.web.flow.service;

public interface AdditionOperation {

	/**
	 * 流程结束操作
	 * 
	 * @param dataId
	 */
	void processEnd(String dataId);

	/**
	 * 流程失败操作
	 * 
	 * @param dataId
	 */
	void processFail(String dataId);

}
