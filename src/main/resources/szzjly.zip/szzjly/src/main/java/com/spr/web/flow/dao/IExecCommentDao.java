package com.spr.web.flow.dao;

import java.util.List;
import java.util.Map;

import com.spr.core.common.dao.IBaseDao;
import com.spr.web.flow.dto.exec.ExecCommentDTO;
import com.spr.web.flow.entity.ExecComment;

public interface IExecCommentDao extends IBaseDao<String, ExecComment> {

	Long countByCondition(Map<String, Object> queryMap);

	List<ExecCommentDTO> selectListByCondition(Map<String, Object> queryMap);

	ExecCommentDTO getDetailById(String id);

	int deleteByProcInstId(String procInstId);
}