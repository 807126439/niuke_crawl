package com.spr.web.evaluate.controller;

import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.spr.core.common.bean.AjaxJson;
import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.controller.BaseController;
import com.spr.core.common.dto.DownLoadDTO;
import com.spr.web.evaluate.dto.record.EvaluateRecordFileDTO;
import com.spr.web.evaluate.service.IEvaluateRecordFileService;

@Controller
@Scope("prototype")
@RequestMapping("/evaluateRecordFileController")
public class EvaluateRecordFileController extends BaseController{

	private static final long serialVersionUID = 1L;
	
	@Resource
	private IEvaluateRecordFileService evaluateRecordFileService;
	
	
	
	@RequestMapping(value="/viewPage",method={RequestMethod.GET})
	public String viewPage(HttpServletRequest request){
		this.wrapMenuTitle(request);
		
		return "evaluate/evaluateRecordFile/evaluateRecordFileList.jsp";
	}
	
	
	@RequestMapping(value="/getPageData",method={RequestMethod.POST})
	@ResponseBody
	public Map<String, Object> loadPageData(HttpServletRequest request,DataQuery dq){

		this.wrapTableQueryParams(request, dq);
				
		Page<EvaluateRecordFileDTO> pageResult = this.evaluateRecordFileService.searchByPage(dq);
		 
		return this.handlePageReult(pageResult);
	}
	
	
	@RequestMapping(value="/skipAddEvaluateRecordFile")
	public String skipAddEvaluateRecordFile(HttpServletRequest request, @RequestParam String evalId){
		
		request.setAttribute("evalId", evalId);
		return "evaluate/evaluateRecordFile/addEvaluateRecordFile.jsp";
	}
	
	@RequestMapping(value="/addEvaluateRecordFile",method={RequestMethod.POST})
	@ResponseBody
	public AjaxJson addEvaluateRecordFile(EvaluateRecordFileDTO dto) throws Exception{
	
		this.evaluateRecordFileService.addEvaluateRecordFile(dto);
		
		
		return new AjaxJson(this.ADD_SUCCESS_MESSAGE, AjaxJson.success);
	}
	
	@RequestMapping(value="/skipViewEvaluateRecordFile")
	public String skipViewEvaluateRecordFile(HttpServletRequest request, @RequestParam String evalId){
		
		request.setAttribute("evalId", evalId);
		return "evaluate/evaluateRecordFile/viewEvaluateRecordFile.jsp";
	}
	
	
	@RequestMapping("/getDetail")
	public String loadDetail(HttpServletRequest request,@RequestParam(value="id",required=true)String id){
			  		
	    EvaluateRecordFileDTO result = this.evaluateRecordFileService.getDetailById(id);
		request.setAttribute("model", result);
		
	
		return "evaluate/evaluateRecordFile/editEvaluateRecordFile.jsp";
	}
	
	
	@RequestMapping(value="/editEvaluateRecordFile",method={RequestMethod.POST})
	@ResponseBody
	public AjaxJson updateEvaluateRecordFile(EvaluateRecordFileDTO dto){
		
		this.evaluateRecordFileService.updateEvaluateRecordFile(dto);
				
		return new AjaxJson(this.EDIT_SUCCESS_MESSAGE, AjaxJson.success);
	}
	

    // 删除
	@RequestMapping(value="/deleteEvaluateRecordFile",method={RequestMethod.POST})
	@ResponseBody
	public AjaxJson deleteEvaluateRecordFile(String[] ids){
		this.evaluateRecordFileService.deleteEvaluateRecordFiles(ids);
		return new AjaxJson(this.DEL_SUCCESS_MESSAGE, AjaxJson.success);
	}
	
    // ====================附件处理====================
    // 分页查询
    @RequestMapping(value = "/getMyFileData", method = { RequestMethod.POST })
    @ResponseBody
    public Map<String, Object> loadFileByPage(HttpServletRequest request, DataQuery dq, String fileName, String evalId) {
		dq.putToMap("evalId", evalId);
		dq.putToMap("fileName", StringUtils.isBlank(fileName) ? null : '%' + fileName + '%');
		Page<EvaluateRecordFileDTO> pageResult = this.evaluateRecordFileService.searchByPage(dq);
	return this.handleLayerPageReult(pageResult);
    }

    // 上传
    @RequestMapping("/uploadFile")
    @ResponseBody
    public AjaxJson uploadFile(@RequestParam(value = "file") CommonsMultipartFile file, String evalId) {
    	this.evaluateRecordFileService.addEvaluateRecordFile(file, evalId);
    	return new AjaxJson(this.UPLOAD_SUCCESS_MESSAGE, AjaxJson.success);
    }

    // 下载
    @RequestMapping(value = "/downFile")
    public void downFile(HttpServletRequest request, HttpServletResponse response, @RequestParam(required = true) String dataId) {
    	this.createDownLoadStream(request, response, this.evaluateRecordFileService.getDownLoadInfo(dataId));
    }
	
}
