package com.spr.web.flow.dao;

import java.util.List;
import java.util.Map;

import com.spr.core.common.dao.IBaseDao;
import com.spr.web.flow.dto.exec.ExecAttachmentDTO;
import com.spr.web.flow.entity.ExecAttachment;

public interface IExecAttachmentDao extends IBaseDao<String, ExecAttachment> {

	Long countByCondition(Map<String, Object> queryMap);

	List<ExecAttachmentDTO> selectListByCondition(Map<String, Object> queryMap);

	ExecAttachmentDTO getDetailById(String id);

	int deleteByProcInstId(String procInstId);
}