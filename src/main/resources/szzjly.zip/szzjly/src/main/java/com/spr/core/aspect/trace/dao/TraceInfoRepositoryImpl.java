/**
 * 
 */
package com.spr.core.aspect.trace.dao;

import org.bson.Document;

import com.mongodb.client.MongoCollection;
import com.spr.core.aspect.trace.entity.TraceInfo;

/**
 * @date 2019-4-28
 * @author wanve_java_cjy
 *
 */
public class TraceInfoRepositoryImpl implements TraceInfoRepository {
	
	private MongoCollection<Document> mongoCollection;

	public MongoCollection<Document> getMongoCollection() {
		return mongoCollection;
	}

	public void setMongoCollection(MongoCollection<Document> mongoCollection) {
		this.mongoCollection = mongoCollection;
	}

	@Override
	public int deleteById(String id) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(TraceInfo entity) {
		Document document = new Document();
		document.append("traceId", entity.getTraceId());
		document.append("parentId", entity.getParentId());
		document.append("spanId", entity.getSpanId());
		document.append("runTime", entity.getRunTime());
		document.append("startTimeMillis", entity.getStartTimeMillis());
		document.append("endTimeMillis", entity.getEndTimeMillis());
		document.append("startTime", entity.getStartTime());
		document.append("endTime", entity.getEndTime());
		document.append("className", entity.getClassName());
		document.append("methodName", entity.getMethodName());
		document.append("args", entity.getArgs());
		document.append("modifier", entity.getModifier());
		document.append("kind", entity.getKind());
		document.append("contextPath", entity.getContextPath());
		document.append("userId", entity.getUserId());
		this.mongoCollection.insertOne(document);
		return 0;
	}

	@Override
	public int insertSelective(TraceInfo entity) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int update(TraceInfo entity) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public TraceInfo getById(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateSelective(TraceInfo entity) {
		// TODO Auto-generated method stub
		return 0;
	}

}
