/**
 * 
 */
package com.spr.core.aspect.trace;

import org.slf4j.Logger;

import com.spr.core.aspect.trace.dto.TraceInfoDTO;
import com.spr.core.aspect.trace.service.ITraceService;

/**
 * @date 2019-4-12
 * @author wanve_java_cjy
 *
 */
public class TraceThread implements Runnable {
	
	private TraceInfoDTO dto;
	private ITraceService traceService;
	private Logger logger;

	public TraceThread() {
		super();
	}

	public TraceThread(TraceInfoDTO dto, ITraceService traceService, Logger logger) {
		super();
		this.dto = dto;
		this.traceService = traceService;
		this.logger = logger;
	}

	@Override
	public void run() {
		if (this.dto == null || this.traceService == null) {
			return;
		}
		this.traceService.add(dto);
		this.logger.info(dto.toString());
	}

}
