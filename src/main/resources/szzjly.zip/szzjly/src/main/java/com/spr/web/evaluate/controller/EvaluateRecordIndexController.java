package com.spr.web.evaluate.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spr.core.common.bean.AjaxJson;
import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.controller.BaseController;
import com.spr.web.evaluate.dto.record.EvaluateRecordIndexDTO;
import com.spr.web.evaluate.dto.record.EvaluateRecordInputDTO;
import com.spr.web.evaluate.service.IEvaluateRecordIndexService;
import com.spr.web.evaluate.service.IEvaluateRecordInputService;

@Controller
@Scope("prototype")
@RequestMapping("/evaluateRecordIndexController")
public class EvaluateRecordIndexController extends BaseController{

	private static final long serialVersionUID = 1L;
	
	@Resource
	private IEvaluateRecordIndexService evaluateRecordIndexService;	
	@Resource
	private IEvaluateRecordInputService evaluateRecordInputService;
	
	
	
	@RequestMapping(value="/viewPage",method={RequestMethod.GET})
	public String viewPage(HttpServletRequest request){
		this.wrapMenuTitle(request);
		
		return "evaluate/evaluateRecordIndex/evaluateRecordIndexList.jsp";
	}
	
	
	@RequestMapping(value="/getPageData",method={RequestMethod.POST})
	@ResponseBody
	public Map<String, Object> loadPageData(HttpServletRequest request,DataQuery dq){

		this.wrapTableQueryParams(request, dq);
				
		Page<EvaluateRecordIndexDTO> pageResult = this.evaluateRecordIndexService.searchByPage(dq);
		 
		return this.handlePageReult(pageResult);
	}
	
	
	@RequestMapping(value="/skipAddEvaluateRecordIndex")
	public String skipAddEvaluateRecordIndex(HttpServletRequest request){
		
		
		return "evaluate/evaluateRecordIndex/addEvaluateRecordIndex.jsp";
	}
	
	
	@RequestMapping(value="/addEvaluateRecordIndex",method={RequestMethod.POST})
	@ResponseBody
	public AjaxJson addEvaluateRecordIndex(EvaluateRecordIndexDTO dto) throws Exception{
	
		this.evaluateRecordIndexService.addEvaluateRecordIndex(dto);
		
		
		return new AjaxJson(this.ADD_SUCCESS_MESSAGE, AjaxJson.success);
	}
	
	
	@RequestMapping("/getDetail")
	public String loadDetail(HttpServletRequest request,@RequestParam(value="id",required=true)String id){
			  		
	    EvaluateRecordIndexDTO result = this.evaluateRecordIndexService.getDetailById(id);
		request.setAttribute("model", result);
		
	
		return "evaluate/evaluateRecordIndex/editEvaluateRecordIndex.jsp";
	}
	
	
	@RequestMapping(value="/editEvaluateRecordIndex",method={RequestMethod.POST})
	@ResponseBody
	public AjaxJson updateEvaluateRecordIndex(EvaluateRecordIndexDTO dto){
		
		this.evaluateRecordIndexService.updateEvaluateRecordIndex(dto);
				
		return new AjaxJson(this.EDIT_SUCCESS_MESSAGE, AjaxJson.success);
	}
	
	
	@RequestMapping(value="/deleteEvaluateRecordIndex",method={RequestMethod.POST})
	@ResponseBody
	public AjaxJson deleteEvaluateRecordIndex(String[] ids){
		
		this.evaluateRecordIndexService.deleteEvaluateRecordIndexs(ids);
		
		
		return new AjaxJson(this.DEL_SUCCESS_MESSAGE, AjaxJson.success);
	}

	// 异步加载评分指标
	@RequestMapping(value = "/getIndex", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson getIndex(DataQuery dq, @RequestParam String parentId, @RequestParam String evalId) {
		dq.setNotQueryPage();
		dq.putToMap("evalId", evalId);
		// Map<String, BigDecimal> indexInputMap = this.evaluateRecordInputService.selectIndexInputMapByCondition(dq);
		Map<String, EvaluateRecordInputDTO> indexInputMap = this.evaluateRecordInputService.selectIndexModelMapByCondition(dq);
		
		dq.clear();
		dq.putToMap("originalId", parentId);
		dq.putToMap("evalId", evalId);
		EvaluateRecordIndexDTO title = this.evaluateRecordIndexService.selectOneByCondition(dq);
		
		List<EvaluateRecordIndexDTO> list = this.evaluateRecordIndexService.getSubIndexListWithModified(dq, (title == null) ? "" : title.getId(), indexInputMap);
		return new AjaxJson("加载完成", AjaxJson.success, list);
	}
	
}
