package com.spr.web.evaluate.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.service.BaseService;
import com.spr.core.common.utils.Assert;
import com.spr.core.gobal.GobalVal;
import com.spr.web.evaluate.dao.IEvaluateAppealDao;
import com.spr.web.evaluate.dao.IEvaluateRecordDao;
import com.spr.web.evaluate.dto.appeal.EvaluateAppealDTO;
import com.spr.web.evaluate.dto.record.EvaluateRecordDTO;
import com.spr.web.evaluate.entity.EvaluateAppeal;
import com.spr.web.evaluate.entity.EvaluateRecord;
import com.spr.web.evaluate.service.IEvaluateAppealFileService;
import com.spr.web.evaluate.service.IEvaluateAppealService;
import com.spr.web.system.dao.IUserDao;

@Service("evaluateAppealService")
@Transactional
public class EvaluateAppealServiceImpl extends BaseService implements IEvaluateAppealService {

	@Resource
	private IEvaluateAppealFileService evaluateAppealFileService;
	@Resource
	private IEvaluateAppealDao evaluateAppealDao;
	@Resource
	private IEvaluateRecordDao evaluateRecordDao;
	@Resource
	private IUserDao userDao;
	
	private void initText(List<EvaluateAppealDTO> list) {
		for (EvaluateAppealDTO dto : list) {
			dto.setIsMine(this.getNowUserId().equals(dto.getReplyUserId()));
		}
	}

	@Override
	public List<EvaluateAppealDTO> selectListByCondition(DataQuery dq) {
		dq.assemblePageOffset();
		dq.assembleOrderInfo(EvaluateAppeal.class, null);
		List<EvaluateAppealDTO> resultlist = this.evaluateAppealDao.selectListByCondition(dq.getQueryMap());
		
		initText(resultlist);
		return resultlist;
	}
	
	/**
	 * 分页查询
	 * 
	 * @param dq
	 */
	@Override
	public Page<EvaluateAppealDTO> searchByPage(DataQuery dq) {

		Long recTotal = this.evaluateAppealDao.countByCondition(dq.assemblePageOffset().getQueryMap());
		dq.assembleOrderInfo(EvaluateAppeal.class, null);
		List<EvaluateAppealDTO> resultlist = this.evaluateAppealDao.selectListByCondition(dq.getQueryMap());

		return new Page<EvaluateAppealDTO>(dq.getCurrentPage(), dq.getPageSize(), resultlist, recTotal);
	}

	/**
	 * 查询详细
	 * 
	 * @param id
	 */
	@Override
	public EvaluateAppealDTO getDetailById(String id) {
		Assert.hasText(id, Assert.NULL_PARAM_STR("id"));

		EvaluateAppealDTO result = this.evaluateAppealDao.getDetailById(id);
		Assert.notNull(result, Assert.EMPTY_REOCRD_STR);

		return result;
	}
	
	/**
	 * 添加
	 * 
	 * @param dto
	 */
	@Override
	public void addEvaluateAppeal(EvaluateAppealDTO dto) {
		
		String evaluateRecordId = dto.getEvaluateRecordId();
		Assert.hasText(evaluateRecordId, Assert.NULL_PARAM_STR("evaluateRecordId"));
		
		EvaluateRecord evaluateRecord = this.evaluateRecordDao.getById(evaluateRecordId);
		Assert.notNull(evaluateRecord, Assert.EMPTY_REOCRD_STR);
		
		EvaluateAppeal model = new EvaluateAppeal();
		model.setEvaluateRecordId(dto.getEvaluateRecordId());
		model.setContent(dto.getContent());
		model.setReplyUserId(getNowUser().getId()); // 回复人
		model.setReplyUnitId(getNowUser().getUnitId());
		// model.setTargetUnitId(this.userDao.getDetailById(evaluateRecord.getEvalUserId()).getUnitId()); // 回复目标
		model.setStatus(GobalVal.STATUS_ENABLE);
		model.setFlag(GobalVal.NORMAL_FLAG);
		model.setCreateBy(getNowUser().getUnitName());
		
		this.evaluateAppealDao.insert(model);
		
		// 上传附件
		this.evaluateAppealFileService.addEvaluateAppealFile(evaluateRecordId, model.getId(), dto.getUcode());
		
		this.writeInfoLog("Add: " + model.toString());
		
	}

	// 添加履约异议反馈
	@Override
	public void addEvaluateAppealPleaContent(EvaluateRecordDTO dto) {
		
		String evaluateRecordId = dto.getId();
		Assert.hasText(evaluateRecordId, Assert.NULL_PARAM_STR("evaluateRecordId"));
		
		EvaluateRecord evaluateRecord = this.evaluateRecordDao.getById(evaluateRecordId);
		Assert.notNull(evaluateRecord, Assert.EMPTY_REOCRD_STR);
		
		EvaluateAppeal model = new EvaluateAppeal();
		model.setEvaluateRecordId(dto.getId());
		model.setContent(dto.getPleaContent());
		model.setReplyUserId(this.getNowUser().getId()); // 回复人
		model.setReplyUnitId(this.getNowUser().getUnitId());
		model.setTargetUnitId(this.userDao.getDetailById(evaluateRecord.getEvalUserId()).getUnitId()); // 回复目标
		model.setStatus(GobalVal.STATUS_ENABLE);
		model.setFlag(GobalVal.NORMAL_FLAG);
		model.setCreateBy(this.getNowUser().getUnitName());
		
		this.evaluateAppealDao.insert(model);
		
		this.writeInfoLog("Add: " + model.toString());
	}
	
	// 添加异议反馈回复
	@Override
	public void addEvaluateAppealPleaReply(EvaluateRecordDTO dto) {
		
		String evaluateRecordId = dto.getId();
		Assert.hasText(evaluateRecordId, Assert.NULL_PARAM_STR("evaluateRecordId"));

		EvaluateRecord evaluateRecord = this.evaluateRecordDao.getById(evaluateRecordId);
		Assert.notNull(evaluateRecord, Assert.EMPTY_REOCRD_STR);

		EvaluateAppeal model = new EvaluateAppeal();
		model.setEvaluateRecordId(dto.getId());
		model.setContent(dto.getPleaReply());
		model.setReplyUserId(this.getNowUser().getId()); // 回复人
		model.setReplyUnitId(this.getNowUser().getUnitId());
		model.setTargetUnitId(evaluateRecord.getTargetUnitId()); // 回复目标
		model.setStatus(GobalVal.STATUS_ENABLE);
		model.setFlag(GobalVal.NORMAL_FLAG);
		model.setCreateBy(this.getNowUser().getUnitName());

		this.evaluateAppealDao.insert(model);

		this.writeInfoLog("Add: " + model.toString());
	}

	/**
	 * 修改
	 * 
	 * @param dto
	 */
	@Override
	public void updateEvaluateAppeal(EvaluateAppealDTO dto) {
		Assert.hasText(dto.getId(), Assert.NULL_PARAM_STR("id"));

		EvaluateAppeal model = this.evaluateAppealDao.getById(dto.getId());
		Assert.notNull(model, Assert.EMPTY_REOCRD_STR);

		model.setEvaluateRecordId(dto.getEvaluateRecordId());
		model.setContent(dto.getContent());
		model.setReplyUserId(dto.getReplyUserId());
		model.setReplyUnitId(dto.getReplyUnitId());
		model.setTargetUnitId(dto.getTargetUnitId());
		model.setStatus(dto.getStatus());
		model.setFlag(dto.getFlag());
		model.setCreateBy(dto.getCreateBy());
		model.setUpdateBy(dto.getUpdateBy());
		model.setGmtCreate(dto.getGmtCreate());
		model.setGmtModified(dto.getGmtModified());

		this.evaluateAppealDao.update(model);

		this.writeInfoLog("Update: " + model.toString());

	}

	/**
	 * 删除
	 * 
	 * @param ids
	 */
	@Override
	public void deleteEvaluateAppeals(String[] ids) {
		for (int i = 0; i < ids.length; i++) {
			this.evaluateAppealDao.deleteById(ids[i]);
			this.writeInfoLog("Delete id:" + ids[i]);
		}
	}

	@Override
	public List<EvaluateAppealDTO> selectEvaluateAppealAndFileList(String evaluateRecordId) {

		// TODO Auto-generated method stub
		return null;
	}

}
