package com.spr.web.evaluate.dao;

import java.util.List;
import java.util.Map;

import com.spr.core.common.dao.IBaseDao;
import com.spr.web.evaluate.dto.form.EvaluateFormIndexDTO;
import com.spr.web.evaluate.entity.EvaluateFormIndex;

public interface IEvaluateFormIndexDao extends IBaseDao<String, EvaluateFormIndex> {

	Long countByCondition(Map<String, Object> queryMap);

	List<EvaluateFormIndexDTO> selectListByCondition(Map<String, Object> queryMap);

	EvaluateFormIndexDTO getDetailById(String id);

	int deleteByCondition(Map<String, Object> queryMap);

	EvaluateFormIndexDTO getTitleByParentId(String parentId);
}