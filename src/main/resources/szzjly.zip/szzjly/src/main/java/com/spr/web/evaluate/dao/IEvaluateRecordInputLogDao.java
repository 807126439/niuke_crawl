package com.spr.web.evaluate.dao;

import com.spr.core.common.dao.IBaseDao;
import com.spr.web.evaluate.dto.record.EvaluateRecordInputLogDTO;
import com.spr.web.evaluate.entity.EvaluateRecordInputLog;
import java.util.List;
import java.util.Map;

public interface IEvaluateRecordInputLogDao extends IBaseDao<String, EvaluateRecordInputLog> {

    Long countByCondition(Map<String, Object> queryMap);

    List<EvaluateRecordInputLogDTO> selectListByCondition(Map<String, Object> queryMap);

    EvaluateRecordInputLogDTO getDetailById(String id);
}