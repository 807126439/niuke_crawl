package com.spr.web.flow.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.GeneralizeParam;
import com.spr.core.common.bean.Page;
import com.spr.core.common.service.BaseService;
import com.spr.core.common.utils.Assert;
import com.spr.core.utils.DateUtil;
import com.spr.core.utils.GeneralizeUtil;
import com.spr.web.flow.constant.DefinitionCodeConsts;
import com.spr.web.flow.dao.IProcDefDao;
import com.spr.web.flow.dao.IProcIdentitylinkDao;
import com.spr.web.flow.dao.IProcLineDao;
import com.spr.web.flow.dao.IProcNodeDao;
import com.spr.web.flow.dto.def.ProcDefDTO;
import com.spr.web.flow.entity.ProcDef;
import com.spr.web.flow.service.IProcDefService;

@Service("procDefService")
@Transactional
public class ProcDefServiceImpl extends BaseService implements IProcDefService {

	@Resource
	private IProcDefDao procDefDao;
	@Resource
	private IProcLineDao procLineDao;
	@Resource
	private IProcNodeDao procNodeDao;
	@Resource
	private IProcIdentitylinkDao procIdentitylinkDao;

	/**
	 * 分页查询
	 * 
	 * @param dq
	 */
	@Override
	public Page<ProcDefDTO> searchByPage(DataQuery dq) {

		Long recTotal = this.procDefDao.countByCondition(dq.assemblePageOffset().getQueryMap());
		dq.assembleOrderInfo(ProcDef.class, null);
		List<ProcDefDTO> resultlist = this.procDefDao.selectListByCondition(dq.getQueryMap());
		DataQuery.wrapTableNo2(resultlist, dq.getStartQuery());
		return new Page<ProcDefDTO>(dq.getCurrentPage(), dq.getPageSize(), resultlist, recTotal);
	}

	/**
	 * 查询详细
	 * 
	 * @param id
	 */
	@Override
	public ProcDefDTO getDetailById(String id) {
		Assert.hasText(id, Assert.NULL_PARAM_STR("id"));

		ProcDefDTO result = this.procDefDao.getDetailById(id);
		Assert.notNull(result, Assert.EMPTY_REOCRD_STR);

		return result;
	}

	/**
	 * 添加
	 * 
	 * @param dto
	 */
	@Override
	public void addProcDef(ProcDefDTO dto) {
		Assert.hasText(dto.getProcessName(), "流程名称不能为空");

		ProcDef model = new ProcDef();
		model.setUnitId(this.getNowUser().getUnitId());
		model.setProcessCode(dto.getProcessCode());
		model.setProcessName(dto.getProcessName());
		model.setDescription(dto.getDescription());
		model.setNumbTemplate(dto.getNumbTemplate());
		model.setYear(DateUtil.getNowYear());
		model.setSn(0);
		model.setStatus(dto.getStatus());
		model.setFlag(dto.getFlag());
		model.setCreateBy(this.getNowUser().getUsername());
		model.setUpdateBy(dto.getUpdateBy());
		model.setGmtCreate(new Date());
		model.setGmtModified(dto.getGmtModified());

		this.procDefDao.insert(model);

		if (this.logger.isInfoEnabled()) {
			this.logger.info("Add: " + model.toString());
		}
	}

	/**
	 * 修改
	 * 
	 * @param dto
	 */
	@Override
	public void updateProcDef(ProcDefDTO dto) {
		Assert.hasText(dto.getId(), Assert.NULL_PARAM_STR("id"));

		ProcDef model = this.procDefDao.getById(dto.getId());
		Assert.notNull(model, Assert.EMPTY_REOCRD_STR);

		model.setProcessCode(dto.getProcessCode());
		model.setProcessName(dto.getProcessName());
		model.setDescription(dto.getDescription());
		model.setNumbTemplate(dto.getNumbTemplate());
		model.setSn(dto.getSn());
		model.setYear(dto.getYear());
		model.setStatus(dto.getStatus());
		/*
		 * model.setFlag(dto.getFlag()); model.setCreateBy(dto.getCreateBy());
		 */
		model.setUpdateBy(this.getNowUser().getUsername());
		model.setGmtModified(new Date());

		this.procDefDao.updateSelective(model);

		if (this.logger.isInfoEnabled()) {
			this.logger.info("Update: " + model.toString());
		}
	}

	/**
	 * 删除
	 * 
	 * @param ids
	 */
	@Override
	public void deleteProcDefs(String[] ids) {
		for (int i = 0; i < ids.length; i++) {

			ProcDef model = this.procDefDao.getById(ids[i]);
			if (model != null) {

				// 删除流程定义的所有数据
				this.procNodeDao.deleteByProcDefId(model.getId());

				this.procLineDao.deleteByProcDefId(model.getId());

				this.procIdentitylinkDao.deleteByProcDefId(model.getId());

				this.procDefDao.deleteById(model.getId());

				if (this.logger.isInfoEnabled()) {
					this.logger.info("Update: " + model.toString());
				}
			}

		}
	}

	@Override
	public List<DefinitionCodeConsts> getProcDefCode(String mycode) {
		List<DefinitionCodeConsts> list = DefinitionCodeConsts.codes;
		List<DefinitionCodeConsts> list2 = new ArrayList<DefinitionCodeConsts>();
		list2.addAll(list);
		List<DefinitionCodeConsts> templist = new ArrayList<DefinitionCodeConsts>();
		Map<String, Object> queryMap = new HashMap<String, Object>();
		queryMap.put("unitId", this.getNowUser().getUnitId());
		List<String> codes = procDefDao.getProcDefCode(queryMap);
		if (codes != null) {
			for (DefinitionCodeConsts d : list2) {
				for (String code : codes) {
					if (code.equals(d.code()) && (!code.equals(mycode))) {
						templist.add(d);
					}
				}
			}
			list2.removeAll(templist);
		}

		return list2;
	}

	/**
	 * 根据模板生成编号
	 * 
	 * @param processCode
	 * @param param
	 * @return
	 */
	@Override
	public String generalizeNumbTemplate(String processCode, GeneralizeParam param) {
		ProcDef model = this.procDefDao.getByProcessCode(processCode);

		String result = "";
		if (model != null) {
			if (!StringUtils.isBlank(model.getNumbTemplate())) {
				result = GeneralizeUtil.generalizeString(model.getNumbTemplate(), param);
			}

		}

		return result;
	}

	@Override
	public void updateSnByCode(String eventNo, String processCode) {
		String strsub = eventNo.substring(eventNo.length() - 4);// 一个参数表示截取传递的序号之后的部分
		int sn = Integer.parseInt(strsub);
		ProcDef procDef = this.procDefDao.getByProcessCode(processCode);
		procDef.setSn(sn);
		procDefDao.update(procDef);

		if (this.logger.isInfoEnabled()) {
			this.logger.info("Update: " + procDef.toString());
		}
	}

	@Override
	public int getSnByCode(String year, String processCode) {
		ProcDef model = this.procDefDao.getByProcessCode(processCode);
		if (Integer.parseInt(year) > Integer.parseInt(model.getYear())) {
			model.setYear(year);
			model.setSn(0);
			procDefDao.update(model);

			if (this.logger.isInfoEnabled()) {
				this.logger.info("Update: " + model.toString());
			}
		}
		return model.getSn();
		/*
		 * model.setSn(sn+1); this.procDefDao.update(model); if
		 * (this.logger.isInfoEnabled()) { this.logger.info("Update: " +
		 * model.toString()); }
		 */
	}

	@Override
	public ProcDefDTO getDetailByParam(Map<String, Object> queryMap) {

		return this.procDefDao.getDetailByParam(queryMap);
	}

}
