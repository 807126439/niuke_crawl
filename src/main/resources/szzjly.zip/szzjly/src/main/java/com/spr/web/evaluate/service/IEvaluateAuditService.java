package com.spr.web.evaluate.service;

import com.spr.web.flow.dto.def.ProcDefDTO;

public interface IEvaluateAuditService {

	void withdrawEvaluate(String id);

	void resubmitAudit(String id, String auditor);

	ProcDefDTO checkDefIfExist(String id);

	void submitAudit(String recordId, String auditor);

}
