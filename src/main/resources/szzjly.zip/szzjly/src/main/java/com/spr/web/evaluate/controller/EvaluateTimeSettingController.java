package com.spr.web.evaluate.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spr.core.common.bean.AjaxJson;
import com.spr.core.common.controller.BaseController;
import com.spr.web.evaluate.dto.time.EvaluateTimeDTO;
import com.spr.web.evaluate.service.IEvaluateTimeSettingService;

@Controller
@Scope("prototype")
@RequestMapping("/evaluateTimeSettingController")
public class EvaluateTimeSettingController extends BaseController {

	private static final long serialVersionUID = 1L;

	@Resource
	private IEvaluateTimeSettingService evaluateTimeSettingService;

	@RequestMapping(value = "/viewPage", method = { RequestMethod.GET })
	public String viewPage(HttpServletRequest request) {

		this.wrapMenuTitle(request);
		request.setAttribute("model", this.evaluateTimeSettingService.getEvaluateTime());
		return "evaluate/evaluateTimeSetting/index.jsp";
	}

	@RequestMapping(value = "/setEvaluateTime", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson setEvaluateTime(EvaluateTimeDTO dto) throws Exception {
		this.evaluateTimeSettingService.setEvaluateTime(dto);
		return new AjaxJson(this.SAVE_SUCCESS_MESSAGE, AjaxJson.success);
	}
}
