package com.spr.web.project.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.dubbo.common.utils.Assert;
import com.spr.core.common.bean.AjaxJson;
import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.controller.BaseController;
import com.spr.web.evaluate.dto.form.EvaluateFormDTO;
import com.spr.web.evaluate.dto.record.EvaluateRecordDTO;
import com.spr.web.evaluate.service.IEvaluateFormService;
import com.spr.web.evaluate.service.IEvaluateRecordService;
import com.spr.web.project.dto.part.ProjectPartInfoDTO;
import com.spr.web.project.dto.project.ProjectInfoDTO;
import com.spr.web.project.service.IProjectInfoService;
import com.spr.web.project.service.IProjectPartInfoService;
import com.spr.web.system.service.IEngineeringTypeService;

@Controller
@Scope("prototype")
@RequestMapping("/projectPartInfoController")
public class ProjectPartInfoController extends BaseController {

	private static final long serialVersionUID = 1L;

	@Resource
	private IProjectPartInfoService projectPartInfoService;
	@Resource
	private IProjectInfoService projectInfoService;
	@Resource
	private IEvaluateFormService evaluateFormService;
	@Resource
	private IEvaluateRecordService evaluateRecordService;
	@Resource
	private IEngineeringTypeService engineeringTypeService;

	@RequestMapping(value = "/viewPage", method = { RequestMethod.GET })
	public String viewPage(HttpServletRequest request, String proId, String pageType) {
		Assert.notNull(proId, "项目不能为空");

		this.wrapMenuTitle(request);
		ProjectInfoDTO ProjectInfo = this.projectInfoService.getDetailById(proId);
		request.setAttribute("proId", proId);
		request.setAttribute("pageType", pageType);
		request.setAttribute("pageTitle", ProjectInfo.getProName());
		return "project/projectPartInfo/projectPartInfoList.jsp";
	}

	@RequestMapping(value = "/getPageData", method = { RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> loadPageData(HttpServletRequest request, DataQuery dq, String partName, String proId) {
		Assert.notNull(proId, "项目不能为空");
		this.wrapTableQueryParams(request, dq);
		dq.getQueryMap().put("proId", proId);
		dq.getQueryMap().put("partName", StringUtils.isNotBlank(partName) ? "%" + partName + "%" : null);
		Page<ProjectPartInfoDTO> pageResult = this.projectPartInfoService.searchByPage(dq);
		return this.handlePageReult(pageResult);
	}

	// 承包工程
	@RequestMapping(value = "/contractor/viewPage", method = { RequestMethod.GET })
	public String contractorViewPage(HttpServletRequest request) {
		this.wrapMenuTitle(request);
		return "project/projectPartInfo/contractor/projectPartInfoList.jsp";
	}

	@RequestMapping(value = "/contractor/getPageData", method = { RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> contractorLoadPageData(HttpServletRequest request, DataQuery dq, String partName) {
		this.wrapTableQueryParams(request, dq);

		dq.putToMap("contractorUnitId", this.getNowUser().getUnitId());
		dq.putToMap("partName", StringUtils.isNotBlank(partName) ? "%" + partName + "%" : null);
		Page<ProjectPartInfoDTO> pageResult = this.projectPartInfoService.searchByPage(dq);
		return this.handlePageReult(pageResult);
	}

	@RequestMapping(value = "/skipAddProjectPartInfo")
	public String skipAddProjectPartInfo(HttpServletRequest request, String proId) {
		request.setAttribute("proId", proId);
		this.getEngineeringTypeList(request);
		return "project/projectPartInfo/addProjectPartInfo.jsp";
	}

	@RequestMapping(value = "/addProjectPartInfo", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson addProjectPartInfo(ProjectPartInfoDTO dto) throws Exception {

		this.projectPartInfoService.addProjectPartInfo(dto);

		return new AjaxJson(this.ADD_SUCCESS_MESSAGE, AjaxJson.success);
	}

	@RequestMapping("/getDetail")
	public String loadDetail(HttpServletRequest request, @RequestParam(value = "id", required = true) String id) {

		ProjectPartInfoDTO result = this.projectPartInfoService.getDetailById(id);
		request.setAttribute("model", result);
		this.getEngineeringTypeList(request);

		return "project/projectPartInfo/editProjectPartInfo.jsp";
	}

	@RequestMapping(value = "/editProjectPartInfo", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson updateProjectPartInfo(ProjectPartInfoDTO dto) {

		this.projectPartInfoService.updateProjectPartInfo(dto);

		return new AjaxJson(this.EDIT_SUCCESS_MESSAGE, AjaxJson.success);
	}

	@RequestMapping(value = "/deleteProjectPartInfo", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson deleteProjectPartInfo(String[] ids) {

		this.projectPartInfoService.deleteProjectPartInfos(ids);

		return new AjaxJson(this.DEL_SUCCESS_MESSAGE, AjaxJson.success);
	}

	// ------------评价记录 ------------------//
	@RequestMapping(value = "/skipAddEvaluateRecord")
	public String skipAddEvaluateRecord(HttpServletRequest request, String proId, String partId) {
		// 选评价表格
		DataQuery dq = new DataQuery();
		dq.setNotQueryPage();
		dq.putToMap("sidx", "sortNo");
		dq.putToMap("sord", "asc");
		// dq.putToMap("flag", EvaluateFormDTO.FLAG_PUBLISHED);
		List<EvaluateFormDTO> forms = this.evaluateFormService.selectListByCondition(dq);
		request.setAttribute("forms", forms);
		request.setAttribute("proId", proId);
		request.setAttribute("partId", partId);
		return "project/projectPartInfo/addEvaluateRecord.jsp";
	}

	@RequestMapping(value = "/addEvaluateRecord", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson addEvaluateRecord(EvaluateRecordDTO dto) throws Exception {

		ProjectInfoDTO projectInfoDTO = this.projectInfoService.getDetailById(dto.getProId());
		ProjectPartInfoDTO projectPartDTO = this.projectPartInfoService.getDetailById(dto.getPartId());
		this.evaluateRecordService.addEvaluateRecord(projectInfoDTO, projectPartDTO);
		return new AjaxJson(this.ADD_SUCCESS_MESSAGE, AjaxJson.success);
	}

	// -----------------工程类型-----------------//
	public void getEngineeringTypeList(HttpServletRequest request) {
		DataQuery dq = new DataQuery();
		dq.putToMap("sidx", "sort_no");
		dq.putToMap("sord", "asc");
		request.setAttribute("engineeringTypeList", this.engineeringTypeService.selectListByCondition(dq));
	}
}
