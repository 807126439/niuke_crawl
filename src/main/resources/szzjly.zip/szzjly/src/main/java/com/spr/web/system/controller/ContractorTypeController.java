package com.spr.web.system.controller;

import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spr.core.common.bean.AjaxJson;
import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.controller.BaseController;
import com.spr.web.system.dto.contractor.ContractorTypeDTO;
import com.spr.web.system.service.IContractorTypeService;

@Controller
@Scope("prototype")
@RequestMapping("/contractorTypeController")
public class ContractorTypeController extends BaseController {

	private static final long serialVersionUID = 1L;

	@Resource
	private IContractorTypeService contractorTypeService;

	@RequestMapping(value = "/viewPage", method = { RequestMethod.GET })
	public String viewPage(HttpServletRequest request) {
		this.wrapMenuTitle(request);

		return "system/contractorType/contractorTypeList.jsp";
	}

	@RequestMapping(value = "/getPageData", method = { RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> loadPageData(HttpServletRequest request, DataQuery dq, String typeName) {

		this.wrapTableQueryParams(request, dq);

		if (StringUtils.isNotBlank(typeName)) {
			dq.getQueryMap().put("typeName", typeName);
		}

		Page<ContractorTypeDTO> pageResult = this.contractorTypeService.searchByPage(dq);

		return this.handlePageReult(pageResult);
	}

	@RequestMapping(value = "/skipAddContractorType")
	public String skipAddContractorType(HttpServletRequest request) {

		return "system/contractorType/addContractorType.jsp";
	}

	@RequestMapping(value = "/addContractorType", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson addContractorType(ContractorTypeDTO dto) throws Exception {

		this.contractorTypeService.addContractorType(dto);

		return new AjaxJson(this.ADD_SUCCESS_MESSAGE, AjaxJson.success);
	}

	@RequestMapping("/getDetail")
	public String loadDetail(HttpServletRequest request, @RequestParam(value = "id", required = true) String id) {

		ContractorTypeDTO result = this.contractorTypeService.getDetailById(id);
		request.setAttribute("model", result);

		return "system/contractorType/editContractorType.jsp";
	}

	@RequestMapping(value = "/editContractorType", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson updateContractorType(ContractorTypeDTO dto) {

		this.contractorTypeService.updateContractorType(dto);

		return new AjaxJson(this.EDIT_SUCCESS_MESSAGE, AjaxJson.success);
	}

	@RequestMapping(value = "/deleteContractorType", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson deleteContractorType(String[] ids) {

		this.contractorTypeService.deleteContractorTypes(ids);

		return new AjaxJson(this.DEL_SUCCESS_MESSAGE, AjaxJson.success);
	}

}
