package com.spr.web.evaluate.service.impl;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.exception.BusinessException;
import com.spr.core.common.service.BaseService;
import com.spr.core.common.utils.Assert;
import com.spr.core.gobal.GobalVal;
import com.spr.core.spring.security.utils.SecurityPrincipalUtil;
import com.spr.web.evaluate.dao.IEvaluateFormDao;
import com.spr.web.evaluate.dao.IEvaluateRecordDao;
import com.spr.web.evaluate.dto.form.EvaluateFormDTO;
import com.spr.web.evaluate.dto.record.EvaluateRecordDTO;
import com.spr.web.evaluate.dto.record.EvaluateRecordIndexDTO;
import com.spr.web.evaluate.dto.record.EvaluateRecordInputDTO;
import com.spr.web.evaluate.dto.record.EvaluateRecordInputLogDTO;
import com.spr.web.evaluate.entity.EvaluateForm;
import com.spr.web.evaluate.entity.EvaluateRecord;
import com.spr.web.evaluate.service.IEvaluateAppealService;
import com.spr.web.evaluate.service.IEvaluateAuditService;
import com.spr.web.evaluate.service.IEvaluateFormIndexService;
import com.spr.web.evaluate.service.IEvaluateFormService;
import com.spr.web.evaluate.service.IEvaluateRecordFileService;
import com.spr.web.evaluate.service.IEvaluateRecordIndexService;
import com.spr.web.evaluate.service.IEvaluateRecordInputLogService;
import com.spr.web.evaluate.service.IEvaluateRecordInputService;
import com.spr.web.evaluate.service.IEvaluateRecordService;
import com.spr.web.evaluate.service.IEvaluateTimeSettingService;
import com.spr.web.flow.service.IExecNodeService;
import com.spr.web.project.dao.IProjectInfoDao;
import com.spr.web.project.dao.IProjectPartInfoDao;
import com.spr.web.project.dto.part.ProjectPartInfoDTO;
import com.spr.web.project.dto.project.ProjectInfoDTO;
import com.spr.web.project.entity.ProjectPartInfo;
import com.spr.web.project.service.IProjectInfoService;
import com.spr.web.project.service.IProjectPartInfoService;
import com.spr.web.system.entity.Role;
import com.spr.web.system.service.IUnitEvaluatorRelationService;
import com.spr.web.system.service.IUnitService;
import com.spr.web.system.service.IUserService;

@Service("evaluateRecordService")
@Transactional
public class EvaluateRecordServiceImpl extends BaseService implements IEvaluateRecordService {

	@Resource
	private IEvaluateRecordDao evaluateRecordDao;
	@Resource
	private IEvaluateFormService evaluateFormService;
	@Resource
	private IEvaluateFormDao evaluateFormDao;
	@Resource
	private IEvaluateFormIndexService evaluateFormIndexService;
	@Resource
	private IEvaluateRecordInputService evaluateRecordInputService;
	@Resource
	private IEvaluateRecordFileService evaluateRecordFileService;
	@Resource
	private IProjectPartInfoService projectPartInfoService;
	@Resource
	private IProjectPartInfoDao projectPartInfoDao;
	@Resource
	private IProjectInfoService projectInfoService;
	@Resource
	private IProjectInfoDao projectInfoDao;
	@Resource
	private IUnitEvaluatorRelationService unitEvaluatorRelationService;
	@Resource
	private IEvaluateAuditService evaluateAuditService;
	@Resource
	private IEvaluateRecordIndexService evaluateRecordIndexService;
	@Resource
	private IEvaluateRecordInputLogService evaluateRecordInputLogService;
	@Resource
	private IExecNodeService execNodeService;
	@Resource
	private IUserService userService;
	@Resource
	private IUnitService unitService;
	@Resource
	private IEvaluateAppealService evaluateAppealService;
	@Resource
	private IEvaluateTimeSettingService evaluateTimeSettingService;

	@Override
	public EvaluateRecordDTO selectOneByCondition(DataQuery dq) {
		dq.setPageSize(1);
		List<EvaluateRecordDTO> resultlist = this.selectListByCondition(dq);

		if (resultlist == null || resultlist.isEmpty()) {
			return null;
		}
		return resultlist.get(0);
	}

	@Override
	public List<EvaluateRecordDTO> selectListByCondition(DataQuery dq) {
		dq.assemblePageOffset();
		dq.assembleOrderInfo(EvaluateRecord.class, "a");
		List<EvaluateRecordDTO> resultlist = this.evaluateRecordDao.selectListByCondition(dq.getQueryMap());

		return resultlist;
	}

	/**
	 * 分页查询
	 * 
	 * @param dq
	 */
	@Override
	public Page<EvaluateRecordDTO> searchByPage(DataQuery dq) {
		Long recTotal = this.evaluateRecordDao.countByCondition(dq.assemblePageOffset().getQueryMap());
		dq.assembleOrderInfo(EvaluateRecord.class, "a");
		List<EvaluateRecordDTO> resultlist = this.evaluateRecordDao.selectListByCondition(dq.getQueryMap());

		this.initText(resultlist);
		return new Page<EvaluateRecordDTO>(dq.getCurrentPage(), dq.getPageSize(), resultlist, recTotal);
	}

	@Override
	public void initText(List<EvaluateRecordDTO> list) {
		if (list == null || list.isEmpty()) {
			return;
		}

		String[] proIds = new String[list.size()];
		String[] partIds = new String[list.size()];
		String[] targetUnitIds = new String[list.size()];
		String[] evalUserIds = new String[list.size()];
		for (int i = 0; i < list.size(); i++) {
			proIds[i] = list.get(i).getProId();
			partIds[i] = list.get(i).getPartId();
			targetUnitIds[i] = list.get(i).getTargetUnitId();
			evalUserIds[i] = list.get(i).getEvalUserId();
		}
		// 获取项目id-名称映射
		DataQuery dq = new DataQuery();
		dq.setNotQueryPage();
		dq.putToMap("ids", proIds);
		Map<String, String> proMap = this.projectInfoService.selectIdNameMapByCondition(dq);

		// 获取合同id-名称映射
		dq.clear();
		dq.setNotQueryPage();
		dq.putToMap("ids", partIds);
		Map<String, String> partMap = this.projectPartInfoService.selectIdNameMapByCondition(dq);

		// unitId-unitName
		dq.clear();
		dq.setNotQueryPage();
		dq.putToMap("ids", targetUnitIds);
		Map<String, String> unitMap = this.unitService.selectIdNameMapByCondition(dq);

		// userId-userName
		dq.clear();
		dq.setNotQueryPage();
		dq.putToMap("ids", evalUserIds);
		Map<String, String> userMap = this.userService.selectIdNameMapByCondition(dq);

		// 获取评价者id-名称映射
		for (EvaluateRecordDTO dto : list) {
			// 设置项目名称
			dto.setProName(proMap.get(dto.getProId()));
			// 设置合同名称
			dto.setPartName(partMap.get(dto.getPartId()));
			// 设置评价目标单位
			dto.setTargetUnitName(unitMap.get(dto.getTargetUnitId()));
			// 设置评价者名称
			dto.setEvalUserName(userMap.get(dto.getEvalUserId()));
			// 设置评价形式
			dto.setFormTypeText(EvaluateRecordDTO.FORM_TYPE_TEXT.get(dto.getFormType()));
			// 设置评价等级
			dto.setEvalGradeText(EvaluateRecordDTO.EVAL_GRADE_TEXT.get(dto.getEvalGrade()));
			// 设置状态
			dto.setStatusText(EvaluateRecordDTO.STATUS_TEXT.get(dto.getStatus()));
			// 设置申辩状态
			dto.setPleaStatusText(EvaluateRecordDTO.PLEA_STATUS_TEXT.get(dto.getPleaStatus()));
			// 设置合同类型
			dto.setEngTypeCodeName(EvaluateRecordDTO.ENG_TYPE_CODE_TEXT.get(dto.getEngTypeCode()));
		}
	}

	/**
	 * 查询详细
	 * 
	 * @param id
	 */
	@Override
	public EvaluateRecordDTO getDetailById(String id) {
		Assert.hasText(id, Assert.NULL_PARAM_STR("id"));

		EvaluateRecordDTO result = this.evaluateRecordDao.getDetailById(id);
		Assert.notNull(result, Assert.EMPTY_REOCRD_STR);

		if (!StringUtils.isBlank(result.getPartId())) {
			ProjectPartInfo partInfo = this.projectPartInfoDao.getById(result.getPartId());
			result.setPartName(partInfo.getPartName());
		}

		if (!StringUtils.isBlank(result.getFormId())) {
			EvaluateFormDTO form = this.evaluateFormService.getDetailById(result.getFormId());
			result.setForm(form);
		}

		return result;
	}

	/**
	 * 添加
	 * 
	 * @param dto
	 */
	@Override
	public String addEvaluateRecord(EvaluateRecordDTO dto) {

		EvaluateRecord model = new EvaluateRecord();
		model.setProId(dto.getProId());
		model.setPartId(dto.getPartId());
		model.setTargetUnitId(dto.getTargetUnitId());
		model.setEvalUserId(dto.getEvalUserId());
		model.setEvalUnitId(dto.getEvalUnitId());
		model.setFormId(dto.getFormId());
		model.setRecordType(dto.getRecordType());
		model.setFormType(dto.getFormType());
		model.setSpecificStep(dto.getSpecificStep());
		model.setTotalScore(dto.getTotalScore());
		model.setEvalGrade(dto.getEvalGrade());
		model.setGmtEval(dto.getGmtEval());
		model.setProName(dto.getProName());
		model.setContractorName(dto.getContractorName());
		model.setBuildUnitName(dto.getBuildUnitName());
		model.setMemo(dto.getMemo());
		model.setEngTypeCode(dto.getEngTypeCode());
		model.setStatus(dto.getStatus());
		model.setPleaStatus(dto.getPleaStatus());
		model.setGmtPlea(dto.getGmtPlea());
		model.setPleaContent(dto.getPleaContent());
		model.setPleaReply(dto.getPleaReply());
		model.setFlag(dto.getFlag());
		model.setCreateBy(this.getNowUser().getUsername());
		model.setUpdateBy(this.getNowUser().getUsername());
		model.setGmtCreate(new Date());
		model.setGmtModified(new Date());

		this.evaluateRecordDao.insert(model); // TODO

		this.writeInfoLog("Add: " + model.toString());

		return model.getId();
	}

	@Override
	public void addEvaluateRecord(EvaluateRecordDTO dto, String indexIds, String indexVals, String auditor) {
		// TODO delete not exists
		// copy index & return 模板id-实际指标 映射
		Map<String, EvaluateRecordIndexDTO> originModelMap = this.evaluateRecordIndexService.copyIndex(dto);

		// TODO delete not exists
		// save or update input
		String[] inputIds = indexIds.trim().split(",");
		String[] inputVals = indexVals.trim().split(",");
		this.evaluateRecordInputService.saveOrUpdate(dto, inputIds, inputVals, originModelMap);

		// update record
		EvaluateRecord entity = new EvaluateRecord();
		entity.setId(dto.getId());
		// entity.setFormType(dto.getFormType());
		// entity.setSpecificStep(dto.getSpecificStep());
		entity.setTotalScore(dto.getTotalScore());
		entity.setEvalGrade(dto.getEvalGrade());
		if (dto.getStatus() == null) {
			entity.setStatus(EvaluateRecordDTO.STATUS_UNSUBMIT);
		} else if (dto.getStatus() == EvaluateRecordDTO.STATUS_FAILED) {
			entity.setStatus(EvaluateRecordDTO.STATUS_AUDITING);
		} else {
			entity.setStatus(dto.getStatus());
		}
		entity.setGmtEval(new Date());
		entity.setPleaStatus(EvaluateRecordDTO.PLEA_STATUS_DEFAULT);
		entity.setUpdateBy(this.getNowUser().getUsername());
		entity.setGmtModified(new Date());
		entity.setFlag(EvaluateRecordDTO.FLAG_ARCHIVED); // 标志评价记录是否已保存：创建评价记录，默认定时删除，保存/提交后完成归档
		this.evaluateRecordDao.updateSelective(entity);
		this.writeInfoLog("update" + entity.toString());
		this.updateSituation(dto); // 更新特殊情况记录

		if (dto.getStatus() == EvaluateRecordDTO.STATUS_AUDITING) {
			// submit
			this.evaluateAuditService.submitAudit(entity.getId(), auditor);
		} else if (dto.getStatus() == EvaluateRecordDTO.STATUS_FAILED) {

			this.handleDeleteRcord(dto.getId());

			// resubmit
			this.evaluateAuditService.resubmitAudit(entity.getId(), auditor);
		}
	}

	private void handleDeleteRcord(String id) {
		EvaluateRecordDTO dto = this.getDetailById(id);
		if ("DJ".equals(dto.getEngTypeCode())) {
			if (EvaluateRecordDTO.FORM_TYPE_SEASON.equals(dto.getFormType())) {
				// 删除当前评价记录的季度合同评价（建设，住建，发改三合一的记录）
				this.evaluateRecordDao.deleteById(dto.getConnectRecordId());
			} else if (EvaluateRecordDTO.FORM_TYPE_CONTRACT.equals(dto.getFormType())) {
				// 删除项目的总合同评价（建设，住建，发改三合一的记录）
				this.evaluateRecordDao.deleteProTotalContractEvaluateRecord(dto.getProId());
				// 删除项目综合评价
				this.evaluateRecordDao.deleteProComprehensiveEvaluateRecord(dto.getProId());
				// 将项目设置为可评价
				this.projectInfoService.setProjectEvaluateStatus(dto.getProId(), GobalVal.EVALUATE_NOT_END);
			}
		} else {
			if (EvaluateRecordDTO.FORM_TYPE_CONTRACT.equals(dto.getFormType())) {
				// 删除合同的综合评价
				this.evaluateRecordDao.deletePartComprehensiveEvaluateRecord(dto.getPartId());
				// 将合同设置为可评价
				this.projectPartInfoService.setProjectPartEvaluateStatus(dto.getPartId(), GobalVal.EVALUATE_NOT_END);

			}
		}
	}

	// 根据合同信息添加评价记录：合同期3个月以内的，可不进行阶段履约评价，只进行最终履约评价；合同工期1年以上的，至少进行一次阶段履约评价。招标代理合同只需要进行最终履约评价。
	@Override
	public String addEvaluateRecord(ProjectPartInfoDTO projectPartInfo) {
		Assert.hasText(projectPartInfo.getEngTypeCode(), Assert.NULL_PARAM_STR("合同类型代码"));

		// 承包商类型代码 => 评价表格
		DataQuery dq = new DataQuery();
		dq.putToMap("status", EvaluateFormDTO.STATUS_ENABLE);
		// dq.putToMap("flag", EvaluateFormDTO.FLAG_PUBLISHED);
		dq.putToMap("engTypeCode", projectPartInfo.getEngTypeCode());
		EvaluateFormDTO form = this.evaluateFormService.selectOneByCondition(dq);
		Assert.notNull(form, "没有可用的评分标准");

		EvaluateRecordDTO dto = new EvaluateRecordDTO();
		dto.setProId(projectPartInfo.getProId());
		dto.setPartId(projectPartInfo.getId());
		// TODO
		// dto.setTargetUnitId(targetUnitId);
		// dto.setEvalUserId(evalUserId);
		// dto.setRecordType(recordType);
		// dto.setFormType(formType);
		// dto.setSpecificStep(specificStep);
		// ...
		dto.setProName(projectPartInfo.getProName());
		dto.setContractorName(projectPartInfo.getContractorUnitName());
		// dto.setBuildUnitName(buildUnitName);
		dto.setMemo(form.getMemo());
		dto.setStatus(EvaluateRecordDTO.STATUS_UNSUBMIT);
		dto.setPleaStatus(EvaluateRecordDTO.PLEA_STATUS_DEFAULT);
		// ...
		return this.addEvaluateRecord(dto);
	}

	// 根据项目信息与合同信息添加评价记录：合同期3个月以内的，可不进行阶段履约评价，只进行最终履约评价；合同工期1年以上的，至少进行一次阶段履约评价。招标代理合同只需要进行最终履约评价。
	@Override
	public String addEvaluateRecord(String formId, String formType, String specificStep, ProjectInfoDTO projectInfo, ProjectPartInfoDTO projectPartInfo) {
		Assert.hasText(projectPartInfo.getEngTypeCode(), Assert.NULL_PARAM_STR("合同类型代码"));

		EvaluateFormDTO form = this.evaluateFormService.getDetailById(formId);
		Assert.notNull(form, "该合同没有可用的评分标准");

		EvaluateRecordDTO dto = new EvaluateRecordDTO();
		dto.setProId(projectPartInfo.getProId());
		dto.setPartId(projectPartInfo.getId());
		dto.setTargetUnitId(projectPartInfo.getContractorUnitId());
		dto.setEvalUserId(this.getNowUser().getId());
		dto.setEvalUnitId(getNowUser().getUnitId());
		dto.setEngTypeCode(projectPartInfo.getEngTypeCode());
		dto.setFormId(form.getId());
		dto.setFormType(formType);
		dto.setSpecificStep(specificStep);
		dto.setProName(projectPartInfo.getProName());
		dto.setContractorName(projectPartInfo.getContractorUnitName());
		dto.setBuildUnitName(projectInfo.getBuildUnitName());
		dto.setMemo(form.getMemo());
		dto.setStatus(EvaluateRecordDTO.STATUS_UNSUBMIT);
		dto.setPleaStatus(EvaluateRecordDTO.PLEA_STATUS_DEFAULT);
		dto.setFlag(EvaluateRecordDTO.FLAG_TODELETE); // 标志评价记录是否已保存：创建评价记录，默认定时删除，保存/提交后完成归档
		return this.addEvaluateRecord(dto);
	}

	// 根据项目信息添加代建单位评价记录
	@Override
	public String addEvaluateRecord(String formId, String formType, ProjectInfoDTO projectInfo) {
		EvaluateFormDTO form = this.evaluateFormService.getDetailById(formId);
		Assert.notNull(form, "代建单位没有可用的评分标准");

		EvaluateRecordDTO dto = new EvaluateRecordDTO();
		dto.setProId(projectInfo.getId());
		dto.setTargetUnitId(projectInfo.getAgentUnitId());
		dto.setEvalUserId(this.getNowUser().getId());
		dto.setEvalUnitId(getNowUser().getUnitId());
		dto.setEngTypeCode("DJ");
		if (EvaluateRecordDTO.FORM_TYPE_CONTRACT.equals(formType)) {
			dto.setRecordType(this.setDjEvaluateRecordType());
		} else {
			dto.setRecordType(EvaluateRecordDTO.RECORD_TYPE_TOTAL);
		}
		dto.setFormId(form.getId());
		dto.setFormType(formType);
		dto.setProName(projectInfo.getProName());
		dto.setContractorName(projectInfo.getAgentUnitName());
		dto.setBuildUnitName(projectInfo.getBuildUnitName());
		dto.setMemo(form.getMemo());
		dto.setStatus(EvaluateRecordDTO.STATUS_UNSUBMIT);
		dto.setPleaStatus(EvaluateRecordDTO.PLEA_STATUS_DEFAULT);
		dto.setFlag(EvaluateRecordDTO.FLAG_TODELETE); // 标志评价记录是否已保存：创建评价记录，默认定时删除，保存/提交后完成归档
		return this.addEvaluateRecord(dto);
	}

	// 审核修改
	@Override
	public void updateEvaluateRecord(DataQuery dq, String id, String formType, BigDecimal totalScore, Short evalGrade, String situationGoods,
			String situationBads, String nodeId, String note, String[] indexIds, String[] indexVals) {
		// update record
		EvaluateRecord model = this.evaluateRecordDao.getById(id);
		// model.setFormType(formType);
		model.setTotalScore(totalScore);
		model.setEvalGrade(evalGrade);
		model.setSituationGoods(situationGoods);
		model.setSituationBads(situationBads);
		model.setGmtModified(new Date());
		this.evaluateRecordDao.update(model);

		// update input
		if (indexIds == null) {
			return;
		}
		dq.clear();
		dq.setNotQueryPage();
		dq.putToMap("indexIds", indexIds);
		Map<String, EvaluateRecordInputDTO> map = this.evaluateRecordInputService.selectIndexModelMapByCondition(dq);
		for (int i = 0; i < indexIds.length; i++) {
			EvaluateRecordInputDTO dto = map.get(indexIds[i]);
			if (dto != null) {
				// logging
				EvaluateRecordInputLogDTO log = new EvaluateRecordInputLogDTO();
				log.setEvalId(dto.getEvalId());
				log.setIndexId(dto.getIndexId());
				log.setProcNodeId(nodeId);
				log.setUserId(this.getNowUserId());
				log.setBeforeVal(dto.getInputVal());

				dto.setInputVal(indexVals[i] == null ? null : new BigDecimal(new Double(indexVals[i])));
				dto.setIsModified(EvaluateRecordInputDTO.MODIFIED_TRUE);
				log.setChangeVal(dto.getInputVal());
				this.evaluateRecordInputLogService.addEvaluateRecordInputLog(log);
				this.evaluateRecordInputService.updateEvaluateRecordInput(dto);
			}
		}

		// update log
		// this.execNodeService.saveRecord(nodeId, note);
	}

	// 根据项目信息与合同信息添加评价记录：合同期3个月以内的，可不进行阶段履约评价，只进行最终履约评价；合同工期1年以上的，至少进行一次阶段履约评价。招标代理合同只需要进行最终履约评价。
	@Override
	@Deprecated
	public String addEvaluateRecord(ProjectInfoDTO projectInfo, ProjectPartInfoDTO projectPartInfo) {
		Assert.hasText(projectPartInfo.getEngTypeCode(), Assert.NULL_PARAM_STR("合同类型代码"));

		// 合同类型代码 => 评价表格
		DataQuery dq = new DataQuery();
		dq.putToMap("status", EvaluateFormDTO.STATUS_ENABLE);
		// dq.putToMap("flag", EvaluateFormDTO.FLAG_PUBLISHED);
		dq.putToMap("engTypeCode", projectPartInfo.getEngTypeCode());
		EvaluateFormDTO form = this.evaluateFormService.selectOneByCondition(dq);
		Assert.notNull(form, "该合同没有可用的评分标准");

		EvaluateRecordDTO dto = new EvaluateRecordDTO();
		dto.setProId(projectPartInfo.getProId());
		dto.setPartId(projectPartInfo.getId());
		dto.setTargetUnitId(projectPartInfo.getContractorUnitId());
		dto.setEvalUserId(this.getNowUser().getId());
		// dto.setRecordType(recordType);
		dto.setFormId(form.getId());
		// dto.setFormType(EvaluateFormDTO.FORMTYPE_STAGE); // TODO
		// dto.setSpecificStep(specificStep); // TODO
		dto.setProName(projectPartInfo.getProName());
		dto.setContractorName(projectPartInfo.getContractorUnitName());
		dto.setBuildUnitName(projectInfo.getBuildUnitName());
		dto.setMemo(form.getMemo());
		dto.setStatus(EvaluateRecordDTO.STATUS_UNSUBMIT);
		dto.setPleaStatus(EvaluateRecordDTO.PLEA_STATUS_DEFAULT);
		dto.setFlag(EvaluateRecordDTO.FLAG_TODELETE); // 标志评价记录是否已保存：创建评价记录，默认定时删除，保存/提交后完成归档
		return this.addEvaluateRecord(dto);
	}

	// 根据项目信息添加代建单位评价记录：合同期3个月以内的，可不进行阶段履约评价，只进行最终履约评价；合同工期1年以上的，至少进行一次阶段履约评价。招标代理合同只需要进行最终履约评价。
	@Override
	@Deprecated
	public String addEvaluateRecord(ProjectInfoDTO projectInfo) {
		// 代建单位 - 合同类型代码
		String engTypeCode = "DJ";
		DataQuery dq = new DataQuery();
		dq.putToMap("status", EvaluateFormDTO.STATUS_ENABLE);
		// dq.putToMap("flag", EvaluateFormDTO.FLAG_PUBLISHED);
		dq.putToMap("engTypeCode", engTypeCode);
		EvaluateFormDTO form = this.evaluateFormService.selectOneByCondition(dq);
		Assert.notNull(form, "代建单位没有可用的评分标准");

		EvaluateRecordDTO dto = new EvaluateRecordDTO();
		dto.setProId(projectInfo.getId());
		dto.setTargetUnitId(projectInfo.getAgentUnitId());
		dto.setEvalUserId(this.getNowUser().getId());
		// dto.setRecordType(recordType);
		dto.setFormId(form.getId());
		// dto.setFormType(EvaluateFormDTO.FORMTYPE_STAGE); // TODO
		dto.setProName(projectInfo.getProName());
		dto.setContractorName(projectInfo.getAgentUnitName());
		dto.setBuildUnitName(projectInfo.getBuildUnitName());
		dto.setMemo(form.getMemo());
		dto.setStatus(EvaluateRecordDTO.STATUS_UNSUBMIT);
		dto.setPleaStatus(EvaluateRecordDTO.PLEA_STATUS_DEFAULT);
		dto.setFlag(EvaluateRecordDTO.FLAG_TODELETE); // 标志评价记录是否已保存：创建评价记录，默认定时删除，保存/提交后完成归档
		return this.addEvaluateRecord(dto);
	}

	/**
	 * 修改
	 * 
	 * @param dto
	 */
	@Override
	public void updateEvaluateRecord(EvaluateRecordDTO dto) {
		Assert.hasText(dto.getId(), Assert.NULL_PARAM_STR("id"));

		EvaluateRecord model = this.evaluateRecordDao.getById(dto.getId());
		Assert.notNull(model, Assert.EMPTY_REOCRD_STR);

		model.setProId(dto.getProId());
		model.setPartId(dto.getPartId());
		model.setTargetUnitId(dto.getTargetUnitId());
		model.setEvalUserId(dto.getEvalUserId());
		model.setFormId(dto.getFormId());
		model.setRecordType(dto.getRecordType());
		model.setFormType(dto.getFormType());
		model.setSpecificStep(dto.getSpecificStep());
		model.setTotalScore(dto.getTotalScore());
		model.setEvalGrade(dto.getEvalGrade());
		model.setGmtEval(dto.getGmtEval());
		model.setProName(dto.getProName());
		model.setContractorName(dto.getContractorName());
		model.setBuildUnitName(dto.getBuildUnitName());
		model.setMemo(dto.getMemo());
		model.setStatus(dto.getStatus());
		model.setPleaStatus(dto.getPleaStatus());
		model.setGmtPlea(dto.getGmtPlea());
		model.setPleaContent(dto.getPleaContent());
		model.setPleaReply(dto.getPleaReply());
		model.setFlag(dto.getFlag());
		// model.setCreateBy(this.getNowUser().getUsername());
		model.setUpdateBy(this.getNowUser().getUsername());
		// model.setGmtCreate(new Date());
		model.setGmtModified(new Date());

		this.evaluateRecordDao.update(model);

		this.writeInfoLog("Update: " + model.toString());

	}

	@Override
	public void updatePleaContent(EvaluateRecordDTO dto) {
		Assert.hasText(dto.getId(), Assert.NULL_PARAM_STR("id"));

		EvaluateRecord model = this.evaluateRecordDao.getById(dto.getId());
		Assert.notNull(model, Assert.EMPTY_REOCRD_STR);

		model.setPleaStatus(EvaluateRecordDTO.PLEA_STATUS_SUBMIT);
		model.setGmtPlea(new Date());
		model.setPleaContent(dto.getPleaContent());
		model.setUpdateBy(this.getNowUser().getUsername());
		model.setGmtModified(new Date());

		this.evaluateRecordDao.update(model);

		this.writeInfoLog("Update: " + model.toString());

		// 添加履约异议反馈
		this.evaluateAppealService.addEvaluateAppealPleaContent(dto);
	}

	@Override
	public void updateChecked(EvaluateRecordDTO dto) {
		Assert.hasText(dto.getId(), Assert.NULL_PARAM_STR("id"));
		EvaluateRecord model = new EvaluateRecord();
		model.setId(dto.getId());
		model.setChecked(dto.getChecked());
		this.evaluateRecordDao.updateChecked(model);

		this.writeInfoLog("Update: " + model.toString());
	}

	@Override
	public void updatePleaReply(EvaluateRecordDTO dto) {
		Assert.hasText(dto.getId(), Assert.NULL_PARAM_STR("id"));

		EvaluateRecord model = this.evaluateRecordDao.getById(dto.getId());
		Assert.notNull(model, Assert.EMPTY_REOCRD_STR);

		model.setPleaStatus(EvaluateRecordDTO.PLEA_STATUS_REPLIED);
		model.setPleaReply(dto.getPleaReply());
		model.setUpdateBy(this.getNowUser().getUsername());
		model.setGmtModified(new Date());

		this.evaluateRecordDao.update(model);

		this.writeInfoLog("Update: " + model.toString());

		// 添加异议反馈回复
		this.evaluateAppealService.addEvaluateAppealPleaReply(dto);
	}

	@Override
	public void updateSituation(EvaluateRecordDTO dto) {
		Assert.hasText(dto.getId(), Assert.NULL_PARAM_STR("id"));

		EvaluateRecord model = this.evaluateRecordDao.getById(dto.getId());
		Assert.notNull(model, Assert.EMPTY_REOCRD_STR);

		model.setSituationGoods(dto.getSituationGoods());
		model.setSituationBads(dto.getSituationBads());

		this.evaluateRecordDao.update(model);

		this.writeInfoLog("Update: " + model.toString());
	}

	/**
	 * 删除
	 * 
	 * @param ids
	 */
	@Override
	public void deleteEvaluateRecords(String[] ids) {
		// for (int i = 0; i < ids.length; i++) {
		// this.evaluateRecordDao.deleteById(ids[i]);
		// this.writeInfoLog("Delete id:" + ids[i]);
		// }

		// real delete
		// DataQuery dq = new DataQuery();
		// dq.putToMap("ids", ids);
		// this.deleteEvaluateRecordsByCondition(dq);

		for (String id : ids) {
			EvaluateRecord entity = new EvaluateRecord();
			entity.setId(id);
			entity.setFlag(EvaluateRecordDTO.FLAG_TODELETE);
			this.evaluateRecordDao.updateSelective(entity);

			this.writeInfoLog("update: " + entity.toString());
		}
	}

	@Override
	public void deleteEvaluateRecordsByCondition(DataQuery dq) {
		// 获取评价记录
		dq.setNotQueryPage();
		List<EvaluateRecordDTO> list = this.selectListByCondition(dq);
		// 删除评价记录
		this.evaluateRecordDao.deleteByCondition(dq.getQueryMap());

		if (list == null || list.isEmpty()) {
			return;
		}
		String[] evalIds = new String[list.size()];
		for (int i = 0; i < list.size(); i++) {
			evalIds[i] = list.get(i).getId();
		}
		// 删除评价记录录入值
		dq.clear();
		dq.putToMap("evalIds", evalIds);
		this.evaluateRecordInputService.deleteEvaluateRecordInputsByCondition(dq);

		// 删除评价记录附件
		dq.clear();
		dq.putToMap("evalIds", evalIds);
		this.evaluateRecordFileService.deleteEvaluateRecordFilesByCondition(dq);
	}

	@Override
	public Page<EvaluateRecordDTO> searchByPageWithExec(DataQuery dq) {

		Long recTotal = this.evaluateRecordDao.countByConditionWithExec(dq.assemblePageOffset().getQueryMap());
		dq.assembleOrderInfo(EvaluateRecord.class, "a");
		List<EvaluateRecordDTO> resultlist = this.evaluateRecordDao.selectListByConditionWithExec(dq.getQueryMap());

		this.initText(resultlist);
		return new Page<EvaluateRecordDTO>(dq.getCurrentPage(), dq.getPageSize(), resultlist, recTotal);
	}

	@Override
	public Page<EvaluateRecordDTO> avgScoreByPage(DataQuery dq) {
		Long recTotal = this.evaluateRecordDao.countAvgScoreByCondition(dq.assemblePageOffset().getQueryMap());
		// dq.assembleOrderInfo(EvaluateRecord.class, null);
		List<EvaluateRecordDTO> resultlist = this.evaluateRecordDao.avgScoreByCondition(dq.getQueryMap());

		DataQuery.wrapTableNo2(resultlist, dq.getStartQuery());
		return new Page<EvaluateRecordDTO>(dq.getCurrentPage(), dq.getPageSize(), resultlist, recTotal);
	}

	@Override
	public List<Map<String, Object>> bestUnitTopK(DataQuery dq) {
		dq.assemblePageOffset();
		return this.evaluateRecordDao.bestUnitTopK(dq.getQueryMap());
	}

	@Override
	public List<Map<String, Object>> worstUnitTopK(DataQuery dq) {
		dq.assemblePageOffset();
		return this.evaluateRecordDao.worstUnitTopK(dq.getQueryMap());
	}

	/**
	 * 统计承包商履约的平均分
	 * 
	 * @return
	 */
	@Override
	public JSONObject statUnitAvgScore() {
		List<Map<String, Object>> statData = this.evaluateRecordDao.statUnitAvgScore();
		JSONObject retOBj = new JSONObject();

		JSONArray unitArray = new JSONArray();
		JSONArray scoreArray = new JSONArray();
		for (Map<String, Object> map : statData) {
			unitArray.add(map.get("unitName"));

			if (map.get("avgScore") != null) {
				BigDecimal score = new BigDecimal(String.valueOf(map.get("avgScore")));
				scoreArray.add(score.setScale(2, BigDecimal.ROUND_HALF_UP));
			}

		}

		retOBj.put("unitNames", unitArray);
		retOBj.put("avgScores", scoreArray);

		return retOBj;
	}

	@Override
	public JSONObject statContractorTypeAvgScore() {
		List<Map<String, Object>> statData = this.evaluateRecordDao.statContractorTypeAvgScore();
		JSONObject retOBj = new JSONObject();

		JSONArray unitArray = new JSONArray();
		JSONArray scoreArray = new JSONArray();
		for (Map<String, Object> map : statData) {
			unitArray.add(map.get("typeName"));

			if (map.get("avgScore") != null) {
				BigDecimal score = new BigDecimal(String.valueOf(map.get("avgScore")));
				scoreArray.add(score.setScale(2, BigDecimal.ROUND_HALF_UP));
			}

		}

		retOBj.put("typeNames", unitArray);
		retOBj.put("avgScores", scoreArray);

		return retOBj;
	}

	@Override
	public JSONObject getNumOfEngType() {
		List<Map<String, Object>> excellentData = this.evaluateRecordDao.getExcellentNumOfEngType();
		List<Map<String, Object>> failData = this.evaluateRecordDao.getFailNumOfEngType();
		JSONObject retOBj = new JSONObject();
		// 总合格
		int totalExcellent = 0;
		// 总不合格
		int totalFail = 0;

		JSONArray totalArray = new JSONArray();
		JSONArray excellentArray = new JSONArray();
		JSONArray failArray = new JSONArray();
		for (Map<String, Object> map : excellentData) {

			if (map.get("goodNum") != null) {
				int goodNum = Integer.valueOf((String.valueOf(map.get("goodNum"))));
				Map<String, Object> resultMap = new HashMap<String, Object>();
				resultMap.put("name", map.get("typeName"));
				resultMap.put("value", goodNum);
				totalExcellent += goodNum;
				excellentArray.add(resultMap);
			} else {
				// resultMap.put("name", map.get("typeName") + "合格");
				// resultMap.put("value", 0);
			}

		}
		for (Map<String, Object> map : failData) {

			if (map.get("badNum") != null) {
				int badNum = Integer.valueOf((String.valueOf(map.get("badNum"))));
				Map<String, Object> resultMap = new HashMap<String, Object>();
				resultMap.put("name", map.get("typeName"));
				resultMap.put("value", badNum);
				totalFail += badNum;
				failArray.add(resultMap);
			} else {
				// resultMap.put("name", map.get("typeName") + "不合格");
				// resultMap.put("value", 0);
			}

		}

		totalArray.add(totalExcellent);
		totalArray.add(totalFail);

		retOBj.put("totalArray", totalArray);
		retOBj.put("excellentArray", excellentArray);
		retOBj.put("failArray", failArray);

		return retOBj;
	}

	/**
	 * 统计承包商被评价次数
	 * 
	 * @return
	 */
	@Override
	public JSONObject statUnitScoreTime() {
		List<Map<String, Object>> statData = this.evaluateRecordDao.statUnitScoreTime();
		JSONObject retOBj = new JSONObject();

		JSONArray unitArray = new JSONArray();
		JSONArray scoreArray = new JSONArray();
		for (Map<String, Object> map : statData) {
			unitArray.add(map.get("unitName"));

			scoreArray.add(map.get("scoreTime"));

		}

		retOBj.put("unitNames", unitArray);
		retOBj.put("scoreTimes", scoreArray);

		return retOBj;
	}

	//
	@Override
	public void tempImport(String engTypeName, String proId, String partId, String proName, String buildUnitName, String targetUnitId, String contractorName,
			String formType, String totalScore, String engTypeCode) {
		EvaluateFormDTO evaluateFormDTO = this.evaluateFormService.getFormByTypeName(engTypeName);

		EvaluateRecord model = new EvaluateRecord();
		model.setProId(proId);
		model.setEngTypeCode(engTypeCode);
		model.setPartId(partId);
		model.setTargetUnitId(targetUnitId);
		model.setEvalUserId(this.getNowUser().getId());
		model.setRecordType("import"); // 导入
		// model.setFormId(evaluateFormDTO == null ? null :
		// evaluateFormDTO.getId());
		model.setFormType(formType);
		// model.setSpecificStep(specificStep);
		BigDecimal score = StringUtils.isBlank(totalScore) ? null : new BigDecimal(totalScore);
		model.setTotalScore(score);
		model.setEvalGrade(EvaluateRecordDTO.getEvalGradeByTotalScore(score));
		model.setGmtEval(new Date());
		model.setProName(proName);
		model.setContractorName(contractorName);
		model.setBuildUnitName(buildUnitName);
		model.setMemo("导入");
		model.setStatus(EvaluateRecordDTO.STATUS_SUCCEED);
		model.setPleaStatus(EvaluateRecordDTO.PLEA_STATUS_DEFAULT);
		model.setFlag(EvaluateRecordDTO.FLAG_ARCHIVED);
		model.setCreateBy(this.getNowUser().getUsername());
		model.setUpdateBy(this.getNowUser().getUsername());
		model.setGmtCreate(new Date());
		model.setGmtModified(new Date());

		this.evaluateRecordDao.insert(model);

		this.writeInfoLog("import: " + model.toString());
	}

	@Override
	public void createNotDjComprehensiveEvaluateRecord(EvaluateRecordDTO evaluateRecord) {

		// 合同评价记得分
		BigDecimal contractScore = evaluateRecord.getTotalScore();
		// 季度评价记录平均分
		Map<String, Object> queryMap = new HashMap<>();
		queryMap.put("partId", evaluateRecord.getPartId());
		BigDecimal seasonAvgScore = this.evaluateRecordDao.getSeasonAvgScore(queryMap);

		// 综合履约评价得分=季度履约评价得分的平均分×p+合同完成履约评价的得分×f，p=0.4，f=0.6
		BigDecimal comprehensiveScore = null;

		if (seasonAvgScore != null) {
			comprehensiveScore = seasonAvgScore.multiply(new BigDecimal(0.4)).add(contractScore.multiply(new BigDecimal(0.6)));
		} else {
			comprehensiveScore = contractScore;
		}

		// 四舍五入
		comprehensiveScore = comprehensiveScore.setScale(1, BigDecimal.ROUND_HALF_UP);

		EvaluateRecord entity = new EvaluateRecord();

		entity.setProId(evaluateRecord.getProId());
		entity.setProName(evaluateRecord.getProName());
		entity.setPartId(evaluateRecord.getPartId());
		entity.setEngTypeCode(evaluateRecord.getEngTypeCode());
		entity.setTargetUnitId(evaluateRecord.getTargetUnitId());
		entity.setEvalUserId(getNowUserId());
		entity.setEvalUnitId(getNowUser().getUnitId());
		entity.setContractorName(evaluateRecord.getContractorName());
		entity.setBuildUnitName(evaluateRecord.getBuildUnitName());
		entity.setFormType(EvaluateRecordDTO.FORM_TYPE_COMPREHENSIVE);
		entity.setStatus(EvaluateRecordDTO.STATUS_SUCCEED);
		entity.setGmtEval(new Date());
		entity.setCreateBy(this.getNowUser().getUsername());
		entity.setFlag(EvaluateRecordDTO.FLAG_ARCHIVED); // 标志评价记录是否已保存：创建评价记录，默认定时删除，保存/提交后完成归档
		entity.setTotalScore(comprehensiveScore);
		entity.setEvalGrade(getEvalGradeByTotalScore(comprehensiveScore));
		entity.setPleaStatus(EvaluateRecordDTO.PLEA_STATUS_DEFAULT);
		this.evaluateRecordDao.insert(entity);

		this.writeInfoLog("Add: " + entity.toString());

		// 将合同的评价状态设置为完成
		this.projectPartInfoService.setProjectPartEvaluateStatus(evaluateRecord.getPartId(), GobalVal.EVALUATE_END);
	}

	private Short getEvalGradeByTotalScore(BigDecimal comprehensiveScore) {

		int score = comprehensiveScore.intValue();
		Short result = null;
		if (score < 60) {
			result = EvaluateRecordDTO.EVAL_GRADE_BAD;
		} else if (score >= 60 && score < 75) {
			result = EvaluateRecordDTO.EVAL_GRADE_GOOD;
		} else if (score >= 75 && score < 90) {
			result = EvaluateRecordDTO.EVAL_GRADE_BETTER;
		} else if (score >= 90) {
			result = EvaluateRecordDTO.EVAL_GRADE_BEST;
		}
		return result;
	}

	// ------------------------年度履约评价相关---------------------------//

	@Override
	public Page<EvaluateRecordDTO> searchContractorYearEvaluateRecordByPage(DataQuery dq) {
		Long recTotal = this.evaluateRecordDao.countYearByCondition(dq.assemblePageOffset().getQueryMap());
		dq.assembleOrderInfo(EvaluateRecord.class, "a");
		List<EvaluateRecordDTO> resultlist = this.evaluateRecordDao.selectYearListByCondition(dq.getQueryMap());
		this.initText(resultlist);
		return new Page<EvaluateRecordDTO>(dq.getCurrentPage(), dq.getPageSize(), resultlist, recTotal);
	}

	@Override
	public void createContractorYearEvaluateRecord() {

		// 1.删除本年度旧记录
		this.deleteYearEvaluateRecord();

		// 2.查出本年度所有季度评价记录
		DataQuery dq = new DataQuery();
		dq.putToMap("certainYear", Calendar.getInstance().get(Calendar.YEAR));
		dq.putToMap("flag", EvaluateRecordDTO.FLAG_ARCHIVED);
		dq.putToMap("status", EvaluateRecordDTO.STATUS_SUCCEED);
		dq.putToMap("formType", EvaluateRecordDTO.FORM_TYPE_SEASON);
		List<EvaluateRecordDTO> resultList = this.evaluateRecordDao.selectListByCondition(dq.getQueryMap());

		// 3.数据分组，生成年度履约记录
		this.groupingYearDataAndGetScore(resultList);

	}

	/**
	 * 删除本年度的年度履约评价
	 */
	private void deleteYearEvaluateRecord() {
		this.evaluateRecordDao.deleteYearEvaluateRecord();
	}

	private void groupingYearDataAndGetScore(List<EvaluateRecordDTO> resultList) {
		// 3.根据承包商分组
		if (resultList != null && !resultList.isEmpty()) {
			// Map<承包商,Map<合同类型,结果集>>
			Map<String, Map<String, List<EvaluateRecordDTO>>> resultMap = new HashMap<>();

			// 第一次遍历，根据承包商分组
			Map<String, List<EvaluateRecordDTO>> contractorMap = new HashMap<>();
			for (EvaluateRecordDTO recordDTO : resultList) {
				if (contractorMap.containsKey(recordDTO.getTargetUnitId())) {
					contractorMap.get(recordDTO.getTargetUnitId()).add(recordDTO);
				} else {
					List<EvaluateRecordDTO> recordList = new ArrayList<EvaluateRecordDTO>();
					recordList.add(recordDTO);
					contractorMap.put(recordDTO.getTargetUnitId(), recordList);
				}
			}

			// 遍历承包商map,根据合同类型分组
			for (Entry<String, List<EvaluateRecordDTO>> entry : contractorMap.entrySet()) {
				String contractorId = entry.getKey();
				// 该承包商所有评价
				List<EvaluateRecordDTO> contractorRecordList = entry.getValue();
				Map<String, List<EvaluateRecordDTO>> engTypeMap = new HashMap<>();
				if (contractorRecordList != null && !contractorRecordList.isEmpty()) {
					for (EvaluateRecordDTO recordDTO : contractorRecordList) {

						if (recordDTO.getEngTypeCode().equals("DJ")) {
							if (recordDTO.getRecordType().equals(EvaluateRecordDTO.RECORD_TYPE_TOTAL)) {
								if (engTypeMap.containsKey(recordDTO.getEngTypeCode())) {
									engTypeMap.get(recordDTO.getEngTypeCode()).add(recordDTO);
								} else {
									List<EvaluateRecordDTO> recordList = new ArrayList<EvaluateRecordDTO>();
									recordList.add(recordDTO);
									engTypeMap.put(recordDTO.getEngTypeCode(), recordList);
								}
							}
						} else {
							if (engTypeMap.containsKey(recordDTO.getEngTypeCode())) {
								engTypeMap.get(recordDTO.getEngTypeCode()).add(recordDTO);
							} else {
								List<EvaluateRecordDTO> recordList = new ArrayList<EvaluateRecordDTO>();
								recordList.add(recordDTO);
								engTypeMap.put(recordDTO.getEngTypeCode(), recordList);
							}
						}

					}
					resultMap.put(contractorId, engTypeMap);
				}
			}

			// 3.遍历结果集，生成年度履约评价
			for (Entry<String, Map<String, List<EvaluateRecordDTO>>> contractorEntry : resultMap.entrySet()) {
				String contractorId = contractorEntry.getKey();
				Map<String, List<EvaluateRecordDTO>> engTypeMap = contractorEntry.getValue();

				if (contractorEntry.getValue() != null) {
					// 同一承包商，每种合同类型生成一条年度履约评价结果
					for (Entry<String, List<EvaluateRecordDTO>> engTypeEntry : engTypeMap.entrySet()) {
						EvaluateRecord entity = new EvaluateRecord();
						BigDecimal totalScore = getYearEvaluateRecordScore(engTypeEntry.getValue());
						entity.setTargetUnitId(contractorId);
						entity.setEngTypeCode(engTypeEntry.getKey());
						entity.setEvalUserId(getNowUserId());
						entity.setFormType(EvaluateRecordDTO.FORM_TYPE_YEAR);
						entity.setStatus(EvaluateRecordDTO.STATUS_SUCCEED);
						entity.setGmtEval(new Date());
						entity.setCreateBy(this.getNowUser().getUsername());
						entity.setFlag(EvaluateRecordDTO.FLAG_ARCHIVED); // 标志评价记录是否已保存：创建评价记录，默认定时删除，保存/提交后完成归档
						entity.setTotalScore(totalScore);
						entity.setEvalGrade(getEvalGradeByTotalScore(totalScore));
						entity.setPleaStatus(EvaluateRecordDTO.PLEA_STATUS_DEFAULT);
						this.evaluateRecordDao.insert(entity);

						this.writeInfoLog("Add: " + entity.toString());
					}

				}
			}

		}
	}

	/**
	 * 计算年度得分
	 * 
	 * @param resultList
	 * @return
	 */
	private BigDecimal getYearEvaluateRecordScore(List<EvaluateRecordDTO> resultList) {
		BigDecimal result = new BigDecimal(0);
		Boolean isHasFaildRecord = false;

		int i = 0;
		for (EvaluateRecordDTO recordDTO : resultList) {
			// 有不合格记录
			if (recordDTO.getTotalScore().intValue() < 60) {
				isHasFaildRecord = true;
			}

			if (EvaluateRecordDTO.FORM_TYPE_SEASON.equals(recordDTO.getFormType())) {
				result = result.add(recordDTO.getTotalScore());
				i++;
			}
		}

		// 结果四舍五入
		result = result.divide(new BigDecimal(i), 1, RoundingMode.HALF_UP);

		// 若年度内任一阶段存在合同履约评价不合格的，其年度履约评价结果不能评为优秀
		if (isHasFaildRecord == true) {
			if (result.intValue() >= 90) {
				result = new BigDecimal(89);
			}
		}

		return result;
	}

	@Override
	public void judgeIfEvaluateRecordExist(String formId, String formType, String proId, String partId) {

		if (StringUtils.isNotBlank(formId)) {
			EvaluateForm evaluateForm = this.evaluateFormDao.getById(formId);
			if (evaluateForm != null) {
				DataQuery dq = new DataQuery();
				dq.putToMap("evalUnitId", getNowUser().getUnitId());
				dq.putToMap("engTypeCode", evaluateForm.getEngTypeCode());
				dq.putToMap("formType", formType);
				if (EvaluateRecordDTO.FORM_TYPE_SEASON.equals(formType)) {
					Map<String, Date> dateMap = this.evaluateTimeSettingService.getSeasonEvaluateTime();
					dq.putToMap("evalBeginTime", dateMap.get("beginTime"));
					dq.putToMap("evalEndTime", dateMap.get("endTime"));
				}
				if (EvaluateRecordDTO.ENG_TYPE_CODE_DJ.equals(evaluateForm.getEngTypeCode())) {
					// 代建
					dq.putToMap("proId", proId);
				} else {
					// 非代建
					dq.putToMap("partId", partId);
				}

				Long result = this.evaluateRecordDao.judgeIfEvaluateRecordExist(dq.getQueryMap());

				if (result > 0) {
					if (EvaluateRecordDTO.FORM_TYPE_SEASON.equals(formType)) {
						throw new BusinessException("本季度季度履约评价进行中/已完成，请勿重复添加");
					}
					if (EvaluateRecordDTO.FORM_TYPE_CONTRACT.equals(formType)) {
						throw new BusinessException("合同评价进行中,请勿重复添加");
					}
				}
			} else {
				throw new BusinessException("评价表异常");
			}
		}

	}

	@Override
	public void createDjEvaluateRecord(EvaluateRecordDTO evaluateRecord) {

		// 查询该代建项目的所有合同履约评价
		DataQuery dq = new DataQuery();
		dq.putToMap("proId", evaluateRecord.getProId());
		dq.putToMap("flag", EvaluateRecordDTO.FLAG_ARCHIVED);
		dq.putToMap("status", EvaluateRecordDTO.STATUS_SUCCEED);
		dq.putToMap("formType", evaluateRecord.getFormType());
		dq.putToMap("engTypeCode", "DJ");

		// 查出所有季度/合同评价
		List<EvaluateRecordDTO> recordList = this.evaluateRecordDao.selectListByCondition(dq.getQueryMap());

		if (recordList != null && !recordList.isEmpty() && recordList.size() == 3) {

			EvaluateRecord buildRecord = null; // 建设单位评分记录
			BigDecimal buildScore = null; // 建设单位评分

			EvaluateRecord zjRecord = null; // 住建局评分记录
			BigDecimal zjScore = null; // 住建局评分

			EvaluateRecord fgRecord = null; // 发改局评分记录
			BigDecimal fgcore = null; // 发改局评分

			for (EvaluateRecordDTO recordDTO : recordList) {
				if (EvaluateRecordDTO.RECORD_TYPE_BUILD_UNIT.equals(recordDTO.getRecordType())) {
					buildScore = recordDTO.getTotalScore();
					buildRecord = this.evaluateRecordDao.getById(recordDTO.getId());
				}
				if (EvaluateRecordDTO.RECORD_TYPE_ZJ_UNIT.equals(recordDTO.getRecordType())) {
					zjScore = recordDTO.getTotalScore();
					zjRecord = this.evaluateRecordDao.getById(recordDTO.getId());
				}
				if (EvaluateRecordDTO.RECORD_TYPE_FG_UNIT.equals(recordDTO.getRecordType())) {
					fgcore = recordDTO.getTotalScore();
					fgRecord = this.evaluateRecordDao.getById(recordDTO.getId());
				}
			}

			BigDecimal totalScore = buildScore.multiply(new BigDecimal(0.6)).add(zjScore.multiply(new BigDecimal(0.2)))
					.add(fgcore.multiply(new BigDecimal(0.2)));
			totalScore = totalScore.setScale(1, BigDecimal.ROUND_HALF_UP);

			EvaluateRecord entity = new EvaluateRecord();
			entity.setEngTypeCode("DJ");
			entity.setRecordType(EvaluateRecordDTO.RECORD_TYPE_TOTAL);
			entity.setProId(evaluateRecord.getProId());
			entity.setProName(evaluateRecord.getProName());
			entity.setFormType(evaluateRecord.getFormType());
			entity.setTargetUnitId(evaluateRecord.getTargetUnitId());
			entity.setBuildUnitName(evaluateRecord.getBuildUnitName());
			entity.setContractorName(evaluateRecord.getContractorName());
			entity.setStatus(EvaluateRecordDTO.STATUS_SUCCEED);
			entity.setGmtEval(new Date());
			entity.setCreateBy(this.getNowUser().getUsername());
			entity.setFlag(EvaluateRecordDTO.FLAG_ARCHIVED); // 标志评价记录是否已保存：创建评价记录，默认定时删除，保存/提交后完成归档
			entity.setTotalScore(totalScore);
			entity.setEvalGrade(getEvalGradeByTotalScore(totalScore));
			entity.setPleaStatus(EvaluateRecordDTO.PLEA_STATUS_DEFAULT);
			this.evaluateRecordDao.insert(entity);

			buildRecord.setConnectRecordId(entity.getId());
			zjRecord.setConnectRecordId(entity.getId());
			fgRecord.setConnectRecordId(entity.getId());

			this.evaluateRecordDao.update(buildRecord);
			this.evaluateRecordDao.update(zjRecord);
			this.evaluateRecordDao.update(fgRecord);

			// 生成综合履约评价

			// 合同总评价记得分
			BigDecimal contractScore = totalScore;
			// 季度评价记录平均分
			Map<String, Object> queryMap = new HashMap<>();
			queryMap.put("proId", evaluateRecord.getProId());
			BigDecimal seasonAvgScore = this.evaluateRecordDao.getSeasonAvgScore(queryMap);

			// 综合履约评价得分=季度履约评价得分的平均分×p+合同完成履约评价的得分×f，p=0.4，f=0.6
			BigDecimal comprehensiveScore = null;

			if (seasonAvgScore != null) {
				comprehensiveScore = seasonAvgScore.multiply(new BigDecimal(0.4)).add(contractScore.multiply(new BigDecimal(0.6)));
			} else {
				comprehensiveScore = contractScore;
			}

			// 四舍五入
			comprehensiveScore = comprehensiveScore.setScale(1, BigDecimal.ROUND_HALF_UP);

			EvaluateRecord comprehensiveRecord = new EvaluateRecord();

			comprehensiveRecord.setProId(evaluateRecord.getProId());
			comprehensiveRecord.setProName(evaluateRecord.getProName());
			comprehensiveRecord.setEngTypeCode("DJ");
			comprehensiveRecord.setProName(evaluateRecord.getProName());
			comprehensiveRecord.setTargetUnitId(evaluateRecord.getTargetUnitId());
			comprehensiveRecord.setContractorName(evaluateRecord.getContractorName());
			comprehensiveRecord.setBuildUnitName(evaluateRecord.getBuildUnitName());
			comprehensiveRecord.setFormType(EvaluateRecordDTO.FORM_TYPE_COMPREHENSIVE);
			comprehensiveRecord.setStatus(EvaluateRecordDTO.STATUS_SUCCEED);
			comprehensiveRecord.setGmtEval(new Date());
			comprehensiveRecord.setCreateBy(this.getNowUser().getUsername());
			comprehensiveRecord.setFlag(EvaluateRecordDTO.FLAG_ARCHIVED); // 标志评价记录是否已保存：创建评价记录，默认定时删除，保存/提交后完成归档
			comprehensiveRecord.setTotalScore(comprehensiveScore);
			comprehensiveRecord.setEvalGrade(getEvalGradeByTotalScore(comprehensiveScore));
			comprehensiveRecord.setPleaStatus(EvaluateRecordDTO.PLEA_STATUS_DEFAULT);
			this.evaluateRecordDao.insert(comprehensiveRecord);

			// 将项目的评价状态设置为完成
			this.projectInfoService.setProjectEvaluateStatus(evaluateRecord.getProId(), GobalVal.EVALUATE_END);

		}
	}

	/**
	 * 合同类型为代建时，用于标识该条记录是由哪个单位评分
	 * 
	 * @buildUnit - 建设单位评价
	 * @zjUnit 住建单位评价
	 * @fgUnit 发改局评价
	 * 
	 */
	private String setDjEvaluateRecordType() {
		String result = "";
		if (SecurityPrincipalUtil.checkIsHasRole(Role.ROLE_BUILD_UNIT)) {
			result = EvaluateRecordDTO.RECORD_TYPE_BUILD_UNIT;
		}
		if (SecurityPrincipalUtil.checkIsHasRole(Role.ROLE_HOUSING) || SecurityPrincipalUtil.checkIsHasRole(Role.ROLE_HOUSING_PJ)) {
			result = EvaluateRecordDTO.RECORD_TYPE_ZJ_UNIT;
		}
		if (SecurityPrincipalUtil.checkIsHasRole(Role.ROLE_FG)) {
			result = EvaluateRecordDTO.RECORD_TYPE_FG_UNIT;
		}
		return result;

	}

	@Override
	public List<Map<String, Object>> yearUnitTopK(DataQuery dq) {
		return this.evaluateRecordDao.yearUnitTopK(dq.getQueryMap());
	}
	
	// 定时任务 
	public void deleteInvalidScheduling() {
		System.out.println("==================== delete invalid evaluate record ====================");
		DataQuery dq = new DataQuery();
		dq.setNotQueryPage();
		dq.putToMap("flag", EvaluateRecordDTO.FLAG_TODELETE);
		this.evaluateRecordDao.deleteByCondition(dq.getQueryMap());
	}

}
