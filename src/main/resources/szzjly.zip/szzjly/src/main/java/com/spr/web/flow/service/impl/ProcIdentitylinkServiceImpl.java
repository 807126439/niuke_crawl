package com.spr.web.flow.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.service.BaseService;
import com.spr.core.common.utils.Assert;
import com.spr.web.flow.dao.IProcIdentitylinkDao;
import com.spr.web.flow.dao.IProcNodeDao;
import com.spr.web.flow.dto.def.ProcIdentitylinkDTO;
import com.spr.web.flow.entity.ProcIdentitylink;
import com.spr.web.flow.entity.ProcNode;
import com.spr.web.flow.service.IProcIdentitylinkService;
import com.spr.web.system.dto.user.WeiUserDTO;

@Service("procIdentitylinkService")
@Transactional
public class ProcIdentitylinkServiceImpl extends BaseService implements IProcIdentitylinkService {

	@Resource
	private IProcIdentitylinkDao procIdentitylinkDao;
	@Resource
	private IProcNodeDao procNodeDao;

	/**
	 * 通过流程码查询流程开始节点下一节点的默认负责人
	 * 
	 * @param processCode
	 * @return
	 */
	@Override
	public List<WeiUserDTO> getNodeAfterStartUser(String processCode) {
		List<ProcNode> startNodes = this.procNodeDao.getByProcessCodeAndNodeType(processCode, ProcNode.TYPE_START);
		Assert.notEmpty(startNodes, "未定义流程的开始节点！");

		ProcNode startNode = startNodes.get(0);
		List<ProcNode> nextNodes = this.procNodeDao.getByPreNodeId(startNode.getId());
		if (!nextNodes.isEmpty()) {
			List<String> ids = new ArrayList<String>(nextNodes.size());
			for (ProcNode procNode : nextNodes) {
				ids.add(procNode.getId());
			}

			return this.procIdentitylinkDao.getUserInfoByNodeIds(ids);
		}

		return null;
	}

	/**
	 * 通过节点id查找负责人
	 * 
	 * @param nodeId
	 * @return
	 */
	@Override
	public List<WeiUserDTO> getUsersByNodeId(String nodeId) {
		Assert.hasText(nodeId, Assert.NULL_PARAM_STR("nodeId"));

		return this.procIdentitylinkDao.getUserInfoByNodeId(nodeId);
	}

	/**
	 * 分页查询
	 * 
	 * @param dq
	 */
	@Override
	public Page<ProcIdentitylinkDTO> searchByPage(DataQuery dq) {

		Long recTotal = this.procIdentitylinkDao.countByCondition(dq.assemblePageOffset().getQueryMap());
		dq.assembleOrderInfo(ProcIdentitylink.class, null);
		List<ProcIdentitylinkDTO> resultlist = this.procIdentitylinkDao.selectListByCondition(dq.getQueryMap());

		return new Page<ProcIdentitylinkDTO>(dq.getCurrentPage(), dq.getPageSize(), resultlist, recTotal);
	}

	/**
	 * 查询详细
	 * 
	 * @param id
	 */
	@Override
	public ProcIdentitylinkDTO getDetailById(String id) {
		Assert.hasText(id, Assert.NULL_PARAM_STR("id"));

		ProcIdentitylinkDTO result = this.procIdentitylinkDao.getDetailById(id);
		Assert.notNull(result, Assert.EMPTY_REOCRD_STR);

		return result;
	}

	/**
	 * 添加
	 * 
	 * @param dto
	 */
	@Override
	public void addProcIdentitylink(ProcIdentitylinkDTO dto) {

		ProcIdentitylink model = new ProcIdentitylink();
		model.setProcDefId(dto.getProcDefId());
		model.setNodeId(dto.getNodeId());
		model.setUserId(dto.getUserId());
		model.setDepartId(dto.getDepartId());
		model.setType(ProcIdentitylink.ALLOT_USER_TYPE);
		model.setStatus(ProcIdentitylink.DEF_STATUS);
		model.setCreateBy(getNowUser().getUsername());

		this.procIdentitylinkDao.insert(model);

		if (this.logger.isInfoEnabled()) {
			this.logger.info("Add: " + model.toString());
		}
	}

	/**
	 * 修改
	 * 
	 * @param dto
	 */
	@Override
	public void updateProcIdentitylink(ProcIdentitylinkDTO dto) {
		Assert.hasText(dto.getId(), Assert.NULL_PARAM_STR("id"));

		ProcIdentitylink model = this.procIdentitylinkDao.getById(dto.getId());
		Assert.notNull(model, Assert.EMPTY_REOCRD_STR);

		model.setProcDefId(dto.getProcDefId());
		model.setNodeId(dto.getNodeId());
		model.setUserId(dto.getUserId());
		model.setDepartId(dto.getDepartId());
		model.setType(dto.getType());
		model.setStatus(dto.getStatus());
		model.setCreateBy(dto.getCreateBy());
		model.setUpdateBy(dto.getUpdateBy());
		model.setGmtCreate(dto.getGmtCreate());
		model.setGmtModified(dto.getGmtModified());

		this.procIdentitylinkDao.update(model);

		if (this.logger.isInfoEnabled()) {
			this.logger.info("Update: " + model.toString());
		}
	}

	/**
	 * 删除
	 * 
	 * @param ids
	 */
	@Override
	public void deleteProcIdentitylinks(String[] ids) {
		for (int i = 0; i < ids.length; i++) {
			this.procIdentitylinkDao.deleteById(ids[i]);

			if (this.logger.isInfoEnabled()) {
				this.logger.info("Delete：:" + ids[i]);
			}
		}
	}

}
