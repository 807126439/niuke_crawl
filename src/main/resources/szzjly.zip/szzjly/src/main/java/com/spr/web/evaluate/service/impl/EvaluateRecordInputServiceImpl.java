package com.spr.web.evaluate.service.impl;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.service.BaseService;
import com.spr.core.common.utils.Assert;
import com.spr.web.evaluate.dao.IEvaluateRecordInputDao;
import com.spr.web.evaluate.dto.form.EvaluateFormIndexDTO;
import com.spr.web.evaluate.dto.record.EvaluateRecordDTO;
import com.spr.web.evaluate.dto.record.EvaluateRecordIndexDTO;
import com.spr.web.evaluate.dto.record.EvaluateRecordInputDTO;
import com.spr.web.evaluate.entity.EvaluateRecordInput;
import com.spr.web.evaluate.service.IEvaluateFormIndexService;
import com.spr.web.evaluate.service.IEvaluateRecordInputService;

@Service("evaluateRecordInputService")
@Transactional
public class EvaluateRecordInputServiceImpl extends BaseService implements IEvaluateRecordInputService {

	
   @Resource
   private IEvaluateRecordInputDao evaluateRecordInputDao;
	@Resource
	private IEvaluateFormIndexService evaluateFormIndexService;
	
	   @Override
	   public Map<String, EvaluateRecordInputDTO> selectIndexModelMapByCondition(DataQuery dq) {
			List<EvaluateRecordInputDTO> list = this.selectListByCondition(dq);
			
			Map<String, EvaluateRecordInputDTO> map = new HashMap<String, EvaluateRecordInputDTO>();
			for (EvaluateRecordInputDTO dto : list) {
				map.put(dto.getIndexId(), dto);
			}
	   		return map;
	   }
	   
   @Override
   public Map<String, BigDecimal> selectIndexInputMapByCondition(DataQuery dq) {
		List<EvaluateRecordInputDTO> list = this.selectListByCondition(dq);
		
		Map<String, BigDecimal> map = new HashMap<String, BigDecimal>();
		for (EvaluateRecordInputDTO dto : list) {
			map.put(dto.getIndexId(), dto.getInputVal());
		}
   		return map;
   }
   
   @Override
   public List<EvaluateRecordInputDTO> selectListByCondition(DataQuery dq) {
	   dq.assemblePageOffset();
		dq.assembleOrderInfo(EvaluateRecordInput.class, null);
		List<EvaluateRecordInputDTO> resultlist = this.evaluateRecordInputDao.selectListByCondition(dq.getQueryMap());
   		return resultlist;
   }
   
   /**
    * 分页查询
    * @param dq
    */
   @Override
   public Page<EvaluateRecordInputDTO> searchByPage(DataQuery dq) {
   		
   		Long recTotal = this.evaluateRecordInputDao.countByCondition(dq.assemblePageOffset().getQueryMap());
		dq.assembleOrderInfo(EvaluateRecordInput.class, null);
		List<EvaluateRecordInputDTO> resultlist = this.evaluateRecordInputDao.selectListByCondition(dq.getQueryMap());
   
   		return new Page<EvaluateRecordInputDTO>(dq.getCurrentPage(), dq.getPageSize(), resultlist, recTotal);
   }
   
   
   /**
    * 查询详细
    * @param id
    */
   @Override
   public EvaluateRecordInputDTO getDetailById(String id){
   	   Assert.hasText(id, Assert.NULL_PARAM_STR("id")); 
   	   
   
   	   EvaluateRecordInputDTO result = this.evaluateRecordInputDao.getDetailById(id);
   	   Assert.notNull(result,Assert.EMPTY_REOCRD_STR);
   	   
   	   return result;
   }
   
   
   
   
   /**
    * 添加
    * @param dto
   	*/
   @Override
   public void addEvaluateRecordInput(EvaluateRecordInputDTO dto){
   
   	  EvaluateRecordInput model = new EvaluateRecordInput();
	  model.setEvalId(dto.getEvalId()); 	  
	  model.setFormId(dto.getFormId()); 	  
	  model.setIndexId(dto.getIndexId()); 	  
	  model.setInputVal(dto.getInputVal());   
	  model.setOrginalVal(dto.getInputVal()); 	  
	  model.setIsModified(EvaluateRecordInputDTO.MODIFIED_FALSE);	  
	  model.setStatus(dto.getStatus()); 	  
	  model.setCreateBy(this.getNowUser().getUsername()); 	  
	  model.setUpdateBy(this.getNowUser().getUsername()); 	  
	  model.setGmtCreate(new Date()); 	  
	  model.setGmtModified(new Date()); 	  
   
   	  this.evaluateRecordInputDao.insert(model);
   	  
   
      this.writeInfoLog("Add: "+model.toString());
      
   }
   
   
   /**
    * 修改
    * @param dto
   	*/
   @Override
   public void updateEvaluateRecordInput(EvaluateRecordInputDTO dto){
   	    Assert.hasText(dto.getId(), Assert.NULL_PARAM_STR("id")); 
    	
    	EvaluateRecordInput model = this.evaluateRecordInputDao.getById(dto.getId());
    	Assert.notNull(model,Assert.EMPTY_REOCRD_STR);
    	
	  	model.setEvalId(dto.getEvalId()); 	  
	  	model.setFormId(dto.getFormId()); 	  
	  	model.setIndexId(dto.getIndexId()); 	  
	  	model.setInputVal(dto.getInputVal()); 	  
	  	model.setOrginalVal(dto.getInputVal()); 	  
	  	model.setIsModified(dto.getIsModified()); 	  
	  	model.setStatus(dto.getStatus()); 	  
		// model.setCreateBy(this.getNowUser().getUsername()); 	  
		model.setUpdateBy(this.getNowUser().getUsername()); 	  
		// model.setGmtCreate(new Date()); 	  
		model.setGmtModified(new Date()); 	  
    	    	
    	this.evaluateRecordInputDao.update(model);
    	
   
    	this.writeInfoLog("Update: "+model.toString());
        
   }
   
   
   
    /**
   	 * 删除
   	 * @param ids
   	 */
   	@Override
    public void deleteEvaluateRecordInputs(String[] ids){
    	for (int i = 0; i < ids.length; i++) {
			this.evaluateRecordInputDao.deleteById(ids[i]);
			
			
	        this.writeInfoLog("Delete id:" + ids[i]);
	        
		}
    }
   
   	public void deleteEvaluateRecordInputsByCondition(DataQuery dq) {
   		this.evaluateRecordInputDao.deleteByCondition(dq.getQueryMap());
   	}

    
   	// 获取子评分指标
	@Override
   	public List<EvaluateFormIndexDTO> getSubIndexList(
   			DataQuery dq, 
   			String parentId, 
   			Map<String, BigDecimal> indexInputMap, 
   			Map<String, EvaluateRecordIndexDTO> originModelMap) {
   		dq.clear();
   		dq.setNotQueryPage();
   		dq.setSidx("sortNo");
   		dq.setSord("asc");
   		dq.putToMap("parentId", parentId);
   		List<EvaluateFormIndexDTO> list = this.evaluateFormIndexService.selectListByCondition(dq);
   		if (list == null || list.isEmpty()) {
   			return null;
   		}
   		
   		for (EvaluateFormIndexDTO dto : list) { 
   			// formIndexId => recordIndex => recordIndexId => inputVal
   			EvaluateRecordIndexDTO recordIndex = originModelMap.get(dto.getId());
   			dto.setInputVal(recordIndex == null ? null : indexInputMap.get(recordIndex.getId()));
   			List<EvaluateFormIndexDTO> subList = this.getSubIndexList(dq, dto.getId(), indexInputMap, originModelMap);
   			dto.setSubIndexList(subList);
   		}
   		return list;
   	}
	
   	
   	// TODO delete not exists
   	// save or update fillin input 
   	public void saveOrUpdate(EvaluateRecordDTO dto, String[] inputIds, String[] inputVals, Map<String, EvaluateRecordIndexDTO> originModelMap) {
		// 获取 实际指标id-输入值 映射
		DataQuery dq = new DataQuery();
		dq.setNotQueryPage();
		dq.putToMap("evalId", dto.getId());
		Map<String, EvaluateRecordInputDTO> indexInputMap = this.selectIndexModelMapByCondition(dq);

		for (int i = 0; i < inputIds.length; i++) {
			EvaluateRecordIndexDTO recordIndex = originModelMap.get(inputIds[i]);
			if (recordIndex != null) {
				// exist in form
				if (indexInputMap.containsKey(recordIndex.getId())) {
					// already input, update
					EvaluateRecordInputDTO recordInput = indexInputMap.get(recordIndex.getId());
					if (i < inputVals.length) {
						recordInput.setInputVal(StringUtils.isBlank(inputVals[i].trim()) ? null : BigDecimal.valueOf(Double.valueOf(inputVals[i].trim())));
						// TODO
					} else {
						// no input, ignore
						// recordInput.setInputVal(BigDecimal.valueOf(0));
					}
					this.updateEvaluateRecordInput(recordInput);
				} else {
					// never input, add
					EvaluateRecordInputDTO recordInput = new EvaluateRecordInputDTO();
					recordInput.setEvalId(dto.getId());
					recordInput.setFormId(dto.getFormId());
					recordInput.setIndexId(recordIndex.getId());
					if (i < inputVals.length) {
						recordInput.setInputVal(StringUtils.isBlank(inputVals[i].trim()) ? null : BigDecimal.valueOf(Double.valueOf(inputVals[i].trim())));
						// TODO
					} else {
						// no input, ignore
						// recordInput.setInputVal(BigDecimal.valueOf(0));
					}
					this.addEvaluateRecordInput(recordInput);
				}
			}
		}
   	}
}
