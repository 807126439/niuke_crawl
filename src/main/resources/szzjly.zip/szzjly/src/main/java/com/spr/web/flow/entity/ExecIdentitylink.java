package com.spr.web.flow.entity;

import java.io.Serializable;

import com.spr.core.annotations.DbField;
import com.spr.core.common.entity.UUIDEntity;

public class ExecIdentitylink extends UUIDEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final Short PENDINF_STATUS = 0; // 待办理
	public static final Short SUCCESS_HANDLE_STATUS = 1;// 办理成功
	public static final Short FAIL_HANDLE_STATUS = 2; // 办理退回

	private String procDefId;

	private String procInstId;

	private String nodeId;

	private String userId;

	private String departId;

	private Short type;

	private Short status;

	private String createBy;

	private String updateBy;

	@DbField(name = "proc_def_id")
	public String getProcDefId() {
		return procDefId;
	}

	public void setProcDefId(String procDefId) {
		this.procDefId = procDefId == null ? null : procDefId.trim();
	}

	@DbField(name = "proc_inst_id")
	public String getProcInstId() {
		return procInstId;
	}

	public void setProcInstId(String procInstId) {
		this.procInstId = procInstId == null ? null : procInstId.trim();
	}

	@DbField(name = "node_id")
	public String getNodeId() {
		return nodeId;
	}

	public void setNodeId(String nodeId) {
		this.nodeId = nodeId == null ? null : nodeId.trim();
	}

	@DbField(name = "user_id")
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId == null ? null : userId.trim();
	}

	@DbField(name = "depart_id")
	public String getDepartId() {
		return departId;
	}

	public void setDepartId(String departId) {
		this.departId = departId == null ? null : departId.trim();
	}

	@DbField(name = "type")
	public Short getType() {
		return type;
	}

	public void setType(Short type) {
		this.type = type;
	}

	@DbField(name = "status")
	public Short getStatus() {
		return status;
	}

	public void setStatus(Short status) {
		this.status = status;
	}

	@DbField(name = "create_by")
	public String getCreateBy() {
		return createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy == null ? null : createBy.trim();
	}

	@DbField(name = "update_by")
	public String getUpdateBy() {
		return updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy == null ? null : updateBy.trim();
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode());
		sb.append(",Super = ").append(super.toString());
		sb.append(", serialVersionUID=").append(serialVersionUID);
		sb.append(", procDefId=").append(procDefId);
		sb.append(", procInstId=").append(procInstId);
		sb.append(", nodeId=").append(nodeId);
		sb.append(", userId=").append(userId);
		sb.append(", departId=").append(departId);
		sb.append(", type=").append(type);
		sb.append(", status=").append(status);
		sb.append(", createBy=").append(createBy);
		sb.append(", updateBy=").append(updateBy);
		sb.append("]");
		return sb.toString();
	}
}