package com.spr.core.aspect.trace.dao;

import com.spr.core.aspect.trace.entity.TraceInfo;
import com.spr.core.common.dao.IBaseDao;

public interface TraceInfoDao extends IBaseDao<String, TraceInfo>  {
    int deleteByPrimaryKey(String id);

    TraceInfo selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TraceInfo record);

    int updateByPrimaryKey(TraceInfo record);
}