package com.spr.web.evaluate.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spr.core.common.exception.BusinessException;
import com.spr.core.common.service.BaseService;
import com.spr.web.evaluate.dto.record.EvaluateRecordDTO;
import com.spr.web.evaluate.service.IEvaluateAuditService;
import com.spr.web.evaluate.service.IEvaluateRecordService;
import com.spr.web.flow.constant.DefinitionCodeConsts;
import com.spr.web.flow.dto.def.ProcDefDTO;
import com.spr.web.flow.dto.exec.ExecNodeDTO;
import com.spr.web.flow.service.IExecNodeService;
import com.spr.web.flow.service.IProcDefService;
import com.spr.web.project.dto.project.ProjectInfoDTO;
import com.spr.web.project.service.IProjectInfoService;
import com.spr.web.system.dto.unit.UnitDTO;
import com.spr.web.system.service.IUnitService;

@Service("execAuditService")
@Transactional
public class EvaluateAuditServiceImpl extends BaseService implements IEvaluateAuditService {
	@Resource
	private IEvaluateRecordService evaluateRecordService;
	@Resource
	private IExecNodeService execNodeService;
	@Resource
	private IUnitService unitService;
	@Resource
	private IProcDefService procDefService;
	@Resource
	private IProjectInfoService projectInfoService;

	@Override
	public void withdrawEvaluate(String id) {
		EvaluateRecordDTO record = this.evaluateRecordService.getDetailById(id);

		ExecNodeDTO runingNode = this.execNodeService.getCurrNodeByDateId(record.getId());

		// 流程为空的直接删除
		ExecNodeDTO currNode = this.execNodeService.getCurrNodeByDateId(id);
		if (currNode != null) {
			// 检查
			List<ExecNodeDTO> nodeList = this.execNodeService.getStraightStructureProccess(runingNode.getProcInstId(), null);
			ExecNodeDTO secNode = nodeList.get(0);
			// 排序1 为第二步且未完成
			if (secNode.getFlowStatus() == 1 && secNode.getStatus() != 1) {
				this.execNodeService.deleteProcessByProcInstId(runingNode.getProcInstId());
				this.evaluateRecordService.deleteEvaluateRecords(new String[] { record.getId() });
			} else {
				throw new BusinessException("文书正在审核，无法撤回");
			}
		} else {
			this.evaluateRecordService.deleteEvaluateRecords(new String[] { record.getId() });
		}
	}

	/**
	 * 提交流程方法
	 * 
	 * @param id
	 *            评分记录Id
	 */
	@Override
	public void submitAudit(String recordId, String auditor) {

		ProcDefDTO procDef = this.checkDefIfExist(recordId);
		// 启动流程
		List<String> users = null;
		if (StringUtils.isNotBlank(auditor)) {
			users = new ArrayList<String>();
			users.add(auditor);
		}
		execNodeService.startProcess(procDef.getId(), recordId, users);

	}

	@Override
	public ProcDefDTO checkDefIfExist(String recordId) {
		// 根据单位类型获取执行流程
		UnitDTO unit = this.unitService.getDetailById(this.getNowUser().getUnitId());
		EvaluateRecordDTO record = this.evaluateRecordService.getDetailById(recordId);
		ProjectInfoDTO project = this.projectInfoService.getDetailById(record.getProId());

		String unitCode = DefinitionCodeConsts.run_process.code();
		Map<String, Object> queryMap = new HashMap<String, Object>();
		queryMap.put("procdefCodeIs", unitCode);
		queryMap.put("unitId", this.getNowUser().getUnitId());
		// TODO 如有多条，加激活状态查询条件
		ProcDefDTO procDef = this.procDefService.getDetailByParam(queryMap);

		if (procDef == null)
			throw new BusinessException("审核流程未设置");

		return procDef;
	}

	/**
	 * 重新提交
	 */
	@Override
	public void resubmitAudit(String id, String auditor) {
		this.execNodeService.restartProcess(id, auditor);
	}
}
