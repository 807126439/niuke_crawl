package com.spr.web.evaluate.service.impl;

import com.spr.web.evaluate.service.IEvaluateContractorRelationService;
import com.spr.core.common.service.BaseService;
import com.spr.web.evaluate.dao.IEvaluateContractorRelationDao;
import com.spr.web.evaluate.entity.EvaluateContractorRelation;
import com.spr.web.evaluate.dto.relation.EvaluateContractorRelationDTO;

import javax.annotation.Resource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.utils.Assert;

@Service("evaluateContractorRelationService")
@Transactional
public class EvaluateContractorRelationServiceImpl extends BaseService implements IEvaluateContractorRelationService {

	
   @Resource
   private IEvaluateContractorRelationDao evaluateContractorRelationDao;
   
   
   /**
    * 分页查询
    * @param dq
    */
   @Override
   public Page<EvaluateContractorRelationDTO> searchByPage(DataQuery dq) {
   		
   		Long recTotal = this.evaluateContractorRelationDao.countByCondition(dq.assemblePageOffset().getQueryMap());
		dq.assembleOrderInfo(EvaluateContractorRelation.class, null);
		List<EvaluateContractorRelationDTO> resultlist = this.evaluateContractorRelationDao.selectListByCondition(dq.getQueryMap());
   
   		return new Page<EvaluateContractorRelationDTO>(dq.getCurrentPage(), dq.getPageSize(), resultlist, recTotal);
   }
   
   
   /**
    * 查询详细
    * @param id
    */
   @Override
   public EvaluateContractorRelationDTO getDetailById(String id){
   	   Assert.hasText(id, Assert.NULL_PARAM_STR("id")); 
   	   
   
   	   EvaluateContractorRelationDTO result = this.evaluateContractorRelationDao.getDetailById(id);
   	   Assert.notNull(result,Assert.EMPTY_REOCRD_STR);
   	   
   	   return result;
   }
   
   
   
   
   /**
    * 添加
    * @param dto
   	*/
   @Override
   public void addEvaluateContractorRelation(EvaluateContractorRelationDTO dto){
   
   	  EvaluateContractorRelation model = new EvaluateContractorRelation();
	  model.setSortNo(dto.getSortNo()); 	  
	  model.setContractorTypeCode(dto.getContractorTypeCode()); 	  
	  model.setEvalFormId(dto.getEvalFormId()); 	  
	  model.setEvalWay(dto.getEvalWay()); 	  
	  model.setStatus(dto.getStatus()); 	  
	  model.setCreateBy(dto.getCreateBy()); 	  
	  model.setUpdateBy(dto.getUpdateBy()); 	  
	  model.setGmtCreate(dto.getGmtCreate()); 	  
	  model.setGmtModified(dto.getGmtModified()); 	  
   
   	  this.evaluateContractorRelationDao.insert(model);
   	  
   
      this.writeInfoLog("Add: "+model.toString());
      
   }
   
   
   
   /**
    * 修改
    * @param dto
   	*/
   @Override
   public void updateEvaluateContractorRelation(EvaluateContractorRelationDTO dto){
   	    Assert.hasText(dto.getId(), Assert.NULL_PARAM_STR("id")); 
    	
    	EvaluateContractorRelation model = this.evaluateContractorRelationDao.getById(dto.getId());
    	Assert.notNull(model,Assert.EMPTY_REOCRD_STR);
    	
	  	model.setSortNo(dto.getSortNo()); 	  
	  	model.setContractorTypeCode(dto.getContractorTypeCode()); 	  
	  	model.setEvalFormId(dto.getEvalFormId()); 	  
	  	model.setEvalWay(dto.getEvalWay()); 	  
	  	model.setStatus(dto.getStatus()); 	  
	  	model.setCreateBy(dto.getCreateBy()); 	  
	  	model.setUpdateBy(dto.getUpdateBy()); 	  
	  	model.setGmtCreate(dto.getGmtCreate()); 	  
	  	model.setGmtModified(dto.getGmtModified()); 	  
    	    	
    	this.evaluateContractorRelationDao.update(model);
    	
   
    	this.writeInfoLog("Update: "+model.toString());
        
   }
   
   
   
    /**
   	 * 删除
   	 * @param ids
   	 */
   	@Override
    public void deleteEvaluateContractorRelations(String[] ids){
    	for (int i = 0; i < ids.length; i++) {
			this.evaluateContractorRelationDao.deleteById(ids[i]);
			
			
	        this.writeInfoLog("Delete id:" + ids[i]);
	        
		}
    }
   

}
