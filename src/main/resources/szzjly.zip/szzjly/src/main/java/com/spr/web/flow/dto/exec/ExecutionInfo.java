package com.spr.web.flow.dto.exec;

import java.util.Date;

import com.spr.core.common.dto.UUIDDTO;

public class ExecutionInfo extends UUIDDTO {

	private String id;

	private Date gmtModified;

	private String procDefId;

	private String tlNodeId;

	private String dataId;

	private String dataType;

	private String procInstId;

	private String progressText;

	private String nodeName;

	private String nodeCode;

	private String nodeType;

	private String subDefId;

	private String procType;

	private String title;

	private String requirement;

	private String note;

	private Integer limitDay;

	private Short allotStrategy;

	private Date startTime;

	private Short status;

	private Short checkStatus;

	private Short flowStatus;

	@Override
	public String getId() {
		return id;
	}

	@Override
	public void setId(String id) {
		this.id = id;
	}

	@Override
	public Date getGmtModified() {
		return gmtModified;
	}

	@Override
	public void setGmtModified(Date gmtModified) {
		this.gmtModified = gmtModified;
	}

	public String getProcDefId() {
		return procDefId;
	}

	public void setProcDefId(String procDefId) {
		this.procDefId = procDefId;
	}

	public String getTlNodeId() {
		return tlNodeId;
	}

	public void setTlNodeId(String tlNodeId) {
		this.tlNodeId = tlNodeId;
	}

	public String getDataId() {
		return dataId;
	}

	public void setDataId(String dataId) {
		this.dataId = dataId;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public String getProcInstId() {
		return procInstId;
	}

	public void setProcInstId(String procInstId) {
		this.procInstId = procInstId;
	}

	public String getProgressText() {
		return progressText;
	}

	public void setProgressText(String progressText) {
		this.progressText = progressText;
	}

	public String getNodeName() {
		return nodeName;
	}

	public void setNodeName(String nodeName) {
		this.nodeName = nodeName;
	}

	public String getNodeCode() {
		return nodeCode;
	}

	public void setNodeCode(String nodeCode) {
		this.nodeCode = nodeCode;
	}

	public String getNodeType() {
		return nodeType;
	}

	public void setNodeType(String nodeType) {
		this.nodeType = nodeType;
	}

	public String getSubDefId() {
		return subDefId;
	}

	public void setSubDefId(String subDefId) {
		this.subDefId = subDefId;
	}

	public String getProcType() {
		return procType;
	}

	public void setProcType(String procType) {
		this.procType = procType;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getRequirement() {
		return requirement;
	}

	public void setRequirement(String requirement) {
		this.requirement = requirement;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public Integer getLimitDay() {
		return limitDay;
	}

	public void setLimitDay(Integer limitDay) {
		this.limitDay = limitDay;
	}

	public Short getAllotStrategy() {
		return allotStrategy;
	}

	public void setAllotStrategy(Short allotStrategy) {
		this.allotStrategy = allotStrategy;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Short getStatus() {
		return status;
	}

	public void setStatus(Short status) {
		this.status = status;
	}

	public Short getCheckStatus() {
		return checkStatus;
	}

	public void setCheckStatus(Short checkStatus) {
		this.checkStatus = checkStatus;
	}

	public Short getFlowStatus() {
		return flowStatus;
	}

	public void setFlowStatus(Short flowStatus) {
		this.flowStatus = flowStatus;
	}

}