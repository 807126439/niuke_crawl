package com.spr.web.system.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.service.BaseService;
import com.spr.core.common.utils.Assert;
import com.spr.web.system.dao.IContractorTypeDao;
import com.spr.web.system.dto.contractor.ContractorTypeDTO;
import com.spr.web.system.entity.ContractorType;
import com.spr.web.system.service.IContractorTypeService;

@Service("contractorTypeService")
@Transactional
public class ContractorTypeServiceImpl extends BaseService implements IContractorTypeService {

	@Resource
	private IContractorTypeDao contractorTypeDao;
	
	@Override
	public Map<String, String> selectCodeNameMapByCondition(DataQuery dq) {
		dq.assemblePageOffset();
		dq.assembleOrderInfo(ContractorType.class, null);
		List<ContractorTypeDTO> resultlist = this.contractorTypeDao.selectListByCondition(dq.getQueryMap());
		Map<String, String> map = new HashMap<String, String>(resultlist.size());
		for (ContractorTypeDTO dto : resultlist) {
			map.put(dto.getTypeCode(), dto.getTypeName());
		}
		return map;
	}
	
	@Override
	public List<ContractorTypeDTO> selectListByCondition(DataQuery dq) {
		dq.assemblePageOffset();
		dq.assembleOrderInfo(ContractorType.class, null);
		List<ContractorTypeDTO> resultlist = this.contractorTypeDao.selectListByCondition(dq.getQueryMap());
		return resultlist;
	}

	/**
	 * 分页查询
	 * 
	 * @param dq
	 */
	@Override
	public Page<ContractorTypeDTO> searchByPage(DataQuery dq) {

		Long recTotal = this.contractorTypeDao.countByCondition(dq.assemblePageOffset().getQueryMap());
		dq.assembleOrderInfo(ContractorType.class, null);
		List<ContractorTypeDTO> resultlist = this.contractorTypeDao.selectListByCondition(dq.getQueryMap());

		return new Page<ContractorTypeDTO>(dq.getCurrentPage(), dq.getPageSize(), resultlist, recTotal);
	}

	/**
	 * 查询详细
	 * 
	 * @param id
	 */
	@Override
	public ContractorTypeDTO getDetailById(String id) {
		Assert.hasText(id, Assert.NULL_PARAM_STR("id"));

		ContractorTypeDTO result = this.contractorTypeDao.getDetailById(id);
		Assert.notNull(result, Assert.EMPTY_REOCRD_STR);

		return result;
	}

	/**
	 * 添加
	 * 
	 * @param dto
	 */
	@Override
	public void addContractorType(ContractorTypeDTO dto) {

		ContractorType model = new ContractorType();
		model.setSortNo(dto.getSortNo());
		model.setTypeName(dto.getTypeName());
		model.setTypeCode(dto.getTypeCode());
		model.setIsAgent(dto.getIsAgent());
		// model.setStatus(dto.getStatus());
		model.setCreateBy(this.getNowUser().getUsername());
		model.setUpdateBy(this.getNowUser().getUsername());
		model.setGmtCreate(dto.getGmtCreate());
		model.setGmtModified(dto.getGmtModified());

		this.contractorTypeDao.insert(model);

		this.writeInfoLog("Add: " + model.toString());

	}

	/**
	 * 修改
	 * 
	 * @param dto
	 */
	@Override
	public void updateContractorType(ContractorTypeDTO dto) {
		Assert.hasText(dto.getId(), Assert.NULL_PARAM_STR("id"));

		ContractorType model = this.contractorTypeDao.getById(dto.getId());
		Assert.notNull(model, Assert.EMPTY_REOCRD_STR);

		model.setSortNo(dto.getSortNo());
		model.setTypeName(dto.getTypeName());
		model.setTypeCode(dto.getTypeCode());
		model.setIsAgent(dto.getIsAgent());
		// model.setStatus(dto.getStatus());
		// model.setCreateBy(dto.getCreateBy());
		model.setUpdateBy(this.getNowUser().getUsername());
		// model.setGmtCreate(dto.getGmtCreate());
		model.setGmtModified(dto.getGmtModified());

		this.contractorTypeDao.update(model);

		this.writeInfoLog("Update: " + model.toString());

	}

	/**
	 * 删除
	 * 
	 * @param ids
	 */
	@Override
	public void deleteContractorTypes(String[] ids) {
		for (int i = 0; i < ids.length; i++) {
			this.contractorTypeDao.deleteById(ids[i]);

			this.writeInfoLog("Delete id:" + ids[i]);

		}
	}

	@Override
	public List<ContractorTypeDTO> selectList(DataQuery dq) {

		return this.contractorTypeDao.selectListByCondition(dq.getQueryMap());
	}

}
