package com.spr.web.evaluate.dao;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.spr.core.common.dao.IBaseDao;
import com.spr.web.evaluate.dto.record.EvaluateRecordDTO;
import com.spr.web.evaluate.entity.EvaluateRecord;

public interface IEvaluateRecordDao extends IBaseDao<String, EvaluateRecord> {

	Long countByCondition(Map<String, Object> queryMap);

	List<EvaluateRecordDTO> selectListByCondition(Map<String, Object> queryMap);

	EvaluateRecordDTO getDetailById(String id);

	int deleteByCondition(Map<String, Object> queryMap);

	List<EvaluateRecordDTO> selectListByConditionWithExec(Map<String, Object> queryMap);

	Long countByConditionWithExec(Map<String, Object> queryMap);

	List<EvaluateRecordDTO> selectYearListByCondition(Map<String, Object> queryMap);

	Long countYearByCondition(Map<String, Object> queryMap);

	// 统计

	Long countAvgScoreByCondition(Map<String, Object> queryMap);

	List<EvaluateRecordDTO> avgScoreByCondition(Map<String, Object> queryMap);

	List<Map<String, Object>> bestUnitTopK(Map<String, Object> queryMap);

	List<Map<String, Object>> worstUnitTopK(Map<String, Object> queryMap);

	List<Map<String, Object>> yearUnitTopK(Map<String, Object> queryMap);

	List<Map<String, Object>> statUnitAvgScore();

	List<Map<String, Object>> statUnitScoreTime();

	List<Map<String, Object>> statContractorTypeAvgScore();

	List<Map<String, Object>> getExcellentNumOfEngType();

	List<Map<String, Object>> getFailNumOfEngType();

	// 获取季度履约平均分
	BigDecimal getSeasonAvgScore(Map<String, Object> map);

	// 删除本年度履约评价结果
	void deleteYearEvaluateRecord();

	void updateChecked(EvaluateRecord model);

	/**
	 * 判断评价记录是否已经存在
	 * 
	 * @param queryMap
	 * @return
	 */
	Long judgeIfEvaluateRecordExist(Map<String, Object> queryMap);

	/**
	 * 删除合同的综合评价
	 * 
	 * @param partId
	 */
	void deletePartComprehensiveEvaluateRecord(String partId);

	/**
	 * 删除项目的综合评价
	 * 
	 * @param partId
	 */
	void deleteProComprehensiveEvaluateRecord(String proId);

	/**
	 * 删除项目的总合同评价（建设，住建，发改三合一的记录）
	 * 
	 * @param partId
	 */
	void deleteProTotalContractEvaluateRecord(String proId);

}