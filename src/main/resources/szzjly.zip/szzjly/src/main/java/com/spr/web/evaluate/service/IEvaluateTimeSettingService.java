package com.spr.web.evaluate.service;

import java.util.Date;
import java.util.Map;

import com.spr.web.evaluate.dto.time.EvaluateTimeDTO;

public interface IEvaluateTimeSettingService {

	// 判断当前时间是否处于季度评价时间段中
	Boolean isTodayBetweenEvaluateTime();

	// 判断当前时间处于哪个季度评价时间段中
	Map<String, Date> getSeasonEvaluateTime();

	// 获取所有季度评价时间
	EvaluateTimeDTO getEvaluateTime();

	// 设置季度评价时间
	void setEvaluateTime(EvaluateTimeDTO dto);

}
