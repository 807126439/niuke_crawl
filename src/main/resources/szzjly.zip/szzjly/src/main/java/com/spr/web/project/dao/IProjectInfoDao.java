package com.spr.web.project.dao;

import java.util.List;
import java.util.Map;

import com.spr.core.common.dao.IBaseDao;
import com.spr.web.project.dto.project.ProjectInfoDTO;
import com.spr.web.project.entity.ProjectInfo;

public interface IProjectInfoDao extends IBaseDao<String, ProjectInfo> {

	Long countByCondition(Map<String, Object> queryMap);

	List<ProjectInfoDTO> selectListByCondition(Map<String, Object> queryMap);

	ProjectInfoDTO getDetailById(String id);

	ProjectInfoDTO getDetailByProName(String proName);

	List<Map<String, Object>> selectNotEvaluateList(Map<String, Object> queryMap);
}