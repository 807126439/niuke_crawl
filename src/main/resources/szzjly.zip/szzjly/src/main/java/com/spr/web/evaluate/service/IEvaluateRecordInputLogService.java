package com.spr.web.evaluate.service;

import java.util.List;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.web.evaluate.dto.record.EvaluateRecordInputLogDTO;

public interface IEvaluateRecordInputLogService {

	List<EvaluateRecordInputLogDTO> selectListByCondition(DataQuery dq);
	
	 Page<EvaluateRecordInputLogDTO> searchByPage(DataQuery dq);
	
	 EvaluateRecordInputLogDTO getDetailById(String id);
	
	 void addEvaluateRecordInputLog(EvaluateRecordInputLogDTO dto);
	
	 void updateEvaluateRecordInputLog(EvaluateRecordInputLogDTO dto);
	
	 void deleteEvaluateRecordInputLogs(String[] ids);

}
