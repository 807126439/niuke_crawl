package com.spr.web.evaluate.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spr.core.common.bean.AjaxJson;
import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.controller.BaseController;
import com.spr.web.evaluate.dto.appeal.EvaluateAppealDTO;
import com.spr.web.evaluate.dto.appeal.EvaluateAppealFileDTO;
import com.spr.web.evaluate.dto.record.EvaluateRecordDTO;
import com.spr.web.evaluate.service.IEvaluateAppealFileService;
import com.spr.web.evaluate.service.IEvaluateAppealService;
import com.spr.web.evaluate.service.IEvaluateRecordService;
import com.spr.web.file.service.IBaseFileService;

@Controller
@Scope("prototype")
@RequestMapping("/evaluateAppealController")
public class EvaluateAppealController extends BaseController {

	private static final long serialVersionUID = 1L;

	@Resource
	private IEvaluateAppealService evaluateAppealService;
	@Resource
	private IBaseFileService baseFileService;
	@Resource
	private IEvaluateRecordService evaluateRecordService;
	@Resource
	private IEvaluateAppealFileService evaluateAppealFileService;
	
	// 2019.04.22 履约异议
	@RequestMapping("/chatBox")
	public String getPleaChatBox(HttpServletRequest request, DataQuery dq, @RequestParam(value = "evaluateRecordId", required = true) String evaluateRecordId) {
		EvaluateRecordDTO record = this.evaluateRecordService.getDetailById(evaluateRecordId);
		request.setAttribute("record", record);
		request.setAttribute("ucode", this.baseFileService.getUploadCode());
		return "evaluate/evaluateAppeal/chatBox.jsp";
	}

	@RequestMapping(value = "/list", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson list(HttpServletRequest request, DataQuery dq, @RequestParam(value = "evaluateRecordId", required = true) String evaluateRecordId) {
		dq.setNotQueryPage();
		dq.setSidx("gmtCreate");
		dq.setSord("asc");
		
		dq.putToMap("evaluateRecordId", evaluateRecordId);
		List<EvaluateAppealDTO> list = this.evaluateAppealService.selectListByCondition(dq);
		
		// 设置附件
		Map<String, List<EvaluateAppealFileDTO>> map = this.evaluateAppealFileService.selectAppealListMapByRecordId(evaluateRecordId);
		if (map != null && !map.isEmpty()) {
			for (EvaluateAppealDTO dto : list) {
				dto.setFiles(map.get(dto.getId()));
			}			
		}
		return new AjaxJson(this.OPER_SUCCESS_MESSAGE, AjaxJson.success, list);
	}
	
	// ==========

	@RequestMapping(value = "/viewPage", method = { RequestMethod.GET })
	public String viewPage(HttpServletRequest request) {
		this.wrapMenuTitle(request);

		return "evaluate/evaluateAppeal/evaluateAppealList.jsp";
	}

	@RequestMapping(value = "/getPageData", method = { RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> loadPageData(HttpServletRequest request, DataQuery dq) {

		this.wrapTableQueryParams(request, dq);

		Page<EvaluateAppealDTO> pageResult = this.evaluateAppealService.searchByPage(dq);

		return this.handlePageReult(pageResult);
	}

	@RequestMapping(value = "/skipAddEvaluateAppeal")
	public String skipAddEvaluateAppeal(HttpServletRequest request, String evaluateRecordId) {

		request.setAttribute("evaluateRecordId", evaluateRecordId);
		request.setAttribute("ucode", this.baseFileService.getUploadCode());
		request.setAttribute("historyList", this.evaluateAppealService.selectEvaluateAppealAndFileList(evaluateRecordId));
		return "evaluate/evaluateAppeal/addEvaluateAppeal.jsp";
	}

	@RequestMapping(value = "/addEvaluateAppeal", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson addEvaluateAppeal(EvaluateAppealDTO dto) throws Exception {
		this.evaluateAppealService.addEvaluateAppeal(dto);
		return new AjaxJson(this.ADD_SUCCESS_MESSAGE, AjaxJson.success);
	}

	@RequestMapping("/getDetail")
	public String loadDetail(HttpServletRequest request, @RequestParam(value = "id", required = true) String id) {

		EvaluateAppealDTO result = this.evaluateAppealService.getDetailById(id);
		request.setAttribute("model", result);

		return "evaluate/evaluateAppeal/editEvaluateAppeal.jsp";
	}

	@RequestMapping(value = "/editEvaluateAppeal", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson updateEvaluateAppeal(EvaluateAppealDTO dto) {

		this.evaluateAppealService.updateEvaluateAppeal(dto);

		return new AjaxJson(this.EDIT_SUCCESS_MESSAGE, AjaxJson.success);
	}

	@RequestMapping(value = "/deleteEvaluateAppeal", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson deleteEvaluateAppeal(String[] ids) {

		this.evaluateAppealService.deleteEvaluateAppeals(ids);

		return new AjaxJson(this.DEL_SUCCESS_MESSAGE, AjaxJson.success);
	}

}
