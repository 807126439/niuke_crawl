/**
 * 
 */
package com.spr.core.aspect.trace.service;

import com.spr.core.aspect.trace.dto.TraceInfoDTO;


/**
 * @date 2019-4-12
 * @author wanve_java_cjy
 *
 */
public interface ITraceService{
	
	public void add(TraceInfoDTO traceInfoCore);

}
