package com.spr.web.file.dto.baseFile;

public class DownFileDTO {

	
	
}
