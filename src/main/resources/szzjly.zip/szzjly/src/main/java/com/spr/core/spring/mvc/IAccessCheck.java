package com.spr.core.spring.mvc;

public interface IAccessCheck {

	void refreshWhiteDomain();

}
