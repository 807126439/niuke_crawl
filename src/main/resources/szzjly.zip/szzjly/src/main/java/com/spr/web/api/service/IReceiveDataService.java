package com.spr.web.api.service;

public interface IReceiveDataService {

	void receiveProjectData();

}
