package com.spr.web.api.test;

import com.spr.web.api.webservice.ProjdataServiceStub;
import com.spr.web.api.webservice.ProjdataServiceStub.ProcessData;
import com.spr.web.api.webservice.ProjdataServiceStub.ProcessDataE;
import com.spr.web.api.webservice.ProjdataServiceStub.ProcessDataResponse;
import com.spr.web.api.webservice.ProjdataServiceStub.ProcessDataResponseE;

public class Axis2Test {
	
	public static void main(String[] args) {
		try {
//			String reqPacket = "<ReqPacket>" +
//			 		"<Header>" +
//			 		"<requestId>402881ed491324d1014913260a410001</requestId>" +
//			 		"<from>xxxxx</from>" +
//	            	"<instruct>ProjectCodeService.project.getAll</instruct>" +
//	            	"</Header>" +
//	            	"<Content><![CDATA[<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
//	            	"<ProjectCodeServiceRequest>" +
//	            	"<formTemplateFlag>2</formTemplateFlag>" +
//	            	"<formTemplatePageNumber>1</formTemplatePageNumber>" +
//	            	"<formTemplatePageSize>10</formTemplatePageSize>" +
//	            	"</ProjectCodeServiceRequest>" +
//	            	"]]></Content>" +
//	            	"</ReqPacket>";
	          
			//根据项目id查工程
//			String reqPacket = "<ReqPacket>" +
//			 		"<Header>" +
//			 		"<requestId>402881ed491324d1014913260a410001</requestId>" +
//			 		"<from>xxxxx</from>" +
//	            	"<instruct>ProjectCodeService.engineering.getAllByProID</instruct>" +
//	            	"</Header>" +
//	            	"<Content><![CDATA[<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
//	            	"<ProjectCodeServiceRequest>" +
//	            	"<formTemplateProId>8e7ec518-f822-bb4c-964b-99662c669498</formTemplateProId>" +
//	            	"</ProjectCodeServiceRequest>" +
//	            	"]]></Content>" +
//	            	"</ReqPacket>";
			
			//根据区号获取区号下的项目和工程
			String reqPacket = "<ReqPacket>" +
			 		"<Header>" +
			 		"<requestId>402881ed491324d1014913260a410001</requestId>" +
			 		"<from>xxxxx</from>" +
	            	"<instruct>ProjectCodeService.project.getListByDepartment</instruct>" +
	            	"</Header>" +
	            	"<Content><![CDATA[<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
	            	"<ProjectCodeServiceRequest>" +
	            	"<formTemplateFlag>1</formTemplateFlag>" +
	            	"<formTemplateDepartment>440304</formTemplateDepartment>" +
	            	"<formTemplatePageNumber>2</formTemplatePageNumber>" +
	            	"<formTemplatePageSize>30</formTemplatePageSize>" +
	            	"</ProjectCodeServiceRequest>"+
	            	"]]></Content>" +
	            	"</ReqPacket>";
			
			
			
			ProjdataServiceStub stub = new ProjdataServiceStub();
			
			stub._getServiceClient().getOptions().setProperty(org.apache.axis2.Constants.Configuration.DISABLE_SOAP_ACTION, true);
			
			ProcessData processData = new ProcessData();
			processData.setReqPacket(reqPacket);
			
			ProcessDataE processDataE = new ProcessDataE();
			processDataE.setProcessData(processData);
			
			ProcessDataResponseE responseE =stub.processData(processDataE);
			ProcessDataResponse response = responseE.getProcessDataResponse();
			String ret = response.get_return();
			
			System.out.println(ret);
			
//			MyProjdataServiceCallbackHandler call =  new MyProjdataServiceCallbackHandler();
//			
//			stub.startprocessData(processDataE, call);
			
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}



}
