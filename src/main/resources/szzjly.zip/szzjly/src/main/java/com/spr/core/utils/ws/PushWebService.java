package com.spr.core.utils.ws;

import javax.xml.namespace.QName;

import org.apache.axis.client.Call;
import org.apache.axis.client.Service;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

public class PushWebService {

	public static Logger logger = Logger.getLogger(PushWebService.class);

	private static String url="http://www.zhihuigongwu.com/WanveWXServices/SendMessage.asmx";//提供接口的地址  
    private static String soapaction="http://tempuri.org/";   //域名，这是在server定义的  
     
    public static void sendMsg(String useropenid,String describe,String applytime,String applybusiness,String state,String inscribe ){ 
    	if(StringUtils.isBlank(useropenid)){
    		 logger.info("useropenid："+useropenid);
    	}
         /*useropenid = "orQeLxKvUtNRjjp451_InRC7LsfQ";    
         describe = "88888";
         applytime = "2016-10-18"; 
         applybusiness = "查询档案";
         state = "已受理";
         inscribe = "11";*/
        Service service = new Service();  
        try{  
            Call call = (Call)service.createCall();              
            call.setTargetEndpointAddress(url);              
            call.setOperationName(new QName(soapaction,"SengMsg")); //设置要调用哪个方法  
            //call.setOperation("SengMsg");
          
            
            call.addParameter(new QName(soapaction,"useropenid"),  //设置要传递的参数  
                    org.apache.axis.encoding.XMLType.XSD_STRING,                       
                   javax.xml.rpc.ParameterMode.IN); 
            
            call.addParameter(new QName(soapaction,"describe"), //设置要传递的参数  
                    org.apache.axis.encoding.XMLType.XSD_STRING,  	                     
                   javax.xml.rpc.ParameterMode.IN); 
            
            call.addParameter(new QName(soapaction,"applytime"), //设置要传递的参数  
                    org.apache.axis.encoding.XMLType.XSD_STRING,  	                     
                   javax.xml.rpc.ParameterMode.IN); 
            
            call.addParameter(new QName(soapaction,"applybusiness"), //设置要传递的参数              		 
                    org.apache.axis.encoding.XMLType.XSD_STRING,  	                     
                   javax.xml.rpc.ParameterMode.IN); 
            
            call.addParameter(new QName(soapaction,"state"), //设置要传递的参数  
                    org.apache.axis.encoding.XMLType.XSD_STRING,  
                   javax.xml.rpc.ParameterMode.IN); 
            
            call.addParameter(new QName(soapaction,"inscribe"), //设置要传递的参数  
                    org.apache.axis.encoding.XMLType.XSD_STRING,  
                   javax.xml.rpc.ParameterMode.IN); 
            
            
            //call.setReturnType(new QName(soapaction,"SengMsgResult"),String.class); //要返回的数据类型（自定义类型）  
             
            call.setReturnType(org.apache.axis.encoding.XMLType.XSD_STRING);//（标准的类型）  
             
            call.setUseSOAPAction(true);  
            call.setSOAPActionURI("http://tempuri.org/SengMsg");      
                         
            String v= (String) call.invoke(new Object[]{useropenid,describe,applytime,applybusiness,state,inscribe});//调用方法并传递参数          
            System.out.println(v); 
            logger.info("微信推送："+v);
             
        }catch(Exception ex)  {  
       	 ex.printStackTrace();  
        }          
}

    public static void main(String[] args) {
   	     sendMsg(null, null, null, null, null, null);
    	//System.out.println("ll");
	}
	
}
