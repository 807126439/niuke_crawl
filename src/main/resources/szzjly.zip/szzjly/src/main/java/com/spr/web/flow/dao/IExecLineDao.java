package com.spr.web.flow.dao;

import java.util.List;
import java.util.Map;

import com.spr.core.common.dao.IBaseDao;
import com.spr.web.flow.dto.exec.ExecLineDTO;
import com.spr.web.flow.entity.ExecLine;

public interface IExecLineDao extends IBaseDao<String, ExecLine> {

	Long countByCondition(Map<String, Object> queryMap);

	List<ExecLineDTO> selectListByCondition(Map<String, Object> queryMap);

	ExecLineDTO getDetailById(String id);

	int deleteByProcInstId(String procInstId);

}