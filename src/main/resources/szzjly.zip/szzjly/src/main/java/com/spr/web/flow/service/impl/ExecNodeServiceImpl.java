package com.spr.web.flow.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.exception.BusinessException;
import com.spr.core.common.service.BaseService;
import com.spr.core.common.utils.Assert;
import com.spr.core.utils.img.IconPathUtil;
import com.spr.web.evaluate.dto.record.EvaluateRecordDTO;
import com.spr.web.evaluate.service.IEvaluateRecordService;
import com.spr.web.flow.dao.IExecAttachmentDao;
import com.spr.web.flow.dao.IExecCommentDao;
import com.spr.web.flow.dao.IExecIdentitylinkDao;
import com.spr.web.flow.dao.IExecLineDao;
import com.spr.web.flow.dao.IExecNodeDao;
import com.spr.web.flow.dao.IProcDefDao;
import com.spr.web.flow.dao.IProcIdentitylinkDao;
import com.spr.web.flow.dao.IProcLineDao;
import com.spr.web.flow.dao.IProcNodeDao;
import com.spr.web.flow.dto.def.ProcDefDTO;
import com.spr.web.flow.dto.def.ProcIdentitylinkDTO;
import com.spr.web.flow.dto.exec.ExecAttachmentDTO;
import com.spr.web.flow.dto.exec.ExecCommentDTO;
import com.spr.web.flow.dto.exec.ExecIdentitylinkDTO;
import com.spr.web.flow.dto.exec.ExecLineDTO;
import com.spr.web.flow.dto.exec.ExecNodeDTO;
import com.spr.web.flow.entity.ExecAttachment;
import com.spr.web.flow.entity.ExecComment;
import com.spr.web.flow.entity.ExecIdentitylink;
import com.spr.web.flow.entity.ExecLine;
import com.spr.web.flow.entity.ExecNode;
import com.spr.web.flow.entity.ProcLine;
import com.spr.web.flow.entity.ProcNode;
import com.spr.web.flow.service.AdditionOperation;
import com.spr.web.flow.service.IExecCommentService;
import com.spr.web.flow.service.IExecIdentitylinkService;
import com.spr.web.flow.service.IExecNodeService;
import com.spr.web.flow.service.IProcIdentitylinkService;
import com.spr.web.project.dto.project.ProjectInfoDTO;
import com.spr.web.project.service.IProjectInfoService;
import com.spr.web.system.dto.user.WeiUserDTO;

@Service("execNodeService")
@Transactional
public class ExecNodeServiceImpl extends BaseService implements IExecNodeService {

	@Resource
	private IExecNodeDao execNodeDao;
	@Resource
	private IExecLineDao execLineDao;
	@Resource
	private IProcDefDao procDefDao;
	@Resource
	private IProcNodeDao procNodeDao;
	@Resource
	private IProcLineDao procLineDao;
	@Resource
	private IExecIdentitylinkService execIdentitylinkService;
	@Resource
	private IExecIdentitylinkDao execIdentitylinkDao;
	@Resource
	private IExecCommentService execCommentService;
	@Resource
	private IExecCommentDao execCommentDao;
	@Resource
	private IExecAttachmentDao execAttachmentDao;
	@Resource
	private IProcIdentitylinkService procIdentitylinkService;
	@Resource
	private AdditionOperation additionOperation;
	@Resource
	private IEvaluateRecordService evaluateRecordService;
	@Resource
	private IProjectInfoService projectInfoService;
	@Resource
	private IProcIdentitylinkDao procIdentitylinkDao;

	/**
	 * 启动流程
	 * 
	 * @param procCode
	 *            流程码
	 * @param dataId
	 *            申请记录id
	 * @param allotUserIds
	 *            分配用户id--------null,使用流程默认人员
	 * 
	 * @return procInstId 流程实例id
	 */
	@Override
	public String startProcess(String prodId, String dataId, List<String> allotUserIds) {
		// Assert.notEmpty(allotUserIds, "送办负责人不能为空！");

		ProcDefDTO procDef = this.procDefDao.getDetailById(prodId);
		Assert.notNull(procDef, "当前模块未绑定流程！");

		List<ProcNode> nodes = this.procNodeDao.getByProcDefId(procDef.getId());

		Assert.isTrue(!nodes.isEmpty(), "启动流程失败（原因：流程无执行节点）");

		// 检查是否已存在
		if (checkIfExist(dataId)) {
			throw new BusinessException("启动流程失败（原因：该记录已有流程正在执行）");
		}

		List<ProcLine> lines = this.procLineDao.getByProcDefId(procDef.getId());

		List<ExecNode> execNodes = new ArrayList<ExecNode>();
		for (ProcNode node : nodes) {
			execNodes.add(addExecNodeByProcNode(node, dataId, procDef));
		}
		// 项目
		EvaluateRecordDTO record = this.evaluateRecordService.getDetailById(dataId);
		ProjectInfoDTO project = this.projectInfoService.getDetailById(record.getProId());
		ExecNode latestNode = null;
		ExecNode endNode = null;
		ExecLine endLine = null;
		// 项目

		ExecNode startNode = null;
		for (ExecNode execNode : execNodes) {
			// ---------------------------履约评价特殊处理--------
			if (ProcNode.TYPE_END.equals(execNode.getNodeType())) {
				// 代建单位
				if (this.getNowUser().getUnitId().equals(project.getAgentUnitId())) {
					// 新建步骤
					endNode = new ExecNode();
					endNode.setProcDefId(execNode.getProcDefId());
					endNode.setDataId(dataId);
					endNode.setDataType(execNode.getDataType());
					endNode.setProcInstId(execNode.getProcInstId());
					endNode.setNodeType("end");
					endNode.setProcType("build");
					endNode.setTitle("建设单位终审");
					endNode.setStatus((short) 0);
					endNode.setFlowStatus((short) 0);
					endNode.setFlag((short) 1);
					endNode.setCreateBy(this.getNowUserId());

					latestNode = execNode;

					execNode.setNodeType("node");

				}
			}
			// ---------------------------履约评价特殊处理--------
			if (ProcNode.TYPE_START.equals(execNode.getNodeType())) {
				startNode = execNode;
				startNode.setFlowStatus(ExecNode.FLOW_STATUS_HISTORY); // 开始节点在流程开始时候设为已执行状态
				persistenceExecNode(startNode);
			}
		}

		if (endNode != null) {
			execNodes.add(endNode);
		}

		Assert.notNull(startNode, "找不到流程开始节点，操作失败！");

		for (ExecNode execNode : execNodes) {
			if (execNode != startNode) {
				execNode.setProcInstId(startNode.getId());
				persistenceExecNode(execNode);
			}
		}

		List<ExecLine> execLines = new ArrayList<ExecLine>();
		for (ProcLine procLine : lines) {
			execLines.add(addExecLineByProcLine(procLine, startNode.getId(), execNodes));
		}

		if (endNode != null) {
			endLine = new ExecLine();
			endLine.setProcDefId(startNode.getProcDefId());
			endLine.setProcInstId(startNode.getId());
			endLine.setPreNodeId(latestNode.getId());
			endLine.setNextNodeId(endNode.getId());
			endLine.setStatus((short) 1);
			endLine.setCreateBy(this.getNowUserId());
			this.execLineDao.insert(endLine);
			execLines.add(endLine);
		}

		StringBuilder progressText = new StringBuilder();
		// 激活流程开始节点的下一个节点
		for (ExecLine l : execLines) {
			if (!StringUtils.isBlank(l.getPreNodeId())) {

				if (!StringUtils.isBlank(l.getNextNodeId())) {
					ExecNode node = getNodeById(execNodes, l.getNextNodeId());

					progressText.append(node.getTitle()).append(",");

					if (l.getPreNodeId().equals(startNode.getId())) {
						activatetNode(node);
						if (allotUserIds != null) {
							// 去重
							Set<String> idsSet = new HashSet<String>(allotUserIds);
							// 添加下一节点负责人
							for (String userId : idsSet) {
								this.execIdentitylinkService.addExecIdentitylink(new ExecIdentitylinkDTO(node.getProcDefId(), node.getProcInstId(), node
										.getId(), userId));
							}
						}
					}
					if (node.getTlNodeId() != null) {
						List<WeiUserDTO> dutyUserIds = this.procIdentitylinkService.getUsersByNodeId(node.getTlNodeId());
						// 添加下一节点负责人
						if (dutyUserIds != null && dutyUserIds.size() > 0) {
							for (WeiUserDTO user : dutyUserIds) {
								if (user != null)
									this.execIdentitylinkService.addExecIdentitylink(new ExecIdentitylinkDTO(node.getProcDefId(), node.getProcInstId(), node
											.getId(), user.getId()));
							}
						}

					}
				}

			}

		}

		startNode.setProcInstId(startNode.getId());
		// 更新流程进度文本
		if (progressText.length() > 0) {
			progressText.deleteCharAt(progressText.length() - 1);

			startNode.setProgressText(progressText.toString());
		}
		this.execNodeDao.update(startNode);

		return startNode.getId();
	}

	/**
	 * 重启流程，状态全转为未审核
	 * 
	 * @param procCode
	 * @param dataId
	 * @param allotUserIds
	 * @return
	 */
	@Override
	public void restartProcess(String dataId, String auditor) {
		Map<String, Object> queryMap = new HashMap<String, Object>();
		// 查询条件
		queryMap.put("queryDataId", dataId);
		queryMap.put("queryStatus", ExecNode.STATUS_FAIL);
		// 更新条件
		queryMap.put("flowStatus", ExecNode.FLOW_STATUS_STATiC);
		queryMap.put("status", ExecNode.STATUS_STATIC);
		this.execNodeDao.updateAllByCondition(queryMap);

		// 第一节点改为完成，第二节点改为正在执行
		queryMap.clear();
		queryMap.put("dataId", dataId);
		queryMap.put("status", ExecNode.STATUS_STATIC);
		queryMap.put("nodeType", "start");
		ExecNodeDTO startNode = this.execNodeDao.getDetailByCondition(queryMap);
		if (startNode == null) {
			throw new BusinessException("重启错误");
		}
		startNode.setFlowStatus(ExecNode.FLOW_STATUS_HISTORY); // 开始节点在流程开始时候设为已执行状态
		this.updateExecNode(startNode);

		ExecNodeDTO secNode = this.getNextNode(startNode);
		secNode.setFlowStatus(ExecNode.FLOW_STATUS_CURR);
		this.updateExecNode(secNode);
		// 如第二节点审核人没有则设置auditor，auditor必须存在
		queryMap.clear();
		queryMap.put("nodeId", secNode.getId());
		List<ExecIdentitylinkDTO> exIdLinks = this.execIdentitylinkDao.selectListByCondition(queryMap);
		if (exIdLinks == null || exIdLinks.size() == 0) {
			Assert.hasText(auditor, "审核人不能为空");
			this.execIdentitylinkService
					.addExecIdentitylink(new ExecIdentitylinkDTO(secNode.getProcDefId(), secNode.getProcInstId(), secNode.getId(), auditor));
		}
	}

	/**
	 * 添加节点
	 * 
	 * @param node
	 * @param dataId
	 * @return
	 */
	public ExecNode addExecNodeByProcNode(ProcNode node, String dataId, ProcDefDTO procDef) {

		ExecNode model = new ExecNode();
		model.setProcDefId(node.getProcDefId());
		model.setTlNodeId(node.getId());
		model.setDataId(dataId);
		model.setDataType(procDef.getProcessCode());
		// model.setProcInstId(dto.getProcInstId());
		// model.setProgressText(dto.getProgressText());
		model.setNodeName(node.getNodeName());
		model.setNodeCode(node.getNodeCode());
		model.setNodeType(node.getNodeType());
		model.setLeftPos(node.getLeftPos());
		model.setTopPos(node.getTopPos());
		model.setWidth(node.getWidth());
		model.setHeight(node.getHeight());
		model.setSubDefId(node.getSubDefId());
		model.setProcType(node.getProcType());
		model.setTitle(node.getTitle());
		model.setRequirement(node.getRequirement());
		model.setNote(node.getNote());
		model.setLimitDay(node.getLimitDay());
		// model.setDutyDepartId(dto.getDutyDepartId());
		if (StringUtils.isNoneBlank(node.getDutyUserId())) {
			model.setDutyUserId(node.getDutyUserId());
		}
		// model.setDutyUserId(dto.getDutyUserId());
		model.setAllotStrategy(node.getAllotStrategy());
		// model.setStartTime(dto.getStartTime());
		model.setStatus(ExecNode.STATUS_STATIC);
		// model.setCheckStatus(dto.getCheckStatus());
		model.setFlowStatus(ExecNode.FLOW_STATUS_STATiC);
		model.setFlag(ExecNode.DEF_FLAG);
		model.setCreateBy(getNowUser().getUsername());

		return model;
	}

	/**
	 * 持久化节点对象
	 * 
	 * @param model
	 */
	public void persistenceExecNode(ExecNode model) {

		this.execNodeDao.insert(model);

		if (this.logger.isInfoEnabled()) {
			this.logger.info("Add: " + model.toString());
		}

	}

	/**
	 * 添加连线
	 * 
	 * @param line
	 * @param procInstId
	 * @param execNodes
	 */
	private ExecLine addExecLineByProcLine(ProcLine line, String procInstId, List<ExecNode> execNodes) {

		ExecLine model = new ExecLine();
		model.setProcDefId(line.getProcDefId());
		model.setProcInstId(procInstId);
		model.setTlLineId(line.getId());
		model.setLineName(line.getLineName());
		model.setLineType(line.getLineType());
		model.setLineCode(line.getLineCode());
		model.setLineAlt(line.getLineAlt());
		model.setMidPos(line.getMidPos());

		ExecNode preNode = getNodeByTlNodeId(execNodes, line.getPreNodeId());
		ExecNode nextNode = getNodeByTlNodeId(execNodes, line.getNextNodeId());

		model.setPreNodeId(preNode == null ? null : preNode.getId());
		model.setNextNodeId(nextNode == null ? null : nextNode.getId());

		model.setStatus(ExecLine.DEF_STATUS);
		model.setCreateBy(getNowUser().getUsername());

		this.execLineDao.insert(model);

		if (this.logger.isInfoEnabled()) {
			this.logger.info("Add: " + model.toString());
		}

		return model;
	}

	private ExecNode getNodeByTlNodeId(List<ExecNode> nodes, String nodeId) {

		for (ExecNode node : nodes) {
			if (node.getTlNodeId().equals(nodeId)) {
				return node;
			}
		}

		return null;
	}

	private ExecNode getNodeById(List<ExecNode> nodes, String id) {

		for (ExecNode node : nodes) {
			if (node.getId().equals(id)) {
				return node;
			}
		}

		return null;
	}

	/**
	 * 检查该记录是否有正在执行的流程
	 * 
	 * @param dataId
	 * @return
	 */
	private Boolean checkIfExist(String dataId) {
		// 只允许一条记录一个流程
		Map<String, Object> queryMap = new HashMap<String, Object>();
		queryMap.put("dataId", dataId);
		// queryMap.put("status", ExecNode.STATUS_STATIC);
		queryMap.put("nodeType", "start");
		List<ExecNodeDTO> nodes = this.execNodeDao.selectListByCondition(queryMap);
		if (nodes != null && nodes.size() > 0) {
			return true;
		}
		return false;
	}

	/** -------流程启动 - end---------- */

	/**
	 * 查询直线流程图
	 * 
	 * @param procInstId
	 * @return
	 */
	@Override
	public List<ExecNodeDTO> getStraightStructureProccess(String procInstId, String userId) {
		DataQuery dq = new DataQuery();
		dq.setSidx("sort");
		dq.setSord("asc");
		dq.putToMap("procInstId", procInstId);
		List<ExecNodeDTO> nodes = this.execNodeDao.selectListByCondition(dq.getQueryMap());
		List<ExecLineDTO> lines = this.execLineDao.selectListByCondition(dq.getQueryMap());

		// 当前流程节点，直线流程只存在一个
		ExecNodeDTO startNode = null;
		ExecNodeDTO currNode = null;
		for (ExecNodeDTO nd : nodes) {
			if (ExecNode.FLOW_STATUS_CURR == nd.getFlowStatus()) {
				currNode = nd;
			}
			if (nd.getId().equals(procInstId)) {
				startNode = nd;
			}
		}

		if (!StringUtils.isBlank(userId)) {
			dq.clear();
			dq.putToMap("nodeId", currNode.getId()).putToMap("userId", userId);
			Long checkAuth = this.execIdentitylinkDao.countByCondition(dq.getQueryMap());
			if (checkAuth > 0) {
				currNode.setAuthHandle(true);
			}
		}

		List<ExecNodeDTO> resultNodes = new ArrayList<ExecNodeDTO>(nodes.size());

		cycleNextNode(resultNodes, startNode, nodes, lines);

		List<String> nodeIds = new ArrayList<String>(resultNodes.size());
		for (ExecNodeDTO nd : resultNodes) {
			nodeIds.add(nd.getId());
		}

		if (!nodeIds.isEmpty()) {
			dq.clear();
			dq.putToMap("nodeIds", nodeIds);
			dq.setSidx("sort");
			dq.setSord("asc");
			dq.assembleOrderInfo(ExecComment.class, "c");
			List<ExecCommentDTO> coments = this.execCommentDao.selectListByCondition(dq.getQueryMap());
			dq.assembleOrderInfo(ExecAttachment.class, null);
			List<ExecAttachmentDTO> attachment = this.execAttachmentDao.selectListByCondition(dq.getQueryMap());

			for (ExecCommentDTO c : coments) {
				for (ExecNodeDTO nd : resultNodes) {
					if (nd.getId().equals(c.getProcNodeId())) {
						nd.getComments().add(c);
						break;
					}
				}
			}

			for (ExecAttachmentDTO at : attachment) {
				for (ExecNodeDTO nd : resultNodes) {
					if (nd.getId().equals(at.getProcNodeId())) {
						nd.getAttachments().add(at);
						break;
					}
				}

				at.setIconPath(IconPathUtil.getIconPathByfileType(at.getFileType()));
			}

		}

		return resultNodes;
	}

	/**
	 * 根据当前节点向下迭代获取下一个节点
	 * 
	 * @param resultNodes
	 * @param curr
	 * @param nodes
	 * @param lines
	 */
	private void cycleNextNode(List<ExecNodeDTO> resultNodes, ExecNodeDTO curr, List<ExecNodeDTO> nodes, List<ExecLineDTO> lines) {

		ExecNodeDTO nextNode = getNextNode(curr, nodes, lines);
		if (nextNode != null) {
			resultNodes.add(nextNode);
			cycleNextNode(resultNodes, nextNode, nodes, lines);
		}

	}

	/**
	 * 根据当前节点获取上一个节点
	 * 
	 * @param curr
	 * @param nodes
	 * @param lines
	 * @return
	 */
	private ExecNodeDTO getPreNode(ExecNodeDTO curr, List<ExecNodeDTO> nodes, List<ExecLineDTO> lines) {
		for (ExecLineDTO l : lines) {
			if (!StringUtils.isBlank(l.getNextNodeId()) && l.getNextNodeId().equals(curr.getId())) {
				if (!StringUtils.isBlank(l.getPreNodeId())) {
					for (ExecNodeDTO nd : nodes) {
						if (nd.getId().equals(l.getPreNodeId())) {

							return nd;
						}
					}
				}
			}
		}

		return null;
	}

	/**
	 * 根据当前节点获取下一个节点
	 * 
	 * @param curr
	 * @param nodes
	 * @param lines
	 * @return
	 */
	private ExecNodeDTO getNextNode(ExecNodeDTO curr, List<ExecNodeDTO> nodes, List<ExecLineDTO> lines) {
		for (ExecLineDTO l : lines) {
			if (l.getPreNodeId().equals(curr.getId())) {
				for (ExecNodeDTO nd : nodes) {
					if (nd.getId().equals(l.getNextNodeId())) {
						return nd;
					}
				}
			}
		}
		return null;
	}

	/**
	 * 激活流程，从第一步开始激活设第二步为当前状态
	 * 
	 * @param procInstId
	 * @param allotUserIds
	 */
	@Override
	public void activeProcess(String procInstId, List<String> allotUserIds) {
		ExecNode node = this.execNodeDao.getById(procInstId);
		Assert.notNull(node, Assert.EMPTY_REOCRD_STR);

		node.setStatus(ExecNode.FLOW_STATUS_HISTORY);
		node.setGmtModified(new Date());

		List<ExecNode> nextNodes = this.execNodeDao.getNextNodeByPreNodeId(node.getId());

		StringBuilder progressText = new StringBuilder();
		for (ExecNode execNode : nextNodes) {

			// 下一结点为结束节点，整个流程结束-----当前流程？？
			// if (ProcNode.TYPE_END.equals(execNode.getNodeType())) {
			// endProcess(execNode.getProcInstId());
			// activatetNode(execNode);
			// break;
			// }

			progressText.append(execNode.getTitle()).append(",");
			activatetNode(execNode);

			Assert.notEmpty(allotUserIds, Assert.NULL_PARAM_STR("allotUserIds"));

			// 去重
			Set<String> idsSet = new HashSet<String>(allotUserIds);

			DataQuery dq = new DataQuery();
			dq.putToMap("nodeId", execNode.getId());
			// 添加下一节点负责人
			for (String userId : idsSet) {

				// 检查负责人是否已存在，不存在则添加
				dq.putToMap("userId", userId);
				List<ExecIdentitylinkDTO> checkRepeat = this.execIdentitylinkDao.selectListByCondition(dq.getQueryMap());

				if (checkRepeat.isEmpty()) {
					this.execIdentitylinkService.addExecIdentitylink(new ExecIdentitylinkDTO(execNode.getProcDefId(), execNode.getProcInstId(), execNode
							.getId(), userId));
					// 设为待办理状态
				} else {
					for (ExecIdentitylinkDTO lk : checkRepeat) {
						this.execIdentitylinkService.updateExecIdentitylinkStatus(lk.getId(), ExecIdentitylink.PENDINF_STATUS);
					}

				}

			}
		}

		// 更新流程进度文本
		if (progressText.length() > 0) {
			progressText.deleteCharAt(progressText.length() - 1);

			updateProcessText(node.getProcInstId(), progressText.toString());
		}

		this.execNodeDao.update(node);
		if (this.logger.isInfoEnabled()) {
			this.logger.info("Update: " + node.toString());
		}

	}

	/**
	 * 流程节点办理
	 * 
	 * @param nodeId
	 * @param comment
	 */
	@Override
	public void handleSuccessNode(String nodeId, String content, String handlerId, List<String> allotUserIds) {
		Assert.hasText(nodeId, Assert.NULL_PARAM_STR("nodeId"));
		Assert.hasText(content, "办理意见不能为空！");

		ExecNode node = this.execNodeDao.getById(nodeId);
		Assert.isTrue(ExecNode.FLOW_STATUS_CURR == node.getFlowStatus(), "状态有误，办理失败！");

		// 判断其他人是否办理完成
		DataQuery dq = new DataQuery();
		dq.putToMap("nodeId", node.getId());
		List<ExecIdentitylinkDTO> lks = this.execIdentitylinkDao.selectListByCondition(dq.getQueryMap());

		// 如果关联未空则为未指定，可办理
		String ownHandleIlId = null;
		if (lks == null || lks.isEmpty()) {
			// 新建关联
			ExecIdentitylink idLink = this.execIdentitylinkService.addExecIdentitylink(new ExecIdentitylinkDTO(node.getProcDefId(), node.getProcInstId(), node
					.getId(), handlerId));
			ownHandleIlId = idLink.getId();
		} else {
			for (ExecIdentitylinkDTO lk : lks) {
				if (lk.getUserId().equals(handlerId)) {
					ownHandleIlId = lk.getId();
					break;
				}
			}
			Assert.notNull(ownHandleIlId, "抱歉，您无权办理当前业务！");
		}

		// 保存办理意见
		ExecCommentDTO comment = new ExecCommentDTO(node.getProcInstId(), node.getId(), handlerId, ExecComment.TYRP_SUCCESS, content);

		// 保存暂存的修改记录
		if (StringUtils.isNotBlank(node.getNote())) {
			comment.setNote(node.getNote());
			node.setNote("");
		}
		this.execCommentService.addExecComment(comment);

		this.execIdentitylinkService.updateExecIdentitylinkStatus(ownHandleIlId, ExecIdentitylink.SUCCESS_HANDLE_STATUS);

		dq.putToMap("status", ExecComment.TYRP_SUCCESS);
		List<ExecCommentDTO> comemnts = this.execCommentDao.selectListByCondition(dq.getQueryMap());

		boolean isFinish = true;

		for (ExecIdentitylinkDTO lk : lks) {
			if (!containUserId(comemnts, lk.getUserId())) {
				isFinish = false;
			}
		}

		// 激活下一节点
		if (isFinish) {
			node.setFlowStatus(ExecNode.FLOW_STATUS_HISTORY);
			node.setGmtModified(new Date());

			List<ExecNode> nextNodes = this.execNodeDao.getNextNodeByPreNodeId(node.getId());

			StringBuilder progressText = new StringBuilder();
			for (ExecNode execNode : nextNodes) {

				progressText.append(execNode.getTitle()).append(",");

				// 下一结点为结束节点，整个流程结束
				// if (ProcNode.TYPE_END.equals(execNode.getNodeType())) {
				// endProcess(execNode.getProcInstId());
				// activatetNode(execNode);
				// break;
				// }

				activatetNode(execNode);

				Assert.notEmpty(allotUserIds, "下一步审核人员不能为空");

				// 去重
				Set<String> idsSet = new HashSet<String>(allotUserIds);

				dq.clear();
				dq.putToMap("nodeId", execNode.getId());
				// 添加下一节点负责人
				for (String userId : idsSet) {

					// 检查负责人是否已存在，不存在则添加
					dq.putToMap("userId", userId);
					List<ExecIdentitylinkDTO> checkRepeat = this.execIdentitylinkDao.selectListByCondition(dq.getQueryMap());

					if (checkRepeat.isEmpty()) {
						this.execIdentitylinkService.addExecIdentitylink(new ExecIdentitylinkDTO(execNode.getProcDefId(), execNode.getProcInstId(), execNode
								.getId(), userId));
						// 设为待办理状态
					} else {
						for (ExecIdentitylinkDTO lk : checkRepeat) {
							this.execIdentitylinkService.updateExecIdentitylinkStatus(lk.getId(), ExecIdentitylink.PENDINF_STATUS);
						}

					}

				}
			}

			// 更新流程进度文本
			if (progressText.length() > 0) {
				progressText.deleteCharAt(progressText.length() - 1);

				updateProcessText(node.getProcInstId(), progressText.toString());
			}

			this.execNodeDao.update(node);
			if (this.logger.isInfoEnabled()) {
				this.logger.info("Update: " + node.toString());
			}

			// 如果当前节点为完结节点则执行自定义完结操作
			if (ProcNode.TYPE_END.equals(node.getNodeType())) {
				this.additionOperation.processEnd(node.getDataId());
			}

		}

	}

	/**
	 * 结束流程
	 * 
	 * @param procInstId
	 */
	private void endProcess(String procInstId) {
		ExecNode node = this.execNodeDao.getById(procInstId);
		if (node != null) {
			node.setStatus(ExecNode.STATUS_FINISH);
			node.setGmtModified(new Date());

			this.execNodeDao.update(node);

			if (this.logger.isInfoEnabled()) {
				this.logger.info("Update: " + node.toString());
			}
			additionOperation.processEnd(node.getDataId());
		}
	}

	/**
	 * 更新流程进度文本
	 * 
	 * @param procInstId
	 * @param text
	 */
	private void updateProcessText(String procInstId, String text) {
		ExecNode node = this.execNodeDao.getById(procInstId);
		if (node != null) {
			node.setProgressText(text);
			node.setGmtModified(new Date());

			this.execNodeDao.update(node);

			if (this.logger.isInfoEnabled()) {
				this.logger.info("Update: " + node.toString());
			}
		}
	}

	/**
	 * 办理失败，退回到上一步
	 * 
	 * @param nodeId
	 * @param content
	 */
	@Override
	public void handleFailNode(String nodeId, String handlerId, String content) {
		Assert.hasText(nodeId, Assert.NULL_PARAM_STR("nodeId"));
		Assert.hasText(content, "办理意见不能为空！");

		ExecNode node = this.execNodeDao.getById(nodeId);
		Assert.isTrue(ExecNode.FLOW_STATUS_CURR == node.getFlowStatus(), "状态有误，办理失败！");

		// 保存办理意见
		ExecCommentDTO comment = new ExecCommentDTO(node.getProcInstId(), node.getId(), handlerId, ExecComment.TYRP_FAIL, content);
		// 保存暂存的修改记录
		if (StringUtils.isNotBlank(node.getNote())) {
			comment.setNote(node.getNote());
			node.setNote("");
		}
		this.execCommentService.addExecComment(comment);

		DataQuery dq = new DataQuery();
		dq.putToMap("nodeId", node.getId());
		dq.putToMap("userId", handlerId);
		List<ExecIdentitylinkDTO> lks = this.execIdentitylinkDao.selectListByCondition(dq.getQueryMap());

		for (ExecIdentitylinkDTO ik : lks) {
			this.execIdentitylinkService.updateExecIdentitylinkStatus(ik.getId(), ExecIdentitylink.FAIL_HANDLE_STATUS);
		}

		// 退回到上一节点
		node.setFlowStatus(ExecNode.FLOW_STATUS_BACK);
		node.setGmtModified(new Date());

		// 删除审核人，重置为模板值
		Map<String, Object> queryMap = new HashMap<String, Object>();
		queryMap.put("nodeId", node.getId());
		List<ExecIdentitylinkDTO> exdto = this.execIdentitylinkDao.selectListByCondition(queryMap);
		queryMap.clear();
		if (exdto != null && exdto.size() != 0) {
			for (ExecIdentitylinkDTO exidl : exdto) {
				this.execIdentitylinkDao.deleteById(exidl.getId());
			}
		}
		if (StringUtils.isNotBlank(node.getTlNodeId())) {
			queryMap.put("nodeId", node.getTlNodeId());
			List<ProcIdentitylinkDTO> procIdLinks = this.procIdentitylinkDao.selectListByCondition(queryMap);
			// 判断
			if (procIdLinks != null && procIdLinks.size() > 0) {
				// 重新设置审核人
				this.execIdentitylinkService.addExecIdentitylink(new ExecIdentitylinkDTO(node.getProcDefId(), node.getProcInstId(), node.getId(), procIdLinks
						.get(0).getUserId()));
			}
		}

		StringBuilder progressText = new StringBuilder();
		List<ExecNode> preNodes = this.execNodeDao.getPreNodeByNextNodeId(node.getId());
		for (ExecNode execNode : preNodes) {

			// 上一结点为开始节点，回退整个流程
			if (ProcNode.TYPE_START.equals(execNode.getNodeType())) {
				backProcess(execNode.getDataId(), execNode.getDataType(), execNode.getProcInstId());
				return;
			}

			activatetNode(execNode);

			// 上一步办理人员设为待办理状态
			this.execIdentitylinkDao.updateStatusByNodeId(ExecIdentitylink.PENDINF_STATUS, execNode.getId());

			progressText.append(execNode.getTitle()).append(",");
		}

		// 更新流程进度文本
		if (progressText.length() > 0) {
			progressText.deleteCharAt(progressText.length() - 1);

			updateProcessText(node.getProcInstId(), progressText.toString());
		}

		this.execNodeDao.update(node);
		if (this.logger.isInfoEnabled()) {
			this.logger.info("Update: " + node.toString());
		}

	}

	/**
	 * 迭代评论集合检查是否包含指定用户的评论
	 * 
	 * @param comemnts
	 * @param userId
	 * @return
	 */
	private boolean containUserId(List<ExecCommentDTO> comemnts, String userId) {
		for (ExecCommentDTO cm : comemnts) {
			if (cm.getUserId().equals(userId)) {
				return true;
			}
		}

		return false;
	}

	/**
	 * 回退整个流程，找到对应申请记录修改状态
	 * 
	 * @param procInstId
	 */
	private void backProcess(String dataId, String dataType, String procInstId) {
		// 流程失败相关操作
		Map<String, Object> queryMap = new HashMap<String, Object>();
		// 查询条件
		queryMap.put("queryProcInstId", procInstId);
		// 更新条件
		queryMap.put("flowStatus", ExecNode.FLOW_STATUS_FAIL);
		queryMap.put("status", ExecNode.STATUS_FAIL);
		this.execNodeDao.updateAllByCondition(queryMap);

		// 审核人重置为模板要求
		// 获取模板设置与现有设置进行比对，不存在则删除
		// 仅适用审核人唯一情况
		queryMap.clear();
		queryMap.put("procInstId", procInstId);
		List<ExecIdentitylinkDTO> exIdLinks = this.execIdentitylinkDao.selectListByCondition(queryMap);

		if (exIdLinks != null && exIdLinks.size() > 0) {
			// 模板审核人
			queryMap.clear();
			queryMap.put("procDefId", exIdLinks.get(0).getProcDefId());
			List<ProcIdentitylinkDTO> procIdLinks = this.procIdentitylinkDao.selectListByCondition(queryMap);
			// 执行节点为桥梁
			queryMap.clear();
			queryMap.put("procInstId", procInstId);
			List<ExecNodeDTO> execnodes = this.execNodeDao.selectListByCondition(queryMap);

			for (ExecIdentitylinkDTO ei : exIdLinks) {
				for (ExecNodeDTO exNode : execnodes) {
					if (ei.getNodeId().equals(exNode.getId())) {
						String procNodeId = exNode.getTlNodeId();
						// 是否模板中存在
						boolean exists = false;
						for (ProcIdentitylinkDTO pi : procIdLinks) {
							if (procNodeId.equals(pi.getNodeId())) {
								exists = true;
								break;
							}
						}
						if (!exists) {
							// 删除上次审核人权限
							this.execIdentitylinkDao.deleteById(ei.getId());
						}
						break;
					}
				}
			}
		}

		// 失败自定义操作
		this.additionOperation.processFail(dataId);
	}

	/**
	 * 激活节点
	 */
	private void activatetNode(ExecNode node) {

		node.setFlowStatus(ExecNode.FLOW_STATUS_CURR);
		node.setGmtModified(new Date());

		this.execNodeDao.update(node);
		if (this.logger.isInfoEnabled()) {
			this.logger.info("Update: " + node.toString());
		}
	}

	/**
	 * 恢复节点
	 * 
	 * @param node
	 */
	private void recoverNode(ExecNode node) {

		node.setFlowStatus(ExecNode.FLOW_STATUS_STATiC);
		node.setGmtModified(new Date());

		this.execNodeDao.update(node);
		if (this.logger.isInfoEnabled()) {
			this.logger.info("Update: " + node.toString());
		}
	}

	/**
	 * 删除流程的所有的数据
	 * 
	 * @param procInstId
	 */
	@Override
	public void deleteProcessByProcInstId(String procInstId) {

		if (!StringUtils.isBlank(procInstId)) {
			// 删除办理意见
			this.execCommentDao.deleteByProcInstId(procInstId);

			// 删除附件，未删除物理文件
			this.execAttachmentDao.deleteByProcInstId(procInstId);

			// 删除办理负责人
			this.execIdentitylinkDao.deleteByProcInstId(procInstId);

			// 删除流程结构数据
			this.execLineDao.deleteByProcInstId(procInstId);

			this.execLineDao.deleteByProcInstId(procInstId);

		}

	}

	/**
	 * 通过dataId删除
	 */
	@Override
	public void deleteProcessByDataId(String dataId) {
		ExecNodeDTO currNode = this.getCurrNodeByDateId(dataId);
		if (currNode != null) {
			this.deleteProcessByProcInstId(currNode.getProcInstId());
		}

	}

	/**
	 * 分页查询
	 * 
	 * @param dq
	 */
	@Override
	public Page<ExecNodeDTO> searchByPage(DataQuery dq) {

		Long recTotal = this.execNodeDao.countByCondition(dq.assemblePageOffset().getQueryMap());
		dq.assembleOrderInfo(ExecNode.class, null);
		List<ExecNodeDTO> resultlist = this.execNodeDao.selectListByCondition(dq.getQueryMap());

		return new Page<ExecNodeDTO>(dq.getCurrentPage(), dq.getPageSize(), resultlist, recTotal);
	}

	/**
	 * 查询详细
	 * 
	 * @param id
	 */
	@Override
	public ExecNodeDTO getDetailById(String id) {
		Assert.hasText(id, Assert.NULL_PARAM_STR("id"));

		ExecNodeDTO result = this.execNodeDao.getDetailById(id);
		Assert.notNull(result, Assert.EMPTY_REOCRD_STR);

		return result;
	}

	/**
	 * 添加
	 * 
	 * @param dto
	 */
	@Override
	public void addExecNode(ExecNodeDTO dto) {

		ExecNode model = new ExecNode();
		model.setProcDefId(dto.getProcDefId());
		model.setDataId(dto.getDataId());
		model.setDataType(dto.getDataType());
		model.setProcInstId(dto.getProcInstId());
		model.setProgressText(dto.getProgressText());
		model.setNodeName(dto.getNodeName());
		model.setNodeCode(dto.getNodeCode());
		model.setNodeType(dto.getNodeType());
		model.setLeftPos(dto.getLeftPos());
		model.setTopPos(dto.getTopPos());
		model.setWidth(dto.getWidth());
		model.setHeight(dto.getHeight());
		model.setSubDefId(dto.getSubDefId());
		model.setProcType(dto.getProcType());
		model.setTitle(dto.getTitle());
		model.setRequirement(dto.getRequirement());
		model.setNote(dto.getNote());
		model.setLimitDay(dto.getLimitDay());
		model.setDutyDepartId(dto.getDutyDepartId());
		model.setDutyUserId(dto.getDutyUserId());
		model.setAllotStrategy(dto.getAllotStrategy());
		model.setStartTime(dto.getStartTime());
		model.setStatus(dto.getStatus());
		model.setCheckStatus(dto.getCheckStatus());
		model.setFlowStatus(dto.getFlowStatus());
		model.setFlag(dto.getFlag());
		model.setCreateBy(dto.getCreateBy());
		model.setUpdateBy(dto.getUpdateBy());
		model.setGmtCreate(dto.getGmtCreate());
		model.setGmtModified(dto.getGmtModified());

		this.execNodeDao.insert(model);

		if (this.logger.isInfoEnabled()) {
			this.logger.info("Add: " + model.toString());
		}
	}

	/**
	 * 修改
	 * 
	 * @param dto
	 */
	@Override
	public void updateExecNode(ExecNodeDTO dto) {
		Assert.hasText(dto.getId(), Assert.NULL_PARAM_STR("id"));

		ExecNode model = this.execNodeDao.getById(dto.getId());
		Assert.notNull(model, Assert.EMPTY_REOCRD_STR);

		model.setProcDefId(dto.getProcDefId());
		model.setDataId(dto.getDataId());
		model.setDataType(dto.getDataType());
		model.setProcInstId(dto.getProcInstId());
		model.setProgressText(dto.getProgressText());
		model.setNodeName(dto.getNodeName());
		model.setNodeCode(dto.getNodeCode());
		model.setNodeType(dto.getNodeType());
		model.setLeftPos(dto.getLeftPos());
		model.setTopPos(dto.getTopPos());
		model.setWidth(dto.getWidth());
		model.setHeight(dto.getHeight());
		model.setSubDefId(dto.getSubDefId());
		model.setProcType(dto.getProcType());
		model.setTitle(dto.getTitle());
		model.setRequirement(dto.getRequirement());
		model.setNote(dto.getNote());
		model.setLimitDay(dto.getLimitDay());
		model.setDutyDepartId(dto.getDutyDepartId());
		model.setDutyUserId(dto.getDutyUserId());
		model.setAllotStrategy(dto.getAllotStrategy());
		model.setStartTime(dto.getStartTime());
		model.setStatus(dto.getStatus());
		model.setCheckStatus(dto.getCheckStatus());
		model.setFlowStatus(dto.getFlowStatus());
		model.setFlag(dto.getFlag());
		model.setCreateBy(dto.getCreateBy());
		model.setUpdateBy(dto.getUpdateBy());
		model.setGmtCreate(dto.getGmtCreate());
		model.setGmtModified(dto.getGmtModified());

		this.execNodeDao.update(model);

		if (this.logger.isInfoEnabled()) {
			this.logger.info("Update: " + model.toString());
		}
	}

	/**
	 * 删除
	 * 
	 * @param ids
	 */
	@Override
	public void deleteExecNodes(String[] ids) {
		for (int i = 0; i < ids.length; i++) {
			this.execNodeDao.deleteById(ids[i]);

			if (this.logger.isInfoEnabled()) {
				this.logger.info("Delete：:" + ids[i]);
			}
		}
	}

	/**
	 * 根据Dateid获取当前执行的节点
	 */
	@Override
	public ExecNodeDTO getCurrNodeByDateId(String id) {
		Map<String, Object> queryMap = new HashMap<String, Object>();
		queryMap.put("dataId", id);
		queryMap.put("flowStatus", ExecNode.FLOW_STATUS_CURR);
		ExecNodeDTO curr = this.execNodeDao.getDetailByCondition(queryMap);
		// 为空则返回已完成的最后节点
		if (curr == null) {
			queryMap.put("dataId", id);
			queryMap.put("flowStatus", ExecNode.FLOW_STATUS_HISTORY);
			queryMap.put("nodeType", "end");
			ExecNodeDTO end = this.execNodeDao.getDetailByCondition(queryMap);
			if (end == null) {
				// 仍为空搜索返回失败流程第一节点
				queryMap.put("dataId", id);
				queryMap.put("flowStatus", ExecNode.FLOW_STATUS_FAIL);
				queryMap.put("nodeType", "start");
				ExecNodeDTO fail = this.execNodeDao.getDetailByCondition(queryMap);
				return fail;
			}
			return end;
		}
		return curr;
	}

	/**
	 * 获取下一节点
	 */
	@Override
	public ExecNodeDTO getNextNode(ExecNodeDTO currNode) {

		DataQuery dq = new DataQuery();
		dq.setSidx("sort");
		dq.setSord("asc");
		dq.putToMap("procInstId", currNode.getProcInstId());
		List<ExecNodeDTO> nodes = this.execNodeDao.selectListByCondition(dq.getQueryMap());
		List<ExecLineDTO> lines = this.execLineDao.selectListByCondition(dq.getQueryMap());

		return this.getNextNode(currNode, nodes, lines);
	}

	/**
	 * 暂存变更信息，在节点变化时进行处理
	 * 
	 * @param nodeId
	 *            流程节点ID
	 * @param note
	 *            内容
	 */
	@Override
	public void saveRecord(String nodeId, String note) {
		Assert.hasText(nodeId);

		ExecNodeDTO node = this.execNodeDao.getDetailById(nodeId);

		Assert.notNull(node);

		ExecNode nodeEntity = new ExecNode();
		nodeEntity.setId(node.getId());
		nodeEntity.setNote((node.getNote() == null ? "; " : node.getNote()) + note);

		this.execNodeDao.updateSelective(nodeEntity);

	}
}
