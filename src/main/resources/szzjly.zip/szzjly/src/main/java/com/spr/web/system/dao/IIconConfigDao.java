package com.spr.web.system.dao;

import java.util.List;
import java.util.Map;

import com.spr.core.common.dao.IBaseDao;
import com.spr.web.system.dto.iconConfig.IconConfigDTO;
import com.spr.web.system.entity.IconConfig;

public interface IIconConfigDao extends IBaseDao<String, IconConfig> {

	Long countByCondition(Map<String, Object> queryMap);

	List<IconConfigDTO> selectListByCondition(Map<String, Object> queryMap);

}