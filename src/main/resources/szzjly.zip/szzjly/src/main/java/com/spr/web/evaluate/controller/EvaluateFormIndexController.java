package com.spr.web.evaluate.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spr.core.common.bean.AjaxJson;
import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.controller.BaseController;
import com.spr.web.evaluate.dto.form.EvaluateFormIndexDTO;
import com.spr.web.evaluate.service.IEvaluateFormIndexService;
import com.spr.web.evaluate.service.IEvaluateFormService;

@Controller
@Scope("prototype")
@RequestMapping("/evaluateFormIndexController")
public class EvaluateFormIndexController extends BaseController {

	private static final long serialVersionUID = 1L;

	@Resource
	private IEvaluateFormService evaluateFormService;
	@Resource
	private IEvaluateFormIndexService evaluateFormIndexService;

	/**
	 * 树页面
	 * 
	 * @param request
	 * @param formId
	 * @return
	 */
	@RequestMapping(value = "/viewIndexTree")
	public String viewIndexTree(HttpServletRequest request, @RequestParam(value = "formId") String formId) {
		request.setAttribute("formId", formId);
		request.setAttribute("titleId", this.evaluateFormIndexService.getTitleByParentId(formId).getId());
		request.setAttribute("formName", this.evaluateFormService.getDetailById(formId).getFormName());
		return "evaluate/evaluateFormIndex/evaluateFormIndexTree.jsp";
	}

	@RequestMapping(value = "/getEvaluateFormIndexTreeData", method = { RequestMethod.POST })
	@ResponseBody
	public List<EvaluateFormIndexDTO> getEvaluateFormIndexTreeData(String parentId, Boolean isFormId) {
		return this.evaluateFormIndexService.getEvaluateFormIndexTreeData(parentId, isFormId);
	}

	@RequestMapping(value = "/viewPage/{level}/{formId}", method = { RequestMethod.GET })
	public String viewPageWithFormId(HttpServletRequest request, DataQuery dq, @PathVariable int level, @PathVariable String formId) {
		this.wrapMenuTitle(request);

		dq.putToMap("parentId", formId);
		EvaluateFormIndexDTO dto = this.evaluateFormIndexService.selectOneByCondition(dq);
		request.setAttribute("level", level);
		request.setAttribute("titleId", dto.getId());
		request.setAttribute("parentId", dto.getId());
		
		request.setAttribute("title", dto);
		return "evaluate/evaluateFormIndex/evaluateFormIndexList.jsp";
	}

	@RequestMapping(value = "/viewPage/{level}/{titleId}/{parentId}", method = { RequestMethod.GET })
	public String viewPage(HttpServletRequest request, @PathVariable int level, @PathVariable String titleId, @PathVariable String parentId) {
		this.wrapMenuTitle(request);

		request.setAttribute("level", level);
		request.setAttribute("titleId", titleId);
		request.setAttribute("parentId", parentId);
		
		request.setAttribute("title", this.evaluateFormIndexService.getDetailById(titleId));
		return "evaluate/evaluateFormIndex/evaluateFormIndexList.jsp";
	}

	@RequestMapping(value = "/getPageData", method = { RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> loadPageData(HttpServletRequest request, DataQuery dq, String indexName, String parentId) {

		this.wrapTableQueryParams(request, dq);

		dq.putToMap("parentId", parentId);
		dq.putToMap("likeIndexName", StringUtils.isBlank(indexName) ? null : "%" + indexName + "%");
		Page<EvaluateFormIndexDTO> pageResult = this.evaluateFormIndexService.searchByPage(dq);

		return this.handlePageReult(pageResult);
	}

	@RequestMapping(value = "/skipAddEvaluateFormIndex/{level}/{titleId}/{parentId}")
	public String skipAddEvaluateFormIndexWithParentId(HttpServletRequest request, @PathVariable int level, @PathVariable String titleId,
			@PathVariable String parentId) {
		EvaluateFormIndexDTO title = this.evaluateFormIndexService.getDetailById(titleId);
		request.setAttribute("title", title);

		EvaluateFormIndexDTO dto = new EvaluateFormIndexDTO();
		dto.setParentId(parentId);
		dto.setLevel(level);
		request.setAttribute("model", dto);
		return "evaluate/evaluateFormIndex/addEvaluateFormIndex.jsp";
	}

	@RequestMapping(value = "/skipAddEvaluateFormIndex")
	public String skipAddEvaluateFormIndex(HttpServletRequest request) {

		return "evaluate/evaluateFormIndex/addEvaluateFormIndex.jsp";
	}

	@RequestMapping(value = "/addEvaluateFormIndex", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson addEvaluateFormIndex(EvaluateFormIndexDTO dto) throws Exception {

		this.evaluateFormIndexService.addEvaluateFormIndex(dto);

		return new AjaxJson(this.ADD_SUCCESS_MESSAGE, AjaxJson.success);
	}

	@RequestMapping("/getDetail")
	public String loadDetail(HttpServletRequest request, @RequestParam(value = "id", required = true) String id,
			@RequestParam(value = "titleId", required = true) String titleId, @RequestParam(value = "level", required = true) int level) {
		EvaluateFormIndexDTO title = this.evaluateFormIndexService.getDetailById(titleId);
		request.setAttribute("title", title);

		EvaluateFormIndexDTO result = this.evaluateFormIndexService.getDetailById(id);
		result.setLevel(level);
		request.setAttribute("model", result);
		return "evaluate/evaluateFormIndex/editEvaluateFormIndex.jsp";
	}

	@RequestMapping(value = "/editEvaluateFormIndex", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson updateEvaluateFormIndex(EvaluateFormIndexDTO dto) {

		this.evaluateFormIndexService.updateEvaluateFormIndex(dto);

		return new AjaxJson(this.EDIT_SUCCESS_MESSAGE, AjaxJson.success);
	}

	@RequestMapping(value = "/deleteEvaluateFormIndex", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson deleteEvaluateFormIndex(String[] ids) {

		this.evaluateFormIndexService.deleteEvaluateFormIndexs(ids);

		return new AjaxJson(this.DEL_SUCCESS_MESSAGE, AjaxJson.success);
	}

	// 异步加载评分指标
	@RequestMapping(value = "/getIndex", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson getIndex(DataQuery dq, @RequestParam String parentId) {
		List<EvaluateFormIndexDTO> list = this.evaluateFormIndexService.getSubIndexList(dq, parentId);
		return new AjaxJson("加载完成", AjaxJson.success, list);
	}

}
