package com.spr.web.flow.entity;

import java.io.Serializable;

import com.spr.core.annotations.DbField;
import com.spr.core.common.entity.UUIDEntity;

public class ExecAttachment extends UUIDEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final short DEF_STATUS = 1;

	private String procInstId;

	private String procNodeId;

	private String userId;

	private String fileName;

	private Short type;

	private String fileType;

	private Long baseFileId;

	private String fileView;

	private String backFileView;

	private Short status;

	private String createBy;

	private String updateBy;

	@DbField(name = "proc_inst_id")
	public String getProcInstId() {
		return procInstId;
	}

	public void setProcInstId(String procInstId) {
		this.procInstId = procInstId == null ? null : procInstId.trim();
	}

	@DbField(name = "proc_node_id")
	public String getProcNodeId() {
		return procNodeId;
	}

	public void setProcNodeId(String procNodeId) {
		this.procNodeId = procNodeId == null ? null : procNodeId.trim();
	}

	@DbField(name = "user_id")
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId == null ? null : userId.trim();
	}

	@DbField(name = "file_name")
	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName == null ? null : fileName.trim();
	}

	@DbField(name = "type")
	public Short getType() {
		return type;
	}

	public void setType(Short type) {
		this.type = type;
	}

	@DbField(name = "file_type")
	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType == null ? null : fileType.trim();
	}

	@DbField(name = "base_file_id")
	public Long getBaseFileId() {
		return baseFileId;
	}

	public void setBaseFileId(Long baseFileId) {
		this.baseFileId = baseFileId;
	}

	@DbField(name = "file_view")
	public String getFileView() {
		return fileView;
	}

	public void setFileView(String fileView) {
		this.fileView = fileView == null ? null : fileView.trim();
	}

	@DbField(name = "back_file_view")
	public String getBackFileView() {
		return backFileView;
	}

	public void setBackFileView(String backFileView) {
		this.backFileView = backFileView == null ? null : backFileView.trim();
	}

	@DbField(name = "status")
	public Short getStatus() {
		return status;
	}

	public void setStatus(Short status) {
		this.status = status;
	}

	@DbField(name = "create_by")
	public String getCreateBy() {
		return createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy == null ? null : createBy.trim();
	}

	@DbField(name = "update_by")
	public String getUpdateBy() {
		return updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy == null ? null : updateBy.trim();
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode());
		sb.append(",Super = ").append(super.toString());
		sb.append(", serialVersionUID=").append(serialVersionUID);
		sb.append(", procInstId=").append(procInstId);
		sb.append(", procNodeId=").append(procNodeId);
		sb.append(", userId=").append(userId);
		sb.append(", fileName=").append(fileName);
		sb.append(", type=").append(type);
		sb.append(", fileType=").append(fileType);
		sb.append(", baseFileId=").append(baseFileId);
		sb.append(", fileView=").append(fileView);
		sb.append(", backFileView=").append(backFileView);
		sb.append(", status=").append(status);
		sb.append(", createBy=").append(createBy);
		sb.append(", updateBy=").append(updateBy);
		sb.append("]");
		return sb.toString();
	}
}