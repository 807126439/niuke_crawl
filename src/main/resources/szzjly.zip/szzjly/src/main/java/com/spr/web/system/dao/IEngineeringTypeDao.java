package com.spr.web.system.dao;

import com.spr.core.common.dao.IBaseDao;
import com.spr.web.system.dto.engineering.EngineeringTypeDTO;
import com.spr.web.system.entity.EngineeringType;
import java.util.List;
import java.util.Map;

public interface IEngineeringTypeDao extends IBaseDao<String, EngineeringType> {

    Long countByCondition(Map<String, Object> queryMap);

    List<EngineeringTypeDTO> selectListByCondition(Map<String, Object> queryMap);

    EngineeringTypeDTO getDetailById(String id);
}