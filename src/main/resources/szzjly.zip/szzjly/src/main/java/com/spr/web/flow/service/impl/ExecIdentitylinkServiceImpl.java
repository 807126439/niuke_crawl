package com.spr.web.flow.service.impl;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.service.BaseService;
import com.spr.core.common.utils.Assert;
import com.spr.web.flow.dao.IExecIdentitylinkDao;
import com.spr.web.flow.dto.exec.ExecIdentitylinkDTO;
import com.spr.web.flow.entity.ExecIdentitylink;
import com.spr.web.flow.service.IExecIdentitylinkService;
import com.spr.web.system.dto.user.WeiUserDTO;

@Service("execIdentitylinkService")
@Transactional
public class ExecIdentitylinkServiceImpl extends BaseService implements IExecIdentitylinkService {

	@Resource
	private IExecIdentitylinkDao execIdentitylinkDao;

	/**
	 * 分页查询
	 * 
	 * @param dq
	 */
	@Override
	public Page<ExecIdentitylinkDTO> searchByPage(DataQuery dq) {

		Long recTotal = this.execIdentitylinkDao.countByCondition(dq.assemblePageOffset().getQueryMap());
		dq.assembleOrderInfo(ExecIdentitylink.class, null);
		List<ExecIdentitylinkDTO> resultlist = this.execIdentitylinkDao.selectListByCondition(dq.getQueryMap());

		return new Page<ExecIdentitylinkDTO>(dq.getCurrentPage(), dq.getPageSize(), resultlist, recTotal);
	}

	/**
	 * 查询详细
	 * 
	 * @param id
	 */
	@Override
	public ExecIdentitylinkDTO getDetailById(String id) {
		Assert.hasText(id, Assert.NULL_PARAM_STR("id"));

		ExecIdentitylinkDTO result = this.execIdentitylinkDao.getDetailById(id);
		Assert.notNull(result, Assert.EMPTY_REOCRD_STR);

		return result;
	}

	/**
	 * 添加
	 * 
	 * @param dto
	 */
	@Override
	public ExecIdentitylink addExecIdentitylink(ExecIdentitylinkDTO dto) {

		ExecIdentitylink model = new ExecIdentitylink();
		model.setProcDefId(dto.getProcDefId());
		model.setProcInstId(dto.getProcInstId());
		model.setNodeId(dto.getNodeId());
		model.setUserId(dto.getUserId());
		// model.setDepartId(dto.getDepartId());
		model.setType(dto.getType());
		model.setStatus(ExecIdentitylink.PENDINF_STATUS);
		model.setCreateBy(getNowUser().getUsername());

		this.execIdentitylinkDao.insert(model);

		if (this.logger.isInfoEnabled()) {
			this.logger.info("Add: " + model.toString());
		}
		return model;
	}

	/**
	 * 更新负责人办理状态
	 * 
	 * @param id
	 * @param status
	 */
	@Override
	public void updateExecIdentitylinkStatus(String id, Short status) {
		Assert.hasText(id, Assert.NULL_PARAM_STR("id"));

		ExecIdentitylink model = this.execIdentitylinkDao.getById(id);
		Assert.notNull(model, Assert.EMPTY_REOCRD_STR);

		model.setStatus(status);
		model.setUpdateBy(getNowUser().getUsername());
		model.setGmtModified(new Date());

		this.execIdentitylinkDao.update(model);

		if (this.logger.isInfoEnabled()) {
			this.logger.info("Update: " + model.toString());
		}
	}

	/**
	 * 修改
	 * 
	 * @param dto
	 */
	@Override
	public void updateExecIdentitylink(ExecIdentitylinkDTO dto) {
		Assert.hasText(dto.getId(), Assert.NULL_PARAM_STR("id"));

		ExecIdentitylink model = this.execIdentitylinkDao.getById(dto.getId());
		Assert.notNull(model, Assert.EMPTY_REOCRD_STR);

		model.setProcDefId(dto.getProcDefId());
		model.setProcInstId(dto.getProcInstId());
		model.setNodeId(dto.getNodeId());
		model.setUserId(dto.getUserId());
		model.setDepartId(dto.getDepartId());
		model.setType(dto.getType());
		model.setStatus(dto.getStatus());
		model.setCreateBy(dto.getCreateBy());
		model.setUpdateBy(dto.getUpdateBy());
		model.setGmtCreate(dto.getGmtCreate());
		model.setGmtModified(dto.getGmtModified());

		this.execIdentitylinkDao.update(model);

		if (this.logger.isInfoEnabled()) {
			this.logger.info("Update: " + model.toString());
		}
	}

	/**
	 * 删除
	 * 
	 * @param ids
	 */
	@Override
	public void deleteExecIdentitylinks(String[] ids) {
		for (int i = 0; i < ids.length; i++) {
			this.execIdentitylinkDao.deleteById(ids[i]);

			if (this.logger.isInfoEnabled()) {
				this.logger.info("Delete：:" + ids[i]);
			}
		}
	}

	@Override
	public List<WeiUserDTO> getUsersByNodeId(String nodeId) {
		Assert.hasText(nodeId, Assert.NULL_PARAM_STR("nodeId"));

		return this.execIdentitylinkDao.getUserInfoByNodeId(nodeId);
	}
}
