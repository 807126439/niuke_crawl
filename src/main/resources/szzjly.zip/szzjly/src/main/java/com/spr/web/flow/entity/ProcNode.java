package com.spr.web.flow.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import com.spr.core.annotations.DbField;
import com.spr.core.common.entity.UUIDEntity;

public class ProcNode extends UUIDEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final Short DEF_STATUS = 1;

	public static final String jname = "name";
	public static final String jleft = "left";
	public static final String jtop = "top";
	public static final String jtype = "type";
	public static final String jwidth = "width";
	public static final String jheight = "height";

	public static final String jnodeId = "nodeId";
	public static final String jtitle = "title";
	public static final String jlimittime = "limittime";
	public static final String jrequirement = "requirement";
	public static final String jnote = "note";
	public static final String jdutyUserId = "dutyMan";
	public static final String jdutyUserIds = "dutyManIds";
	public static final String jdutyUserNames = "dutyMans";
	public static final String jsubprocessId = "subprocessId";
	public static final String jprocType = "procType";

	/* line */
	public static final String jfrom = "from";
	public static final String jto = "to";
	public static final String jlineName = "name";
	public static final String jlineType = "type";
	public static final String jlineCode = "lineCode";
	public static final String jlineMid = "M";

	/* 节点类型 */
	public static final String TYPE_START = "start";
	public static final String TYPE_END = "end";
	public static final String TYPE_NODE = "node";

	private String procDefId;

	private String nodeName;

	private String nodeCode;

	private String nodeType;

	private BigDecimal leftPos;

	private BigDecimal topPos;

	private String width;

	private String height;

	private String subDefId;

	private String procType;

	private String title;

	private String requirement;

	private String note;

	private Integer limitDay;

	private String dutyDepartId;

	private String dutyUserId;

	private Short allotStrategy;

	private Short status;

	private String createBy;

	private String updateBy;

	@DbField(name = "proc_def_id")
	public String getProcDefId() {
		return procDefId;
	}

	public void setProcDefId(String procDefId) {
		this.procDefId = procDefId == null ? null : procDefId.trim();
	}

	@DbField(name = "node_name")
	public String getNodeName() {
		return nodeName;
	}

	public void setNodeName(String nodeName) {
		this.nodeName = nodeName == null ? null : nodeName.trim();
	}

	@DbField(name = "node_code")
	public String getNodeCode() {
		return nodeCode;
	}

	public void setNodeCode(String nodeCode) {
		this.nodeCode = nodeCode == null ? null : nodeCode.trim();
	}

	@DbField(name = "node_type")
	public String getNodeType() {
		return nodeType;
	}

	public void setNodeType(String nodeType) {
		this.nodeType = nodeType == null ? null : nodeType.trim();
	}

	@DbField(name = "left_pos")
	public BigDecimal getLeftPos() {
		return leftPos;
	}

	public void setLeftPos(BigDecimal leftPos) {
		this.leftPos = leftPos;
	}

	@DbField(name = "top_pos")
	public BigDecimal getTopPos() {
		return topPos;
	}

	public void setTopPos(BigDecimal topPos) {
		this.topPos = topPos;
	}

	@DbField(name = "width")
	public String getWidth() {
		return width;
	}

	public void setWidth(String width) {
		this.width = width == null ? null : width.trim();
	}

	@DbField(name = "height")
	public String getHeight() {
		return height;
	}

	public void setHeight(String height) {
		this.height = height == null ? null : height.trim();
	}

	@DbField(name = "sub_def_id")
	public String getSubDefId() {
		return subDefId;
	}

	public void setSubDefId(String subDefId) {
		this.subDefId = subDefId == null ? null : subDefId.trim();
	}

	@DbField(name = "proc_type")
	public String getProcType() {
		return procType;
	}

	public void setProcType(String procType) {
		this.procType = procType == null ? null : procType.trim();
	}

	@DbField(name = "title")
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title == null ? null : title.trim();
	}

	@DbField(name = "requirement")
	public String getRequirement() {
		return requirement;
	}

	public void setRequirement(String requirement) {
		this.requirement = requirement == null ? null : requirement.trim();
	}

	@DbField(name = "note")
	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note == null ? null : note.trim();
	}

	@DbField(name = "limit_day")
	public Integer getLimitDay() {
		return limitDay;
	}

	public void setLimitDay(Integer limitDay) {
		this.limitDay = limitDay;
	}

	@DbField(name = "duty_depart_id")
	public String getDutyDepartId() {
		return dutyDepartId;
	}

	public void setDutyDepartId(String dutyDepartId) {
		this.dutyDepartId = dutyDepartId == null ? null : dutyDepartId.trim();
	}

	@DbField(name = "duty_user_id")
	public String getDutyUserId() {
		return dutyUserId;
	}

	public void setDutyUserId(String dutyUserId) {
		this.dutyUserId = dutyUserId == null ? null : dutyUserId.trim();
	}

	@DbField(name = "allot_strategy")
	public Short getAllotStrategy() {
		return allotStrategy;
	}

	public void setAllotStrategy(Short allotStrategy) {
		this.allotStrategy = allotStrategy;
	}

	@DbField(name = "status")
	public Short getStatus() {
		return status;
	}

	public void setStatus(Short status) {
		this.status = status;
	}

	@DbField(name = "create_by")
	public String getCreateBy() {
		return createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy == null ? null : createBy.trim();
	}

	@DbField(name = "update_by")
	public String getUpdateBy() {
		return updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy == null ? null : updateBy.trim();
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode());
		sb.append(",Super = ").append(super.toString());
		sb.append(", serialVersionUID=").append(serialVersionUID);
		sb.append(", procDefId=").append(procDefId);
		sb.append(", nodeName=").append(nodeName);
		sb.append(", nodeCode=").append(nodeCode);
		sb.append(", nodeType=").append(nodeType);
		sb.append(", leftPos=").append(leftPos);
		sb.append(", topPos=").append(topPos);
		sb.append(", width=").append(width);
		sb.append(", height=").append(height);
		sb.append(", subDefId=").append(subDefId);
		sb.append(", procType=").append(procType);
		sb.append(", title=").append(title);
		sb.append(", requirement=").append(requirement);
		sb.append(", note=").append(note);
		sb.append(", limitDay=").append(limitDay);
		sb.append(", dutyDepartId=").append(dutyDepartId);
		sb.append(", dutyUserId=").append(dutyUserId);
		sb.append(", allotStrategy=").append(allotStrategy);
		sb.append(", status=").append(status);
		sb.append(", createBy=").append(createBy);
		sb.append(", updateBy=").append(updateBy);
		sb.append("]");
		return sb.toString();
	}
}