package com.spr.web.evaluate.dao;

import com.spr.core.common.dao.IBaseDao;
import com.spr.web.evaluate.dto.record.EvaluateRecordInputDTO;
import com.spr.web.evaluate.entity.EvaluateRecordInput;
import java.util.List;
import java.util.Map;

public interface IEvaluateRecordInputDao extends IBaseDao<String, EvaluateRecordInput> {

    Long countByCondition(Map<String, Object> queryMap);

    List<EvaluateRecordInputDTO> selectListByCondition(Map<String, Object> queryMap);

    EvaluateRecordInputDTO getDetailById(String id);
	
	int deleteByCondition(Map<String, Object> queryMap);
}