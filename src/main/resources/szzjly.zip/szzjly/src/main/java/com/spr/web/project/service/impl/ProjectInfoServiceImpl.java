package com.spr.web.project.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.dto.ZtreeDTO;
import com.spr.core.common.exception.BusinessException;
import com.spr.core.common.service.BaseService;
import com.spr.core.common.utils.Assert;
import com.spr.core.gobal.GobalVal;
import com.spr.core.spring.security.utils.SecurityPrincipalUtil;
import com.spr.core.utils.DateUtil;
import com.spr.core.utils.excel.ExcelReader;
import com.spr.web.evaluate.dao.IEvaluateRecordDao;
import com.spr.web.evaluate.dto.record.EvaluateRecordDTO;
import com.spr.web.evaluate.service.IEvaluateRecordService;
import com.spr.web.evaluate.service.IEvaluateTimeSettingService;
import com.spr.web.project.dao.IProjectInfoDao;
import com.spr.web.project.dao.IProjectPartInfoDao;
import com.spr.web.project.dto.project.ProjectInfoDTO;
import com.spr.web.project.entity.ProjectInfo;
import com.spr.web.project.service.IProjectInfoService;
import com.spr.web.system.dao.IUnitDao;
import com.spr.web.system.dto.unit.UnitDTO;
import com.spr.web.system.entity.Role;
import com.spr.web.system.entity.Unit;
import com.spr.web.system.service.IUnitService;
import com.spr.web.system.service.IUserService;

@Service("projectInfoService")
@Transactional
public class ProjectInfoServiceImpl extends BaseService implements IProjectInfoService {

	@Resource
	private IProjectInfoDao projectInfoDao;
	@Resource
	private IProjectPartInfoDao projectPartInfoDao;
	@Resource
	private IUnitDao unitDao;
	@Resource
	private IUserService userService;
	@Resource
	private IUnitService unitService;
	@Resource
	private IEvaluateRecordService evaluateRecordService;
	@Resource
	private IEvaluateRecordDao evaluateRecordDao;
	@Resource
	private IEvaluateTimeSettingService evaluateTimeSettingService;

	@Override
	public Map<String, String> selectIdNameMapByCondition(DataQuery dq) {
		List<ProjectInfoDTO> list = this.selectListByCondition(dq);

		Map<String, String> map = new HashMap<String, String>(list.size());
		for (ProjectInfoDTO dto : list) {
			map.put(dto.getId(), dto.getProName());
		}
		return map;
	}

	@Override
	public List<ProjectInfoDTO> selectListByCondition(DataQuery dq) {
		dq.assemblePageOffset();
		dq.assembleOrderInfo(ProjectInfo.class, null);
		List<ProjectInfoDTO> resultlist = this.projectInfoDao.selectListByCondition(dq.getQueryMap());
		return resultlist;
	}

	/**
	 * 分页查询
	 * 
	 * @param dq
	 */
	@Override
	public Page<ProjectInfoDTO> searchByPage(DataQuery dq) {

		Long recTotal = this.projectInfoDao.countByCondition(dq.assemblePageOffset().getQueryMap());
		dq.assembleOrderInfo(ProjectInfo.class, null);
		List<ProjectInfoDTO> resultlist = this.projectInfoDao.selectListByCondition(dq.getQueryMap());
		return new Page<ProjectInfoDTO>(dq.getCurrentPage(), dq.getPageSize(), resultlist, recTotal);
	}

	/**
	 * 查询详细
	 * 
	 * @param id
	 */
	@Override
	public ProjectInfoDTO getDetailById(String id) {
		Assert.hasText(id, Assert.NULL_PARAM_STR("id"));

		ProjectInfoDTO result = this.projectInfoDao.getDetailById(id);
		Assert.notNull(result, Assert.EMPTY_REOCRD_STR);

		return result;
	}

	@Override
	public void updateProjectInfo(ProjectInfoDTO dto) {
		Assert.hasText(dto.getId(), Assert.NULL_PARAM_STR("id"));
		Assert.hasText(dto.getBuildNo(), "项目编号不能为空！");
		Assert.hasText(dto.getProName(), "项目名称不能为空！");
		Assert.hasText(dto.getProAddr(), "项目地址不能为空！");
		// Assert.hasText(dto.getAgentUnitId(), "代建单位不能为空！");

		ProjectInfo model = this.projectInfoDao.getById(dto.getId());
		Assert.notNull(model, Assert.EMPTY_REOCRD_STR);

		model.setBuildNo(dto.getBuildNo());
		model.setProName(dto.getProName());
		model.setProAddr(dto.getProAddr());
		model.setBuildUnitId(dto.getBuildUnitId());
		model.setAgentUnitId(dto.getAgentUnitId());
		model.setRegisterTime(dto.getRegisterTime());
		model.setApplyTime(dto.getApplyTime());
		model.setInvestAmount(dto.getInvestAmount());
		model.setLinkMan(dto.getLinkMan());
		model.setLinkTel(dto.getLinkTel());
		model.setGmtInput(dto.getGmtInput());
		model.setMemo(dto.getMemo());
		// model.setStatus(dto.getStatus());
		// model.setFlag(dto.getFlag());
		// model.setSrcFlag(dto.getSrcFlag());
		// model.setCreateBy(dto.getCreateBy());
		model.setUpdateBy(dto.getUpdateBy());
		// model.setGmtCreate(dto.getGmtCreate());
		model.setGmtModified(dto.getGmtModified());

		this.projectInfoDao.update(model);

		this.writeInfoLog("Update: " + model.toString());

	}

	/**
	 * 删除
	 * 
	 * @param ids
	 */
	@Override
	public void deleteProjectInfos(String[] ids) {
		for (int i = 0; i < ids.length; i++) {

			ProjectInfo projectInfo = this.projectInfoDao.getById(ids[i]);
			if (projectInfo != null) {
				DataQuery dq = new DataQuery();
				if (StringUtils.isNotBlank(projectInfo.getAgentUnitId())) {
					// 代建项目
					// 查询是否有评价记录
					dq.putToMap("proId", projectInfo.getId());
					dq.putToMap("engTypeCode", EvaluateRecordDTO.ENG_TYPE_CODE_DJ);
					dq.putToMap("flag", EvaluateRecordDTO.FLAG_ARCHIVED);
					Long num = this.evaluateRecordDao.countByCondition(dq.getQueryMap());
					if (num > 0) {
						throw new BusinessException("该项目已进行履约评价,无法删除");
					}
				} else {
					// 非代建项目
					// 查询是否有合同
					dq.putToMap("proId", projectInfo.getId());
					Long num = this.projectPartInfoDao.countByCondition(dq.getQueryMap());
					if (num > 0) {
						throw new BusinessException("该项目下有合同信息,无法删除");
					}
				}
			}
			this.projectInfoDao.deleteById(ids[i]);

			this.writeInfoLog("Delete id:" + ids[i]);

		}
	}

	@Override
	public String importProjectInfo(CommonsMultipartFile file) {
		StringBuilder result = new StringBuilder();
		int totalCount = 0; // 记录总数量
		int realCount = 0; // 已插入记录数量
		try {
			ExcelReader excelReader = new ExcelReader();
			Map<Integer, Map<Integer, String>> map = excelReader.readExcelContent(file.getInputStream(), 0, file.getOriginalFilename());

			Iterator<Entry<Integer, Map<Integer, String>>> it = map.entrySet().iterator();
			while (it.hasNext()) {
				totalCount++;
				Entry<Integer, Map<Integer, String>> entry = it.next();
				Map<Integer, String> rowData = entry.getValue();

				String buildNo = rowData.get(0); // 项目编号
				String proName = rowData.get(1); // 项目名称
				String proAddr = rowData.get(2); // 项目地点
				String buildUnitCode = rowData.get(3); // 建设单位组织机构代码
				String buildUnitName = rowData.get(4); // 建设单位
				String buildUnitLinkMan = rowData.get(5); // 建设单位联系人
				String buildUnitLinkTel = rowData.get(6); // 建设单位联系人手机
				String agentUnitCode = rowData.get(7); // 代建单位组织机构代码
				String agentUnitName = rowData.get(8); // 代建单位
				String agentUnitLinkMan = rowData.get(9); // 代建单位联系人
				String agentUnitLinkTel = rowData.get(10); // 代建单位联系人手机

				String registerTime = rowData.get(11); // 登记时间
				String applyTime = rowData.get(12); // 申请时间
				String investAmount = rowData.get(13); // 总投资额
				String linkMan = rowData.get(14); // 项目经办人
				String linkTel = rowData.get(15); // 经办人电话

				// 项目名为空则导入失败
				if (StringUtils.isBlank(proName)) {
					continue;
				}

				String buildUnitId = null;
				if (StringUtils.isNotBlank(buildUnitCode)) {
					UnitDTO buildUnit = this.unitDao.getDetailByOrganizationCode(buildUnitCode);
					if (buildUnit != null) {
						buildUnitId = buildUnit.getId();
					} else {
						// 单位不存在，新建建设单位
						Unit unit = new Unit();
						unit.setOrganizationCode(buildUnitCode);
						unit.setUnitName(buildUnitName);
						unit.setLinkMan(buildUnitLinkMan);
						unit.setLinkTel(buildUnitLinkTel);
						unit.setFlag(GobalVal.NORMAL_FLAG);
						unit.setStatus(GobalVal.STATUS_ENABLE);
						unit.setCreateBy(getNowUser().getUsername());
						this.unitDao.insert(unit);
						buildUnitId = unit.getId();

						this.userService.addUnitDefaultUser(buildUnitId, buildUnitCode, buildUnitLinkMan, "buildUnit");

					}
				}

				String agentUnitId = null;
				if (StringUtils.isNotBlank(agentUnitCode)) {
					UnitDTO agentUnit = this.unitDao.getDetailByOrganizationCode(agentUnitCode);
					if (agentUnit != null) {
						agentUnitId = agentUnit.getId();
					} else {
						// 单位不存在，新建建设单位
						Unit unit = new Unit();
						unit.setOrganizationCode(agentUnitCode);
						unit.setUnitName(agentUnitName);
						unit.setLinkMan(agentUnitLinkMan);
						unit.setLinkTel(agentUnitLinkTel);
						unit.setFlag(GobalVal.NORMAL_FLAG);
						unit.setStatus(GobalVal.STATUS_ENABLE);
						unit.setCreateBy(getNowUser().getUsername());
						this.unitDao.insert(unit);
						agentUnitId = unit.getId();

						this.userService.addUnitDefaultUser(agentUnitId, agentUnitCode, agentUnitLinkMan, "agentUnit");
					}
				}

				ProjectInfo projectInfo = new ProjectInfo();
				projectInfo.setBuildNo(buildNo);
				projectInfo.setProName(proName);
				projectInfo.setProAddr(proAddr);
				projectInfo.setBuildUnitId(buildUnitId);
				projectInfo.setAgentUnitId(agentUnitId);
				projectInfo.setRegisterTime(StringUtils.isNotBlank(registerTime) ? DateUtil.str2Date(registerTime) : null);
				projectInfo.setApplyTime(StringUtils.isNotBlank(applyTime) ? DateUtil.str2Date(applyTime) : null);
				if (StringUtils.isNotBlank(investAmount)) {
					projectInfo.setInvestAmount(new BigDecimal(investAmount));
				}
				projectInfo.setLinkMan(linkMan);
				projectInfo.setLinkTel(linkTel);
				projectInfo.setGmtInput(new Date());
				projectInfo.setSrcFlag(ProjectInfo.IMPORT_SRC); // 导入来源
				projectInfo.setEvaluateStatus(GobalVal.EVALUATE_NOT_END);
				projectInfo.setStatus(GobalVal.STATUS_ENABLE);
				projectInfo.setFlag(GobalVal.NORMAL_FLAG);
				projectInfo.setCreateBy(getNowUser().getUsername());

				this.projectInfoDao.insert(projectInfo);

				if (this.logger.isInfoEnabled()) {
					this.logger.info("import: " + projectInfo.toString());
				}

				realCount++;
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException("Import error：" + e.getMessage());
		}

		result.append("结果:总记录数：" + totalCount + " 成功插入记录数：" + realCount);
		return result.toString();
	}

	@Override
	public List<ZtreeDTO> getProjectInfoTreeData() {
		List<ZtreeDTO> resultList = new ArrayList<ZtreeDTO>();
		DataQuery dq = new DataQuery();
		List<ProjectInfoDTO> projectInfoList = this.projectInfoDao.selectListByCondition(dq.getQueryMap());
		if (projectInfoList != null && projectInfoList.size() > 0) {
			for (ProjectInfoDTO projectInfoDTO : projectInfoList) {
				ZtreeDTO ztreeDTO = new ZtreeDTO();
				ztreeDTO.setId(projectInfoDTO.getId());
				ztreeDTO.setName(projectInfoDTO.getProName());
				resultList.add(ztreeDTO);
			}
		}
		return resultList;
	}

	@Override
	public String importProjectInfoAndEvaluate(CommonsMultipartFile file) {
		StringBuilder result = new StringBuilder();
		int totalCount = 0; // 记录总数量
		int realCount = 0; // 已插入记录数量
		try {
			ExcelReader excelReader = new ExcelReader();
			Map<Integer, Map<Integer, String>> map = excelReader.readExcelContent(file.getInputStream(), 0, file.getOriginalFilename());

			Iterator<Entry<Integer, Map<Integer, String>>> it = map.entrySet().iterator();
			while (it.hasNext()) {
				totalCount++;
				Entry<Integer, Map<Integer, String>> entry = it.next();
				Map<Integer, String> rowData = entry.getValue();

				// String buildNo = rowData.get(0); // 项目编号
				// String proName = rowData.get(1); // 项目名称
				// String proAddr = rowData.get(2); // 项目地点
				// String buildUnitCode = rowData.get(3); // 建设单位组织机构代码
				// String buildUnitName = rowData.get(4); // 建设单位
				// String buildUnitLinkMan = rowData.get(5); // 建设单位联系人
				// String buildUnitLinkTel = rowData.get(6); // 建设单位联系人手机

				// String registerTime = rowData.get(11); // 登记时间
				// String applyTime = rowData.get(12); // 申请时间
				// String investAmount = rowData.get(13); // 总投资额
				// String linkMan = rowData.get(14); // 项目经办人
				// String linkTel = rowData.get(15); // 经办人电话

				String engType = rowData.get(1); // 工程类型
				String contractor = rowData.get(2); // 承包商名称
				String contractorCode = rowData.get(3); // 承包商机构代码

				//
				//
				// String yearMiddleCycle = rowData.get(19);// 年中周期
				// String yearMiddleScore = rowData.get(20);// 年中分数
				// String yearEndCycle = rowData.get(21);// 年终周期
				String yearEndScore = rowData.get(4);// 年终分数

				// 项目名为空则导入失败
				// if (StringUtils.isBlank(proName)) {
				// continue;
				// }
				//
				// String buildUnitId = null;
				// if (StringUtils.isNotBlank(buildUnitCode)) {
				// UnitDTO buildUnit =
				// this.unitDao.getDetailByOrganizationCode(buildUnitCode);
				// if (buildUnit != null) {
				// buildUnitId = buildUnit.getId();
				// } else {
				// // 单位不存在，新建建设单位
				// Unit unit = new Unit();
				// unit.setOrganizationCode(buildUnitCode);
				// unit.setUnitName(buildUnitName);
				// unit.setLinkMan(buildUnitLinkMan);
				// unit.setLinkTel(buildUnitLinkTel);
				// unit.setFlag(GobalVal.NORMAL_FLAG);
				// unit.setStatus(GobalVal.STATUS_ENABLE);
				// unit.setCreateBy(getNowUser().getUsername());
				// this.unitDao.insert(unit);
				// buildUnitId = unit.getId();
				//
				// this.userService.addUnitDefaultUser(buildUnitId,
				// buildUnitCode, "", "buildUnit");
				// }
				// }

				// 判断承包商是否已经存在
				String contractorUnitId = null;
				String contractorName = null;
				if (StringUtils.isNotBlank(contractorCode)) {
					UnitDTO contractorUnit = this.unitDao.getDetailByOrganizationCode(contractorCode);
					if (contractorUnit != null) {
						contractorUnitId = contractorUnit.getId();
						contractorName = contractorUnit.getUnitName();
					} else {
						// 单位不存在，新建建设单位
						Unit unit = new Unit();
						unit.setOrganizationCode(contractorCode);
						unit.setUnitName(contractor);
						unit.setFlag(GobalVal.NORMAL_FLAG);
						unit.setStatus(GobalVal.STATUS_ENABLE);
						unit.setCreateBy(getNowUser().getUsername());
						this.unitDao.insert(unit);
						contractorUnitId = unit.getId();
						contractorName = unit.getUnitName();

						this.userService.addUnitDefaultUser(contractorUnitId, contractorCode, "", "contractorUnit");
					}
				}

				// 工程类型
				String engTypeCode = getEngTypeCodeByEngTypeName(engType);

				// ProjectInfoDTO projectInfoDTO =
				// this.projectInfoDao.getDetailByProName(proName);

				// 项目已经存在
				// if (projectInfoDTO != null) {
				// ProjectPartInfo partInfo = new ProjectPartInfo();
				// partInfo.setPartName(projectInfoDTO.getProName() + engType +
				// "工程");
				// partInfo.setContractorUnitId(contractorUnitId);
				// partInfo.setProId(projectInfoDTO.getId());
				// partInfo.setEngTypeCode(engTypeCode);
				// partInfo.setStatus(GobalVal.STATUS_ENABLE);
				// partInfo.setFlag(GobalVal.NORMAL_FLAG);
				// partInfo.setCreateBy(getNowUser().getUsername());
				// this.projectPartInfoDao.insert(partInfo);
				//
				// if (StringUtils.isNotBlank(yearMiddleCycle) &&
				// StringUtils.isNotBlank(yearMiddleScore)) {
				// this.evaluateRecordService.tempImport(engType,
				// projectInfoDTO.getId(), partInfo.getId(), proName,
				// buildUnitName, contractorUnitId,
				// contractorName, yearMiddleCycle, yearMiddleScore);
				// }
				//
				// if (StringUtils.isNotBlank(yearEndCycle) &&
				// StringUtils.isNotBlank(yearEndScore)) {
				// this.evaluateRecordService.tempImport(engType,
				// projectInfoDTO.getId(), partInfo.getId(), proName,
				// buildUnitName, contractorUnitId,
				// contractorName, yearEndCycle, yearMiddleScore);
				// }
				//
				// } else {

				// ProjectInfo projectInfo = new ProjectInfo();
				// projectInfo.setProName(proName);
				// projectInfo.setBuildUnitId(buildUnitId);
				// // projectInfo.setAgentUnitId(agentUnitId);
				// // projectInfo.setLinkMan(linkMan);
				// // projectInfo.setLinkTel(linkTel);
				// projectInfo.setGmtInput(new Date());
				// projectInfo.setSrcFlag(ProjectInfo.IMPORT_SRC); // 导入来源
				// projectInfo.setEvaluateStatus(GobalVal.EVALUATE_NOT_END);
				// projectInfo.setStatus(GobalVal.STATUS_ENABLE);
				// projectInfo.setFlag(GobalVal.NORMAL_FLAG);
				// projectInfo.setCreateBy(getNowUser().getUsername());
				// this.projectInfoDao.insert(projectInfo);

				// ProjectPartInfo partInfo = new ProjectPartInfo();
				// partInfo.setPartName(projectInfo.getProName() + engType +
				// "工程");
				// partInfo.setContractorUnitId(contractorUnitId);
				// partInfo.setProId(projectInfo.getId());
				// partInfo.setEngTypeCode(engTypeCode);
				// partInfo.setEvaluateStatus(GobalVal.EVALUATE_NOT_END);
				// partInfo.setStatus(GobalVal.STATUS_ENABLE);
				// partInfo.setFlag(GobalVal.NORMAL_FLAG);
				// partInfo.setCreateBy(getNowUser().getUsername());
				// this.projectPartInfoDao.insert(partInfo);

				// if (StringUtils.isNotBlank(yearMiddleCycle) &&
				// StringUtils.isNotBlank(yearMiddleScore)) {
				// this.evaluateRecordService.tempImport(engType,
				// projectInfo.getId(), partInfo.getId(), proName,
				// buildUnitName, contractorUnitId,
				// contractorName, EvaluateRecordDTO.FORM_TYPE_SEASON,
				// yearMiddleScore, partInfo.getEngTypeCode());
				// }

				// if (StringUtils.isNotBlank(yearEndCycle) &&
				// StringUtils.isNotBlank(yearEndScore)) {
				this.evaluateRecordService.tempImport(engType, "", "", "", "", contractorUnitId, contractorName, EvaluateRecordDTO.FORM_TYPE_YEAR,
						yearEndScore, engTypeCode);
				// }

				realCount++;
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException("Import error：" + e.getMessage());
		}

		result.append("结果:总记录数：" + totalCount + " 成功插入记录数：" + realCount);
		return result.toString();
	}

	private String getEngTypeCodeByEngTypeName(String name) {

		String code = "";
		if (name.equals("施工")) {
			code = "SG";
		}
		if (name.equals("勘察")) {
			code = "KC";
		}
		if (name.equals("监理")) {
			code = "JL";
		}
		if (name.equals("设计")) {
			code = "SJ";
		}
		if (name.equals("造价咨询")) {
			code = "ZJZX";
		}
		if (name.equals("招标代理")) {
			code = "ZBDL";
		}
		if (name.equals("代建")) {
			code = "DJ";
		}

		return code;
	}

	@Override
	public void setProjectEvaluateStatus(String proId, Short evaluateStatus) {
		Assert.hasText(proId, "proId null error");
		ProjectInfo projectInfo = this.projectInfoDao.getById(proId);
		projectInfo.setEvaluateStatus(evaluateStatus);
		projectInfo.setUpdateBy(getNowUser().getUsername());
		projectInfo.setGmtModified(new Date());
		this.projectInfoDao.update(projectInfo);
	}

	@Override
	public Boolean isProjectEvaluateStatusFinished(String proId) {
		Assert.hasText(proId, "proId null error");
		ProjectInfo projectInfo = this.projectInfoDao.getById(proId);
		if (projectInfo.getEvaluateStatus() == GobalVal.EVALUATE_END) {
			return true;
		}
		return false;
	}

	@Override
	public void addProjectInfo(ProjectInfoDTO dto) {
		Assert.hasText(dto.getBuildNo(), "项目编号不能为空！");
		Assert.hasText(dto.getProName(), "项目名称不能为空！");
		Assert.hasText(dto.getProAddr(), "项目地址不能为空！");
		Assert.hasText(dto.getBuildUnitId(), "建设单位不能为空！");

		ProjectInfo model = new ProjectInfo();

		model.setBuildNo(dto.getBuildNo());
		model.setProName(dto.getProName());
		model.setProAddr(dto.getProAddr());
		model.setBuildUnitId(dto.getBuildUnitId());
		model.setAgentUnitId(dto.getAgentUnitId());
		model.setRegisterTime(dto.getRegisterTime());
		model.setApplyTime(dto.getApplyTime());
		model.setInvestAmount(dto.getInvestAmount());
		model.setLinkMan(dto.getLinkMan());
		model.setLinkTel(dto.getLinkTel());
		model.setGmtInput(dto.getGmtInput());
		model.setMemo(dto.getMemo());
		model.setStatus(GobalVal.STATUS_ENABLE);
		model.setFlag(GobalVal.NORMAL_FLAG);
		model.setSrcFlag(ProjectInfo.INPUT_SRC); // 手动录入
		model.setCreateBy(getNowUser().getUsername());

		this.projectInfoDao.insert(model);

		this.writeInfoLog("Add: " + model.toString());

	}

	@Override
	public List<Map<String, Object>> getNotEvaluateProList() {

		List<Map<String, Object>> resultList = new ArrayList<Map<String, Object>>();

		// 查询当前单位是否已经对项目进行评价
		Map<String, Object> queryMap = new HashMap<String, Object>();
		queryMap.put("evalUnitId", getNowUser().getUnitId());
		if (SecurityPrincipalUtil.checkIsHasRole(Role.ROLE_HOUSING) || SecurityPrincipalUtil.checkIsHasRole(Role.ROLE_FG)
				|| SecurityPrincipalUtil.checkIsHasRole(Role.ROLE_HOUSING_PJ)) {
			// 查询未评价项目(合同评价)
			queryMap.put("formType", EvaluateRecordDTO.FORM_TYPE_CONTRACT);
			resultList = this.projectInfoDao.selectNotEvaluateList(queryMap);
		} else if (SecurityPrincipalUtil.checkIsHasRole(Role.ROLE_BUILD_UNIT)) {
			queryMap.put("buildUnitId", getNowUser().getUnitId());
			// 查询未评价项目(合同评价)
			queryMap.put("formType", EvaluateRecordDTO.FORM_TYPE_CONTRACT);
			List<Map<String, Object>> proList = this.projectInfoDao.selectNotEvaluateList(queryMap);
			// 查询未评价项目(履约评价)
			Map<String, Date> timeMap = this.evaluateTimeSettingService.getSeasonEvaluateTime();
			if (timeMap != null && !timeMap.isEmpty()) {
				queryMap.put("evalBeginTime", timeMap.get("beginTime"));
				queryMap.put("evalEndTime", timeMap.get("endTime"));
				queryMap.put("formType", EvaluateRecordDTO.FORM_TYPE_SEASON);
				List<Map<String, Object>> partList = this.projectInfoDao.selectNotEvaluateList(queryMap);
				resultList.addAll(partList);
			}
			resultList.addAll(proList);

		}
		return resultList;

	}
}
