package com.spr.web.api.test;

import java.rmi.RemoteException;

import org.apache.axis2.AxisFault;

import com.spr.web.api.webservice.ProjdataServiceStub;
import com.spr.web.api.webservice.ProjdataServiceStub.ProcessData;
import com.spr.web.api.webservice.ProjdataServiceStub.ProcessDataE;

public class Test {

	public static void main(String[] args) {

		try {
			ProjdataServiceStub stub = new ProjdataServiceStub();

			ProcessData processData = new ProcessData();
			processData.setReqPacket("");

			ProcessDataE processDataE = new ProcessDataE();
			processDataE.setProcessData(processData);

			// TestCallBack callBack = new TestCallBack();

			// stub.startprocessData(processDataE, callBack);

		} catch (AxisFault e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
