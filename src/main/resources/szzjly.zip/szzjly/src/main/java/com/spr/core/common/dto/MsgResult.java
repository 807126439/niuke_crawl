package com.spr.core.common.dto;

public class MsgResult {
	
	private Short status;
	private String resultNote;
		
	public Short getStatus() {
		return status;
	}
	public void setStatus(Short status) {
		this.status = status;
	}
	public String getResultNote() {
		return resultNote;
	}
	public void setResultNote(String resultNote) {
		this.resultNote = resultNote;
	}
}
