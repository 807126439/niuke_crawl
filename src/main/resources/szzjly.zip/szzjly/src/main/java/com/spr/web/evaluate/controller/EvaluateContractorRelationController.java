package com.spr.web.evaluate.controller;

import com.spr.web.evaluate.service.IEvaluateContractorRelationService;
import com.spr.web.evaluate.dto.relation.EvaluateContractorRelationDTO;
import com.spr.core.common.controller.BaseController;

import java.util.Map;
import javax.annotation.Resource;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import javax.servlet.http.HttpServletRequest;

import com.spr.core.common.bean.AjaxJson;
import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;

@Controller
@Scope("prototype")
@RequestMapping("/evaluateContractorRelationController")
public class EvaluateContractorRelationController extends BaseController{

	private static final long serialVersionUID = 1L;
	
	@Resource
	private IEvaluateContractorRelationService evaluateContractorRelationService;
	
	
	
	@RequestMapping(value="/viewPage",method={RequestMethod.GET})
	public String viewPage(HttpServletRequest request){
		this.wrapMenuTitle(request);
		
		return "evaluate/evaluateContractorRelation/evaluateContractorRelationList.jsp";
	}
	
	
	@RequestMapping(value="/getPageData",method={RequestMethod.POST})
	@ResponseBody
	public Map<String, Object> loadPageData(HttpServletRequest request,DataQuery dq){

		this.wrapTableQueryParams(request, dq);
				
		Page<EvaluateContractorRelationDTO> pageResult = this.evaluateContractorRelationService.searchByPage(dq);
		 
		return this.handlePageReult(pageResult);
	}
	
	
	@RequestMapping(value="/skipAddEvaluateContractorRelation")
	public String skipAddEvaluateContractorRelation(HttpServletRequest request){
		
		
		return "evaluate/evaluateContractorRelation/addEvaluateContractorRelation.jsp";
	}
	
	
	@RequestMapping(value="/addEvaluateContractorRelation",method={RequestMethod.POST})
	@ResponseBody
	public AjaxJson addEvaluateContractorRelation(EvaluateContractorRelationDTO dto) throws Exception{
	
		this.evaluateContractorRelationService.addEvaluateContractorRelation(dto);
		
		
		return new AjaxJson(this.ADD_SUCCESS_MESSAGE, AjaxJson.success);
	}
	
	
	@RequestMapping("/getDetail")
	public String loadDetail(HttpServletRequest request,@RequestParam(value="id",required=true)String id){
			  		
	    EvaluateContractorRelationDTO result = this.evaluateContractorRelationService.getDetailById(id);
		request.setAttribute("model", result);
		
	
		return "evaluate/evaluateContractorRelation/editEvaluateContractorRelation.jsp";
	}
	
	
	@RequestMapping(value="/editEvaluateContractorRelation",method={RequestMethod.POST})
	@ResponseBody
	public AjaxJson updateEvaluateContractorRelation(EvaluateContractorRelationDTO dto){
		
		this.evaluateContractorRelationService.updateEvaluateContractorRelation(dto);
				
		return new AjaxJson(this.EDIT_SUCCESS_MESSAGE, AjaxJson.success);
	}
	
	
	@RequestMapping(value="/deleteEvaluateContractorRelation",method={RequestMethod.POST})
	@ResponseBody
	public AjaxJson deleteEvaluateContractorRelation(String[] ids){
		
		this.evaluateContractorRelationService.deleteEvaluateContractorRelations(ids);
		
		
		return new AjaxJson(this.DEL_SUCCESS_MESSAGE, AjaxJson.success);
	}
	
}
