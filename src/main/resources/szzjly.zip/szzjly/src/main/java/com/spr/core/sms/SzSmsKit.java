package com.spr.core.sms;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.List;
import java.util.Properties;

import org.apache.axis.client.Call;
import org.apache.axis.client.Service;
import org.apache.commons.lang3.StringUtils;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import com.spr.core.utils.PropertiesUtil;

/**
 * 新短信接口
 * 
 * @author wb_java_zjr 2018-6-21
 */
public class SzSmsKit {

	private static final String username = "AjsDaF0/";
	private static final String password = "AjkDal0tUlBXJFAVU1RXO1xXBzAFVlJmVzw=";

	private static String endpoint = "http://10.210.136.165/services/Sms?wsdl";

	private static String validationPhoneSmsTpl = "您此次操作的验证码为{0}，5分钟内有效，切勿转发或告知他人。";

	public static final String SUCCESS = "0";

	static {

		Properties properties = PropertiesUtil.loadPropertiesFromSrc("systemConfig.properties");

		String temp = properties.getProperty("SMS_WS_URL");
		if (StringUtils.isNoneBlank(temp)) {
			endpoint = temp;
		}
	}

	public static String getValidationPhoneSmsTpl() {
		return validationPhoneSmsTpl;
	}

	/**
	 * 发送短信
	 * 
	 * @param phone
	 * @param content
	 * @return 2018-6-21 上午11:51:21
	 */
	public static String sendMsg(String phone, String content) {
		String msgId = "";
		try {
			Service service = new Service();
			Call call = (Call) service.createCall();

			// 发送短信
			call.setOperationName("InsertDownSms");
			call.setTargetEndpointAddress(new java.net.URL(endpoint));
			String boay = "<sendbody><message><orgaddr></orgaddr><mobile>" + phone + "</mobile><content>" + content
					+ "</content><sendtime></sendtime><needreport>0</needreport></message><publicContent></publicContent></sendbody>";
			String respXml = (String) call.invoke(new Object[] { username, password, "", boay });

			System.out.println("InsertDownSms: " + respXml);
			msgId = getRespMsgId(respXml);

		} catch (Exception e) {
			e.printStackTrace();
		}

		return msgId;

	}

	/**
	 * 查询短信发送状态
	 * 
	 * @param msgId
	 * @return 0成功 2018-6-21 上午11:51:30
	 */
	public static String getMsgStatus(String msgId) {
		String status = "";
		try {
			Service service = new Service();
			Call call = (Call) service.createCall();

			call.setOperationName("getSpecialDownSmsResult");
			call.setTargetEndpointAddress(new java.net.URL(endpoint));
			String respXml = (String) call.invoke(new Object[] { username, password, "", msgId });

			System.out.println("return value is " + respXml);

			status = getRespStatus(respXml);
			return status;

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	/**
	 * 查询短信发送结果
	 * 
	 * @param msgId
	 * @return
	 */
	public static String getMsgResult(String msgId) {
		try {
			Service service = new Service();
			Call call = (Call) service.createCall();

			call.setOperationName("getSpecialDownSmsResult");
			call.setTargetEndpointAddress(new java.net.URL(endpoint));
			String respXml = (String) call.invoke(new Object[] { username, password, "", msgId });

			return respXml;

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	/**
	 * 从xml获取返回的msgId
	 * 
	 * @param respXml
	 * @return 2018-6-21 上午11:23:37
	 */
	public static String getRespMsgId(String respXml) {

		String result = "";

		SAXReader reader = new SAXReader();
		Document document = null;

		try {
			InputStream is = new ByteArrayInputStream(respXml.getBytes());
			document = reader.read(is);
			Element root = document.getRootElement();
			List<Element> list = root.elements();
			for (Element e : list) {
				if ("body".equals(e.getName())) {
					Element msg = e.element("msgid");

					String text = msg.getText().trim();
					result = text.split(",")[1];

				}

			}
			is.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return result;
	}

	/**
	 * 从xml获取返回的status
	 * 
	 * @param respXml
	 * @return 2018-6-21 上午11:38:47
	 */
	public static String getRespStatus(String respXml) {

		String status = "";

		SAXReader reader = new SAXReader();
		try {
			reader.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
			reader.setFeature("http://xml.org/sax/features/external-general-entities", false);
			reader.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
		} catch (Exception e) {
			e.printStackTrace();
		}
		Document document = null;

		try {
			InputStream is = new ByteArrayInputStream(respXml.getBytes());
			document = reader.read(is);
			Element root = document.getRootElement();
			List<Element> list = root.elements();
			for (Element e : list) {
				if ("body".equals(e.getName())) {
					Element cnt = e.element("smsresultcnt");
					Integer qt = Integer.valueOf(cnt.getTextTrim());
					if (qt > 0) {
						Element smsresult = e.element("smsresult");
						status = smsresult.elementText("status");
						System.out.println(status);
					}

				}

			}
			is.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return status;
	}

	/**
	 * 短信查询结果
	 * 
	 * @author wb_java_zjr
	 * 
	 */
	public static class SmsResult {

		private String content; // 短信内容
		private Short status; // 发送状态 1：等待回执，2：发送失败，3：发送成功
		private String resultNote; // 返回结果

		public SmsResult(String content, Short status, String resultNote) {
			super();
			this.content = content;
			this.status = status;
			this.resultNote = resultNote;
		}

		public String getContent() {
			return content;
		}

		public void setContent(String content) {
			this.content = content;
		}

		public Short getStatus() {
			return status;
		}

		public void setStatus(Short status) {
			this.status = status;
		}

		public String getResultNote() {
			return resultNote;
		}

		public void setResultNote(String resultNote) {
			this.resultNote = resultNote;
		}

	}

	public static void main(String[] args) {
		// SzSmsKit.sendMsg("13532855563", "");
		SzSmsKit.getMsgStatus("201806220954403790");
		// String s =
		// "<?xml version=\"1.0\" encoding=\"GBK\" ?><response><head><code>0</code><message></message></head><body><smsresultcnt>1</smsresultcnt><smsresult><msgid>201806210929265060</msgid><status>0</status><msgstatus>0</msgstatus><resultmsg>1,3,2,CMPP2.0,0,0,DELIVRD</resultmsg><senttime>2018-06-21 09:29:30.237</senttime><reserve></reserve></smsresult></body></response>";
		//
		// SAXReader reader = new SAXReader();
		// Document document = null;
		//
		// try {
		// InputStream is = new ByteArrayInputStream(s.getBytes());
		// document = reader.read(is);
		// Element root = document.getRootElement();
		// List<Element> list = root.elements();
		// for (Element e : list) {
		// if ("body".equals(e.getName())) {
		// Element cnt = e.element("smsresultcnt");
		// Integer qt = Integer.valueOf(cnt.getTextTrim());
		// if (qt > 0) {
		// Element smsresult = e.element("smsresult");
		// String status = smsresult.elementText("status");
		// System.out.println(status);
		// }
		//
		// }
		//
		// }
		// is.close();
		//
		// } catch (Exception e) {
		// e.printStackTrace();
		// }

	}
}
