package com.spr.core.utils.img;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import javax.media.jai.JAI;
import javax.media.jai.RenderedOp;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.RectangleReadOnly;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfWriter;
import com.spr.core.utils.UUIDGenerator;
import com.sun.media.jai.codec.ImageCodec;
import com.sun.media.jai.codec.ImageEncodeParam;
import com.sun.media.jai.codec.ImageEncoder;

public class ImgToPdf {

	protected static Logger logger = LoggerFactory.getLogger(ImgToPdf.class);

	public static final float A0_width = 2384;
	public static final float A0_heigth = 3370;

	public static final float A1_width = 1684;
	public static final float A1_heigth = 2384;

	public static final float A2_width = 1191;
	public static final float A2_heigth = 1684;

	public static final float A3_width = 842;
	public static final float A3_heigth = 1191;

	public static final float A4_width = 595;
	public static final float A4_heigth = 842;

	/**
	 * 判断文件是否tiff文件
	 * 
	 * @param filePath
	 * @return
	 */
	public static boolean isTiff(String filePath) {
		boolean ret = false;

		if (filePath.endsWith("tif") || filePath.endsWith("TIF") || filePath.endsWith("tiff") || filePath.endsWith("TIFF")) {
			ret = true;
		}

		return ret;
	}

	/**
	 * 判断文件是否jpg文件
	 * 
	 * @param filePath
	 * @return
	 */
	public static boolean isJpg(String filePath) {
		boolean ret = false;

		if (filePath.endsWith("jpg") || filePath.endsWith("JPG")) {
			ret = true;
		}

		return ret;
	}

	/**
	 * 判断文件是否gif文件
	 * 
	 * @param filePath
	 * @return
	 */
	public static boolean isGif(String filePath) {
		boolean ret = false;

		if (filePath.endsWith("gif") || filePath.endsWith("GIF")) {
			ret = true;
		}

		return ret;
	}

	/**
	 * 检查文件是否存在
	 * 
	 * @param filePath
	 * @return
	 */
	public static boolean checkFileExist(String filePath) {
		boolean ret = false;

		File file = new File(filePath);
		if (file.exists()) {
			ret = true;
		}

		return ret;
	}

	// 将多个tif文件合并成一个pdf文件
	public static boolean imgToPdf(List<String> imags, String sFilePdf) {
		boolean ret = false;
		// 创建一个文档对象
		Document doc = new Document();

		try {
			// File pdfFile = new File(sFilePdf);

			// 定义输出位置并把文档对象装入输出对象中
			PdfWriter writer = PdfWriter.getInstance(doc, new FileOutputStream(sFilePdf));

			for (int i = 0; i < imags.size(); i++) {
				String imgPath = imags.get(i);

				if (checkFileExist(imgPath)) {

					if (isTiff(imgPath) || isGif(imgPath)) {
						String jpgPath = convertToJpg(imgPath, sFilePdf);
						if (StringUtils.isNoneBlank(jpgPath)) {
							Image img = Image.getInstance(jpgPath);
							commonAddImg(doc, writer, img);

							File jpgFile = new File(jpgPath);
							if (jpgFile.exists()) {
								jpgFile.delete();
							}
						}
						// RandomAccessFileOrArray ra = null;
						// int comps = 0;
						// try {
						// ra = new RandomAccessFileOrArray(imgPath);
						// comps = TiffImage.getNumberOfPages(ra);
						// } catch (Throwable e) {
						// e.printStackTrace();
						// System.out.println("Exception in " + imgPath + " " +
						// e.getMessage());
						//
						// }
						//
						// for (int c = 0; c < comps; ++c) {
						// try {
						// Image img = TiffImage.getTiffImage(ra, c + 1);
						// if (img != null) {
						//
						// commonAddImg(doc, writer, img);
						//
						// }
						// } catch (Exception e) {
						// e.printStackTrace();
						// if (logger.isInfoEnabled()) {
						// logger.info("Exception " + imgPath + " page " + (c +
						// 1) + " " + e.getMessage());
						// }
						//
						// }
						// }
						// ra.close();// 关闭

					} else {
						Image img = Image.getInstance(imgPath);
						commonAddImg(doc, writer, img);
					}
				}

			}
			if (doc.isOpen()) {
				// 关闭文档对象，释放资源
				doc.close();
			}

			ret = true;

		} catch (Exception e) {
			e.printStackTrace();
		}

		return ret;
	}

	private static void commonAddImg(Document doc, PdfWriter writer, Image img) throws DocumentException {
		// img.scalePercent((float) (7200f / img.getDpiX() *
		// 0.9), (float) (7200f / img.getDpiY() * 0.9));

		float pageWidth = 0;
		float pageHeigth = 0;

		if (img.getWidth() >= A0_width) {// 用A0
			doc.setPageSize(PageSize.A0);
			img.scaleToFit(new RectangleReadOnly(A0_width - 10, A0_heigth));

			pageWidth = A0_width - 10;
			pageHeigth = A0_heigth;

		} else if (img.getWidth() >= A2_width && img.getWidth() < A1_width) {// 用A1
			doc.setPageSize(PageSize.A1);
			img.scaleToFit(new RectangleReadOnly(A1_width - 10, A1_heigth));

			pageWidth = A1_width - 10;
			pageHeigth = A1_heigth;

		} else if (img.getWidth() >= A3_width && img.getWidth() < A2_width) {// 用A2
			doc.setPageSize(PageSize.A2);
			img.scaleToFit(new RectangleReadOnly(A2_width - 10, A2_heigth));

			pageWidth = A2_width - 10;
			pageHeigth = A2_heigth;

		} else if (img.getWidth() >= A4_width && img.getWidth() < A3_width) {// 用A3
			doc.setPageSize(PageSize.A3);
			img.scaleToFit(new RectangleReadOnly(A3_width - 10, A3_heigth));

			pageWidth = A3_width - 10;
			pageHeigth = A3_heigth;
		} else {
			doc.setPageSize(PageSize.A4);
			img.scaleToFit(new RectangleReadOnly(A4_width - 10, A4_heigth));

			pageWidth = A4_width - 10;
			pageHeigth = A4_heigth;
		}

		if (!doc.isOpen()) {
			// 打开文档对象
			doc.open();
		}

		PdfContentByte cb = writer.getDirectContentUnder();

		// 根据A4尺寸调整图片位置
		float x = 0;
		float y = 0;
		if (pageWidth - img.getScaledWidth() > 0) {
			x = (pageWidth - img.getScaledWidth()) / 2;
		} else {
			x = 5;
		}

		if (pageHeigth - img.getScaledHeight() > 0) {
			y = (pageHeigth - img.getScaledHeight()) / 2;
		} else {
			y = 0;
		}

		img.setAbsolutePosition(x, y);
		cb.addImage(img);
		doc.newPage();
	}

	/**
	 * tif转jpg
	 * 
	 * @param tifPath
	 * @param sFilePdf
	 * @return
	 */
	public static String convertToJpg(String tifPath, String sFilePdf) {
		String ret = null;
		try {
			File jpgFile = new File(new File(sFilePdf).getParent(), UUIDGenerator.getUUID() + ".jpg");

			RenderedOp src2 = JAI.create("fileload", tifPath);// 读取tiff文件
			OutputStream os2 = new FileOutputStream(jpgFile.getPath()); // 文件存储输出流
			ImageEncodeParam param = new com.sun.media.jai.codec.JPEGEncodeParam();

			ImageEncoder enc2 = ImageCodec.createImageEncoder("JPEG", os2, param); // 指定输出格式
			enc2.encode(src2);// 解析输出流进行输出
			os2.close();

			ret = jpgFile.getPath();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return ret;
	}

	// public static String gifToJpg(String gifPath,String sFilePdf){
	// String ret = null;
	// try {
	// File jpgFile = new File(new
	// File(sFilePdf).getParent(),UUIDGenerator.getUUID()+".jpg");
	//
	// RenderedOp src2 = JAI.create("fileload", gifPath);//读取tiff文件
	// OutputStream os2 = new FileOutputStream(jpgFile.getPath()); //文件存储输出流
	// ImageEncodeParam param = new Gif;
	//
	// ImageEncoder enc2 = ImageCodec.createImageEncoder("JPEG", os2, param);
	// //指定输出格式
	// enc2.encode(src2 );//解析输出流进行输出
	// os2.close();
	//
	// ret = jpgFile.getPath();
	// } catch (Exception e) {
	// e.printStackTrace();
	// }
	//
	// return ret;
	// }

	public static void main(String[] args) {
		// String[] arr = new String[] { "d:/tif/1.tif", "d:/tif/5.tif",
		// "d:/tif/10.jpg", "d:/tif/20.gif" };// ,
		// "d:/tif/2.tif",

		List<String> list = new ArrayList<String>();
		list.add("d:/1.tif");
		list.add("d:/2.tif");
		// list.add("d:/tif/30.dwg");
		ImgToPdf.imgToPdf(list, "d:/tif/out.pdf");

		// ImgToPdf.convertToJpg("d:/tif/I0000-004074-001-001-002-002.gif","d:/tif/out.pdf");

		System.out.println("finish");
	}
}
