package com.spr.web.evaluate.dto.appeal;

import java.util.List;

import com.spr.core.common.dto.UUIDDTO;

public class EvaluateAppealDTO extends UUIDDTO {

	private String evaluateRecordId;

	private String content;

	private String replyUserId;

	private String replyUnitId;

	private String replyUnitName;

	private String targetUnitId;

	private Short status;

	private Short flag;

	private String createBy;

	private String updateBy;

	private String ucode;
	
	private Boolean isMine;
	
	List<EvaluateAppealFileDTO> files;

	/**
	 * @return the files
	 */
	public List<EvaluateAppealFileDTO> getFiles() {
		return files;
	}

	/**
	 * @param files the files to set
	 */
	public void setFiles(List<EvaluateAppealFileDTO> files) {
		this.files = files;
	}

	/**
	 * @return the isMine
	 */
	public Boolean getIsMine() {
		return isMine;
	}

	/**
	 * @param isMine the isMine to set
	 */
	public void setIsMine(Boolean isMine) {
		this.isMine = isMine;
	}

	public String getEvaluateRecordId() {
		return evaluateRecordId;
	}

	public void setEvaluateRecordId(String evaluateRecordId) {
		this.evaluateRecordId = evaluateRecordId == null ? null : evaluateRecordId.trim();
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content == null ? null : content.trim();
	}

	public String getReplyUserId() {
		return replyUserId;
	}

	public void setReplyUserId(String replyUserId) {
		this.replyUserId = replyUserId == null ? null : replyUserId.trim();
	}

	public String getReplyUnitId() {
		return replyUnitId;
	}

	public void setReplyUnitId(String replyUnitId) {
		this.replyUnitId = replyUnitId == null ? null : replyUnitId.trim();
	}

	public String getTargetUnitId() {
		return targetUnitId;
	}

	public void setTargetUnitId(String targetUnitId) {
		this.targetUnitId = targetUnitId == null ? null : targetUnitId.trim();
	}

	public Short getStatus() {
		return status;
	}

	public void setStatus(Short status) {
		this.status = status;
	}

	public Short getFlag() {
		return flag;
	}

	public void setFlag(Short flag) {
		this.flag = flag;
	}

	public String getCreateBy() {
		return createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy == null ? null : createBy.trim();
	}

	public String getUpdateBy() {
		return updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy == null ? null : updateBy.trim();
	}

	public String getReplyUnitName() {
		return replyUnitName;
	}

	public void setReplyUnitName(String replyUnitName) {
		this.replyUnitName = replyUnitName;
	}

	public String getUcode() {
		return ucode;
	}

	public void setUcode(String ucode) {
		this.ucode = ucode;
	}

}