package com.spr.web.api.service.impl;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Node;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.spr.core.common.service.BaseService;
import com.spr.core.gobal.GobalVal;
import com.spr.core.utils.DateUtil;
import com.spr.web.api.service.IReceiveDataService;
import com.spr.web.api.webservice.ProjdataUtils;
import com.spr.web.project.dao.IProjectInfoDao;
import com.spr.web.project.dao.IProjectPartInfoDao;
import com.spr.web.project.entity.ProjectInfo;
import com.spr.web.project.entity.ProjectPartInfo;
import com.spr.web.system.dao.IUnitDao;
import com.spr.web.system.dto.unit.UnitDTO;
import com.spr.web.system.entity.Unit;
import com.spr.web.system.service.IUnitService;
import com.spr.web.system.service.IUserService;

@Service("receiveDataService")
public class ReceiveDataServiceImpl extends BaseService implements IReceiveDataService {

	@Resource
	private IUnitService unitService;
	@Resource
	private IProjectInfoDao projectInfoDao;
	@Resource
	private IProjectPartInfoDao projectPartInfoDao;
	@Resource
	private IUnitDao unitDao;
	@Resource
	private IUserService userService;

	// 接收接口项目数据
	@Override
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public void receiveProjectData() {
		int totalNum = Integer.valueOf(handleProjectTotalNum());
		int pageSize = 20;
		int totalPage = totalNum / pageSize + 1;
		for (int i = 1; i <= totalPage; i++) {
			handleProjectData(String.valueOf(i), String.valueOf(pageSize));
		}

	}

	private void handleProjectData(String pageNum, String pageSize) {
		String projectData = ProjdataUtils.getProjectData("440304", pageNum, pageSize);

		Document proDoc = null;
		try {
			proDoc = DocumentHelper.parseText(projectData); // 将字符串转为XML

			Node proNode = proDoc.selectSingleNode("//Content");

			String proResptext = proNode.getText();

			// 我还得将这些文本转为xml对象 再通过xpath查找元素 取得标签里的值
			Document projectDoc = DocumentHelper.parseText(proResptext);

			Element rootEl = projectDoc.getRootElement(); // ProjectCodeServiceResponse
			Element formTemplate = rootEl.element("formTemplate"); // formTemplate
			Element projectsEl = formTemplate.element("projects");
			List<Element> projectList = projectsEl.elements("project");
			for (Element projectElement : projectList) {
				// 项目登记时间
				String registerTimeStr = projectElement.elementText("registerTime");
				Date dateLine = DateUtil.str2Date("2015-12-31");

				if (StringUtils.isNotBlank(registerTimeStr)) {
					Date registerTime = DateUtil.str2Date(registerTimeStr);
					// 只取16年以后项目
					if (registerTime.after(dateLine)) {

						// 插入项目信息
						String apiProId = projectElement.elementText("id");
						String buildNo = projectElement.elementText("proNumber"); // 项目编号
						String proName = projectElement.elementText("proName"); // 项目名称
						String proAddr = projectElement.elementText("projAddress"); // 项目地点
						String buildUnitCode = projectElement.elementText("constructioNnumber"); // 建设单位组织机构代码
						String buildUnitName = projectElement.elementText("constructionUnit"); // 建设单位
						String buildUnitLinkMan = projectElement.elementText("constructionPerson"); // 建设单位联系人
						String buildUnitLinkTel = projectElement.elementText("constructionPhone");// 建设单位联系人手机

						String buildUnitId = null;
						if (StringUtils.isNotBlank(buildUnitCode)) {
							UnitDTO buildUnit = this.unitDao.getDetailByOrganizationCode(buildUnitCode);
							if (buildUnit != null) {
								buildUnitId = buildUnit.getId();
							} else {
								// 单位不存在，新建建设单位
								Unit unit = new Unit();
								unit.setOrganizationCode(buildUnitCode);
								unit.setUnitName(buildUnitName);
								unit.setLinkMan(buildUnitLinkMan);
								unit.setLinkTel(buildUnitLinkTel);
								unit.setFlag(GobalVal.NORMAL_FLAG);
								unit.setStatus(GobalVal.STATUS_ENABLE);
								unit.setCreateBy(getNowUser().getUsername());
								this.unitDao.insert(unit);
								buildUnitId = unit.getId();

								this.userService.addUnitDefaultUser(buildUnitId, buildUnitCode, buildUnitLinkMan, "buildUnit");

							}
						}

						Element otherUnitEl = projectElement.element("otherUnit");
						Element unitEl = otherUnitEl.element("unit");

						String agentUnitCode = unitEl.elementText("constructioNnumber"); // 代建单位组织机构代码
						String agentUnitName = unitEl.elementText("constructionUnit"); // 代建单位
						String agentUnitLinkMan = unitEl.elementText("constructionPerson"); // 代建单位联系人
						String agentUnitLinkTel = unitEl.elementText("constructionPhone"); // 代建单位联系人手机

						String agentUnitId = null;
						if (StringUtils.isNotBlank(agentUnitCode)) {
							UnitDTO agentUnit = this.unitDao.getDetailByOrganizationCode(agentUnitCode);
							if (agentUnit != null) {
								agentUnitId = agentUnit.getId();
							} else {
								// 单位不存在，新建建设单位
								Unit unit = new Unit();
								unit.setOrganizationCode(agentUnitCode);
								unit.setUnitName(agentUnitName);
								unit.setLinkMan(agentUnitLinkMan);
								unit.setLinkTel(agentUnitLinkTel);
								unit.setFlag(GobalVal.NORMAL_FLAG);
								unit.setStatus(GobalVal.STATUS_ENABLE);
								unit.setCreateBy(getNowUser().getUsername());
								this.unitDao.insert(unit);
								agentUnitId = unit.getId();

								this.userService.addUnitDefaultUser(agentUnitId, agentUnitCode, agentUnitLinkMan, "agentUnit");
							}
						}

						String applyTime = projectElement.elementText("applyTime"); // 申请时间
						String investAmount = projectElement.elementText("totalInvestment"); // 总投资额
						String linkMan = projectElement.elementText("operator"); // 项目经办人
						String linkTel = projectElement.elementText("operatorPhone"); // 经办人电话

						ProjectInfo projectInfo = new ProjectInfo();
						projectInfo.setApiProId(apiProId);
						projectInfo.setBuildNo(buildNo);
						projectInfo.setProName(proName);
						projectInfo.setProAddr(proAddr);
						projectInfo.setBuildUnitId(buildUnitId);
						projectInfo.setAgentUnitId(agentUnitId);
						projectInfo.setRegisterTime(registerTime);
						projectInfo.setApplyTime(StringUtils.isNotBlank(applyTime) ? DateUtil.str2Date(applyTime) : null);
						if (StringUtils.isNotBlank(investAmount)) {
							projectInfo.setInvestAmount(new BigDecimal(investAmount));
						}
						projectInfo.setLinkMan(linkMan);
						projectInfo.setLinkTel(linkTel);
						projectInfo.setGmtInput(new Date());
						projectInfo.setSrcFlag(ProjectInfo.INTERFACE_SRC); // 接口来源
						projectInfo.setStatus(GobalVal.STATUS_ENABLE);
						projectInfo.setFlag(GobalVal.NORMAL_FLAG);
						projectInfo.setCreateBy(getNowUser().getUsername());

						System.out.println("项目：[" + projectInfo.getProName() + "],登记时间:" + registerTimeStr + ",接收成功");

						this.projectInfoDao.insert(projectInfo);

						// 插入工程信息
						handleEngData(projectInfo.getId(), apiProId);

					}
				}

				System.out.println(projectElement.elementText("proName"));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void handleEngData(String proId, String apiProId) {
		String engData = ProjdataUtils.getEngData(apiProId);

		Document doc = null;
		try {
			doc = DocumentHelper.parseText(engData); // 将字符串转为XML

			Node engNode = doc.selectSingleNode("//Content");

			if (engNode != null) {
				String engResptext = engNode.getText();
				if (StringUtils.isNotBlank(engResptext)) {
					// 将这些文本转为xml对象
					Document engDoc = DocumentHelper.parseText(engResptext);

					Element rootEl = engDoc.getRootElement(); // ProjectCodeServiceResponse
					Element formTemplate = rootEl.element("formTemplate"); // formTemplate

					Element engsEl = formTemplate.element("engineerings");
					List<Element> engList = engsEl.elements("engineering");

					for (Element engElement : engList) {

						String apiEngId = engElement.elementText("id");
						String engNo = engElement.elementText("engNumber"); // 工程编号
						String engName = engElement.elementText("engName"); // 工程名称
						String engAddr = engElement.elementText("engAddress"); // 工程地点
						String startTime = engElement.elementText("startTime"); // 开工时间
						String finishTime = engElement.elementText("finishTime"); // 竣工时间
						String registerTime = engElement.elementText("registerTime"); // 登记时间

						ProjectPartInfo projectPartInfo = new ProjectPartInfo();
						projectPartInfo.setApiEngId(apiEngId);
						projectPartInfo.setApiProId(apiProId);
						projectPartInfo.setProId(proId);
						projectPartInfo.setPartNo(engNo);
						projectPartInfo.setPartName(engName);
						projectPartInfo.setPartAddress(engAddr);
						projectPartInfo.setStartTime(StringUtils.isNotBlank(startTime) ? DateUtil.str2Date(startTime) : null);
						projectPartInfo.setEndTime(StringUtils.isNotBlank(finishTime) ? DateUtil.str2Date(finishTime) : null);
						projectPartInfo.setRegisterTime(StringUtils.isNotBlank(registerTime) ? DateUtil.str2Date(registerTime) : null);
						projectPartInfo.setStatus(GobalVal.STATUS_ENABLE);
						projectPartInfo.setFlag(GobalVal.NORMAL_FLAG);
						projectPartInfo.setCreateBy(getNowUser().getUsername());

						String surveyCode = engElement.elementText("surveyCode"); // 勘察单位组织机构代码
						String designCode = engElement.elementText("designCode"); // 设计单位组织机构代码
						String supervisionCode = engElement.elementText("supervisionCode"); // 监理单位
						String constructionOrgCode = engElement.elementText("constructionOrgCode"); // 施工单位组织机构代码

						// 插入工程信息
						if (StringUtils.isNotBlank(surveyCode)) {
							// 勘察
							String survey = engElement.elementText("survey"); // 勘察单位
							String surveyPrincipal = engElement.elementText("surveyPrincipal"); // 负责人
							String surveyPrincipalPhone = engElement.elementText("surveyPrincipalPhone"); // 联系方式
							String contractorUnitId = this.unitService
									.getOrAddUnitByOrganizationCode(surveyCode, survey, surveyPrincipal, surveyPrincipalPhone);
							projectPartInfo.setContractorUnitId(contractorUnitId);
							projectPartInfo.setLinkMan(surveyPrincipal);
							projectPartInfo.setLinkTel(surveyPrincipalPhone);
							projectPartInfo.setEngTypeCode("KC");
							this.projectPartInfoDao.insert(projectPartInfo);
							System.out.println("工程：[" + projectPartInfo.getPartName() + "],登记时间:" + projectPartInfo.getRegisterTime() + ",接收成功");

						}
						if (StringUtils.isNotBlank(designCode)) {
							// 设计
							String design = engElement.elementText("design"); // 设计单位
							String designPrincipal = engElement.elementText("designPrincipal"); // 负责人
							String designPrincipalPhone = engElement.elementText("designPrincipalPhone"); // 联系方式
							String contractorUnitId = this.unitService
									.getOrAddUnitByOrganizationCode(designCode, design, designPrincipal, designPrincipalPhone);
							projectPartInfo.setContractorUnitId(contractorUnitId);
							projectPartInfo.setLinkMan(designPrincipal);
							projectPartInfo.setLinkTel(designPrincipalPhone);
							projectPartInfo.setEngTypeCode("SJ");
							this.projectPartInfoDao.insert(projectPartInfo);
							System.out.println("工程：[" + projectPartInfo.getPartName() + "],登记时间:" + projectPartInfo.getRegisterTime() + ",接收成功");
						}
						if (StringUtils.isNotBlank(supervisionCode)) {
							// 监理
							String supervision = engElement.elementText("supervision"); // 监理单位
							String supervisionDirector = engElement.elementText("supervisionDirector"); // 项目总监
							String supervisionDirectorPhone = engElement.elementText("supervisionDirectorPhone"); // 联系方式

							String contractorUnitId = this.unitService.getOrAddUnitByOrganizationCode(supervisionCode, supervision, supervisionDirector,
									supervisionDirectorPhone);
							projectPartInfo.setContractorUnitId(contractorUnitId);
							projectPartInfo.setLinkMan(supervisionDirector);
							projectPartInfo.setLinkTel(supervisionDirectorPhone);
							projectPartInfo.setEngTypeCode("JL");
							this.projectPartInfoDao.insert(projectPartInfo);
							System.out.println("工程：[" + projectPartInfo.getPartName() + "],登记时间:" + projectPartInfo.getRegisterTime() + ",接收成功");
						}
						if (StringUtils.isNotBlank(constructionOrgCode)) {
							// 施工
							String constructionOrg = engElement.elementText("constructionOrg"); // 施工单位
							String constructionOrgManager = engElement.elementText("constructionOrgManager"); // 项目经理
							String constructionOrgManagerPhone = engElement.elementText("constructionOrgManagerPhone"); // 联系方式

							String contractorUnitId = this.unitService.getOrAddUnitByOrganizationCode(constructionOrgCode, constructionOrg,
									constructionOrgManager, constructionOrgManagerPhone);
							projectPartInfo.setContractorUnitId(contractorUnitId);
							projectPartInfo.setLinkMan(constructionOrgManager);
							projectPartInfo.setLinkTel(constructionOrgManagerPhone);
							projectPartInfo.setEngTypeCode("SG");
							this.projectPartInfoDao.insert(projectPartInfo);
							System.out.println("工程：[" + projectPartInfo.getPartName() + "],登记时间:" + projectPartInfo.getRegisterTime() + ",接收成功");
						}
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private String handleProjectTotalNum() {
		String totalNum = "0";
		String projectData = ProjdataUtils.getProjectTotalNum("440304");
		Document proDoc = null;
		try {
			proDoc = DocumentHelper.parseText(projectData); // 将字符串转为XML

			Node proNode = proDoc.selectSingleNode("//Content");

			String proResptext = proNode.getText();

			// 我还得将这些文本转为xml对象 再通过xpath查找元素 取得标签里的值
			Document projectDoc = DocumentHelper.parseText(proResptext);

			Element rootEl = projectDoc.getRootElement(); // ProjectCodeServiceResponse
			Element formTemplate = rootEl.element("formTemplate"); // formTemplate
			totalNum = formTemplate.elementText("total");

		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("项目总记录数为:" + totalNum);
		return totalNum;
	}

}
