package com.spr.web.flow.service;

import java.util.List;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.web.flow.dto.exec.ExecNodeDTO;

public interface IExecNodeService {

	Page<ExecNodeDTO> searchByPage(DataQuery dq);

	ExecNodeDTO getDetailById(String id);

	void addExecNode(ExecNodeDTO dto);

	void updateExecNode(ExecNodeDTO dto);

	void deleteExecNodes(String[] ids);

	String startProcess(String procCode, String dataId, List<String> allotUserIds);

	List<ExecNodeDTO> getStraightStructureProccess(String procInstId, String userId);

	void handleFailNode(String nodeId, String handlerId, String content);

	void handleSuccessNode(String nodeId, String content, String handlerId, List<String> allotUserIds);

	void deleteProcessByProcInstId(String procInstId);

	void activeProcess(String procInstId, List<String> allotUserIds);

	ExecNodeDTO getCurrNodeByDateId(String id);

	ExecNodeDTO getNextNode(ExecNodeDTO currNode);

	void restartProcess(String dataId, String auditor);

	void deleteProcessByDataId(String dataId);

	void saveRecord(String nodeId, String note);

}
