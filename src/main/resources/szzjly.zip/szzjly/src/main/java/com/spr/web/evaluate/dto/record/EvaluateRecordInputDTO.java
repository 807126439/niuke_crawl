package com.spr.web.evaluate.dto.record;

import java.math.BigDecimal;

import com.spr.core.common.dto.UUIDDTO;
import com.spr.web.evaluate.dto.form.EvaluateFormIndexDTO;

public class EvaluateRecordInputDTO extends UUIDDTO {
	public static final Byte MODIFIED_FALSE = Byte.parseByte("0");
	public static final Byte MODIFIED_TRUE = Byte.parseByte("1");

	private String evalId;

	private String formId;

	private String indexId;

	private BigDecimal inputVal;

	private BigDecimal orginalVal;

	private Byte isModified;

	private Short status;

	private String createBy;

	private String updateBy;

	private EvaluateFormIndexDTO index;

	/**
	 * @return the index
	 */
	public EvaluateFormIndexDTO getIndex() {
		return index;
	}

	/**
	 * @param index
	 *            the index to set
	 */
	public void setIndex(EvaluateFormIndexDTO index) {
		this.index = index;
	}

	public String getEvalId() {
		return evalId;
	}

	public void setEvalId(String evalId) {
		this.evalId = evalId == null ? null : evalId.trim();
	}

	public String getFormId() {
		return formId;
	}

	public void setFormId(String formId) {
		this.formId = formId == null ? null : formId.trim();
	}

	public String getIndexId() {
		return indexId;
	}

	public void setIndexId(String indexId) {
		this.indexId = indexId == null ? null : indexId.trim();
	}

	public BigDecimal getInputVal() {
		return inputVal;
	}

	public void setInputVal(BigDecimal inputVal) {
		this.inputVal = inputVal;
	}

	public BigDecimal getOrginalVal() {
		return orginalVal;
	}

	public void setOrginalVal(BigDecimal orginalVal) {
		this.orginalVal = orginalVal;
	}

	public Byte getIsModified() {
		return isModified;
	}

	public void setIsModified(Byte isModified) {
		this.isModified = isModified;
	}

	public Short getStatus() {
		return status;
	}

	public void setStatus(Short status) {
		this.status = status;
	}

	public String getCreateBy() {
		return createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy == null ? null : createBy.trim();
	}

	public String getUpdateBy() {
		return updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy == null ? null : updateBy.trim();
	}
}