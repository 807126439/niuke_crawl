package com.spr.web.flow.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.service.BaseService;
import com.spr.core.common.utils.Assert;
import com.spr.web.flow.dao.IExecCommentDao;
import com.spr.web.flow.dto.exec.ExecCommentDTO;
import com.spr.web.flow.entity.ExecComment;
import com.spr.web.flow.service.IExecCommentService;

@Service("execCommentService")
@Transactional
public class ExecCommentServiceImpl extends BaseService implements IExecCommentService {

	@Resource
	private IExecCommentDao execCommentDao;

	/**
	 * 分页查询
	 * 
	 * @param dq
	 */
	@Override
	public Page<ExecCommentDTO> searchByPage(DataQuery dq) {

		Long recTotal = this.execCommentDao.countByCondition(dq.assemblePageOffset().getQueryMap());
		dq.assembleOrderInfo(ExecComment.class, null);
		List<ExecCommentDTO> resultlist = this.execCommentDao.selectListByCondition(dq.getQueryMap());

		return new Page<ExecCommentDTO>(dq.getCurrentPage(), dq.getPageSize(), resultlist, recTotal);
	}

	/**
	 * 查询详细
	 * 
	 * @param id
	 */
	@Override
	public ExecCommentDTO getDetailById(String id) {
		Assert.hasText(id, Assert.NULL_PARAM_STR("id"));

		ExecCommentDTO result = this.execCommentDao.getDetailById(id);
		Assert.notNull(result, Assert.EMPTY_REOCRD_STR);

		return result;
	}

	/**
	 * 添加
	 * 
	 * @param dto
	 */
	@Override
	public void addExecComment(ExecCommentDTO dto) {

		ExecComment model = new ExecComment();
		model.setProcInstId(dto.getProcInstId());
		model.setProcNodeId(dto.getProcNodeId());
		model.setUserId(dto.getUserId());
		model.setType(dto.getType());
		model.setContent(dto.getContent());
		model.setNote(dto.getNote());
		model.setStatus(ExecComment.DEF_STATUS);
		model.setCreateBy(getNowUser().getUsername());

		this.execCommentDao.insert(model);

		if (this.logger.isInfoEnabled()) {
			this.logger.info("Add: " + model.toString());
		}
	}

	/**
	 * 修改
	 * 
	 * @param dto
	 */
	@Override
	public void updateExecComment(ExecCommentDTO dto) {
		Assert.hasText(dto.getId(), Assert.NULL_PARAM_STR("id"));

		ExecComment model = this.execCommentDao.getById(dto.getId());
		Assert.notNull(model, Assert.EMPTY_REOCRD_STR);

		model.setProcInstId(dto.getProcInstId());
		model.setProcNodeId(dto.getProcNodeId());
		model.setUserId(dto.getUserId());
		model.setType(dto.getType());
		model.setContent(dto.getContent());
		model.setNote(dto.getNote());
		model.setStatus(dto.getStatus());
		model.setCreateBy(dto.getCreateBy());
		model.setUpdateBy(dto.getUpdateBy());
		model.setGmtCreate(dto.getGmtCreate());
		model.setGmtModified(dto.getGmtModified());

		this.execCommentDao.update(model);

		if (this.logger.isInfoEnabled()) {
			this.logger.info("Update: " + model.toString());
		}
	}

	/**
	 * 删除
	 * 
	 * @param ids
	 */
	@Override
	public void deleteExecComments(String[] ids) {
		for (int i = 0; i < ids.length; i++) {
			this.execCommentDao.deleteById(ids[i]);

			if (this.logger.isInfoEnabled()) {
				this.logger.info("Delete：:" + ids[i]);
			}
		}
	}

}
