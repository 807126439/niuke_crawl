/**
 * 
 */
package com.spr.core.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

/**
 * @date 2019-4-12
 * @author wanve_java_cjy
 *
 */
@Configuration
@EnableAspectJAutoProxy
@ComponentScan(basePackages = {"com.spr.core.aspect"})
public class AspectConfig {
}
