package com.spr.web.evaluate.service;

import java.util.List;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.web.evaluate.dto.form.EvaluateFormIndexDTO;

public interface IEvaluateFormIndexService {

	EvaluateFormIndexDTO selectOneByCondition(DataQuery dq);

	List<EvaluateFormIndexDTO> selectListByCondition(DataQuery dq);

	Page<EvaluateFormIndexDTO> searchByPage(DataQuery dq);

	EvaluateFormIndexDTO getDetailById(String id);

	EvaluateFormIndexDTO getTitleByParentId(String parentId);

	void addEvaluateFormIndex(EvaluateFormIndexDTO dto);

	void updateEvaluateFormIndex(EvaluateFormIndexDTO dto);

	void deleteEvaluateFormIndexs(String[] ids);

	void deleteEvaluateFormIndexsByCondition(DataQuery dq);

	List<EvaluateFormIndexDTO> getSubIndexList(DataQuery dq, String parentId);

	List<EvaluateFormIndexDTO> getEvaluateFormIndexTreeData(String parentId, Boolean isFormId);

}
