/**
 * 
 */
package com.spr.core.config;

import java.util.concurrent.ThreadPoolExecutor;

import javax.annotation.Resource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

/**
 * @date 2019-4-12
 * @author wanve_java_cjy
 *
 */
@Configuration
@PropertySource("classpath:thread.properties")
public class ThreadPoolConfig {
	
	@Resource
	private Environment env;  
	
	@Bean
	public TaskExecutor taskExecutor() {		
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		executor.setCorePoolSize(corePoolSize());
        executor.setKeepAliveSeconds(keepAliveSeconds());
        executor.setMaxPoolSize(maxPoolSize());
        executor.setQueueCapacity(queueCapacity());
        ThreadPoolExecutor.CallerRunsPolicy callerRunsPolicy = new ThreadPoolExecutor.CallerRunsPolicy();
        //对拒绝task的处理策略
        executor.setRejectedExecutionHandler(callerRunsPolicy);
		executor.initialize();
		return executor;
	}
	
	private int corePoolSize() {
		return Integer.parseInt(env.getProperty("core_pool_size"));
	}
	
	private int keepAliveSeconds() {
		return Integer.parseInt(env.getProperty("keep_alive_seconds"));
	}
	
	private int maxPoolSize() {
		return Integer.parseInt(env.getProperty("max_pool_size"));
	}
	
	private int queueCapacity() {
		return Integer.parseInt(env.getProperty("queue_capacity"));
	}
}
