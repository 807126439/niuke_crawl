package com.spr.web.system.dao;

import java.util.List;
import java.util.Map;

import com.spr.core.common.dao.IBaseDao;
import com.spr.web.system.dto.unit.UnitEvaluatorRelationDTO;
import com.spr.web.system.entity.UnitEvaluatorRelation;

public interface IUnitEvaluatorRelationDao extends IBaseDao<String, UnitEvaluatorRelation> {

	Long countByCondition(Map<String, Object> queryMap);

	List<UnitEvaluatorRelationDTO> selectListByCondition(Map<String, Object> queryMap);

	UnitEvaluatorRelationDTO getDetailById(String id);

	void deleteByUnitId(String unitId);
}