package com.spr.web.project.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.spr.core.common.bean.AjaxJson;
import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.controller.BaseController;
import com.spr.core.common.dto.ZtreeDTO;
import com.spr.web.project.dto.project.ProjectInfoDTO;
import com.spr.web.project.service.IProjectInfoService;
import com.spr.web.system.service.IRoleService;

@Controller
@Scope("prototype")
@RequestMapping("/projectInfoController")
public class ProjectInfoController extends BaseController {

	private static final long serialVersionUID = 1L;

	@Resource
	private IProjectInfoService projectInfoService;
	@Resource
	private IRoleService roleService;

	/**
	 * 住建局项目信息页
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/viewPageAdminUnit", method = { RequestMethod.GET })
	public String viewPageAdminUnit(HttpServletRequest request) {
		this.wrapMenuTitle(request);
		return "project/projectInfo/list/adminProjectInfoList.jsp";
	}

	/**
	 * 建设单位项目信息页
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/viewPageBuildUnit", method = { RequestMethod.GET })
	public String viewPageBuildUnit(HttpServletRequest request) {
		this.wrapMenuTitle(request);
		request.setAttribute("buildUnitId", getNowUser().getUnitId());
		return "project/projectInfo/list/buildUnitProjectInfoList.jsp";
	}

	/**
	 * 代建单位项目信息页
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/viewPageAgentUnit", method = { RequestMethod.GET })
	public String viewPageAgentUnit(HttpServletRequest request) {
		this.wrapMenuTitle(request);
		request.setAttribute("agentUnitId", getNowUser().getUnitId());
		return "project/projectInfo/list/agentUnitProjectInfoList.jsp";
	}

	@RequestMapping(value = "/getPageData", method = { RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> loadPageData(HttpServletRequest request, DataQuery dq, String proType, String buildNo, String proName, String buildUnitId,
			String agentUnitId) {
		this.wrapTableQueryParams(request, dq);
		dq.putToMap("buildUnitId", StringUtils.isNotBlank(buildUnitId) ? buildUnitId : null);
		dq.putToMap("agentUnitId", StringUtils.isNotBlank(agentUnitId) ? agentUnitId : null);
		dq.putToMap("buildNo", StringUtils.isNotBlank(buildNo) ? buildNo : null);
		dq.putToMap("proName", StringUtils.isNotBlank(proName) ? "%" + proName + "%" : null);
		if (StringUtils.isNotBlank(proType)) {
			if ("agentPro".equals(proType)) {
				// 代建项目
				dq.putToMap("agentPro", true);
			}
			if ("notAgentPro".equals(proType)) {
				// 非代建项目
				dq.putToMap("notAgentPro", true);
			}
		}
		Page<ProjectInfoDTO> pageResult = this.projectInfoService.searchByPage(dq);
		return this.handlePageReult(pageResult);
	}

	/**
	 * 跳转导入页面
	 * 
	 * @param request
	 * @return
	 */

	@RequestMapping(value = "/skipAddProjectInfo")
	public String skipAddProjectInfo(HttpServletRequest request) {

		request.setAttribute("nowUnitId", getNowUser().getUnitId());
		request.setAttribute("nowUnitName", getNowUser().getUnitName());

		return "project/projectInfo/addProjectInfo.jsp";
	}

	@RequestMapping(value = "/addProjectInfo", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson addProjectInfo(ProjectInfoDTO dto) {

		this.projectInfoService.addProjectInfo(dto);
		return new AjaxJson(this.ADD_SUCCESS_MESSAGE, AjaxJson.success);
	}

	/**
	 * 跳转导入页面
	 * 
	 * @param request
	 * @return
	 */

	@RequestMapping(value = "/skipImportProjectInfo")
	public String skipImportProjectInfo() {
		return "project/projectInfo/importProjectInfo.jsp";
	}

	/**
	 * Excel导入项目信息
	 * 
	 * @param file
	 * @return
	 */
	@RequestMapping(value = "/importProjectInfo", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson importProjectInfo(@RequestParam(required = true, value = "file") CommonsMultipartFile file) {
		try {
			String result = this.projectInfoService.importProjectInfo(file);
			return new AjaxJson(result, AjaxJson.success);
		} catch (Exception e) {

			return new AjaxJson(e.getMessage(), AjaxJson.error);
		}
	}

	@RequestMapping("/getDetail")
	public String loadDetail(HttpServletRequest request, @RequestParam(value = "id", required = true) String id) {

		ProjectInfoDTO result = this.projectInfoService.getDetailById(id);
		request.setAttribute("model", result);
		return "project/projectInfo/editProjectInfo.jsp";
	}

	@RequestMapping(value = "/editProjectInfo", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson updateProjectInfo(ProjectInfoDTO dto) {

		this.projectInfoService.updateProjectInfo(dto);
		return new AjaxJson(this.EDIT_SUCCESS_MESSAGE, AjaxJson.success);
	}

	/**
	 * 跳转查看页面
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/skipCheckProjectInfo")
	public String skipCheckProjectInfo(HttpServletRequest request, @RequestParam(value = "id", required = true) String id) {
		ProjectInfoDTO result = this.projectInfoService.getDetailById(id);
		request.setAttribute("model", result);
		return "project/projectInfo/checkProjectInfo.jsp";
	}

	/**
	 * 跳转选择项目页面
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/skipProjectInfoTree")
	public String skipProjectInfoTree(HttpServletRequest request) {

		return "project/projectInfo/selectProject.jsp";
	}

	/**
	 * 获取项目数据
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/getProjectInfoTreeData")
	@ResponseBody
	public List<ZtreeDTO> getProjectInfoTreeData(HttpServletRequest request) {
		return this.projectInfoService.getProjectInfoTreeData();
	}

	@RequestMapping(value = "/deleteProjectInfo", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson deleteProjectInfo(String[] ids) {

		this.projectInfoService.deleteProjectInfos(ids);

		return new AjaxJson(this.DEL_SUCCESS_MESSAGE, AjaxJson.success);
	}
}
