package com.spr.web.flow.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spr.core.common.bean.AjaxJson;
import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.controller.BaseController;
import com.spr.web.flow.constant.DefinitionCodeConsts;
import com.spr.web.flow.dto.def.ProcDefDTO;
import com.spr.web.flow.service.IProcDefService;

@Controller
@Scope("prototype")
@RequestMapping("/procDefController")
public class ProcDefController extends BaseController {

	private static final long serialVersionUID = 1L;

	@Resource
	private IProcDefService procDefService;

	@RequestMapping(value = "/viewPage", method = { RequestMethod.GET })
	public String viewPage(HttpServletRequest request) {
		this.wrapMenuTitle(request);

		return "flow/procDef/procDefList.jsp";
	}

	@RequestMapping(value = "/getPageData", method = { RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> loadPageData(HttpServletRequest request, DataQuery dq, String procdefName, String procdefCode) {

		this.wrapTableQueryParams(request, dq);

		dq.putToMap("unitId", this.getNowUser().getUnitId());
		dq.putToMap("procdefName", StringUtils.isBlank(procdefName) ? null : "%" + procdefName + "%");
		dq.putToMap("procdefCode", StringUtils.isBlank(procdefCode) ? null : "%" + procdefCode + "%");
		Page<ProcDefDTO> pageResult = this.procDefService.searchByPage(dq);

		return this.handlePageReult(pageResult);
	}

	@RequestMapping(value = "/skipAddProcDef")
	public String skipAddProcDef(HttpServletRequest request) {

		List<DefinitionCodeConsts> list = procDefService.getProcDefCode(null);
		request.setAttribute("codes", list);

		return "flow/procDef/addProcDef.jsp";
	}

	@RequestMapping(value = "/addProcDef", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson addProcDef(ProcDefDTO dto) throws Exception {

		this.procDefService.addProcDef(dto);

		return new AjaxJson(this.ADD_SUCCESS_MESSAGE, AjaxJson.success);
	}

	@RequestMapping("/getDetail")
	public String loadDetail(HttpServletRequest request, @RequestParam(value = "id", required = true) String id) {

		ProcDefDTO result = this.procDefService.getDetailById(id);
		String mycode = result.getProcessCode();
		List<DefinitionCodeConsts> list = procDefService.getProcDefCode(mycode);
		request.setAttribute("model", result);
		request.setAttribute("codes", list);

		return "flow/procDef/editProcDef.jsp";
	}

	@RequestMapping(value = "/editProcDef", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson updateProcDef(ProcDefDTO dto) {

		this.procDefService.updateProcDef(dto);

		return new AjaxJson(this.EDIT_SUCCESS_MESSAGE, AjaxJson.success);
	}

	@RequestMapping(value = "/deleteProcDef", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson deleteProcDef(String[] ids) {

		this.procDefService.deleteProcDefs(ids);

		return new AjaxJson(this.DEL_SUCCESS_MESSAGE, AjaxJson.success);
	}

}
