package com.spr.web.evaluate.entity;

import com.spr.core.annotations.DbField;
import com.spr.core.common.entity.UUIDEntity;
import java.io.Serializable;

public class EvaluateContractorRelation extends UUIDEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer sortNo;

    private String contractorTypeCode;

    private String evalFormId;

    private Short evalWay;

    private Short status;

    private String createBy;

    private String updateBy;

    @DbField(name="sort_no")
    public Integer getSortNo() {
        return sortNo;
    }

    public void setSortNo(Integer sortNo) {
        this.sortNo = sortNo;
    }

    @DbField(name="contractor_type_code")
    public String getContractorTypeCode() {
        return contractorTypeCode;
    }

    public void setContractorTypeCode(String contractorTypeCode) {
        this.contractorTypeCode = contractorTypeCode == null ? null : contractorTypeCode.trim();
    }

    @DbField(name="eval_form_id")
    public String getEvalFormId() {
        return evalFormId;
    }

    public void setEvalFormId(String evalFormId) {
        this.evalFormId = evalFormId == null ? null : evalFormId.trim();
    }

    @DbField(name="eval_way")
    public Short getEvalWay() {
        return evalWay;
    }

    public void setEvalWay(Short evalWay) {
        this.evalWay = evalWay;
    }

    @DbField(name="status")
    public Short getStatus() {
        return status;
    }

    public void setStatus(Short status) {
        this.status = status;
    }

    @DbField(name="create_by")
    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    @DbField(name="update_by")
    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(",Super = ").append(super.toString());
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append(", sortNo=").append(sortNo);
        sb.append(", contractorTypeCode=").append(contractorTypeCode);
        sb.append(", evalFormId=").append(evalFormId);
        sb.append(", evalWay=").append(evalWay);
        sb.append(", status=").append(status);
        sb.append(", createBy=").append(createBy);
        sb.append(", updateBy=").append(updateBy);
        sb.append("]");
        return sb.toString();
    }
}