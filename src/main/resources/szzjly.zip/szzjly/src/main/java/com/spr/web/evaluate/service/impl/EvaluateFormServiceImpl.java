package com.spr.web.evaluate.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.dto.ZtreeDTO;
import com.spr.core.common.service.BaseService;
import com.spr.core.common.utils.Assert;
import com.spr.web.evaluate.dao.IEvaluateFormDao;
import com.spr.web.evaluate.dto.form.EvaluateFormDTO;
import com.spr.web.evaluate.dto.form.EvaluateFormIndexDTO;
import com.spr.web.evaluate.entity.EvaluateForm;
import com.spr.web.evaluate.service.IEvaluateFormIndexService;
import com.spr.web.evaluate.service.IEvaluateFormService;
import com.spr.web.evaluate.service.IEvaluateRecordService;
import com.spr.web.system.dto.engineering.EngineeringTypeDTO;
import com.spr.web.system.service.IContractorTypeService;
import com.spr.web.system.service.IEngineeringTypeService;

@Service("evaluateFormService")
@Transactional
public class EvaluateFormServiceImpl extends BaseService implements IEvaluateFormService {

	@Resource
	private IEvaluateFormDao evaluateFormDao;
	@Resource
	private IEvaluateFormIndexService evaluateFormIndexService;
	@Resource
	private IEvaluateRecordService evaluateRecordService;
	@Resource
	private IContractorTypeService contractorTypeService;
	@Resource
	private IEngineeringTypeService engineeringTypeService;

	@Override
	public EvaluateFormDTO selectOneByCondition(DataQuery dq) {
		dq.setPageSize(1);
		List<EvaluateFormDTO> resultlist = this.selectListByCondition(dq);
		if (resultlist == null || resultlist.isEmpty()) {
			return null;
		}
		return resultlist.get(0);
	}

	@Override
	public List<EvaluateFormDTO> selectListByCondition(DataQuery dq) {
		dq.assemblePageOffset();
		dq.assembleOrderInfo(EvaluateForm.class, null);
		List<EvaluateFormDTO> resultlist = this.evaluateFormDao.selectListByCondition(dq.getQueryMap());
		return resultlist;
	}

	/**
	 * 分页查询
	 * 
	 * @param dq
	 */
	@Override
	public Page<EvaluateFormDTO> searchByPage(DataQuery dq) {
		Long recTotal = this.evaluateFormDao.countByCondition(dq.assemblePageOffset().getQueryMap());
		dq.assembleOrderInfo(EvaluateForm.class, null);
		List<EvaluateFormDTO> resultlist = this.evaluateFormDao.selectListByCondition(dq.getQueryMap());

		this.initListText(resultlist);
		return new Page<EvaluateFormDTO>(dq.getCurrentPage(), dq.getPageSize(), resultlist, recTotal);
	}

	private void initListText(List<EvaluateFormDTO> list) {
		DataQuery dq = new DataQuery();
		dq.clear();
		dq.setNotQueryPage();
		dq.setSidx("sortNo");
		dq.setSord("asc");
		Map<String, String> engCodeNameMap = this.engineeringTypeService.selectCodeNameMapByCondition(dq);

		for (EvaluateFormDTO dto : list) {
			dto.setEngTypeName(engCodeNameMap.get(dto.getEngTypeCode()));
			// dto.setStatusText(EvaluateFormDTO.STATUS_MAP.get(dto.getStatus()));
		}
	}

	/**
	 * 查询详细
	 * 
	 * @param id
	 */
	@Override
	public EvaluateFormDTO getDetailById(String id) {
		Assert.hasText(id, Assert.NULL_PARAM_STR("id"));

		EvaluateFormDTO result = this.evaluateFormDao.getDetailById(id);
		Assert.notNull(result, Assert.EMPTY_REOCRD_STR);

		DataQuery dq = new DataQuery();
		dq.putToMap("parentId", id);
		EvaluateFormIndexDTO index = this.evaluateFormIndexService.selectOneByCondition(dq);
		result.setIndex(index);

		return result;
	}

	/**
	 * 添加
	 * 
	 * @param dto
	 */
	@Override
	public void addEvaluateForm(EvaluateFormDTO dto) {

		EvaluateForm model = new EvaluateForm();
		model.setSortNo(dto.getSortNo());
		model.setFormName(dto.getFormName());
		model.setEngTypeCode(dto.getEngTypeCode());
		model.setFormType(dto.getFormType());
		model.setMemo(dto.getMemo());
		model.setStatus(dto.getStatus());
		model.setFlag(dto.getFlag());
		model.setCreateBy(this.getNowUser().getUsername());
		model.setUpdateBy(this.getNowUser().getUsername());
		model.setGmtCreate(new Date());
		model.setGmtModified(new Date());

		this.evaluateFormDao.insert(model);

		this.writeInfoLog("Add: " + model.toString());

	}

	/**
	 * 添加
	 * 
	 * @param dto
	 */
	@Override
	public void addEvaluateForm(EvaluateFormDTO dto, EvaluateFormIndexDTO index) {

		EvaluateForm model = new EvaluateForm();
		model.setSortNo(dto.getSortNo());
		model.setFormName(dto.getFormName());
		model.setEngTypeCode(dto.getEngTypeCode());
		model.setFormType(dto.getFormType());
		model.setMemo(dto.getMemo());
		// if (dto.getStatus() == null || dto.getStatus() ==
		// EvaluateFormDTO.STATUS_DISABLE) {
		// model.setStatus(EvaluateFormDTO.STATUS_DISABLE);
		// } else {
		// // 清空其他启用状态
		// EvaluateForm entity = new EvaluateForm();
		// entity.setStatus(EvaluateFormDTO.STATUS_DISABLE);
		// entity.setUpdateBy(this.getNowUser().getUsername());
		// entity.setGmtModified(new Date());
		// entity.setEngTypeCode(dto.getEngTypeCode());
		// this.evaluateFormDao.updateStatus(entity);
		//
		// model.setStatus(EvaluateFormDTO.STATUS_ENABLE);
		// }
		model.setStatus(dto.getStatus());
		model.setFlag(dto.getFlag());
		model.setCreateBy(this.getNowUser().getUsername());
		model.setUpdateBy(this.getNowUser().getUsername());
		model.setGmtCreate(new Date());
		model.setGmtModified(new Date());

		this.evaluateFormDao.insert(model);

		// 添加指标标题
		index.setParentId(model.getId());
		index.setLevel(EvaluateFormIndexDTO.LEVEL_START);
		this.evaluateFormIndexService.addEvaluateFormIndex(index);

		this.writeInfoLog("Add: " + model.toString());

	}

	/**
	 * 修改
	 * 
	 * @param dto
	 */
	@Override
	public void updateEvaluateForm(EvaluateFormDTO dto) {
		Assert.hasText(dto.getId(), Assert.NULL_PARAM_STR("id"));

		EvaluateForm model = this.evaluateFormDao.getById(dto.getId());
		Assert.notNull(model, Assert.EMPTY_REOCRD_STR);

		model.setSortNo(dto.getSortNo());
		model.setFormName(dto.getFormName());
		model.setEngTypeCode(dto.getEngTypeCode());
		model.setFormType(dto.getFormType());
		model.setMemo(dto.getMemo());
		// if (dto.getStatus() == null || dto.getStatus() ==
		// EvaluateFormDTO.STATUS_DISABLE) {
		// model.setStatus(EvaluateFormDTO.STATUS_DISABLE);
		// } else {
		// // 清空其他启用状态
		// EvaluateForm entity = new EvaluateForm();
		// entity.setStatus(EvaluateFormDTO.STATUS_DISABLE);
		// entity.setUpdateBy(this.getNowUser().getUsername());
		// entity.setGmtModified(new Date());
		// entity.setEngTypeCode(dto.getEngTypeCode());
		// this.evaluateFormDao.updateStatus(entity);
		//
		// model.setStatus(EvaluateFormDTO.STATUS_ENABLE);
		// }
		model.setStatus(dto.getStatus());
		model.setFlag(dto.getFlag());
		// model.setCreateBy(this.getNowUser().getUsername());
		model.setUpdateBy(this.getNowUser().getUsername());
		// model.setGmtCreate(new Date());
		model.setGmtModified(new Date());

		this.evaluateFormDao.update(model);

		this.writeInfoLog("Update: " + model.toString());

	}

	/**
	 * 修改
	 * 
	 * @param dto
	 */
	@Override
	public void updateEvaluateForm(EvaluateFormDTO dto, EvaluateFormIndexDTO index) {
		Assert.hasText(dto.getId(), Assert.NULL_PARAM_STR("id"));

		EvaluateForm model = this.evaluateFormDao.getById(dto.getId());
		Assert.notNull(model, Assert.EMPTY_REOCRD_STR);

		model.setSortNo(dto.getSortNo());
		model.setFormName(dto.getFormName());
		model.setEngTypeCode(dto.getEngTypeCode());
		model.setFormType(dto.getFormType());
		model.setMemo(dto.getMemo());
		// if (dto.getStatus() == null || dto.getStatus() ==
		// EvaluateFormDTO.STATUS_DISABLE) {
		// model.setStatus(EvaluateFormDTO.STATUS_DISABLE);
		// } else {
		// // 清空其他启用状态
		// EvaluateForm entity = new EvaluateForm();
		// entity.setStatus(EvaluateFormDTO.STATUS_DISABLE);
		// entity.setUpdateBy(this.getNowUser().getUsername());
		// entity.setGmtModified(new Date());
		// entity.setEngTypeCode(dto.getEngTypeCode());
		// this.evaluateFormDao.updateStatus(entity);
		//
		// model.setStatus(EvaluateFormDTO.STATUS_ENABLE);
		// }
		model.setStatus(dto.getStatus());
		model.setFlag(dto.getFlag());
		// model.setCreateBy(this.getNowUser().getUsername());
		model.setUpdateBy(this.getNowUser().getUsername());
		// model.setGmtCreate(new Date());
		model.setGmtModified(new Date());

		this.evaluateFormDao.update(model);

		// 更新指标项
		index.setId(dto.getIndexId());
		index.setParentId(dto.getId());
		index.setLevel(EvaluateFormIndexDTO.LEVEL_START);
		this.evaluateFormIndexService.updateEvaluateFormIndex(index);

		this.writeInfoLog("Update: " + model.toString());

	}

	@Override
	@Deprecated
	public void publishEvaluateForm(String id) {
		EvaluateForm model = new EvaluateForm();
		model.setId(id);
		// model.setFlag(EvaluateFormDTO.FLAG_PUBLISHED);
		model.setUpdateBy(this.getNowUser().getUsername());
		model.setGmtModified(new Date());
		this.evaluateFormDao.updateSelective(model);
		this.writeInfoLog("Update: " + model.toString());
	}

	@Override
	@Deprecated
	public void enableEvaluateForm(String id, String engTypeCode) {
		// 清空其他启用状态
		EvaluateForm entity = new EvaluateForm();
		entity.setStatus(EvaluateFormDTO.STATUS_DISABLE);
		entity.setUpdateBy(this.getNowUser().getUsername());
		entity.setGmtModified(new Date());
		entity.setEngTypeCode(engTypeCode);
		this.evaluateFormDao.updateStatus(entity);

		EvaluateForm model = new EvaluateForm();
		model.setId(id);
		model.setStatus(EvaluateFormDTO.STATUS_ENABLE);
		model.setUpdateBy(this.getNowUser().getUsername());
		model.setGmtModified(new Date());
		this.evaluateFormDao.updateSelective(model);
		this.writeInfoLog("Update: " + model.toString());
	}

	/**
	 * 删除
	 * 
	 * @param ids
	 */
	@Override
	public void deleteEvaluateForms(String[] ids) {
		// for (int i = 0; i < ids.length; i++) {
		// this.evaluateFormDao.deleteById(ids[i]);
		// this.writeInfoLog("Delete id:" + ids[i]);
		// }

		if (ids == null || ids.length < 1) {
			return;
		}

		// 删除评分表格
		DataQuery dq = new DataQuery();
		dq.putToMap("ids", ids);
		this.deleteEvaluateFormsByCondition(dq);

		// 删除评分指标
		dq.clear();
		dq.putToMap("parentIds", ids);
		this.evaluateFormIndexService.deleteEvaluateFormIndexsByCondition(dq);

		// 删除评价记录 TODO
		dq.clear();
		dq.putToMap("formIds", ids);
		this.evaluateRecordService.deleteEvaluateRecordsByCondition(dq);
	}

	@Override
	public void deleteEvaluateFormsByCondition(DataQuery dq) {
		this.evaluateFormDao.deleteByCondition(dq.getQueryMap());
	}

	@Override
	public EvaluateFormDTO getFormByTypeName(String engTypeName) {
		// 根据工程类型名字获取工程类型
		DataQuery dq = new DataQuery();
		dq.putToMap("typeName", engTypeName);
		EngineeringTypeDTO engTypeDTO = this.engineeringTypeService.selectOneByCondition(dq);
		if (engTypeDTO == null) {
			return null;
		}

		// TODO
		// 根据工程类型代码获取启用的评分标准
		dq.clear();
		dq.putToMap("engTypeCode", engTypeDTO.getTypeCode());
		// dq.putToMap("status", EvaluateFormDTO.STATUS_ENABLE);
		EvaluateFormDTO dto = this.selectOneByCondition(dq);
		return dto;
	}

	@Override
	public List<ZtreeDTO> getEvaluateFormTreeData(String engTypeCode) {
		List<ZtreeDTO> resultList = new ArrayList<ZtreeDTO>();
		DataQuery dq = new DataQuery();
		dq.getQueryMap().put("engTypeCode", engTypeCode);
		List<EvaluateFormDTO> formList = this.evaluateFormDao.selectListByCondition(dq.getQueryMap());
		if (formList != null && formList.size() > 0) {
			for (EvaluateFormDTO formDTO : formList) {
				ZtreeDTO ztreeDTO = new ZtreeDTO();
				ztreeDTO.setId(formDTO.getId());
				ztreeDTO.setName(formDTO.getFormName());
				resultList.add(ztreeDTO);
			}
		}
		return resultList;
	}

}
