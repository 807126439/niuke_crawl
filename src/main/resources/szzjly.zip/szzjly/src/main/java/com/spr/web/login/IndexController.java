package com.spr.web.login;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.controller.BaseController;
import com.spr.core.spring.security.utils.SecurityPrincipalUtil;
import com.spr.web.evaluate.dto.record.EvaluateRecordDTO;
import com.spr.web.evaluate.service.IEvaluateRecordService;
import com.spr.web.file.service.IBaseFileService;
import com.spr.web.flow.entity.ExecNode;
import com.spr.web.flow.entity.ProcNode;
import com.spr.web.project.dto.part.ProjectPartInfoDTO;
import com.spr.web.project.dto.project.ProjectInfoDTO;
import com.spr.web.project.service.IProjectInfoService;
import com.spr.web.project.service.IProjectPartInfoService;
import com.spr.web.system.dto.engineering.EngineeringTypeDTO;
import com.spr.web.system.entity.Role;
import com.spr.web.system.service.IBaseDictService;
import com.spr.web.system.service.IEngineeringTypeService;
import com.spr.web.system.service.IUserService;

@Controller
@Scope("prototype")
public class IndexController extends BaseController {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2874105942311327743L;

	@Resource
	private IBaseFileService baseFileService;
	@Resource
	private IBaseDictService baseDictService;
	@Resource
	private IUserService userService;
	@Resource
	private IEvaluateRecordService evaluateRecordService;
	@Resource
	private IProjectInfoService projectInfoService;
	@Resource
	private IProjectPartInfoService projectPartInfoService;
	@Resource
	private IEngineeringTypeService engineeringTypeService;

	@RequestMapping(value = "/index", method = { RequestMethod.GET })
	public String index(HttpServletRequest request) {

		return "index/index.jsp";
	}

	@RequestMapping(value = "/home", method = { RequestMethod.GET })
	public String home(HttpServletRequest request) {
		String nowYear = new SimpleDateFormat("yyyy").format(new Date());
		request.setAttribute("nowYear", nowYear);
		request.setAttribute("lastYear", Integer.valueOf(nowYear) - 1);

		// // 获取待审核事项列表
		DataQuery dq = new DataQuery();
		dq.setNotQueryPage();
		// dq.setPageSize(5);
		// dq.setCurrentPage(1);
		// 节点为正在审核
		dq.getQueryMap().put("flowStatus", ExecNode.FLOW_STATUS_CURR);
		dq.getQueryMap().put("handlerOnly", this.getNowUser().getId());
		Page<EvaluateRecordDTO> pageResult = this.evaluateRecordService.searchByPageWithExec(dq);
		request.setAttribute("auditList", pageResult.getList());

		// 获取提醒查看列表
		dq.getQueryMap().clear();
		dq.setNotQueryPage();
		dq.getQueryMap().put("flowStatus", ExecNode.FLOW_STATUS_HISTORY);
		dq.getQueryMap().put("nodeType", ProcNode.TYPE_END);
		// 单位为当前单位
		dq.getQueryMap().put("targetUnitId", this.getNowUser().getUnitId());
		// 状态为未阅
		dq.getQueryMap().put("checked", EvaluateRecordDTO.CHECKED_FALSE);
		pageResult = this.evaluateRecordService.searchByPageWithExec(dq);
		request.setAttribute("alterList", pageResult.getList());

		// 获取异议反馈待回复列表
		dq.clear();
		dq.setNotQueryPage();
		dq.setSidx("gmtPlea");
		dq.setSord("asc");
		dq.putToMap("evalUserId", this.getNowUser().getId());
		dq.putToMap("formTypes", new String[] { EvaluateRecordDTO.FORM_TYPE_SEASON, EvaluateRecordDTO.FORM_TYPE_CONTRACT });
		dq.putToMap("status", EvaluateRecordDTO.STATUS_SUCCEED);
		dq.putToMap("pleaStatus", EvaluateRecordDTO.PLEA_STATUS_SUBMIT);
		List<EvaluateRecordDTO> toReplyList = this.evaluateRecordService.selectListByCondition(dq);
		request.setAttribute("toReplyList", toReplyList);

		// 获取所有工程类型
		dq.getQueryMap().clear();
		dq.setNotQueryPage();
		List<EngineeringTypeDTO> allType = this.engineeringTypeService.selectListByCondition(dq);
		request.setAttribute("allEngType", allType);

		dq.clear();
		// 预警提醒(未评价的项目)
		List<Map<String, Object>> notEvaluateProList = this.projectInfoService.getNotEvaluateProList();
		request.setAttribute("notEvaluateProList", notEvaluateProList);
		List<Map<String, Object>> notEvaluatePartList = this.projectPartInfoService.getNotEvaluatePartList();
		request.setAttribute("notEvaluatePartList", notEvaluatePartList);

		// 搜索栏类型
		Map<String, String> searchTypeMap = new LinkedHashMap<String, String>();
		if (SecurityPrincipalUtil.checkIsHasRole(Role.ROLE_CONSTRACTOR)) {
			// 当前账号角色为承包商
			searchTypeMap.put("projectPart", "合同");
		} else {
			// 当前账号角色为代建单位
			searchTypeMap.put("project", "项目");
			searchTypeMap.put("projectPart", "合同");
			searchTypeMap.put("contractor", "承包商");
		}
		request.setAttribute("searchTypeMap", searchTypeMap);
		return "index/homePage.jsp";
	}

	// ----------------- 首页检索 ------------------- //
	@RequestMapping(value = "/searchPage", method = { RequestMethod.GET })
	public String skipSearchPage(HttpServletRequest request, String keyWord, String searchType) {

		// 关键字转码
		if (StringUtils.isNotBlank(keyWord)) {
			try {
				request.setAttribute("keyWord", URLDecoder.decode(keyWord, "utf-8"));
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
		}

		String pageType = "";
		// 当前账号角色为建设单位
		if (SecurityPrincipalUtil.checkIsHasRole(Role.ROLE_BUILD_UNIT)) {
			request.setAttribute("buildUnitId", getNowUser().getUnitId());
			pageType = "buildUnit";
		} else if (SecurityPrincipalUtil.checkIsHasRole(Role.ROLE_AGENT_BUILD_UNIT)) {
			// 当前账号角色为代建单位
			request.setAttribute("agentUnitId", getNowUser().getUnitId());
			pageType = "agentUnit";
		} else if (SecurityPrincipalUtil.checkIsHasRole(Role.ROLE_HOUSING)) {
			// 当前账号角色为住建局
			request.setAttribute("agentUnitId", getNowUser().getUnitId());
			pageType = "adminUnit";
		} else if (SecurityPrincipalUtil.checkIsHasRole(Role.ROLE_CONSTRACTOR)) {
			// 当前账号角色为承包商
			request.setAttribute("contractorUnitId", getNowUser().getUnitId());
		}
		request.setAttribute("pageType", pageType);

		// 不同搜索类型跳转对应页面
		if ("project".equals(searchType)) {
			request.setAttribute("TITLE", "综合查询(项目)");
			return "index/search/projectInfoList.jsp";
		}

		if ("projectPart".equals(searchType)) {
			request.setAttribute("TITLE", "综合查询(工程)");
			request.setAttribute("enterWay", "home");
			return "index/search/projectPartInfoList.jsp";
		}

		if ("contractor".equals(searchType)) {
			request.setAttribute("TITLE", "综合查询(承包商)");
			request.setAttribute("enterWay", "home");
			return "index/search/evaluateAvgScoreList.jsp";
		}

		return null;
	}

	/**
	 * 首页查询的项目列表进入工程列表
	 */
	@RequestMapping(value = "/index/viewProjectPart", method = { RequestMethod.GET })
	public String skipViewProjectPartPage(HttpServletRequest request, String proId) {
		ProjectInfoDTO proInfo = this.projectInfoService.getDetailById(proId);
		request.setAttribute("proName", proInfo.getProName());
		request.setAttribute("proId", proId);
		request.setAttribute("enterWay", "project");
		request.setAttribute("TITLE", "综合查询(工程)");
		return "index/search/projectPartInfoList.jsp";
	}

	@RequestMapping(value = "/index/getProjectPartPageData", method = { RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> getProjectPartPageData(HttpServletRequest request, DataQuery dq, String partName, String proId, String buildUnitId,
			String agentUnitId, String contractorUnitId) {
		this.wrapTableQueryParams(request, dq);
		dq.getQueryMap().put("proId", proId);
		dq.getQueryMap().put("buildUnitId", StringUtils.isNotBlank(buildUnitId) ? buildUnitId : null);
		dq.getQueryMap().put("agentUnitId", StringUtils.isNotBlank(agentUnitId) ? agentUnitId : null);
		dq.getQueryMap().put("contractorUnitId", StringUtils.isNotBlank(contractorUnitId) ? contractorUnitId : null);
		dq.getQueryMap().put("partName", StringUtils.isNotBlank(partName) ? "%" + partName + "%" : null);
		Page<ProjectPartInfoDTO> pageResult = this.projectPartInfoService.searchByPage(dq);
		return this.handlePageReult(pageResult);
	}
}
