package com.spr.web.flow.service;

import net.sf.json.JSONObject;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.web.flow.dto.def.ProcNodeDTO;

public interface IProcNodeService {

	Page<ProcNodeDTO> searchByPage(DataQuery dq);

	ProcNodeDTO getDetailById(String id);

	void addProcNode(ProcNodeDTO dto);

	void updateProcNode(ProcNodeDTO dto);

	void deleteProcNodes(String[] ids);

	JSONObject getProcessData(String procDefId, Long checkUserId);

	void addProcess(String data, String procDefId);

	ProcNodeDTO getNextNode(ProcNodeDTO currNode);

}
