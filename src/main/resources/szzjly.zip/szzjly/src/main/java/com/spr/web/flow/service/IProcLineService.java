package com.spr.web.flow.service;

import com.spr.web.flow.dto.def.ProcLineDTO;
import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;

public interface IProcLineService {

	 Page<ProcLineDTO> searchByPage(DataQuery dq);
	
	 ProcLineDTO getDetailById(String id);
	
	 void addProcLine(ProcLineDTO dto);
	
	 void updateProcLine(ProcLineDTO dto);
	
	 void deleteProcLines(String[] ids);

}
