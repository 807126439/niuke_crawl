package com.spr.web.system.service;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.web.system.dto.iconConfig.IconConfigDTO;

public interface IIconConfigService {

	List<IconConfigDTO> selectListByCondition(DataQuery dq);

	Page<IconConfigDTO> searchByPage(DataQuery dq);

	void deleteIconConfigs(String[] ids);

	/**
	 * 添加新图标
	 */
	void addIconConfig(Short iconType, CommonsMultipartFile file);

	/**
	 * 获取分类图标列表
	 */
	Map<String, List<IconConfigDTO>> getIconList();

}
