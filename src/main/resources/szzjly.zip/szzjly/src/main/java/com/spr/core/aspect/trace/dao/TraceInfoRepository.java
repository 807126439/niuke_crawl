/**
 * 
 */
package com.spr.core.aspect.trace.dao;

import com.spr.core.aspect.trace.entity.TraceInfo;
import com.spr.core.common.dao.IBaseDao;

/**
 * @date 2019-4-28
 * @author wanve_java_cjy
 *
 */
public interface TraceInfoRepository extends IBaseDao<String, TraceInfo> {

}
