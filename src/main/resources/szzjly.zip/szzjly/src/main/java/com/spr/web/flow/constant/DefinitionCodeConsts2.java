package com.spr.web.flow.constant;

import java.util.ArrayList;
import java.util.List;

/**
 * 流程定义码
 * 
 * @author wb_java_zjr
 * 
 */
public enum DefinitionCodeConsts2 {
	run_abnormal_receipts("run_abnormal_receipts", "收费异常登记"), run_take_monitor("run_take_monitor", "调取监控审批"), run_waste_transfer("run_waste_transfer", "废旧资产管理");

	String code;
	String title;

	DefinitionCodeConsts2(String code, String title) {
		this.code = code;
		this.title = title;
	}

	public String code() {
		return this.code;
	}

	public String title() {
		return this.title;
	}

	public static List<DefinitionCodeConsts2> codes = new ArrayList<DefinitionCodeConsts2>();

	static {
		codes.add(run_abnormal_receipts);
		codes.add(run_take_monitor);
		codes.add(run_waste_transfer);

	}
}
