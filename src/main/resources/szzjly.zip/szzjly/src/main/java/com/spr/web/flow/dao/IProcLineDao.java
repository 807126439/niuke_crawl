package com.spr.web.flow.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.spr.core.common.dao.IBaseDao;
import com.spr.web.flow.dto.def.ProcLineDTO;
import com.spr.web.flow.entity.ProcLine;

public interface IProcLineDao extends IBaseDao<String, ProcLine> {

	Long countByCondition(Map<String, Object> queryMap);

	List<ProcLineDTO> selectListByCondition(Map<String, Object> queryMap);

	ProcLineDTO getDetailById(String id);

	List<ProcLine> getByProcDefId(String procDefId);

	List<String> getIdByProcDefId(String procDefId);

	int deleteByIds(@Param("ids") List<String> ids);

	int deleteByProcDefId(String procDefId);
}