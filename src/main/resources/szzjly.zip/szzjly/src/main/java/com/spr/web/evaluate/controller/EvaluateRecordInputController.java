package com.spr.web.evaluate.controller;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spr.core.common.bean.AjaxJson;
import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.controller.BaseController;
import com.spr.web.evaluate.dto.form.EvaluateFormIndexDTO;
import com.spr.web.evaluate.dto.record.EvaluateRecordIndexDTO;
import com.spr.web.evaluate.dto.record.EvaluateRecordInputDTO;
import com.spr.web.evaluate.service.IEvaluateRecordIndexService;
import com.spr.web.evaluate.service.IEvaluateRecordInputService;

@Controller
@Scope("prototype")
@RequestMapping("/evaluateRecordInputController")
public class EvaluateRecordInputController extends BaseController{

	private static final long serialVersionUID = 1L;
	
	@Resource
	private IEvaluateRecordInputService evaluateRecordInputService;
	@Resource
	private IEvaluateRecordIndexService evaluateRecordIndexService;		
	
	@RequestMapping(value="/viewPage",method={RequestMethod.GET})
	public String viewPage(HttpServletRequest request){
		this.wrapMenuTitle(request);
		
		return "evaluate/evaluateRecordInput/evaluateRecordInputList.jsp";
	}
	
	
	@RequestMapping(value="/getPageData",method={RequestMethod.POST})
	@ResponseBody
	public Map<String, Object> loadPageData(HttpServletRequest request,DataQuery dq){

		this.wrapTableQueryParams(request, dq);
				
		Page<EvaluateRecordInputDTO> pageResult = this.evaluateRecordInputService.searchByPage(dq);
		 
		return this.handlePageReult(pageResult);
	}
	
	
	@RequestMapping(value="/skipAddEvaluateRecordInput")
	public String skipAddEvaluateRecordInput(HttpServletRequest request){
		
		
		return "evaluate/evaluateRecordInput/addEvaluateRecordInput.jsp";
	}
	
	
	@RequestMapping(value="/addEvaluateRecordInput",method={RequestMethod.POST})
	@ResponseBody
	public AjaxJson addEvaluateRecordInput(EvaluateRecordInputDTO dto) throws Exception{
	
		this.evaluateRecordInputService.addEvaluateRecordInput(dto);
		
		
		return new AjaxJson(this.ADD_SUCCESS_MESSAGE, AjaxJson.success);
	}
	
	
	@RequestMapping("/getDetail")
	public String loadDetail(HttpServletRequest request,@RequestParam(value="id",required=true)String id){
			  		
	    EvaluateRecordInputDTO result = this.evaluateRecordInputService.getDetailById(id);
		request.setAttribute("model", result);
		
	
		return "evaluate/evaluateRecordInput/editEvaluateRecordInput.jsp";
	}
	
	
	@RequestMapping(value="/editEvaluateRecordInput",method={RequestMethod.POST})
	@ResponseBody
	public AjaxJson updateEvaluateRecordInput(EvaluateRecordInputDTO dto){
		
		this.evaluateRecordInputService.updateEvaluateRecordInput(dto);
				
		return new AjaxJson(this.EDIT_SUCCESS_MESSAGE, AjaxJson.success);
	}
	
	
	@RequestMapping(value="/deleteEvaluateRecordInput",method={RequestMethod.POST})
	@ResponseBody
	public AjaxJson deleteEvaluateRecordInput(String[] ids){
		
		this.evaluateRecordInputService.deleteEvaluateRecordInputs(ids);
		
		
		return new AjaxJson(this.DEL_SUCCESS_MESSAGE, AjaxJson.success);
	}
	
	// 异步加载评分指标
	@RequestMapping(value="/getIndex",method={RequestMethod.POST})
	@ResponseBody
	public AjaxJson getIndex(DataQuery dq, @RequestParam String parentId, @RequestParam String evalId){
		dq.setNotQueryPage();
		dq.putToMap("evalId", evalId);
		Map<String, BigDecimal> indexInputMap = this.evaluateRecordInputService.selectIndexInputMapByCondition(dq);
		Map<String, EvaluateRecordIndexDTO> originModelMap = this.evaluateRecordIndexService.selectOriginModelMapByCondition(dq);
		
		List<EvaluateFormIndexDTO> list = this.evaluateRecordInputService.getSubIndexList(dq, parentId, indexInputMap, originModelMap);
		return new AjaxJson("加载成功", AjaxJson.success, list);
	}
	
}
