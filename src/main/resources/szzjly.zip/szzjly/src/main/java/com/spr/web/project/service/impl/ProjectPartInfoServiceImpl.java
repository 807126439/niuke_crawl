package com.spr.web.project.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.core.common.exception.BusinessException;
import com.spr.core.common.service.BaseService;
import com.spr.core.common.utils.Assert;
import com.spr.core.gobal.GobalVal;
import com.spr.core.spring.security.utils.SecurityPrincipalUtil;
import com.spr.web.evaluate.dao.IEvaluateRecordDao;
import com.spr.web.evaluate.dto.record.EvaluateRecordDTO;
import com.spr.web.evaluate.service.IEvaluateTimeSettingService;
import com.spr.web.project.dao.IProjectPartInfoDao;
import com.spr.web.project.dto.part.ProjectPartInfoDTO;
import com.spr.web.project.entity.ProjectPartInfo;
import com.spr.web.project.service.IProjectPartInfoService;
import com.spr.web.system.dto.engineering.EngineeringTypeDTO;
import com.spr.web.system.entity.Role;
import com.spr.web.system.service.IEngineeringTypeService;
import com.spr.web.system.service.IUnitService;

@Service("projectPartInfoService")
@Transactional
public class ProjectPartInfoServiceImpl extends BaseService implements IProjectPartInfoService {

	@Resource
	private IProjectPartInfoDao projectPartInfoDao;
	@Resource
	private IUnitService unitService;
	@Resource
	private IEngineeringTypeService engineeringTypeService;
	@Resource
	private IEvaluateRecordDao evaluateRecordDao;
	@Resource
	private IEvaluateTimeSettingService evaluateTimeSettingService;

	@Override
	public Map<String, String> selectIdNameMapByCondition(DataQuery dq) {
		List<ProjectPartInfoDTO> list = this.selectListByCondition(dq);

		Map<String, String> map = new HashMap<String, String>();
		for (ProjectPartInfoDTO dto : list) {
			map.put(dto.getId(), dto.getPartName());
		}
		return map;
	}

	@Override
	public List<ProjectPartInfoDTO> selectListByCondition(DataQuery dq) {
		dq.assemblePageOffset();
		dq.assembleOrderInfo(ProjectPartInfo.class, null);
		List<ProjectPartInfoDTO> resultlist = this.projectPartInfoDao.selectListByCondition(dq.getQueryMap());

		return resultlist;
	}

	/**
	 * 分页查询
	 * 
	 * @param dq
	 */
	@Override
	public Page<ProjectPartInfoDTO> searchByPage(DataQuery dq) {

		Long recTotal = this.projectPartInfoDao.countByCondition(dq.assemblePageOffset().getQueryMap());
		dq.assembleOrderInfo(ProjectPartInfo.class, null);
		List<ProjectPartInfoDTO> resultlist = this.projectPartInfoDao.selectListByCondition(dq.getQueryMap());

		if (resultlist != null && !resultlist.isEmpty()) {

			DataQuery newDq = new DataQuery();
			newDq.getQueryMap().put("status", GobalVal.STATUS_ENABLE);
			List<EngineeringTypeDTO> engineeringTypeList = this.engineeringTypeService.selectListByCondition(newDq);

			if (engineeringTypeList != null && !engineeringTypeList.isEmpty()) {
				for (ProjectPartInfoDTO partInfoDTO : resultlist) {
					for (EngineeringTypeDTO typeDTO : engineeringTypeList) {
						if (StringUtils.isNotBlank(partInfoDTO.getEngTypeCode()) && partInfoDTO.getEngTypeCode().equals(typeDTO.getTypeCode())) {
							partInfoDTO.setEngTypeName(typeDTO.getTypeName());
						}
					}
				}
			}

		}

		return new Page<ProjectPartInfoDTO>(dq.getCurrentPage(), dq.getPageSize(), resultlist, recTotal);
	}

	/**
	 * 查询详细
	 * 
	 * @param id
	 */
	@Override
	public ProjectPartInfoDTO getDetailById(String id) {
		Assert.hasText(id, Assert.NULL_PARAM_STR("id"));

		ProjectPartInfoDTO result = this.projectPartInfoDao.getDetailById(id);
		Assert.notNull(result, Assert.EMPTY_REOCRD_STR);

		return result;
	}

	/**
	 * 添加
	 * 
	 * @param dto
	 */
	@Override
	public void addProjectPartInfo(ProjectPartInfoDTO dto) {
		Assert.hasText(dto.getPartName(), "请填写工程名称");
		Assert.hasText(dto.getContractorUnitId(), "请选择承包商");

		ProjectPartInfo model = new ProjectPartInfo();
		model.setProId(dto.getProId());
		model.setPartName(dto.getPartName());
		model.setPartNo(dto.getPartNo());
		model.setPartAddress(dto.getPartAddress());
		model.setPartAmount(dto.getPartAmount());
		model.setEngTypeCode(dto.getEngTypeCode());
		model.setContractorUnitId(dto.getContractorUnitId());
		model.setGmtSigned(dto.getGmtSigned());
		model.setLinkMan(dto.getLinkMan());
		model.setLinkTel(dto.getLinkTel());
		model.setRegisterTime(dto.getRegisterTime());
		model.setStartTime(dto.getStartTime());
		model.setEndTime(dto.getEndTime());
		model.setMemo(dto.getMemo());
		model.setEvaluateStatus(GobalVal.EVALUATE_NOT_END);
		model.setStatus(GobalVal.STATUS_ENABLE);
		model.setFlag(GobalVal.NORMAL_FLAG);
		model.setCreateBy(this.getNowUser().getUsername());
		model.setProjectManager(dto.getProjectManager());
		model.setSupervisionDirector(dto.getSupervisionDirector());
		model.setMasterMan(dto.getMasterMan());

		this.projectPartInfoDao.insert(model);

		this.writeInfoLog("Add: " + model.toString());

	}

	/**
	 * 修改
	 * 
	 * @param dto
	 */
	@Override
	public void updateProjectPartInfo(ProjectPartInfoDTO dto) {
		Assert.hasText(dto.getPartName(), "请填写工程名称");
		Assert.hasText(dto.getContractorUnitId(), "请选择承包商");
		Assert.hasText(dto.getId(), Assert.NULL_PARAM_STR("id"));

		ProjectPartInfo model = this.projectPartInfoDao.getById(dto.getId());
		Assert.notNull(model, Assert.EMPTY_REOCRD_STR);

		model.setPartName(dto.getPartName());
		model.setPartNo(dto.getPartNo());
		model.setPartAddress(dto.getPartAddress());
		model.setPartAmount(dto.getPartAmount());
		model.setEngTypeCode(dto.getEngTypeCode());
		model.setContractorUnitId(dto.getContractorUnitId());
		model.setGmtSigned(dto.getGmtSigned());
		model.setLinkMan(dto.getLinkMan());
		model.setLinkTel(dto.getLinkTel());
		model.setRegisterTime(dto.getRegisterTime());
		model.setStartTime(dto.getStartTime());
		model.setEndTime(dto.getEndTime());
		model.setMemo(dto.getMemo());
		model.setUpdateBy(this.getNowUser().getUsername());
		model.setGmtModified(new Date());
		model.setProjectManager(dto.getProjectManager());
		model.setSupervisionDirector(dto.getSupervisionDirector());
		model.setMasterMan(dto.getMasterMan());

		this.projectPartInfoDao.update(model);

		this.writeInfoLog("Update: " + model.toString());

	}

	/**
	 * 删除
	 * 
	 * @param ids
	 */
	@Override
	public void deleteProjectPartInfos(String[] ids) {
		for (int i = 0; i < ids.length; i++) {

			DataQuery dq = new DataQuery();
			// 代建项目
			// 查询是否有评价记录
			dq.putToMap("partId", ids[i]);
			dq.putToMap("flag", EvaluateRecordDTO.FLAG_ARCHIVED);
			Long num = this.evaluateRecordDao.countByCondition(dq.getQueryMap());
			if (num > 0) {
				throw new BusinessException("该合同已进行履约评价,无法删除");
			}

			this.projectPartInfoDao.deleteById(ids[i]);

			this.writeInfoLog("Delete id:" + ids[i]);

		}
	}

	@Override
	public String[] getDjPartInfoIds(String unitId) {
		// TODO
		return null;
	}

	@Override
	public void setProjectPartEvaluateStatus(String partId, Short evaluateStatus) {
		Assert.hasText(partId, "proId null error");
		ProjectPartInfo projectPartInfo = this.projectPartInfoDao.getById(partId);
		projectPartInfo.setEvaluateStatus(evaluateStatus);
		projectPartInfo.setUpdateBy(getNowUser().getUsername());
		projectPartInfo.setGmtModified(new Date());
		this.projectPartInfoDao.update(projectPartInfo);
	}

	@Override
	public Boolean isProjectPartEvaluateStatusFinished(String partId) {
		Assert.hasText(partId, "proId null error");
		ProjectPartInfo projectPartInfo = this.projectPartInfoDao.getById(partId);
		if (projectPartInfo.getEvaluateStatus() == GobalVal.EVALUATE_END) {
			return true;
		}
		return false;
	}

	@Override
	public List<Map<String, Object>> getNotEvaluatePartList() {
		List<Map<String, Object>> resultList = new ArrayList<Map<String, Object>>();

		// 查询当前单位是否已经对项目进行评价
		Map<String, Object> queryMap = new HashMap<String, Object>();
		queryMap.put("evalUnitId", getNowUser().getUnitId());

		if (SecurityPrincipalUtil.checkIsHasRole(Role.ROLE_BUILD_UNIT)) {
			queryMap.put("buildUnitId", getNowUser().getUnitId());
		} else if (SecurityPrincipalUtil.checkIsHasRole(Role.ROLE_AGENT_BUILD_UNIT)) {
			queryMap.put("agentUnitId", getNowUser().getUnitId());
		}

		// 查询未评价项目(合同评价)
		queryMap.put("formType", EvaluateRecordDTO.FORM_TYPE_CONTRACT);
		List<Map<String, Object>> proList = this.projectPartInfoDao.selectNotEvaluateList(queryMap);
		// 查询未评价项目(履约评价)
		Map<String, Date> timeMap = this.evaluateTimeSettingService.getSeasonEvaluateTime();
		if (timeMap != null && !timeMap.isEmpty()) {
			queryMap.put("evalBeginTime", timeMap.get("beginTime"));
			queryMap.put("evalEndTime", timeMap.get("endTime"));
			queryMap.put("formType", EvaluateRecordDTO.FORM_TYPE_SEASON);
			List<Map<String, Object>> partList = this.projectPartInfoDao.selectNotEvaluateList(queryMap);
			resultList.addAll(partList);
		}
		resultList.addAll(proList);

		return resultList;
	}
}
