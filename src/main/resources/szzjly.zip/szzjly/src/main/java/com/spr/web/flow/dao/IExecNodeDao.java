package com.spr.web.flow.dao;

import java.util.List;
import java.util.Map;

import com.spr.core.common.dao.IBaseDao;
import com.spr.web.flow.dto.exec.ExecNodeDTO;
import com.spr.web.flow.entity.ExecNode;

public interface IExecNodeDao extends IBaseDao<String, ExecNode> {

	Long countByCondition(Map<String, Object> queryMap);

	List<ExecNodeDTO> selectListByCondition(Map<String, Object> queryMap);

	ExecNodeDTO getDetailById(String id);

	List<ExecNode> getNextNodeByPreNodeId(String preNodeId);

	List<ExecNode> getPreNodeByNextNodeId(String preNodeId);

	int deleteByProcInstId(String procInstId);

	ExecNodeDTO getDetailByCondition(Map<String, Object> queryMap);

	void updateAllByCondition(Map<String, Object> queryMap);

}