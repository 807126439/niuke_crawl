package com.spr.web.project.service;

import java.util.List;
import java.util.Map;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.web.project.dto.part.ProjectPartInfoDTO;

public interface IProjectPartInfoService {

	Map<String, String> selectIdNameMapByCondition(DataQuery dq);

	List<ProjectPartInfoDTO> selectListByCondition(DataQuery dq);

	Page<ProjectPartInfoDTO> searchByPage(DataQuery dq);

	ProjectPartInfoDTO getDetailById(String id);

	void addProjectPartInfo(ProjectPartInfoDTO dto);

	void updateProjectPartInfo(ProjectPartInfoDTO dto);

	void deleteProjectPartInfos(String[] ids);

	/**
	 * 获取代建单位负责所有工程id
	 * 
	 * @param dq
	 * @return
	 * @date 2019-2-27
	 * @author wanve_java_cjy
	 */
	String[] getDjPartInfoIds(String unitId);

	/**
	 * 将工程的评价状态设置为完成
	 * 
	 * @param partId
	 */
	void setProjectPartEvaluateStatus(String partId, Short evaluateStatus);

	/**
	 * 判断工程评价状态是否完成(true:完成,false:未完成)
	 * 
	 * @param partId
	 * @return
	 */
	Boolean isProjectPartEvaluateStatusFinished(String partId);

	List<Map<String, Object>> getNotEvaluatePartList();
}
