package com.spr.web.flow.service;

import java.util.List;

import com.spr.core.common.bean.DataQuery;
import com.spr.core.common.bean.Page;
import com.spr.web.flow.dto.def.ProcIdentitylinkDTO;
import com.spr.web.system.dto.user.WeiUserDTO;

public interface IProcIdentitylinkService {

	List<WeiUserDTO> getUsersByNodeId(String nodeId);

	Page<ProcIdentitylinkDTO> searchByPage(DataQuery dq);

	ProcIdentitylinkDTO getDetailById(String id);

	void addProcIdentitylink(ProcIdentitylinkDTO dto);

	void updateProcIdentitylink(ProcIdentitylinkDTO dto);

	void deleteProcIdentitylinks(String[] ids);

	List<WeiUserDTO> getNodeAfterStartUser(String processCode);

}
