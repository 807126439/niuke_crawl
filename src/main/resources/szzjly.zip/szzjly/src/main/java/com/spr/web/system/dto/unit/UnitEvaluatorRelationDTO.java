package com.spr.web.system.dto.unit;

import com.spr.core.common.dto.UUIDDTO;

public class UnitEvaluatorRelationDTO extends UUIDDTO {

    private Integer sortNo;

    private String unitId;

    private String userId;

    private Short singleStatus;

    private Short status;

    private String createBy;

    private String updateBy;

    public Integer getSortNo() {
        return sortNo;
    }

    public void setSortNo(Integer sortNo) {
        this.sortNo = sortNo;
    }

    public String getUnitId() {
        return unitId;
    }

    public void setUnitId(String unitId) {
        this.unitId = unitId == null ? null : unitId.trim();
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId == null ? null : userId.trim();
    }

    public Short getSingleStatus() {
        return singleStatus;
    }

    public void setSingleStatus(Short singleStatus) {
        this.singleStatus = singleStatus;
    }

    public Short getStatus() {
        return status;
    }

    public void setStatus(Short status) {
        this.status = status;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }
}