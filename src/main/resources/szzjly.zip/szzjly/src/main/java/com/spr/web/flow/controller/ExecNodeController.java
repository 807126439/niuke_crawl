package com.spr.web.flow.controller;

import java.util.Arrays;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spr.core.common.bean.AjaxJson;
import com.spr.core.common.controller.BaseController;
import com.spr.web.flow.dto.exec.ExecNodeDTO;
import com.spr.web.flow.service.IExecNodeService;

@Controller
@Scope("prototype")
@RequestMapping("/execNodeController")
public class ExecNodeController extends BaseController {

	private static final long serialVersionUID = 1L;

	@Resource
	private IExecNodeService execNodeService;

	@RequestMapping(value = "/getStraightStructureProccess", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson getStraightStructureProccess(String procInstId) throws Exception {

		List<ExecNodeDTO> nodes = this.execNodeService.getStraightStructureProccess(procInstId, getNowUser().getId());

		return new AjaxJson("success", AjaxJson.success, nodes);
	}

	@RequestMapping(value = "/handleSuccessNode", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson handleSuccessNode(String procNodeId, String content, String allotUserIds) throws Exception {

		this.execNodeService.handleSuccessNode(procNodeId, content, getNowUser().getId(),
				StringUtils.isBlank(allotUserIds) ? null : Arrays.asList(allotUserIds.split(",")));

		return new AjaxJson(this.OPER_SUCCESS_MESSAGE, AjaxJson.success);
	}

	@RequestMapping(value = "/handleFailNode", method = { RequestMethod.POST })
	@ResponseBody
	public AjaxJson handleFailNode(String procNodeId, String content) throws Exception {

		this.execNodeService.handleFailNode(procNodeId, getNowUser().getId(), content);

		return new AjaxJson(this.OPER_SUCCESS_MESSAGE, AjaxJson.success);
	}

	// @RequestMapping(value = "/viewPage", method = { RequestMethod.GET })
	// public String viewPage(HttpServletRequest request) {
	// this.wrapMenuTitle(request);
	//
	// return "flow/execNode/execNodeList.jsp";
	// }
	//
	// @RequestMapping(value = "/getPageData", method = { RequestMethod.POST })
	// @ResponseBody
	// public Map<String, Object> loadPageData(HttpServletRequest request,
	// DataQuery dq) {
	//
	// this.wrapTableQueryParams(request, dq);
	//
	// Page<ExecNodeDTO> pageResult = this.execNodeService.searchByPage(dq);
	//
	// return this.handlePageReult(pageResult);
	// }
	//
	// @RequestMapping(value = "/skipAddExecNode")
	// public String skipAddExecNode(HttpServletRequest request) {
	//
	// return "flow/execNode/addExecNode.jsp";
	// }
	//
	// @RequestMapping(value = "/addExecNode", method = { RequestMethod.POST })
	// @ResponseBody
	// public AjaxJson addExecNode(ExecNodeDTO dto) throws Exception {
	//
	// this.execNodeService.addExecNode(dto);
	//
	// return new AjaxJson(this.ADD_SUCCESS_MESSAGE, AjaxJson.success);
	// }
	//
	// @RequestMapping("/getDetail")
	// public String loadDetail(HttpServletRequest request, @RequestParam(value
	// = "id", required = true) String id) {
	//
	// ExecNodeDTO result = this.execNodeService.getDetailById(id);
	// request.setAttribute("model", result);
	//
	// return "flow/execNode/editExecNode.jsp";
	// }
	//
	// @RequestMapping(value = "/editExecNode", method = { RequestMethod.POST })
	// @ResponseBody
	// public AjaxJson updateExecNode(ExecNodeDTO dto) {
	//
	// this.execNodeService.updateExecNode(dto);
	//
	// return new AjaxJson(this.EDIT_SUCCESS_MESSAGE, AjaxJson.success);
	// }
	//
	// @RequestMapping(value = "/deleteExecNode", method = { RequestMethod.POST
	// })
	// @ResponseBody
	// public AjaxJson deleteExecNode(String[] ids) {
	//
	// this.execNodeService.deleteExecNodes(ids);
	//
	// return new AjaxJson(this.DEL_SUCCESS_MESSAGE, AjaxJson.success);
	// }

}
