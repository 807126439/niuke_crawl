package com.zxh.crawlerdisplay.config;

import org.mybatis.spring.boot.autoconfigure.MybatisProperties;

//@Configuration
//@ImportResource("classpath:mybatis-config.xml")
public class MybatisConfig  {


}
