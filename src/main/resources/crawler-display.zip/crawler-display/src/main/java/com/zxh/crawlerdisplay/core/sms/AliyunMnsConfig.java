package com.zxh.crawlerdisplay.core.sms;

public class AliyunMnsConfig {

	// TODO 此处需要替换成开发者自己的AK(在阿里云访问控制台寻找)
	public static final String accesskeyid = "LTAIq6qPkySqM5r3";
	public static final String accesskeysecret = "6UlLfcA25czRFDGtMZ824ojUeTp9mp";
	public static final String accountendpoint = "https://1510195432743947.mns.cn-shenzhen.aliyuncs.com/";

}
