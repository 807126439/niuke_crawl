package com.zxh.crawlerdisplay.core.spring.mvc;

public interface IAccessCheck {

	void refreshWhiteDomain();

}
