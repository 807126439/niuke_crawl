package com.zxh.crawlerdisplay.core.common.dao;

public interface IDaoSupport {

}
