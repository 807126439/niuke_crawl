package com.zxh.crawlerdisplay.core.sms.templeate;

public class TempleateCode {

	public static final String PROJECT_lONGIN_CODE = "SMS_90995034";

}
