package com.zxh.crawlerdisplay.web.file.dto.baseFile;

public class DownFileDTO {

	
	
}
