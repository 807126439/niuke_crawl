package com.zxh.crawlerdisplay.core.dobbo.config.spring;


/**
 * @author wb_java_zjr
 * @create 2017-03-03 15:04
 */
public class Consumer {

	public static void main(String[] args) throws Exception {
		// ClassPathXmlApplicationContext context = new
		// ClassPathXmlApplicationContext(new String[]
		// {"classpath*:consumer.xml"});
		// context.start();
		//
		// DemoService demoService =
		// (DemoService)context.getBean("demoService"); // 获取远程服务代理
		// String hello = demoService.sayHello("world5555"); // 执行远程方法
		//
		// System.out.println( hello ); // 显示调用结果
		//
		// System.in.read();
	}

}
