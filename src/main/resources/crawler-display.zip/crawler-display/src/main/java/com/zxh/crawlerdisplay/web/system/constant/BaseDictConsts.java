package com.zxh.crawlerdisplay.web.system.constant;

public class BaseDictConsts {

    public static final String ICON_TYPE = "icon_type"; // 图标类型
}
