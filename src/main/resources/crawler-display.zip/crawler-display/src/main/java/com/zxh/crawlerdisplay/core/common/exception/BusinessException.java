package com.zxh.crawlerdisplay.core.common.exception;

public class BusinessException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1995086494272094317L;

	public BusinessException(String msg){
		super(msg);
	}
	
	
}
