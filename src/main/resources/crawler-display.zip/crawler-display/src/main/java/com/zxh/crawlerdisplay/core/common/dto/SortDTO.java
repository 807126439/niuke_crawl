package com.zxh.crawlerdisplay.core.common.dto;



public class SortDTO{

	private String id;
	private Long sort;


	
	
	

	

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Long getSort() {
		return sort;
	}

	public void setSort(Long sort) {
		this.sort = sort;
	}
	
	

	
}
